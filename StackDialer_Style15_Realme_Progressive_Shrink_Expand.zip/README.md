StackDialer - Style 15 Realme UI bottom graduated stack (Theme 3)

Changes in this update:
- Only Style 15 (realme-notification-flow) is modified.
- Bottom-most card narrows to 76% width, next to 86%, third to 94%; every card above remains full width.
- Width transitions are continuous while cards enter the bottom stack.
- Style 15 background and card surface use the iOS 18 Theme 3 gold palette.
- Card layout/content and other styles are preserved.

ZIP integrity checked. Flutter build and device animation have not been tested.
