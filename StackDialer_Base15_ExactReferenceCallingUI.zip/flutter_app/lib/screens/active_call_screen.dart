import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/call_record.dart';
import '../services/blocked_numbers_service.dart';
import '../services/telecom_service.dart';

enum CallUIState {
  ringing, // Incoming Call UI
  dialing, // Outgoing Call UI
  active,  // Connected in-call
  holding, // On Hold
  ended,   // Call Ended Summary
}

class ActiveCallScreen extends StatefulWidget {
  final String phoneNumber;
  final String? contactName;
  final String? callerCategory;
  final int simSlot;
  final bool isIncoming;
  final Function(CallRecord completedCall)? onCallEnded;

  const ActiveCallScreen({
    super.key,
    required this.phoneNumber,
    this.contactName,
    this.callerCategory,
    this.simSlot = 1,
    this.isIncoming = false,
    this.onCallEnded,
  });

  @override
  State<ActiveCallScreen> createState() => _ActiveCallScreenState();
}

class _ActiveCallScreenState extends State<ActiveCallScreen>
    with SingleTickerProviderStateMixin {
  late CallUIState _state;
  bool _isMuted = false;
  bool _isSpeaker = false;
  bool _isOnHold = false;
  bool _isRecording = false;
  bool _showDtmfPad = false;
  String _dtmfHistory = '';
  String _callNote = '';
  int _durationSeconds = 0;
  Timer? _callTimer;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _state = widget.isIncoming ? CallUIState.ringing : CallUIState.dialing;

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.1).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    // Initial check for real speaker status
    TelecomService.isSpeakerOn().then((on) {
      if (mounted && on != _isSpeaker) {
        setState(() => _isSpeaker = on);
      }
    });

    // Listen to real Android InCallService native call state events
    TelecomService.setupCallListener((number, nativeState) {
      if (!mounted) return;
      if (nativeState == 'ACTIVE' && _state != CallUIState.active) {
        _transitionToActive();
      } else if (nativeState == 'HOLDING') {
        setState(() {
          _isOnHold = true;
          _state = CallUIState.holding;
        });
      } else if (nativeState == 'DISCONNECTED') {
        _endCall();
      }
    });

    // Listen for confirmed Android audio route changes (earpiece / speaker / bluetooth)
    TelecomService.setupAudioRouteListener((isSpeaker, isMuted) {
      if (!mounted) return;
      setState(() {
        _isSpeaker = isSpeaker;
        _isMuted = isMuted;
      });
    });
  }

  void _transitionToActive() {
    HapticFeedback.heavyImpact();
    setState(() {
      _state = CallUIState.active;
    });
    _startTimer();
  }

  void _startTimer() {
    _callTimer?.cancel();
    _callTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && _state == CallUIState.active) {
        setState(() {
          _durationSeconds++;
        });
      }
    });
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  String _formatDuration(int seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  void _answerCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.answerCall();
    _transitionToActive();
  }

  void _rejectCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.rejectCall();
    _endCall();
  }

  void _hangupCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.disconnectCall();
    _endCall();
  }

  void _endCall() {
    _callTimer?.cancel();
    TelecomService.cancelIncomingBanner();
    HapticFeedback.mediumImpact();
    setState(() {
      _state = CallUIState.ended;
    });

    final record = CallRecord(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: widget.contactName ?? widget.phoneNumber,
      number: widget.phoneNumber,
      type: widget.isIncoming
          ? (_durationSeconds > 0 ? CallType.incoming : CallType.missed)
          : CallType.outgoing,
      timestamp: DateTime.now(),
      durationSeconds: _durationSeconds,
      simSlot: widget.simSlot,
      simCarrier: 'SIM ${widget.simSlot}',
      category: widget.callerCategory ?? 'Personal',
      location: 'Cellular Call',
      note: _callNote.isNotEmpty ? _callNote : null,
    );

    widget.onCallEnded?.call(record);
  }

  void _toggleMute() async {
    HapticFeedback.selectionClick();
    final newMute = !_isMuted;
    await TelecomService.setMuted(newMute);
    setState(() {
      _isMuted = newMute;
    });
  }

  void _toggleSpeaker() async {
    HapticFeedback.selectionClick();
    final newSpeaker = !_isSpeaker;
    await TelecomService.setSpeaker(newSpeaker);
    // UI state will be updated immediately and confirmed by setupAudioRouteListener
    setState(() {
      _isSpeaker = newSpeaker;
    });
  }

  void _toggleHold() async {
    HapticFeedback.selectionClick();
    final newHold = !_isOnHold;
    await TelecomService.holdCall(newHold);
    setState(() {
      _isOnHold = newHold;
      _state = newHold ? CallUIState.holding : CallUIState.active;
    });
  }

  void _toggleRecord() {
    HapticFeedback.mediumImpact();
    setState(() {
      _isRecording = !_isRecording;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              _isRecording ? Icons.fiber_manual_record : Icons.stop_circle_outlined,
              color: _isRecording ? Colors.redAccent : Colors.white70,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(_isRecording ? '🔴 Call recording in progress (HD Quality)' : '⏹️ Call recording saved'),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1E1B26),
      ),
    );
  }

  void _onPressDtmfDigit(String digit) {
    HapticFeedback.lightImpact();
    TelecomService.playDtmf(digit);
    setState(() {
      _dtmfHistory += digit;
    });
    Future.delayed(const Duration(milliseconds: 200), () {
      TelecomService.stopDtmf();
    });
  }

  void _showQuickSmsSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1C25),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final messages = [
          "Can't talk now. What's up?",
          "I'll call you right back.",
          "I'm in a meeting right now.",
          "Driving right now, will call later.",
        ];
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Quick Decline with SMS',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ...messages.map(
                (msg) => ListTile(
                  title: Text(msg, style: const TextStyle(color: Colors.white70)),
                  trailing: const Icon(Icons.send_rounded, color: Color(0xFF10B981), size: 18),
                  onTap: () async {
                    Navigator.pop(ctx);
                    _rejectCall();
                    final uri = Uri(
                      scheme: 'sms',
                      path: widget.phoneNumber,
                      queryParameters: {'body': msg},
                    );
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri);
                    }
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showInCallNoteDialog() {
    final controller = TextEditingController(text: _callNote);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E1C25),
        title: const Text('Add In-Call Note', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          maxLines: 3,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'e.g. Discussed client contract, meeting tomorrow 10am',
            hintStyle: TextStyle(color: Colors.white38),
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF10B981)),
            onPressed: () {
              setState(() {
                _callNote = controller.text.trim();
              });
              Navigator.pop(ctx);
            },
            child: const Text('Save Note', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final displayName = widget.contactName?.isNotEmpty == true
        ? widget.contactName!
        : widget.phoneNumber;
    final isBlocked = BlockedNumbersService.isBlocked(widget.phoneNumber);

    return Scaffold(
      backgroundColor: const Color(0xFF090B12),
      body: SafeArea(
        child: _state == CallUIState.ended
            ? _buildCallEndedSummary(displayName)
            : Stack(
                children: [
                  // Deep charcoal glass backdrop with soft blurred colour blooms.
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFF211C19), Color(0xFF090D12), Color(0xFF030A11)],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 115,
                    left: -105,
                    child: ImageFiltered(
                      imageFilter: ImageFilter.blur(sigmaX: 72, sigmaY: 72),
                      child: Container(
                        width: 250, height: 250,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF8A5B3F).withOpacity(0.22),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 80,
                    right: -110,
                    child: ImageFiltered(
                      imageFilter: ImageFilter.blur(sigmaX: 78, sigmaY: 78),
                      child: Container(
                        width: 270, height: 270,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF1B5266).withOpacity(0.18),
                        ),
                      ),
                    ),
                  ),
                  // Ambient Atmospheric Glow
                  Positioned(
                    top: -100,
                    left: 0,
                    right: 0,
                    child: Center(
                      child: ImageFiltered(
                        imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
                        child: Container(
                          width: 320,
                          height: 320,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: (_state == CallUIState.active
                                    ? const Color(0xFF10B981)
                                    : (_state == CallUIState.holding
                                        ? const Color(0xFFF59E0B)
                                        : const Color(0xFF38BDF8)))
                                .withOpacity(0.12),
                          ),
                        ),
                      ),
                    ),
                  ),

                  // Main UI Content
                  Column(
                    children: [
                      // Keep the active-call screen clean like the supplied reference.
                      if (_state != CallUIState.active && _state != CallUIState.holding)
                        Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white70, size: 28),
                              tooltip: 'Minimize to Banner',
                              onPressed: () => Navigator.of(context).pop(),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Colors.white12),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    widget.simSlot == 2 ? Icons.sim_card_outlined : Icons.sim_card,
                                    size: 14,
                                    color: const Color(0xFF10B981),
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    'SIM ${widget.simSlot}',
                                    style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white70,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    isBlocked ? Icons.warning_amber_rounded : Icons.cell_tower,
                                    size: 13,
                                    color: isBlocked ? const Color(0xFFEF4444) : const Color(0xFF38BDF8),
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    isBlocked ? 'SPAM REPORTED' : 'Cellular Call',
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: isBlocked ? const Color(0xFFEF4444) : const Color(0xFF38BDF8),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      if (_state == CallUIState.active || _state == CallUIState.holding)
                        const SizedBox(height: 30)
                      else
                        const Spacer(),

                      if (_state == CallUIState.active || _state == CallUIState.holding)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(22, 28, 22, 0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(displayName,
                                      maxLines: 2, overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 34, height: 1.08,
                                        fontWeight: FontWeight.w700, color: Colors.white,
                                        letterSpacing: -0.6)),
                                    const SizedBox(height: 9),
                                    Text(widget.contactName?.isNotEmpty == true
                                        ? widget.phoneNumber : (widget.callerCategory ?? 'Mobile call'),
                                      maxLines: 1, overflow: TextOverflow.ellipsis,
                                      style: TextStyle(fontSize: 16, color: Colors.white.withOpacity(0.82))),
                                    const SizedBox(height: 22),
                                    Row(mainAxisSize: MainAxisSize.min, children: [
                                      const Icon(Icons.sim_card, size: 17, color: Colors.white),
                                      const SizedBox(width: 9),
                                      Text(_state == CallUIState.holding ? 'On hold' : _formatDuration(_durationSeconds),
                                        style: const TextStyle(fontSize: 21, color: Colors.white, fontWeight: FontWeight.w500)),
                                    ]),
                                  ],
                                ),
                              ),
                              Container(
                                width: 82, height: 82,
                                decoration: BoxDecoration(shape: BoxShape.circle,
                                  border: Border.all(color: const Color(0xFF9B59D0), width: 2.2),
                                  color: const Color(0xFF9B59D0).withOpacity(0.12)),
                                child: const Icon(Icons.business, size: 42, color: Color(0xFF9B59D0)),
                              ),
                            ],
                          ),
                        )
                      else ...[
                        const Spacer(),
                        ScaleTransition(
                          scale: (_state == CallUIState.dialing || _state == CallUIState.ringing)
                              ? _pulseAnimation : const AlwaysStoppedAnimation(1.0),
                          child: Container(
                            width: 112, height: 112,
                            decoration: BoxDecoration(shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.10),
                              border: Border.all(color: Colors.white.withOpacity(0.25), width: 1.5)),
                            child: Center(child: Text(displayName.isNotEmpty
                              ? displayName.trim().characters.first.toUpperCase() : '?',
                              style: const TextStyle(fontSize: 46, fontWeight: FontWeight.bold, color: Colors.white))),
                          ),
                        ),
                        const SizedBox(height: 22),
                        Text(displayName, textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.white)),
                        const SizedBox(height: 6),
                        if (widget.contactName != null)
                          Text(widget.phoneNumber, style: const TextStyle(fontSize: 16, color: Colors.white60)),
                        const SizedBox(height: 14),
                        Text(_state == CallUIState.ringing ? 'Incoming call'
                          : (_state == CallUIState.dialing ? 'Calling...' : _formatDuration(_durationSeconds)),
                          style: const TextStyle(fontSize: 16, color: Colors.white70)),
                        const Spacer(),
                      ],

                      if (_state == CallUIState.active || _state == CallUIState.holding)
                        const Spacer(),

                      if (_callNote.isNotEmpty && _state != CallUIState.ringing) ...[
                        const SizedBox(height: 8),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 32),
                          child: Text('📝 "$_callNote"', maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12, color: Color(0xFF38BDF8), fontStyle: FontStyle.italic)),
                        ),
                      ],

                      // DTMF Keypad View (if toggled)
                      if (_showDtmfPad && _state != CallUIState.ringing)
                        _buildDtmfPad(),

                      // Bottom Action Controls
                      if (_state == CallUIState.ringing)
                        _buildIncomingCallControls()
                      else
                        _buildReferenceActiveControls(),

                      const SizedBox(height: 28),
                    ],
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildIncomingCallControls() {
    return Column(
      children: [
        // Quick Decline SMS sheet button
        TextButton.icon(
          onPressed: _showQuickSmsSheet,
          icon: const Icon(Icons.message_outlined, color: Colors.white60, size: 16),
          label: const Text(
            'Reply with message',
            style: TextStyle(color: Colors.white60, fontSize: 13),
          ),
        ),
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Reject Call Button
              Column(
                children: [
                  GestureDetector(
                    onTap: _rejectCall,
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFFEF4444),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFEF4444).withOpacity(0.4),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.call_end, color: Colors.white, size: 32),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Decline', style: TextStyle(color: Colors.white70, fontSize: 13)),
                ],
              ),

              // Answer Call Button
              Column(
                children: [
                  GestureDetector(
                    onTap: _answerCall,
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF10B981),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF10B981).withOpacity(0.5),
                            blurRadius: 25,
                            spreadRadius: 3,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.call, color: Colors.white, size: 34),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Answer', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLiveAudioWave() {
    return Container(
      height: 38,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      margin: const EdgeInsets.only(top: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white12),
      ),
      child: AnimatedBuilder(
        animation: _pulseController,
        builder: (context, _) {
          final t = _pulseController.value;
          final barHeights = [
            10.0 + 12.0 * math.sin(t * math.pi * 2 + 0.2).abs(),
            14.0 + 16.0 * math.sin(t * math.pi * 2 + 1.0).abs(),
            8.0 + 18.0 * math.sin(t * math.pi * 2 + 2.2).abs(),
            16.0 + 12.0 * math.sin(t * math.pi * 2 + 3.0).abs(),
            12.0 + 15.0 * math.sin(t * math.pi * 2 + 4.1).abs(),
            15.0 + 10.0 * math.sin(t * math.pi * 2 + 5.2).abs(),
            8.0 + 14.0 * math.sin(t * math.pi * 2 + 6.0).abs(),
          ];
          return Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Icon(Icons.graphic_eq, color: Color(0xFF10B981), size: 16),
              const SizedBox(width: 8),
              ...barHeights.map((h) => Container(
                width: 3.5,
                height: h,
                margin: const EdgeInsets.symmetric(horizontal: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFF10B981),
                  borderRadius: BorderRadius.circular(4),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF10B981).withOpacity(0.6),
                      blurRadius: 4,
                    ),
                  ],
                ),
              )),
              const SizedBox(width: 8),
              const Text(
                'HD Audio',
                style: TextStyle(
                  color: Color(0xFF10B981),
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildReferenceActiveControls() {
    // 3x3 layout and control order copied from the supplied call-screen references.
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 0, 28, 4),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _referenceButton(Icons.radio_button_checked_rounded,
                _isRecording ? _formatDuration(_durationSeconds) : 'Record',
                active: _isRecording, activeColor: const Color(0xFFFFFFFF),
                onTap: _toggleRecord),
              _referenceButton(_isOnHold ? Icons.play_arrow_rounded : Icons.pause_rounded,
                _isOnHold ? 'Unhold' : 'Hold',
                active: _isOnHold, activeColor: const Color(0xFFFFFFFF), onTap: _toggleHold),
              _referenceButton(Icons.add_rounded, 'Add call', enabled: false),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _referenceButton(Icons.mic_off_rounded, 'Mute',
                active: _isMuted, activeColor: const Color(0xFFFFFFFF), onTap: _toggleMute),
              _referenceButton(Icons.videocam_rounded, 'Video call', enabled: false),
              _referenceButton(Icons.description_rounded, 'Summarise',
                active: _callNote.isNotEmpty, activeColor: const Color(0xFFBFA0FF),
                onTap: _showInCallNoteDialog),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _referenceButton(Icons.volume_up_rounded, 'Speaker',
                active: _isSpeaker, activeColor: const Color(0xFFFFFFFF), onTap: _toggleSpeaker),
              _referenceButton(Icons.call_end_rounded, 'End',
                isEnd: true, onTap: _hangupCall),
              _referenceButton(Icons.dialpad_rounded, 'Dial pad', active: _showDtmfPad,
                activeColor: const Color(0xFFFFFFFF),
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _showDtmfPad = !_showDtmfPad);
                }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _referenceButton(IconData icon, String label, {
    VoidCallback? onTap,
    bool active = false,
    bool enabled = true,
    bool isEnd = false,
    Color activeColor = const Color(0xFFBFA0FF),
  }) {
    const double diameter = 74;
    final Color edge = isEnd
        ? const Color(0xFFFF777D).withOpacity(0.92)
        : (active ? activeColor.withOpacity(0.75) : Colors.white.withOpacity(0.28));
    return SizedBox(
      width: 100,
      child: Opacity(
        opacity: enabled ? 1 : 0.92,
        child: GestureDetector(
          onTap: enabled ? onTap : null,
          behavior: HitTestBehavior.opaque,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ClipOval(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOutCubic,
                    width: isEnd ? 74 : diameter,
                    height: isEnd ? 74 : diameter,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isEnd ? const Color(0xFFE94235) : null,
                      gradient: isEnd
                          ? null
                          : LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: active
                                  ? [Colors.white.withOpacity(0.92), Colors.white.withOpacity(0.72)]
                                  : [Colors.white.withOpacity(0.22), Colors.white.withOpacity(0.075)],
                            ),
                      border: Border.all(color: edge, width: isEnd ? 0 : 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: isEnd
                              ? const Color(0xFFE94235).withOpacity(0.25)
                              : Colors.black.withOpacity(0.22),
                          blurRadius: isEnd ? 16 : 18,
                          offset: const Offset(0, 5),
                        ),
                        if (active && !isEnd)
                          BoxShadow(color: activeColor.withOpacity(0.18), blurRadius: 14),
                      ],
                    ),
                    child: Center(
                      child: Icon(
                        icon,
                        color: active && !isEnd ? const Color(0xFF101318) : Colors.white,
                        size: isEnd ? 40 : 31,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  letterSpacing: 0,
                  color: Colors.white.withOpacity(0.96),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActiveCallControls() {
    return Column(
      children: [
        // Frosted Glass Pill Controls: Row 1 (Mute, Speaker, Hold)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildControlBtn(
                icon: _isMuted ? Icons.mic_off : Icons.mic_none,
                label: _isMuted ? 'Muted' : 'Mute',
                isActive: _isMuted,
                activeColor: const Color(0xFFEF4444),
                onTap: _toggleMute,
              ),
              _buildControlBtn(
                icon: _isSpeaker ? Icons.volume_up : Icons.volume_down,
                label: _isSpeaker ? 'Speaker On' : 'Speaker',
                isActive: _isSpeaker,
                activeColor: const Color(0xFF38BDF8),
                onTap: _toggleSpeaker,
              ),
              _buildControlBtn(
                icon: _isOnHold ? Icons.play_arrow : Icons.pause,
                label: _isOnHold ? 'Unhold' : 'Hold',
                isActive: _isOnHold,
                activeColor: const Color(0xFFF59E0B),
                onTap: _toggleHold,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // Frosted Glass Pill Controls: Row 2 (Record, Keypad, Add Note)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildControlBtn(
                icon: _isRecording ? Icons.fiber_manual_record : Icons.radio_button_checked,
                label: _isRecording ? 'Recording' : 'Record',
                isActive: _isRecording,
                activeColor: const Color(0xFFEF4444),
                isRecordingBtn: true,
                onTap: _toggleRecord,
              ),
              _buildControlBtn(
                icon: Icons.dialpad,
                label: 'Keypad',
                isActive: _showDtmfPad,
                activeColor: const Color(0xFF10B981),
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _showDtmfPad = !_showDtmfPad);
                },
              ),
              _buildControlBtn(
                icon: Icons.note_alt_outlined,
                label: _callNote.isNotEmpty ? 'View Note' : 'Add Note',
                isActive: _callNote.isNotEmpty,
                activeColor: const Color(0xFFA855F7),
                onTap: _showInCallNoteDialog,
              ),
            ],
          ),
        ),
        const SizedBox(height: 32),

        // Red Hangup Button
        GestureDetector(
          onTap: _hangupCall,
          child: Container(
            width: 74,
            height: 74,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFEF4444),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFEF4444).withOpacity(0.45),
                  blurRadius: 26,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: const Icon(Icons.call_end, color: Colors.white, size: 34),
          ),
        ),
      ],
    );
  }

  Widget _buildControlBtn({
    required IconData icon,
    required String label,
    required bool isActive,
    Color activeColor = const Color(0xFF10B981),
    required VoidCallback onTap,
    bool isRecordingBtn = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
              child: Container(
                width: 68,
                height: 68,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: isActive
                        ? [activeColor.withOpacity(0.35), activeColor.withOpacity(0.18)]
                        : [Colors.white.withOpacity(0.12), Colors.white.withOpacity(0.04)],
                  ),
                  border: Border.all(
                    color: isActive ? activeColor : Colors.white.withOpacity(0.24),
                    width: 1.4,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: isActive ? activeColor.withOpacity(0.35) : Colors.black.withOpacity(0.25),
                      blurRadius: 14,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(
                      icon,
                      color: isActive ? activeColor : Colors.white,
                      size: 26,
                    ),
                    if (isRecordingBtn && isActive)
                      Positioned(
                        top: 8,
                        right: 8,
                        child: Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Colors.redAccent,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: isActive ? activeColor : Colors.white70,
              fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDtmfPad() {
    final keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF181620),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            _dtmfHistory.isEmpty ? 'Tap keys to send DTMF tone' : 'Sent: $_dtmfHistory',
            style: const TextStyle(fontSize: 12, color: Colors.white60),
          ),
          const SizedBox(height: 8),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 12,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 6,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 1.2,
            ),
            itemBuilder: (ctx, i) {
              final digit = keys[i];
              return InkWell(
                onTap: () => _onPressDtmfDigit(digit),
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Text(
                      digit,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildCallEndedSummary(String displayName) {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(24),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1822),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle_outline, color: Color(0xFF10B981), size: 48),
            const SizedBox(height: 12),
            const Text(
              'Call Ended',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white),
            ),
            const SizedBox(height: 6),
            Text(
              displayName,
              style: const TextStyle(fontSize: 16, color: Colors.white70),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                'Duration: ${_formatDuration(_durationSeconds)}',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF10B981)),
              ),
            ),
            if (_callNote.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                'Note: "$_callNote"',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Color(0xFF38BDF8), fontStyle: FontStyle.italic),
              ),
            ],
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildSummaryAction(
                  icon: Icons.chat_bubble_outline,
                  label: 'WhatsApp',
                  color: const Color(0xFF25D366),
                  onTap: () async {
                    final clean = widget.phoneNumber.replaceAll(RegExp(r'[^\d]'), '');
                    final uri = Uri.parse('https://wa.me/$clean');
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _buildSummaryAction(
                  icon: Icons.sms_outlined,
                  label: 'SMS',
                  color: const Color(0xFF38BDF8),
                  onTap: () async {
                    final uri = Uri(scheme: 'sms', path: widget.phoneNumber);
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _buildSummaryAction(
                  icon: Icons.block,
                  label: 'Block',
                  color: const Color(0xFFEF4444),
                  onTap: () {
                    BlockedNumbersService.blockNumber(widget.phoneNumber);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Blocked ${widget.phoneNumber}')),
                    );
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF10B981),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Back to Dialer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryAction({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.15),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}
