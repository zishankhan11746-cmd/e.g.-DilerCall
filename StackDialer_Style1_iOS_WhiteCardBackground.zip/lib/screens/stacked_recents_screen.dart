import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/call_record.dart';
import '../services/telecom_service.dart';
import '../widgets/call_detail_bottom_sheet.dart';
import '../widgets/settings_dialog.dart';

class StackStyleConfig {
  final String id;
  final int number;
  final String name;
  final String hindiName;
  final String badge;
  final Color badgeBg;
  final Color badgeTextColor;
  final String description;
  final List<Color> highlightGradient;

  const StackStyleConfig({
    required this.id,
    required this.number,
    required this.name,
    required this.hindiName,
    required this.badge,
    required this.badgeBg,
    required this.badgeTextColor,
    required this.description,
    required this.highlightGradient,
  });
}

const List<StackStyleConfig> STACK_STYLES = [
  StackStyleConfig(
    id: 'ios-depth',
    number: 1,
    name: 'iOS Depth Stack',
    hindiName: 'क्लासिक iOS शेड',
    badge: 'iOS 18',
    badgeBg: Color(0x330284C7),
    badgeTextColor: Color(0xFF7DD3FC),
    description: 'Apple notification shade with 3D lip rollup and gentle scale compression.',
    highlightGradient: [Color(0xFF38BDF8), Color(0xFF3B82F6)],
  ),
  StackStyleConfig(
    id: 'coverflow-3d',
    number: 2,
    name: '3D Coverflow Deck',
    hindiName: 'कवरफ्लो 3D टिल्ट',
    badge: 'macOS 3D',
    badgeBg: Color(0x333B82F6),
    badgeTextColor: Color(0xFF93C5FD),
    description: 'Perspective 3D tilt with metallic edge reflection and depth perspective.',
    highlightGradient: [Color(0xFF60A5FA), Color(0xFF6366F1)],
  ),
  StackStyleConfig(
    id: 'cascade-waterfall',
    number: 3,
    name: 'Cascade Waterfall',
    hindiName: 'झरना कैस्केड वेव',
    badge: 'Fluid Wave',
    badgeBg: Color(0x3314B8A6),
    badgeTextColor: Color(0xFF5EEAD4),
    description: 'Fluid staggered waterfall with alternating wave offsets (translateX glide).',
    highlightGradient: [Color(0xFF2DD4BF), Color(0xFF10B981)],
  ),
  StackStyleConfig(
    id: 'cyberpunk-neon',
    number: 4,
    name: 'Cyberpunk Neon',
    hindiName: 'साइबरपंक नियॉन',
    badge: 'Cyber Neon',
    badgeBg: Color(0x33D946EF),
    badgeTextColor: Color(0xFFF0ABFC),
    description: 'Sci-fi stack with horizontal tilt, cyan & magenta edge glows.',
    highlightGradient: [Color(0xFF22D3EE), Color(0xFFE879F9)],
  ),
  StackStyleConfig(
    id: 'origami-fold',
    number: 5,
    name: 'Origami 3D Fold',
    hindiName: 'ओरिगेमी फोल्ड',
    badge: 'Papercraft',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFCD34D),
    description: 'Geometric papercraft folding motion as cards stack at top and bottom.',
    highlightGradient: [Color(0xFFFBBF24), Color(0xFFF97316)],
  ),
  StackStyleConfig(
    id: 'tinder-arc',
    number: 6,
    name: 'Tinder Arc Fan',
    hindiName: 'कार्ड्स फैन आर्क',
    badge: 'Cards Fan',
    badgeBg: Color(0x33F43F5E),
    badgeTextColor: Color(0xFFFDA4AF),
    description: 'Radial deck fanning like a hand of playing cards with smooth rotateZ arc curves.',
    highlightGradient: [Color(0xFFFB7185), Color(0xFFEF4444)],
  ),
  StackStyleConfig(
    id: 'accordion-spring',
    number: 7,
    name: 'Accordion Spring',
    hindiName: 'एलास्टिक स्प्रिंग बाउंस',
    badge: 'Elastic Bounce',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Dynamic elastic compression physics with playful spring recoil.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF22C55E)],
  ),
  StackStyleConfig(
    id: 'dynamic-island',
    number: 8,
    name: 'Dynamic Island',
    hindiName: 'डायनामिक कैप्सूल',
    badge: 'Apple Pill',
    badgeBg: Color(0x338B5CF6),
    badgeTextColor: Color(0xFFC4B5FD),
    description: 'Morphing rounded capsule pill stack with status ring beacons.',
    highlightGradient: [Color(0xFFA78BFA), Color(0xFF8B5CF6)],
  ),
  StackStyleConfig(
    id: 'visionos-glass',
    number: 9,
    name: 'VisionOS Frosted',
    hindiName: 'विज़नओएस ग्लास',
    badge: 'Spatial Glass',
    badgeBg: Color(0x336366F1),
    badgeTextColor: Color(0xFFA5B4FC),
    description: 'Spatial translucent frosted glass with iridescent rim highlights.',
    highlightGradient: [Color(0xFF818CF8), Color(0xFF38BDF8)],
  ),
  StackStyleConfig(
    id: 'charcoal-executive',
    number: 10,
    name: 'Charcoal Executive',
    hindiName: 'प्रीमियम चारकोल स्टैक',
    badge: 'Pro Executive',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Deep luxury matte obsidian charcoal with specular highlights and precision bevels.',
    highlightGradient: [Color(0xFF10B981), Color(0xFF059669)],
  ),
  StackStyleConfig(
    id: 'notification-stack-deck',
    number: 11,
    name: 'Notification Stack Deck',
    hindiName: 'iOS नोटिफिकेशन स्टैक',
    badge: 'Frosted Deck',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Wide overlapping notification cards with 0.96 scale lips, 12px stack spacing, frosted-glass surface and spring-like motion.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'android-notification-flow',
    number: 12,
    name: 'Notification Flow',
    hindiName: 'स्मूद नोटिफिकेशन फ्लो',
    badge: 'Android Shade',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Android notification shade style: separated cards near the top, gradually forming a smooth overlapping deck at the bottom.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'realme-flux-engine',
    number: 13,
    name: 'Realme Flux Engine',
    hindiName: 'रियलमी फ्लक्स इंजन 7.0',
    badge: 'Flux 7.0',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFBBF24),
    description: 'Realme UI 7.0 Flux Engine: 78dp rigid cards with dynamic progressFactor, 6% bottom-center scale compression, and 0.82 vertical stack displacement.',
    highlightGradient: [Color(0xFFF59E0B), Color(0xFFEF4444)],
  ),

  StackStyleConfig(
    id: 'dynamic-shrink-expand-stack',
    number: 14,
    name: 'Dynamic Shrink & Expand',
    hindiName: 'डायनामिक श्रिंक-एक्सपैंड स्टैक',
    badge: 'Bottom Dock',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF86EFAC),
    description: 'Realme-inspired bottom-only notification stack: normal cards flow naturally, then the last visible layers tuck into a fixed bottom dock with progressive horizontal width reduction and finger-following motion.',
    highlightGradient: [Color(0xFF22C55E), Color(0xFF0F766E)],
  ),
];

class StackedRecentsScreen extends StatefulWidget {
  final List<CallRecord> calls;
  final VoidCallback onRefresh;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const StackedRecentsScreen({
    super.key,
    required this.calls,
    required this.onRefresh,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<StackedRecentsScreen> createState() => _StackedRecentsScreenState();
}

class _StackedRecentsScreenState extends State<StackedRecentsScreen>
    with SingleTickerProviderStateMixin {
  late Ticker _ticker;
  double _scrollPos = 0.0;
  double _targetScroll = 0.0;
  double _velocity = 0.0;
  bool _isDragging = false;
  double _lastDragY = 0.0;
  DateTime _lastDragTime = DateTime.now();
  double _viewportHeight = 600.0;
  Duration _lastTickElapsed = Duration.zero;

  static const String _stylePreferenceKey = 'stackdialer_selected_card_style_index';
  int _currentStyleIndex = 0;
  bool _stylePreferenceLoaded = false;
  double _scrollSpeedMultiplier = 1.5;
  String _bottomStackStyle = 'three_layer';
  bool _isStackCollapsed = false;
  String _searchQuery = '';
  String _selectedFilter = 'all'; // 'all', 'missed', 'incoming', 'outgoing'
  List<CallRecord> _cachedFilteredCalls = [];

  void _updateFilteredCalls() {
    _cachedFilteredCalls = widget.calls.where((call) {
      if (_selectedFilter == 'missed') {
        if (call.type != CallType.missed && call.type != CallType.rejected) return false;
      } else if (_selectedFilter == 'incoming') {
        if (call.type != CallType.incoming) return false;
      } else if (_selectedFilter == 'outgoing') {
        if (call.type != CallType.outgoing) return false;
      }

      if (_searchQuery.trim().isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        return call.name.toLowerCase().contains(q) ||
            call.number.contains(q);
      }
      return true;
    }).toList();
  }

  // Card physics constants
  static const double cardHeight = 90.0;
  static const double cardGap = 8.0;
  static const double cardStep = cardHeight + cardGap; // 98.0 for styles 1-10
  static const double notificationCardHeight = 176.0;
  static const double notificationCardStep = 152.0; // Style 11: overlapping notification deck
  static const double notificationFlowCardHeight = 78.0;
  static const double notificationFlowCardStep = 98.0; // Style 12: slim cards with visible overlap as they gather into the deck
  static const double fluxCardHeight = 78.0; // Style 13: Realme UI 7.0 rigid card height
  static const double fluxCardStep = 92.0; // Style 13: 78dp card with 14dp gap in free viewport
  static const double dynamicStackCardHeight = 68.0; // Style 14: compact notification-like card
  static const double dynamicStackCardStep = 72.0; // Style 14: 68dp card + tight 4dp gap
  static const double headerOffset = 10.0;

  double get _activeCardStep {
    if (_currentStyleIndex == 10) return notificationCardStep;
    if (_currentStyleIndex == 11) return notificationFlowCardStep;
    if (_currentStyleIndex == 12) return fluxCardStep;
    if (_currentStyleIndex == 13) return dynamicStackCardStep;
    return cardStep;
  }
  double get _activeCardHeight {
    if (_currentStyleIndex == 10) return notificationCardHeight;
    if (_currentStyleIndex == 11) return notificationFlowCardHeight;
    if (_currentStyleIndex == 12) return fluxCardHeight;
    if (_currentStyleIndex == 13) return dynamicStackCardHeight;
    return cardHeight;
  }

  @override
  void initState() {
    super.initState();
    _updateFilteredCalls();
    _ticker = createTicker(_onTick);
    _ticker.start();
    _loadSavedStyle();
    _loadStackMotionPreferences();
  }

  @override
  void didUpdateWidget(covariant StackedRecentsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    _updateFilteredCalls();
    if (widget.calls.length != oldWidget.calls.length ||
        (widget.calls.isNotEmpty && oldWidget.calls.isNotEmpty && widget.calls.first.id != oldWidget.calls.first.id)) {
      _scrollPos = 0.0;
      _targetScroll = 0.0;
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    if (!mounted) return;

    final filtered = _cachedFilteredCalls;
    final double maxScroll = math.max(
      0.0,
      headerOffset + filtered.length * _activeCardStep - _viewportHeight +
          (_currentStyleIndex == 13 ? 0.0 : _activeCardHeight),
    ).toDouble();
    if (_lastTickElapsed == Duration.zero) {
      _lastTickElapsed = elapsed;
      return;
    }
    // Use elapsed frame time so animation speed is consistent on 60/90/120 Hz screens.
    final frameMs = (elapsed - _lastTickElapsed).inMicroseconds / 1000.0;
    _lastTickElapsed = elapsed;
    final dt = frameMs.clamp(0.0, 40.0);
    if (dt <= 0) return;
    final frameFactor = dt / 16.6667;

    bool changed = false;

    // 1. Time-based kinetic momentum decay (independent of refresh rate).
    if (!_isDragging && _velocity.abs() > 0.08) {
      _targetScroll += _velocity * frameFactor;
      // High-precision silky friction for fluid inertial glide across all 14 styles
      const double friction = 0.942;
      _velocity *= math.pow(friction, frameFactor).toDouble();
      if (_targetScroll < 0) {
        _targetScroll = 0;
        _velocity = 0;
      } else if (_targetScroll > maxScroll) {
        _targetScroll = maxScroll;
        _velocity = 0;
      }
      changed = true;
    } else if (!_isDragging) {
      _velocity = 0;
    }

    // 2. High-performance finger tracking & frame-rate-independent settling across all 14 styles
    final diff = _targetScroll - _scrollPos;
    if (_isDragging) {
      // Instant direct finger tracking during drag eliminates any visible touch latency on 60/90/120Hz screens
      if (diff.abs() > 0.001) {
        _scrollPos = _targetScroll;
        changed = true;
      }
    } else if (diff.abs() > 0.05) {
      // Ultra-smooth 24ms critical damping response for silky glide settling
      const double responseMs = 24.0;
      final interpolation = 1.0 - math.exp(-dt / responseMs);
      _scrollPos += diff * interpolation;
      changed = true;
    } else if (_scrollPos != _targetScroll) {
      _scrollPos = _targetScroll;
      changed = true;
    }

    if (changed) {
      setState(() {});
    }
  }

  List<CallRecord> _getFilteredCalls() {
    return widget.calls.where((call) {
      if (_selectedFilter == 'missed') {
        if (call.type != CallType.missed && call.type != CallType.rejected) return false;
      } else if (_selectedFilter == 'incoming') {
        if (call.type != CallType.incoming) return false;
      } else if (_selectedFilter == 'outgoing') {
        if (call.type != CallType.outgoing) return false;
      }

      if (_searchQuery.trim().isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        return call.name.toLowerCase().contains(q) ||
            call.number.contains(q);
      }
      return true;
    }).toList();
  }

  Future<void> _loadStackMotionPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _scrollSpeedMultiplier = (prefs.getDouble('stack12_scroll_speed') ?? 1.5).clamp(0.5, 3.0).toDouble();
      _bottomStackStyle = prefs.getString('stack12_bottom_style') ?? 'three_layer';
    });
  }

  Future<void> _loadSavedStyle() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedIndex = prefs.getInt(_stylePreferenceKey) ?? 0;
      if (!mounted) return;
      setState(() {
        _currentStyleIndex = savedIndex >= 0 && savedIndex < STACK_STYLES.length
            ? savedIndex
            : 0;
        // Prevent a stale animation/scroll offset from placing every Style 12
        // card outside the viewport when restoring the saved style on launch.
        _scrollPos = 0.0;
        _targetScroll = 0.0;
        _velocity = 0.0;
        _isDragging = false;
        _stylePreferenceLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _stylePreferenceLoaded = true);
    }
  }

  Future<void> _saveSelectedStyle(int index) async {
    final safeIndex = index >= 0 && index < STACK_STYLES.length ? index : 0;
    // Update the UI immediately; persist the selection across app restarts.
    if (mounted) {
      setState(() {
        _currentStyleIndex = safeIndex;
        // Each style can use a different card step/height. Reset the previous
        // style's scroll offset so Style 12 never opens with every card off-screen.
        _scrollPos = 0.0;
        _targetScroll = 0.0;
        _velocity = 0.0;
        _isDragging = false;
      });
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_stylePreferenceKey, safeIndex);
    } catch (_) {
      // Keep the in-memory selection even if device storage is temporarily unavailable.
    }
  }

  void _cycleNextStyle() {
    HapticFeedback.lightImpact();
    _saveSelectedStyle((_currentStyleIndex + 1) % STACK_STYLES.length);
  }

  void _restoreDefaultStyle() {
    HapticFeedback.mediumImpact();
    _saveSelectedStyle(0);
  }

  void _toggleStackCollapsed() {
    HapticFeedback.lightImpact();
    setState(() {
      _isStackCollapsed = !_isStackCollapsed;
    });
  }

  // Exact 3D math engine matching web preview
  Map<String, dynamic> _computeCardTransforms({
    required String styleId,
    required int index,
    required double naturalY,
    required double topBoundary,
    required double bottomBoundary,
    required double dockTopY,
    required double step,
  }) {
    double yPos = 0;
    double xPos = 0;
    double scale = 1.0;
    double rotateX = 0;
    double rotateY = 0;
    double rotateZ = 0;
    double skewX = 0;
    double opacity = 1.0;
    bool isStacked = false;
    Alignment transformOrigin = Alignment.center;
    int zIndex = 200 - index * 4;

    if (styleId == 'dynamic-shrink-expand-stack') {
      // Realme-like bottom dock: no top stack, no early pull-down. Cards follow
      // the finger in their normal lane until they touch the dock boundary.
      const double lip = 12.0;
      final double rawProgress = (naturalY - bottomBoundary) / math.max(step, 1.0);

      if (naturalY < topBoundary) {
        yPos = naturalY;
        opacity = 1.0;
        scale = 1.0;
      } else if (rawProgress < 0.0) {
        yPos = naturalY;
        opacity = 1.0;
        scale = 1.0;
      } else {
        // A single continuous stack lane: front card, then two progressively
        // lower lips; deeper cards tuck behind the last visible layer.
        final double progress = rawProgress.clamp(0.0, 6.0).toDouble();
        yPos = dockTopY + math.min(progress, 2.0) * lip;
        opacity = progress <= 2.0
            ? 1.0
            : (1.0 - (progress - 2.0) * 0.04).clamp(0.84, 1.0).toDouble();
        scale = 1.0; // Keep card height and text size unchanged.
        rotateX = 0.0;
        rotateY = 0.0;
        rotateZ = 0.0;
        skewX = 0.0;
        transformOrigin = Alignment.bottomCenter;
        isStacked = true;
      }
    } else if (_isStackCollapsed && (styleId == 'android-notification-flow' || styleId == 'realme-flux-engine')) {
      const double deckBaseY = 16.0;
      final int stackIndex = math.min(index, 6);
      isStacked = true;
      zIndex = 200 - index * 4;
      yPos = deckBaseY + stackIndex * 14.0;
      scale = (math.max(1.0 - stackIndex * 0.024, 0.88)).toDouble();
      rotateX = (math.min(stackIndex * 2.0, 7.0)).toDouble();
      opacity = (index > 6 ? 0.35 : math.max(1.0 - stackIndex * 0.11, 0.40)).toDouble();
      transformOrigin = Alignment.bottomCenter;
    } else {
      if (naturalY >= topBoundary && naturalY <= bottomBoundary) {
        // NATURAL IN-VIEW POSITION: 100% fully visible, crisp and responsive
        yPos = naturalY;
        isStacked = false;
        scale = 1.0;
        opacity = 1.0;
        rotateX = 0;
        rotateY = 0;
        rotateZ = 0;
        skewX = 0;
        transformOrigin = Alignment.center;
      } else if (naturalY < topBoundary) {
        // TOP STACK BUNCHING
        isStacked = true;
        final double topOverflow = topBoundary - naturalY;
        final double stackFactor = math.min(topOverflow / step, 3.5).toDouble();
        yPos = (topBoundary - math.pow(stackFactor, 0.7) * 12.0).toDouble();
        scale = (math.max(1.0 - stackFactor * 0.02, 0.94)).toDouble();
        rotateX = (-math.min(stackFactor * 1.5, 4.5)).toDouble();
        // Safe top opacity floor - NEVER black or invisible
        opacity = (math.max(1.0 - stackFactor * 0.18, 0.35)).toDouble();

        if (styleId == 'realme-flux-engine') {
          // Realme UI 7.0 "Flux Engine" Top Overlapping Stack Logic:
          // Fixed item height: exactly 78dp
          const double totalItemHeight = fluxCardHeight; // 78.0dp
          // Rigid progressFactor dynamically calculated: (-itemTopPosition / totalItemHeight).clamp(0.0, 1.0)
          final double progressFactor = (topOverflow / totalItemHeight).clamp(0.0, 1.0);

          // Overlapping Y Displacement: Intercept linear displacement vector and offset it dynamically
          // by (progressFactor * totalItemHeight * 0.82) to tightly compress subsequent cards directly underneath active foreground card
          final double linearDisplacement = -topOverflow; // = naturalY - topBoundary
          final double overlappingOffset = progressFactor * totalItemHeight * 0.82;
          yPos = (topBoundary + linearDisplacement + overlappingOffset).toDouble();

          // Smooth background stack tuck as scrolling goes deeper:
          if (topOverflow > totalItemHeight) {
            final double deepOverflow = topOverflow - totalItemHeight;
            final double stackProgress = math.min(deepOverflow / totalItemHeight, 4.0);
            yPos = (topBoundary - (totalItemHeight * 0.18) - stackProgress * 8.0).toDouble();
          }

          // Scale Transform Matrix: Compress top-sliding overlapping cards by exactly 6%
          // (down to 0.94 scale factor) using bottom-center alignment vector:
          scale = (1.0 - progressFactor * 0.06).toDouble();
          transformOrigin = Alignment.bottomCenter;

          // Alpha Translucency Level: Apply smooth opacity degradation layer where cards
          // compressing into background stack drop alpha/opacity by up to 45% (down to 0.55 opacity threshold):
          opacity = (1.0 - progressFactor * 0.45).toDouble();

          // Performance Optimizer: Viewport boundary clause to prune cards scrolled completely away
          if (topOverflow > totalItemHeight * 5.0) {
            opacity = 0.0;
          }
        } else if (styleId == 'notification-stack-deck') {
          yPos = (topBoundary - math.min(stackFactor, 5.0) * 12.0).toDouble();
          scale = math.pow(0.96, math.min(stackFactor, 5.0)).toDouble();
          rotateX = (-math.min(stackFactor * 0.8, 2.5)).toDouble();
          opacity = math.max(1.0 - stackFactor * 0.07, 0.68).toDouble();
        } else if (styleId == 'android-notification-flow') {
          final double deckProgress = math.min(topOverflow / math.max(step, 1.0), 4.0).toDouble();
          yPos = (topBoundary - deckProgress * 8.0).toDouble();
          scale = math.max(1.0 - deckProgress * 0.025, 0.92).toDouble();
          rotateX = -math.min(deckProgress * 1.2, 4.0).toDouble();
          opacity = math.max(1.0 - deckProgress * 0.12, 0.40).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'coverflow-3d') {
          rotateX = (-math.min(stackFactor * 2.2, 5.5)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'origami-fold') {
          rotateX = (-math.min(stackFactor * 2.5, 6.0)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.022, 0.93)).toDouble();
        } else if (styleId == 'tinder-arc') {
          rotateZ = (((index % 5) - 2) * math.min(stackFactor * 1.5, 4.5)).toDouble();
          xPos = (((index % 5) - 2) * math.min(stackFactor * 2.0, 7.5)).toDouble();
        } else if (styleId == 'cascade-waterfall') {
          xPos = ((index % 2 == 0 ? -10.0 : 10.0) * math.min(stackFactor, 1.8)).toDouble();
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = ((index % 2 == 0 ? 3.0 : -3.0) * math.min(stackFactor, 1.6)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.022, 0.93)).toDouble();
        } else if (styleId == 'accordion-spring') {
          yPos = (topBoundary - math.sin(math.min(stackFactor, 3.0) * 1.2) * 12.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'dynamic-island') {
          scale = (math.max(1.0 - stackFactor * 0.03, 0.90)).toDouble();
          yPos = (topBoundary - math.pow(stackFactor, 0.75) * 12.0).toDouble();
        } else if (styleId == 'visionos-glass') {
          opacity = (math.max(1.0 - stackFactor * 0.20, 0.35)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.02, 0.95)).toDouble();
        } else if (styleId == 'charcoal-executive') {
          yPos = (topBoundary - math.pow(stackFactor, 0.75) * 10.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.02, 0.94)).toDouble();
        }
      } else if (naturalY > bottomBoundary) {
        // BOTTOM STACK OVERLAP: cards gather into smooth 3D layered deck
        isStacked = true;
        final double bottomOverflow = naturalY - bottomBoundary;
        final double stackFactor = bottomOverflow / step;
        yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        scale = (math.max(1.0 - math.min(stackFactor, 4.0) * 0.025, 0.90)).toDouble();
        rotateX = (math.min(stackFactor * 1.5, 4.5)).toDouble();
        // Safe bottom opacity: NEVER 0.0!
        opacity = (math.max(1.0 - stackFactor * 0.08, 0.50)).toDouble();

        if (styleId == 'dynamic-shrink-expand-stack') {
          // Fixed bottom dock; continuous progress keeps the animation tied to finger movement.
          final double progress = (bottomOverflow / math.max(step, 1.0)).clamp(0.0, 5.0).toDouble();
          final double dockProgress = 1.0 - math.exp(-progress * 0.92);
          yPos = (bottomBoundary + dockProgress * 18.0).toDouble();
          scale = 1.0; // Never shrink card height.
          rotateX = 0.0;
          rotateY = 0.0;
          rotateZ = 0.0;
          opacity = (1.0 - dockProgress * 0.14).clamp(0.82, 1.0).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'realme-flux-engine') {
          // Realme UI 7.0 "Flux Engine" Bottom Notification Stack:
          // Continuous elastic unstacking & docking animation exactly matching the Realme UI 7.0 update video
          final double progress = (bottomOverflow / step).clamp(0.0, 5.0);

          // 1. Fluid asymptotic docking displacement: cards nest into the bottom deck with 12-14px lip tiers
          // Using continuous exponential deceleration (zero discrete step cuts)
          final double dockOffset = (1.0 - math.exp(-progress * 0.75)) * 26.0;
          yPos = (bottomBoundary + dockOffset).toDouble();

          // 2. Continuous scale compression: scales smoothly from 1.0 (active emerging) down to 0.92 (stacked deep)
          // When swiped up, the card expands smoothly out of the bottom stack!
          scale = (1.0 - (1.0 - math.exp(-progress * 0.70)) * 0.08).clamp(0.88, 1.0).toDouble();

          // 3. Smooth alpha degradation: top 2 stacked cards remain crisp & clear with frosted look
          opacity = (1.0 - progress * 0.10).clamp(0.45, 1.0).toDouble();

          // Bottom-center vector so the card expands outwards and upwards when peeling out of the stack
          transformOrigin = Alignment.bottomCenter;
        } else if (styleId == 'notification-stack-deck') {
          yPos = (bottomBoundary + math.min(stackFactor, 5.0) * 12.0).toDouble();
          scale = math.pow(0.96, math.min(stackFactor, 5.0)).toDouble();
          rotateX = math.min(stackFactor * 0.8, 2.5).toDouble();
          opacity = math.max(1.0 - stackFactor * 0.045, 0.65).toDouble();
        } else if (styleId == 'android-notification-flow') {
          final int layer = math.max(1, stackFactor.ceil());
          final double layerIndex = (layer - 1).toDouble();
          yPos = (bottomBoundary + math.min(layerIndex, 5.0) * 12.0).toDouble();
          scale = (math.max(1.0 - math.min(layerIndex, 5.0) * 0.03, 0.88)).toDouble();
          rotateX = (math.min(layerIndex * 0.6, 2.5)).toDouble();
          opacity = (math.max(1.0 - layerIndex * 0.09, 0.40)).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'coverflow-3d') {
          rotateX = (math.min(stackFactor * 2.0, 5.0)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'cascade-waterfall') {
          xPos = ((index % 2 == 0 ? -8.0 : 8.0) * math.min(stackFactor, 1.8)).toDouble();
        } else if (styleId == 'origami-fold') {
          rotateX = (math.min(stackFactor * 2.2, 5.5)).toDouble();
        } else if (styleId == 'tinder-arc') {
          rotateZ = (((index % 5) - 2) * math.min(stackFactor * 1.2, 3.5)).toDouble();
          xPos = (((index % 5) - 2) * math.min(stackFactor * 1.8, 6.0)).toDouble();
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = ((index % 2 == 0 ? -2.5 : 2.5) * math.min(stackFactor, 1.4)).toDouble();
        } else if (styleId == 'accordion-spring') {
          yPos = (bottomBoundary + math.sin(math.min(stackFactor, 3.0) * 1.0) * 16.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'dynamic-island') {
          scale = (math.max(1.0 - stackFactor * 0.03, 0.90)).toDouble();
        } else if (styleId == 'visionos-glass') {
          opacity = (math.max(1.0 - stackFactor * 0.08, 0.60)).toDouble();
        } else if (styleId == 'charcoal-executive') {
          yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        }
      }
    }

    return {
      'yPos': yPos,
      'xPos': xPos,
      'scale': scale,
      'rotateX': rotateX,
      'rotateY': rotateY,
      'rotateZ': rotateZ,
      'skewX': skewX,
      'opacity': opacity.clamp(0.0, 1.0),
      'isStacked': isStacked,
      'zIndex': zIndex,
      'transformOrigin': transformOrigin,
    };
  }

  void _showStyleSelectorSheet() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141219),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Sheet Grab handle
              Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.style, color: Color(0xFF10B981), size: 18),
                      ),
                      const SizedBox(width: 10),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Card Stack Animation Styles',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '14 Distinct Card Motion Styles',
                            style: TextStyle(color: Colors.white38, fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  TextButton.icon(
                    onPressed: () {
                      _restoreDefaultStyle();
                      Navigator.pop(ctx);
                    },
                    icon: const Icon(Icons.refresh, size: 14, color: Colors.blueAccent),
                    label: const Text('Reset', style: TextStyle(color: Colors.blueAccent, fontSize: 12)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView.builder(
                  itemCount: STACK_STYLES.length,
                  itemBuilder: (context, idx) {
                    final style = STACK_STYLES[idx];
                    final isSelected = idx == _currentStyleIndex;
                    return InkWell(
                      onTap: () {
                        HapticFeedback.selectionClick();
                        _saveSelectedStyle(idx);
                        Navigator.pop(ctx);
                      },
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFF10B981).withOpacity(0.12)
                              : const Color(0xFF1F1D27).withOpacity(0.8),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF10B981).withOpacity(0.6)
                                : Colors.white.withOpacity(0.08),
                            width: isSelected ? 1.5 : 1.0,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: isSelected ? const Color(0xFF10B981) : Colors.white10,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Text(
                                  style.number.toString().padLeft(2, '0'),
                                  style: TextStyle(
                                    color: isSelected ? Colors.white : Colors.white70,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        style.name,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '(${style.hindiName})',
                                        style: const TextStyle(color: Colors.white38, fontSize: 11),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    style.description,
                                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: style.badgeBg,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                style.badge,
                                style: TextStyle(
                                  color: style.badgeTextColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  BoxDecoration _getCardBoxDecoration(String styleId, bool isMissed) {
    if (isMissed && styleId != 'dynamic-shrink-expand-stack') {
      if (styleId == 'visionos-glass') {
        return BoxDecoration(
          color: Colors.redAccent.withOpacity(0.18),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.redAccent.withOpacity(0.55), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.redAccent.withOpacity(0.2),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        );
      } else if (styleId == 'cyberpunk-neon') {
        return BoxDecoration(
          color: const Color(0xFF281120).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.pinkAccent.withOpacity(0.8), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.pinkAccent.withOpacity(0.35),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        );
      } else if (styleId == 'realme-flux-engine') {
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFA2C1E26),
              const Color(0xFA1F151B),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: const Color(0xFFF43F5E).withOpacity(0.35),
            width: 0.9,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.40),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: const Color(0xFFF43F5E).withOpacity(0.12),
              blurRadius: 12,
              offset: const Offset(0, 2),
            ),
          ],
        );
      }
      return BoxDecoration(
        color: const Color(0xFF2B161E).withOpacity(0.96),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFEF4444).withOpacity(0.2),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      );
    }

    switch (styleId) {
      case 'dynamic-shrink-expand-stack':
        // Style 14: match the supplied notification reference—matte charcoal,
        // a fine cool rim, soft depth shadow, and a consistent rounded corner.
        return BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xF0252630), Color(0xF01B1C25)],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFB7BACB).withOpacity(0.20), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.34),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
            BoxShadow(
              color: const Color(0xFF7C83A8).withOpacity(0.055),
              blurRadius: 10,
              spreadRadius: -2,
            ),
          ],
        );
      case 'realme-flux-engine':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFA28272F),
              const Color(0xFA1F1E26),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: Colors.white.withOpacity(0.10),
            width: 0.8,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.04),
              blurRadius: 1,
              offset: const Offset(0, -1),
            ),
          ],
        );
      case 'android-notification-flow':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF25232F).withOpacity(0.96),
              const Color(0xFF1D1B24).withOpacity(0.96),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFF34D399).withOpacity(0.40),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.12),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.55),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'notification-stack-deck':
        return BoxDecoration(
          color: const Color(0xE61B1B20), // dark 90% frosted-glass base
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(0.16), width: 1.1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.42),
              blurRadius: 22,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: const Color(0xFF34D399).withOpacity(0.07),
              blurRadius: 18,
              spreadRadius: -3,
            ),
          ],
        );
      case 'coverflow-3d':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF1E283C).withOpacity(0.95),
              const Color(0xFF141C2B).withOpacity(0.95),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF60A5FA).withOpacity(0.45), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF3B82F6).withOpacity(0.2),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'cyberpunk-neon':
        return BoxDecoration(
          color: const Color(0xFF141724).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF22D3EE).withOpacity(0.7), width: 1.3),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF22D3EE).withOpacity(0.25),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'cascade-waterfall':
        return BoxDecoration(
          color: const Color(0xFF132626).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF2DD4BF).withOpacity(0.45), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF14B8A6).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'origami-fold':
        return BoxDecoration(
          color: const Color(0xFF262016).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFBBF24).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF59E0B).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'tinder-arc':
        return BoxDecoration(
          color: const Color(0xFF2A1522).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFB7185).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF43F5E).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'accordion-spring':
        return BoxDecoration(
          color: const Color(0xFF13281E).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF34D399).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'dynamic-island':
        return BoxDecoration(
          color: const Color(0xFF141120).withOpacity(0.96),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: const Color(0xFFA78BFA).withOpacity(0.55), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF8B5CF6).withOpacity(0.25),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'visionos-glass':
        return BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.1),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'charcoal-executive':
        return BoxDecoration(
          color: const Color(0xFF1E1E26).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF10B981).withOpacity(0.35), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'ios-depth':
        // Style 1 only: clean white iOS-style call card.
        return BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFE5E7EB), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.12),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      default:
        return BoxDecoration(
          color: const Color(0xFF22202C).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
    }
  }

  String _formatTimeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays == 1) return 'Yesterday';
    return '${dt.day}/${dt.month}';
  }

  Widget _buildCardContent(CallRecord call, bool isMissed, String styleId) {
    final isWhiteIosStyle = styleId == 'ios-depth';
    IconData typeIcon;
    Color typeColor;
    if (isMissed) {
      typeIcon = Icons.call_missed;
      typeColor = Colors.redAccent;
    } else if (call.type == CallType.outgoing) {
      typeIcon = Icons.call_made;
      typeColor = Colors.lightBlueAccent;
    } else {
      typeIcon = Icons.call_received;
      typeColor = const Color(0xFF10B981);
    }

    final durationText = call.duration > 0
        ? '${(call.duration ~/ 60)}m ${(call.duration % 60)}s'
        : '0s';

    return Row(
      children: [
        // Avatar
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isMissed
                  ? [Colors.redAccent.withOpacity(0.35), Colors.purpleAccent.withOpacity(0.2)]
                  : [const Color(0xFF10B981).withOpacity(0.35), Colors.blueAccent.withOpacity(0.2)],
            ),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(
              color: isMissed ? Colors.redAccent.withOpacity(0.3) : Colors.white12,
            ),
          ),
          child: Center(
            child: Text(
              call.name.isNotEmpty ? call.name[0].toUpperCase() : '?',
              style: TextStyle(
                color: isMissed ? Colors.redAccent : Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        // Name, Number & Info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      call.name,
                      style: TextStyle(
                        color: isMissed ? const Color(0xFFB91C1C) : (isWhiteIosStyle ? const Color(0xFF171717) : Colors.white),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                    decoration: BoxDecoration(
                      color: isWhiteIosStyle ? const Color(0xFFF1F5F9) : Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                      'SIM ${call.simSlot}',
                      style: TextStyle(color: isWhiteIosStyle ? const Color(0xFF64748B) : Colors.white60, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _formatTimeAgo(call.timestamp),
                    style: TextStyle(
                      color: isWhiteIosStyle ? const Color(0xFF64748B) : Colors.white38,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 4),
                  if (DateTime.now().difference(call.timestamp).inMinutes < 5) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: const Color(0xFF10B981), width: 0.8),
                      ),
                      child: const Text(
                        'LIVE',
                        style: TextStyle(
                          color: Color(0xFF10B981),
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 3),
              Row(
                children: [
                  Icon(typeIcon, color: typeColor, size: 12),
                  const SizedBox(width: 4),
                  Text(
                    call.number,
                    style: TextStyle(color: isWhiteIosStyle ? const Color(0xFF475569) : Colors.white60, fontSize: 11, fontFamily: 'monospace'),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '• $durationText',
                    style: TextStyle(color: isWhiteIosStyle ? const Color(0xFF64748B) : Colors.white38, fontSize: 10),
                  ),
                ],
              ),
            ],
          ),
        ),
        // Action Buttons: Copy & Direct Call CTA
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(Icons.copy, color: isWhiteIosStyle ? const Color(0xFF64748B) : Colors.white38, size: 16),
              tooltip: 'Copy Number',
              onPressed: () {
                Clipboard.setData(ClipboardData(text: call.number));
                HapticFeedback.lightImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Copied ${call.number} to clipboard'),
                    duration: const Duration(seconds: 1),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
            InkWell(
              onTap: () {
                HapticFeedback.heavyImpact();
                widget.onCallNumber(call.number);
              },
              borderRadius: BorderRadius.circular(14),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF10B981), Color(0xFF059669)],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF10B981).withOpacity(0.4),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Center(
                  child: Icon(Icons.call, color: Colors.white, size: 20),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _cachedFilteredCalls;
    final currentStyle = STACK_STYLES[_currentStyleIndex];

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1B1822),
              Color(0xFF141219),
              Color(0xFF0D0C11),
            ],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              // 1. Top Executive Control Strip
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xFF141417).withOpacity(0.95),
                  border: const Border(
                    bottom: BorderSide(color: Colors.white10, width: 0.5),
                  ),
                ),
                child: Column(
                  children: [
                    // Row 1: Title, 11 Styles Dropdown, Cycle, Reset, Stack Toggle
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Title with pulse beacon
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: Color(0xFF10B981),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              'Recent Calls',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '(${filtered.length})',
                              style: const TextStyle(
                                color: Colors.white38,
                                fontSize: 12,
                                fontFamily: 'monospace',
                              ),
                            ),
                          ],
                        ),
                        // Right Controls: 11 Styles Picker + Cycle Next + Restore + Stack Toggle
                        Row(
                          children: [
                            // 10 STYLES PICKER CHIP
                            InkWell(
                              onTap: _showStyleSelectorSheet,
                              borderRadius: BorderRadius.circular(12),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.06),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.white12),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.auto_awesome, color: Color(0xFF10B981), size: 12),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${currentStyle.number}. ${currentStyle.name.split(' ')[0]}',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF10B981).withOpacity(0.2),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Text(
                                        '${STACK_STYLES.length}',
                                        style: const TextStyle(
                                          color: Color(0xFF10B981),
                                          fontSize: 9,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 2),
                                    const Icon(Icons.arrow_drop_down, color: Colors.white54, size: 14),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            // Cycle next style button
                            IconButton(
                              icon: const Icon(Icons.shuffle, size: 16, color: Colors.white60),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                              tooltip: 'Cycle Next Style (1-14)',
                              onPressed: _cycleNextStyle,
                            ),
                            // Restore default style button
                            IconButton(
                              icon: const Icon(Icons.restore, size: 16, color: Colors.lightBlueAccent),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                              tooltip: 'Restore Style 1 (iOS Depth)',
                              onPressed: _restoreDefaultStyle,
                            ),
                            // Stack Deck vs Fan Out toggle for notification deck styles (12 & 13)
                            if (_currentStyleIndex == 11 || _currentStyleIndex == 12) InkWell(
                              onTap: _toggleStackCollapsed,
                              borderRadius: BorderRadius.circular(10),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                decoration: BoxDecoration(
                                  color: _isStackCollapsed
                                      ? Colors.amber.withOpacity(0.25)
                                      : Colors.white.withOpacity(0.06),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: _isStackCollapsed ? Colors.amber : Colors.white12,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.layers,
                                      size: 13,
                                      color: _isStackCollapsed ? Colors.amber : Colors.white70,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      _isStackCollapsed ? 'Fan Out' : 'Stack',
                                      style: TextStyle(
                                        color: _isStackCollapsed ? Colors.amber : Colors.white70,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            // Live Device Call Log Refresh button
                            IconButton(
                              icon: const Icon(Icons.refresh, size: 16, color: Color(0xFF10B981)),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 26, minHeight: 26),
                              tooltip: 'Sync Live Call Logs from Phone',
                              onPressed: () {
                                HapticFeedback.lightImpact();
                                setState(() {
                                  _scrollPos = 0.0;
                                  _targetScroll = 0.0;
                                });
                                widget.onRefresh();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('⚡ Syncing live call logs from phone...'),
                                    duration: Duration(seconds: 1),
                                    behavior: SnackBarBehavior.floating,
                                  ),
                                );
                              },
                            ),
                            const SizedBox(width: 2),
                            // Settings Button
                            IconButton(
                              icon: const Icon(Icons.settings_outlined, size: 16, color: Colors.white70),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 26, minHeight: 26),
                              tooltip: 'Dialer Settings',
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (ctx) => DialerSettingsDialog(
                                    onSimulateIncoming: widget.onSimulateIncoming,
                                  ),
                                ).then((_) => _loadStackMotionPreferences());
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),

                    // Slim unified pill for call filters; search lives in the bottom navigation.
                    Container(
                      height: 34,
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: const Color(0xFF242428),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: Colors.white.withOpacity(0.055)),
                      ),
                      child: Row(
                        children: [
                          Expanded(child: _buildFilterPill('all', 'All')),
                          Expanded(child: _buildFilterPill('missed', 'Missed')),
                          Expanded(child: _buildFilterPill('incoming', 'In')),
                          Expanded(child: _buildFilterPill('outgoing', 'Out')),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // 2. 3D Kinetic Card Stack Stage Viewport
              Expanded(
                child: filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.phone_missed, color: Colors.white.withOpacity(0.15), size: 54),
                            const SizedBox(height: 12),
                            const Text(
                              'No recent calls found',
                              style: TextStyle(color: Colors.white54, fontSize: 14),
                            ),
                          ],
                        ),
                      )
                    : LayoutBuilder(
                        builder: (context, constraints) {
                          final double containerHeight = constraints.maxHeight;
                          _viewportHeight = containerHeight;
                          final double topStackBoundary = headerOffset;
                          // Style 14 reserves the bottom card plus two visible stack lips.
                          // Cards remain in their natural flow until they reach this dock,
                          // preventing the large blank gap seen in the earlier build.
                          final double bottomStackBoundary = _currentStyleIndex == 13
                              ? math.max(
                                  topStackBoundary + _activeCardStep,
                                  containerHeight - dynamicStackCardHeight - 2 * 12.0 - 8.0,
                                ).toDouble()
                              : containerHeight - 140.0;
                          final double maxScroll = math.max(
                            0.0,
                            headerOffset + filtered.length * _activeCardStep - containerHeight +
                                (_currentStyleIndex == 13 ? 0.0 : _activeCardHeight),
                          ).toDouble();
                          // Defensive clamp: if the call count, filter, or card style
                          // changes, don't retain an offset beyond the new scroll range.
                          _scrollPos = _scrollPos.clamp(0.0, maxScroll).toDouble();
                          _targetScroll = _targetScroll.clamp(0.0, maxScroll).toDouble();

                          return GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onVerticalDragStart: (details) {
                              _isDragging = true;
                              _velocity = 0;
                            },
                            onVerticalDragUpdate: (details) {
                              // Flutter native primary delta - immune to child layout rebuilds or localPosition coordinate shifts!
                              final deltaY = -details.delta.dy;
                              if (deltaY.isNaN || deltaY.isInfinite) return;
                              // The adjustable motion control is exclusive to Style 12.
                              // Preserve the previous drag feel for every other card style.
                              final double activeSpeed = _currentStyleIndex == 11 ? _scrollSpeedMultiplier : 1.5;
                              _velocity = (deltaY * 1.12 * activeSpeed).clamp(-60.0, 60.0).toDouble();
                              final double dragGain = activeSpeed;
                              _targetScroll = (_targetScroll + deltaY * dragGain).clamp(0.0, maxScroll).toDouble();
                              // Let the ticker's frame-based interpolation follow the finger;
                              // avoid assigning _scrollPos directly, which causes visible micro-jumps.
                              setState(() {});
                            },
                            onVerticalDragEnd: (details) {
                              _isDragging = false;
                              final pv = details.primaryVelocity;
                              if (pv != null && pv.abs() > 40) {
                                final double activeSpeed = _currentStyleIndex == 11 ? _scrollSpeedMultiplier : 1.5;
                                final double flingDivisor = 52.0 / activeSpeed;
                                final double maxFling = 25.0 * activeSpeed;
                                _velocity = (-pv / flingDivisor).clamp(-maxFling, maxFling).toDouble();
                              } else {
                                _velocity = _velocity.clamp(-16.0, 16.0).toDouble();
                              }
                            },
                            child: SizedBox(
                              width: constraints.maxWidth,
                              height: containerHeight,
                              child: ClipRect(
                                child: Stack(
                                  fit: StackFit.expand,
                                  clipBehavior: Clip.none,
                                  children: [
                                    const SizedBox.expand(),
                                    for (int i = filtered.length - 1; i >= 0; i--)
                                      _buildCardWidget(
                                        index: i,
                                        call: filtered[i],
                                        currentStyle: currentStyle,
                                        topBoundary: topStackBoundary,
                                        bottomBoundary: bottomStackBoundary,
                                        step: _activeCardStep,
                                        containerWidth: constraints.maxWidth,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCardWidget({
    required int index,
    required CallRecord call,
    required StackStyleConfig currentStyle,
    required double topBoundary,
    required double bottomBoundary,
    required double step,
    required double containerWidth,
  }) {
    final double naturalY = headerOffset + index * step - _scrollPos;
    // Keep the deepest visible dock layer above the navigation area. The dock
    // top matches the entry boundary, so the card does not jump on first contact.
    final double dynamicDockTopY = _viewportHeight - dynamicStackCardHeight - 2 * 12.0 - 8.0;

    // Viewport Boundary Clause (Performance Optimizer):
    // Prune items that have scrolled completely out of view.
    // In the 'All' tab (20-30 cards), this keeps only ~5-7 active widgets in memory and rendering,
    // achieving identical buttery-smooth ("makkhan") 120fps performance as the 'Missed' tab!
    if (naturalY < topBoundary - step * 3.2 || naturalY > bottomBoundary + step * 3.2) {
      return const SizedBox.shrink();
    }

    final transforms = _computeCardTransforms(
      styleId: currentStyle.id,
      index: index,
      naturalY: naturalY,
      topBoundary: topBoundary,
      bottomBoundary: bottomBoundary,
      dockTopY: dynamicDockTopY,
      step: step,
    );

    double yPos = transforms['yPos'];
    final double xPos = transforms['xPos'];
    double scale = transforms['scale'];
    final double rotateX = transforms['rotateX'];
    final double rotateY = transforms['rotateY'];
    final double rotateZ = transforms['rotateZ'];
    double opacity = transforms['opacity'];
    final Alignment origin = transforms['transformOrigin'];
    final bool isMissed = call.type == CallType.missed || call.type == CallType.rejected;
    final bool fluxEngineStyle = currentStyle.id == 'realme-flux-engine';
    final bool dynamicShrinkStyle = currentStyle.id == 'dynamic-shrink-expand-stack';
    final bool notificationFlowStyle = currentStyle.id == 'android-notification-flow';
    final bool notificationStackStyle = currentStyle.id == 'notification-stack-deck';

    // Universal visibility guard: cards in visible area MUST be 100% visible
    if (!yPos.isFinite) yPos = naturalY;
    if (!scale.isFinite || scale < 0.6) scale = 1.0;
    if (!opacity.isFinite || opacity < 0.20) opacity = 0.25;
    if (!dynamicShrinkStyle && naturalY >= topBoundary && naturalY <= bottomBoundary) {
      yPos = naturalY;
      opacity = 1.0;
      scale = 1.0;
    }

    // Style 14 width morph: full-width cards flow normally; the docked layers
    // taper horizontally like the Realme notification-shade reference. This is
    // layout-width change, not X scaling, so text and height are not squashed.
    double dynamicWidthScale = 1.0;
    double dynamicDockProgress = -1.0;
    if (dynamicShrinkStyle) {
      dynamicDockProgress = ((naturalY - bottomBoundary) / math.max(step, 1.0)).toDouble();
      double smooth(double value) {
        final t = value.clamp(0.0, 1.0).toDouble();
        return t * t * (3.0 - 2.0 * t);
      }
      if (dynamicDockProgress <= 0.0) {
        dynamicWidthScale = 1.0;
      } else if (dynamicDockProgress <= 1.0) {
        dynamicWidthScale = 1.0 - 0.22 * smooth(dynamicDockProgress); // 100% -> 78%
      } else if (dynamicDockProgress <= 2.0) {
        dynamicWidthScale = 0.78 - 0.16 * smooth(dynamicDockProgress - 1.0); // 78% -> 62%
      } else {
        dynamicWidthScale = 0.58;
      }
      dynamicWidthScale = dynamicWidthScale.clamp(0.58, 1.0).toDouble();
    }

    final double baseHorizontalInset = notificationStackStyle
        ? 20.0
        : (notificationFlowStyle || fluxEngineStyle) ? 12.0 : 14.0;
    final double widthInset = dynamicShrinkStyle
        ? math.max(0.0, (containerWidth - baseHorizontalInset * 2) * (1.0 - dynamicWidthScale) / 2.0)
        : 0.0;

    // No X/Y scaling is applied for Style 14: the actual layout width changes,
    // so card height and text size stay intact while left/right edges move inward.
    final matrix3D = Matrix4.identity()
      ..setEntry(3, 2, 0.0008)
      ..rotateX(rotateX * math.pi / 180.0)
      ..rotateY(rotateY * math.pi / 180.0)
      ..rotateZ(rotateZ * math.pi / 180.0)
      ..scale(scale, scale, 1.0);

    return Positioned(
      top: yPos,
      left: baseHorizontalInset + xPos + widthInset,
      right: baseHorizontalInset - xPos + widthInset,
      child: Transform(
        transform: matrix3D,
        alignment: origin,
        child: Opacity(
          opacity: opacity.clamp(0.0, 1.0),
          child: GestureDetector(
            onTap: () {
              if (_isStackCollapsed) {
                _toggleStackCollapsed();
              } else {
                HapticFeedback.lightImpact();
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (ctx) => CallDetailBottomSheet(
                    call: call,
                    onCallNumber: widget.onCallNumber,
                    onDeleteCall: (id) {
                      setState(() {
                        widget.calls.removeWhere((c) => c.id == id);
                      });
                    },
                  ),
                );
              }
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(dynamicShrinkStyle ? 24 : (notificationStackStyle ? 26 : 20)),
              child: Container(
                height: notificationStackStyle
                    ? notificationCardHeight
                    : (notificationFlowStyle
                        ? notificationFlowCardHeight
                        : (fluxEngineStyle
                            ? fluxCardHeight
                            : (dynamicShrinkStyle ? dynamicStackCardHeight : cardHeight))),
                padding: EdgeInsets.symmetric(
                  horizontal: (notificationFlowStyle || fluxEngineStyle || dynamicShrinkStyle) ? 12 : 14,
                  vertical: (notificationFlowStyle || fluxEngineStyle || dynamicShrinkStyle) ? 7 : 12,
                ),
                decoration: _getCardBoxDecoration(currentStyle.id, isMissed),
                child: _buildCardContent(call, isMissed, styleId),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterPill(String key, String label) {
    final isSelected = _selectedFilter == key;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() {
          _selectedFilter = key;
          _targetScroll = 0.0;
          _scrollPos = 0.0;
          _updateFilteredCalls();
        });
      },
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF414145) : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white60,
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
