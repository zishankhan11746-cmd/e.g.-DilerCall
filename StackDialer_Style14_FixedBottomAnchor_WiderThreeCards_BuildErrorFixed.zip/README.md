# StackDialer — All 14 Original Card Styles Restored

This restore uses the earliest available complete 14-style source snapshot: `StackDialer_Style14_ReferenceCardStyle_Animated.zip`.

The Recents screen source (style visuals, per-style transforms, and shared scroll/ticker motion) was restored from that snapshot. Other app files are retained from the supplied `StackDialer_All14Styles_Animation_Optimized.zip` so unrelated dialer features are not intentionally rolled back.

No new global animation tuning, frame-drop optimization, Origami motion copying, or iOS18-only stack overrides were applied.

Archive integrity was checked. Flutter/Gradle build and physical-device testing have not been run.
