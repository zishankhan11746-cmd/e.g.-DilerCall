package com.stackdialer.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.Call
import android.telephony.TelephonyManager

/**
 * PHONE_STATE is only a fallback signal. Telecom's InCallService is the source of truth
 * for whether a call is actually ringing, active, or disconnected. Some devices emit
 * a stale/early IDLE broadcast while the incoming Telecom Call is still ringing; do
 * not let that broadcast dismiss the UI or mark the call disconnected.
 */
class PhoneCallReceiver : BroadcastReceiver() {
    companion object {
        private var lastState: String? = null
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (stateStr == lastState) return
        lastState = stateStr

        val telecomCall = InCallServiceImpl.currentCall
        val telecomState = telecomCall?.state
        val telecomCallIsLive = telecomState == Call.STATE_RINGING ||
            telecomState == Call.STATE_DIALING ||
            telecomState == Call.STATE_ACTIVE ||
            telecomState == Call.STATE_HOLDING

        // Never allow the less reliable broadcast to override a live Telecom call.
        if (telecomCallIsLive) {
            val number = telecomCall?.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }
                ?: return
            when (telecomState) {
                Call.STATE_RINGING -> MainActivity.showIncomingCallBanner(context, number, null)
                Call.STATE_ACTIVE, Call.STATE_HOLDING -> MainActivity.cancelIncomingCallBanner(context)
            }
            return
        }

        // Do not manufacture an incoming call from PHONE_STATE alone. Some Android
        // builds deliver stale RINGING/IDLE broadcasts with no caller number; showing
        // those as "Unknown" creates a fake banner. InCallServiceImpl is authoritative.
        if (stateStr == TelephonyManager.EXTRA_STATE_IDLE && InCallServiceImpl.currentCall == null) {
            MainActivity.cancelIncomingCallBanner(context)
        }

    }
}
