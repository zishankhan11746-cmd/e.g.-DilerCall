#!/usr/bin/env bash
# Build StackDialer Android release APK from the project root.
set -euo pipefail
flutter doctor -v
flutter pub get
flutter analyze
flutter build apk --release --android-skip-build-dependency-validation
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
