Style 14 - Realme-style bottom stack correction

Changes limited to lib/screens/stacked_recents_screen.dart, Style 14 only:
- Removed the early two-step pull-down transition that pulled cards away from their natural list positions and created a large blank gap.
- Set the bottom dock entry boundary to the height of one card plus two visible stack lips and a small navigation-safe margin.
- Made dockTopY equal to the entry boundary so the card does not jump when it enters the dock.
- Kept normal cards in their natural positions until they reach the dock; only bottom layers stack.
- Width morph is layout-based (no horizontal transform): full width -> 78% -> 62%, with deeper layers tucked behind at 58%.
- Cards keep their normal height and text scale. No stack is created at the top.
- Removed the artificial green light sweep so the effect relies on continuous finger-driven movement, horizontal width morph, and layered stacking like the reference notification shade.

Validation: archive integrity and source-level assertions checked. Flutter/Dart SDK is not installed in this environment, so no Flutter compile or live-device animation test was possible.
