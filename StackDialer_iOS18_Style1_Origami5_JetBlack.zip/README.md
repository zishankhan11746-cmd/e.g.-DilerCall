# StackDialer iOS 18 Style 1 – Top Stack & Smooth Swipe Repair

Changes in this build (Style 1 / `ios-depth` only):
- Added a continuous eased transition into the upper stack so cards no longer jump 64 dp when crossing the top boundary.
- Kept the upper stack's five rounded-edge layers and continuous scaling.
- Matched Style 1 drag gain and fling limits to Style 14's scrolling values.
- Kept the existing lower-stack layout and the current Style 1 card details (gray cards, no SIM badge, no copy button, no LIVE label, saved-contact name behavior).
- Other 13 styles are not intentionally changed.

Validation:
- ZIP archive integrity checked.
- Source edits inspected.
- Flutter/Gradle APK build was not run in this environment; please run the project's normal GitHub Actions build to confirm compilation and test on device.
