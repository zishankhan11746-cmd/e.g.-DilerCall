import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/contact.dart';
import '../services/speed_dial_service.dart';
import '../widgets/settings_dialog.dart';

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> with SingleTickerProviderStateMixin {
  String _digits = '';
  String? _pressedDigit;
  String? _glowOriginDigit;
  Timer? _glowTimer;
  late final AnimationController _glowController;
  int _selectedSim = 1;
  bool _hapticsEnabled = true;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 760));
    _loadHapticsPreference();
  }

  Future<void> _loadHapticsPreference() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _hapticsEnabled = prefs.getBool('stackdialer_haptics_enabled') ?? true);
  }

  final List<Map<String, String>> _speedDialFavorites = [
    {'label': 'Mom ❤️', 'number': '+91 98201 45892', 'color': '0xFFEC4899'},
    {'label': 'Sanib A.', 'number': '+91 97654 21980', 'color': '0xFF3B82F6'},
    {'label': 'Mo Faisal', 'number': '+91 98711 00982', 'color': '0xFF10B981'},
    {'label': 'Shivi 🦋', 'number': '+91 98450 11223', 'color': '0xFF8B5CF6'},
    {'label': '112 SOS', 'number': '112', 'color': '0xFFEF4444'},
  ];

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    if (_hapticsEnabled) HapticFeedback.lightImpact();
    _glowTimer?.cancel();
    setState(() {
      _digits += digit;
      _pressedDigit = digit;
      _glowOriginDigit = digit;
    });
    // Expanding radial glow: the pressed key lights first, then adjacent keys.
    _glowController.forward(from: 0);
    _glowTimer = Timer(const Duration(milliseconds: 170), () {
      if (mounted) setState(() => _pressedDigit = null);
    });
  }

  @override
  void dispose() {
    _glowTimer?.cancel();
    _glowController.dispose();
    super.dispose();
  }

  void _onBackspace() {
    if (_hapticsEnabled) HapticFeedback.lightImpact();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    if (_hapticsEnabled) HapticFeedback.mediumImpact();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    return Scaffold(
      backgroundColor: const Color(0xFF17191D),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF202227), Color(0xFF111317)],
          ),
        ),
        child: SafeArea(
          bottom: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              // Realme UI 7 calculator reference: large, evenly spaced 3D
              // circular keys. Keep the 3-column phone layout and make every
              // number/T9 key use the same diameter and spacing.
              final double keyHeight = (constraints.maxWidth * 0.205).clamp(66.0, 76.0);
              final double keyWidth = keyHeight;
              final double rowSpacing = screenHeight < 600 ? 8.0 : (screenHeight < 700 ? 10.0 : 13.0);
              final double callBtnHeight = screenHeight < 600 ? 58.0 : (screenHeight < 700 ? 68.0 : 76.0);

              return Column(
                children: [
                  // Keep the top area clean like the reference dial pad.
                  const SizedBox(height: 4),

                  // Number display / placeholder, positioned above the large keypad.
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: _digits.isEmpty
                            ? const FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  'Enter number',
                                  style: TextStyle(
                                    fontSize: 44,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.5,
                                    color: Color(0xFFB7BBC3),
                                  ),
                                ),
                              )
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: Text(
                                      _digits,
                                      style: const TextStyle(
                                        fontSize: 36,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 1.5,
                                        color: Color(0xFFF4F5F7),
                                      ),
                                    ),
                                  ),
                                  if (matches.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Text(
                                      '${matches.first.name} • ${matches.first.number}',
                                      style: const TextStyle(color: Color(0xFFB7BBC3), fontSize: 13),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ],
                              ),
                      ),
                    ),
                  ),

                  // 3. Large 3D calculator-style phone keypad.
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildSquircleRow(['1', '2', '3'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['4', '5', '6'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['7', '8', '9'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['*', '0', '#'], keyWidth, keyHeight),
                      ],
                    ),
                  ),

                  SizedBox(height: rowSpacing + 2),

                  // Keep the call action prominent below the keypad.
                  SizedBox(height: rowSpacing + 4),
                  Padding(
                    padding: const EdgeInsets.only(left: 24, right: 24, bottom: 8),
                    child: SizedBox(
                      height: callBtnHeight,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          InkWell(
                            onTap: () {
                              if (_digits.isNotEmpty) {
                                if (_hapticsEnabled) HapticFeedback.heavyImpact();
                                widget.onCallNumber(_digits);
                              }
                            },
                            customBorder: const CircleBorder(),
                            child: Container(
                              width: callBtnHeight,
                              height: callBtnHeight,
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFF10B981).withOpacity(0.32),
                                    blurRadius: 26,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: const Center(
                                child: Icon(Icons.call, color: Colors.white, size: 34),
                              ),
                            ),
                          ),
                          if (_digits.isNotEmpty)
                            Align(
                              alignment: Alignment.centerRight,
                              child: GestureDetector(
                                onTap: _onBackspace,
                                onLongPress: _onClearAll,
                                child: Container(
                                  width: 58,
                                  height: 58,
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [Color(0xFF555960), Color(0xFF25282E)],
                                    ),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0x66FFFFFF), width: 1.1),
                                    boxShadow: const [
                                      BoxShadow(color: Color(0x99000000), blurRadius: 8, offset: Offset(0, 4)),
                                      BoxShadow(color: Color(0x22FFFFFF), blurRadius: 3, offset: Offset(-1, -1)),
                                    ],
                                  ),
                                  child: const Icon(Icons.backspace_outlined, color: Color(0xFFE7E9ED), size: 24),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSimPill(int slot, String label) {
    final isSelected = _selectedSim == slot;
    return GestureDetector(
      onTap: () {
        if (_hapticsEnabled) HapticFeedback.selectionClick();
        setState(() => _selectedSim = slot);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981).withOpacity(0.2) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? const Color(0xFF10B981) : Colors.white12,
            width: isSelected ? 1.2 : 0.8,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? const Color(0xFF10B981) : Colors.white70,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildSquircleRow(List<String> keys, double width, double height) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (int i = 0; i < keys.length; i++) ...[
          if (i > 0) const SizedBox(width: 18),
          _buildSquircleButton(keys[i], width, height),
        ],
      ],
    );
  }

  double _keyGridDistance(String key) {
    const positions = <String, Offset>{
      '1': Offset(0, 0), '2': Offset(1, 0), '3': Offset(2, 0),
      '4': Offset(0, 1), '5': Offset(1, 1), '6': Offset(2, 1),
      '7': Offset(0, 2), '8': Offset(1, 2), '9': Offset(2, 2),
      '*': Offset(0, 3), '0': Offset(1, 3), '#': Offset(2, 3),
    };
    final origin = positions[_glowOriginDigit];
    final target = positions[key];
    if (origin == null || target == null) return 99;
    final dx = target.dx - origin.dx;
    final dy = target.dy - origin.dy;
    return math.sqrt(dx * dx + dy * dy);
  }

  double _neighborGlow(String key) {
    final distance = _keyGridDistance(key);
    if (distance > 2.25 || _glowController.value >= 1) return 0;
    final waveRadius = _glowController.value * 2.25;
    final ring = (1.0 - (distance - waveRadius).abs() / 0.82).clamp(0.0, 1.0);
    final originPulse = distance == 0 ? (1.0 - _glowController.value).clamp(0.0, 1.0) : 0.0;
    return (ring * 0.88 + originPulse * 0.32).clamp(0.0, 1.0).toDouble();
  }

  Widget _buildSquircleButton(String key, double width, double height) {
    final sub = _t9Map[key] ?? '';
    final bool pressed = _pressedDigit == key;

    return AnimatedScale(
      scale: pressed ? 0.955 : 1.0,
      duration: const Duration(milliseconds: 115),
      curve: Curves.easeOutCubic,
      child: AnimatedBuilder(
        animation: _glowController,
        builder: (context, child) {
          final glow = _neighborGlow(key);
          return Material(
        color: const Color(0xFF202226),
        shape: const CircleBorder(),
        elevation: pressed ? 1 : 5 + glow * 3,
        shadowColor: Color.lerp(const Color(0xB8000000), const Color(0xFFB9D9FF), glow * 0.9) ?? const Color(0xB8000000),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _onDigitPress(key),
          onLongPress: () {
            if (key == '0') {
              _onDigitPress('+');
            } else if (key == '1') {
              if (_hapticsEnabled) HapticFeedback.heavyImpact();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Calling Voicemail (*123#)...')),
              );
              widget.onCallNumber('*123#');
            } else {
              final intKey = int.tryParse(key);
              if (intKey != null && intKey >= 2 && intKey <= 9) {
                final entry = SpeedDialService.getEntry(intKey);
                if (entry != null) {
                  if (_hapticsEnabled) HapticFeedback.heavyImpact();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('⚡ Speed Dial #$intKey: Calling ${entry.name} (${entry.number})'),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                  widget.onCallNumber(entry.number);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Speed Dial key $intKey is not assigned yet. Set it in Settings!'),
                    ),
                  );
                }
              }
            }
          },
          customBorder: const CircleBorder(),
          // A full-size circular ink ripple spreads from the touch point,
          // matching the soft expanding highlight in the Realme calculator.
          splashColor: const Color(0xFFE9EDF4).withOpacity(0.34),
          highlightColor: const Color(0xFFFFFFFF).withOpacity(0.13),
          splashFactory: InkRipple.splashFactory,
          child: SizedBox(
            width: height,
            height: height,
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Dark graphite raised key with a bright upper rim and
                // deeper lower edge to create the reference 3D cylinder look.
                DecoratedBox(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: pressed
                          ? const [
                              Color(0xFF686C74),
                              Color(0xFF41444B),
                              Color(0xFF292C32),
                            ]
                          : const [
                              Color(0xFF555960),
                              Color(0xFF3B3E45),
                              Color(0xFF25282E),
                            ],
                      stops: const [0.0, 0.48, 1.0],
                    ),
                    border: Border.all(
                      color: Color.lerp(Colors.white.withOpacity(pressed ? 0.34 : 0.25), const Color(0xFFE7F3FF), glow * 0.95)!,
                      width: 1.15 + glow * 1.25,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(pressed ? 0.22 : 0.48),
                        blurRadius: pressed ? 3 : 8,
                        offset: Offset(0, pressed ? 1 : 4),
                      ),
                      if (glow > 0.02)
                        BoxShadow(
                          color: const Color(0xFFB9DFFF).withOpacity(glow * 0.72),
                          blurRadius: 7 + glow * 17,
                          spreadRadius: glow * 2.2,
                        ),
                      BoxShadow(
                        color: const Color(0xFFDDE1E8).withOpacity(pressed ? 0.10 : 0.16),
                        blurRadius: 3,
                        offset: const Offset(-1, -1),
                      ),
                    ],
                  ),
                ),
                // Subtle glass sheen on the upper half; it fades rather
                // than turning the entire key into a flat pale gradient.
                IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        center: const Alignment(-0.42, -0.62),
                        radius: 1.05,
                        colors: [
                          Colors.white.withOpacity(pressed ? 0.20 : 0.15),
                          Colors.white.withOpacity(0.035),
                          Colors.transparent,
                        ],
                        stops: const [0.0, 0.42, 1.0],
                      ),
                    ),
                  ),
                ),
                if (glow > 0.015)
                  IgnorePointer(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            const Color(0xFFEAF6FF).withOpacity(glow * 0.34),
                            const Color(0xFF9CCFFF).withOpacity(glow * 0.20),
                            Colors.transparent,
                          ],
                          stops: const [0.0, 0.58, 1.0],
                        ),
                      ),
                    ),
                  ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      key,
                      style: TextStyle(
                        fontSize: height >= 74 ? 31 : 28,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFFF5F6F8),
                        height: 1.0,
                        shadows: const [
                          Shadow(color: Color(0x88000000), blurRadius: 2, offset: Offset(0, 1)),
                        ],
                      ),
                    ),
                    if (sub.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(
                        sub,
                        style: TextStyle(
                          fontSize: height >= 74 ? 10.5 : 9.5,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFFD0D3D9),
                          letterSpacing: 1.05,
                          height: 1.0,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      );
        },
      ),
    );
  }

}
