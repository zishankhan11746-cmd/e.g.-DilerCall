from pathlib import Path
p=Path('/mnt/data/sunset_style_work/lib/screens/stacked_recents_screen.dart')
s=p.read_text()
# Add Style 1 sunset glass decoration before default return in ios-depth case
old="""      case 'ios-depth':
      default:
        return BoxDecoration(
          color: const Color(0xFF22202C).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
"""
new="""      case 'ios-depth':
        // iOS 18 Style 1 — Sunset Dream glass cards (Style 5 reference palette).
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isMissed
                ? [const Color(0xDDF7B7B4), const Color(0xDDF2A0B0)]
                : [const Color(0xDDFCE0D7), const Color(0xCFFFCB9F), const Color(0xDDF8B6C6)],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFFFF4EE).withOpacity(0.78), width: 1.15),
          boxShadow: [
            BoxShadow(color: const Color(0xFF4B1B70).withOpacity(0.25), blurRadius: 18, offset: const Offset(0, 7)),
            BoxShadow(color: Colors.white.withOpacity(0.28), blurRadius: 1, offset: const Offset(0, -1)),
          ],
        );
      default:
        return BoxDecoration(
          color: const Color(0xFF22202C).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
"""
assert old in s
s=s.replace(old,new,1)
# Content takes style id
s=s.replace('Widget _buildCardContent(CallRecord call, bool isMissed) {','Widget _buildCardContent(CallRecord call, bool isMissed, {String styleId = \'\'}) {',1)
s=s.replace("    IconData typeIcon;\n    Color typeColor;", "    final bool sunsetStyle = styleId == 'ios-depth';\n    IconData typeIcon;\n    Color typeColor;",1)
# avatar gradient and border/text
s=s.replace("""            colors: isMissed
                  ? [Colors.redAccent.withOpacity(0.35), Colors.purpleAccent.withOpacity(0.2)]
                  : [const Color(0xFF10B981).withOpacity(0.35), Colors.blueAccent.withOpacity(0.2)],
""","""            colors: sunsetStyle
                  ? (isMissed
                      ? [const Color(0xFFE45A7A), const Color(0xFF8D3D9B)]
                      : _sunsetAvatarColors(call))
                  : (isMissed
                      ? [Colors.redAccent.withOpacity(0.35), Colors.purpleAccent.withOpacity(0.2)]
                      : [const Color(0xFF10B981).withOpacity(0.35), Colors.blueAccent.withOpacity(0.2)]),
""",1)
s=s.replace("color: isMissed ? Colors.redAccent.withOpacity(0.3) : Colors.white12,","color: sunsetStyle ? Colors.white.withOpacity(0.48) : (isMissed ? Colors.redAccent.withOpacity(0.3) : Colors.white12),",1)
s=s.replace("color: isMissed ? Colors.redAccent : Colors.white,","color: Colors.white,",1)
# name text color
s=s.replace("color: isMissed ? const Color(0xFFFF8B8B) : Colors.white,","color: sunsetStyle ? const Color(0xFF301B35) : (isMissed ? const Color(0xFFFF8B8B) : Colors.white),",1)
# SIM pill color and text
s=s.replace("color: Colors.white.withOpacity(0.08),\n                      borderRadius: BorderRadius.circular(5),","color: sunsetStyle ? const Color(0xFF8D456D).withOpacity(0.14) : Colors.white.withOpacity(0.08),\n                      borderRadius: BorderRadius.circular(5),",1)
s=s.replace("style: const TextStyle(color: Colors.white60, fontSize: 9, fontWeight: FontWeight.bold),","style: TextStyle(color: sunsetStyle ? const Color(0xFF563047) : Colors.white60, fontSize: 9, fontWeight: FontWeight.bold),",1)
s=s.replace("color: Colors.white38,\n                      fontSize: 10,","color: sunsetStyle ? const Color(0xFF70485D) : Colors.white38,\n                      fontSize: 10,",1)
# live label colors
s=s.replace("color: const Color(0xFF10B981).withOpacity(0.2),\n                        borderRadius: BorderRadius.circular(5),\n                        border: Border.all(color: const Color(0xFF10B981), width: 0.8),","color: sunsetStyle ? const Color(0xFF10B981).withOpacity(0.16) : const Color(0xFF10B981).withOpacity(0.2),\n                        borderRadius: BorderRadius.circular(5),\n                        border: Border.all(color: const Color(0xFF10B981), width: 0.8),",1)
# number/duration/copy colors
s=s.replace("style: const TextStyle(color: Colors.white60, fontSize: 11, fontFamily: 'monospace'),","style: TextStyle(color: sunsetStyle ? const Color(0xFF40243B) : Colors.white60, fontSize: 11, fontFamily: 'monospace'),",1)
s=s.replace("style: const TextStyle(color: Colors.white38, fontSize: 10),","style: TextStyle(color: sunsetStyle ? const Color(0xFF70485D) : Colors.white38, fontSize: 10),",1)
s=s.replace("icon: const Icon(Icons.copy, color: Colors.white38, size: 16),","icon: Icon(Icons.copy, color: sunsetStyle ? const Color(0xFF57344B) : Colors.white38, size: 16),",1)
# Calls to content
s=s.replace('_buildCardContent(call, isMissed),','_buildCardContent(call, isMissed, styleId: currentStyle.id),')
# Root backdrop conditional image, preserving existing dark gradient for all other styles
old="""        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1B1822),
              Color(0xFF141219),
              Color(0xFF0D0C11),
            ],
          ),
        ),
"""
new="""        decoration: BoxDecoration(
          image: currentStyle.id == 'ios-depth'
              ? const DecorationImage(
                  image: AssetImage('assets/sunset_ocean_background.jpg'),
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                )
              : null,
          gradient: currentStyle.id == 'ios-depth'
              ? null
              : const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF1B1822), Color(0xFF141219), Color(0xFF0D0C11)],
                ),
        ),
"""
assert old in s
s=s.replace(old,new,1)
# Top strip glass overlay only for Style 1
s=s.replace("color: const Color(0xFF141417).withOpacity(0.95),\n                  border: const Border(","color: currentStyle.id == 'ios-depth' ? const Color(0x995D2D66) : const Color(0xFF141417).withOpacity(0.95),\n                  border: const Border(",1)
# filter pill
s=s.replace("color: const Color(0xFF242428),\n                        borderRadius: BorderRadius.circular(22),","color: currentStyle.id == 'ios-depth' ? const Color(0x66F9D0E2) : const Color(0xFF242428),\n                        borderRadius: BorderRadius.circular(22),",1)
# Add helper palette before _buildCardContent
needle='  Widget _buildCardContent(CallRecord call, bool isMissed, {String styleId = \'\'}) {'
helper="""  List<Color> _sunsetAvatarColors(CallRecord call) {
    final int palette = call.name.hashCode.abs() % 3;
    switch (palette) {
      case 0:
        return const [Color(0xFF4F7BFF), Color(0xFF2555D8)];
      case 1:
        return const [Color(0xFFE65AAE), Color(0xFF8B2BAA)];
      default:
        return const [Color(0xFF35CDB8), Color(0xFF087F9D)];
    }
  }

"""
assert needle in s
s=s.replace(needle,helper+needle,1)
p.write_text(s)
# pubspec asset declaration
pub=Path('/mnt/data/sunset_style_work/pubspec.yaml')
y=pub.read_text()
y=y.replace('flutter:\n  uses-material-design: true\n','flutter:\n  uses-material-design: true\n  assets:\n    - assets/sunset_ocean_background.jpg\n')
pub.write_text(y)
