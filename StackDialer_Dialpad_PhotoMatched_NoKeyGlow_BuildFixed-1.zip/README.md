DilerCall dial pad update

Base: StackDialer_Dialpad_SphericalGlass_Extra20PercentBrighter_500ms.zip

Changes in this update:
- Call button now uses a darker forest-green gradient with a brighter green outer glow.
- Call button tap triggers a 420ms elastic press/bounce animation.
- Backspace/delete tap and long-press clear action trigger the same bouncy pulse plus a visible white glow.
- Existing spherical glass number keys, 500ms white key glow, and neighboring-key glow behavior are preserved.

This ZIP has been archive-integrity checked. Flutter release build and device testing have not been run.
