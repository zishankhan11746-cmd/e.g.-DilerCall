from PIL import Image, ImageDraw, ImageFilter
import numpy as np, math, random
random.seed(18)
w,h=1080,2400
# vertical sky gradient: deep violet top -> magenta -> coral -> golden horizon
stops=[(0.0,(43,24,111)),(0.18,(91,35,142)),(0.38,(174,67,142)),(0.55,(247,119,128)),(0.68,(255,180,111)),(0.76,(255,202,128)),(1.0,(34,28,77))]
arr=np.zeros((h,w,3),dtype=np.uint8)
for y in range(h):
 t=y/(h-1)
 for j in range(len(stops)-1):
  if stops[j][0]<=t<=stops[j+1][0]:
   a,c1=stops[j]; b,c2=stops[j+1]; q=(t-a)/(b-a)
   col=np.array(c1)*(1-q)+np.array(c2)*q; break
 arr[y,:,:]=col
# subtle cloudy bands/noise
Y,X=np.mgrid[0:h,0:w]
noise=(np.sin(X/91+Y/180)+np.sin(X/43-Y/107)*.45+np.cos(X/160+Y/57)*.28)
cloud=np.clip((noise-0.15)*11,0,18)
for k,fac in enumerate([1.0,.48,.38]): arr[:,:,k]=np.clip(arr[:,:,k]+cloud*fac,0,255)
im=Image.fromarray(arr,'RGB').convert('RGBA')
d=ImageDraw.Draw(im,'RGBA')
# distant cloud bands, soft blurred
cloud_layer=Image.new('RGBA',(w,h),(0,0,0,0)); cd=ImageDraw.Draw(cloud_layer,'RGBA')
for i in range(65):
 y=int(random.gauss(h*.57,h*.11)); x=random.randint(-250,w+100); rw=random.randint(90,420); rh=random.randint(12,65)
 col=random.choice([(255,177,177,22),(93,48,142,35),(255,205,164,28),(65,38,111,32)])
 cd.ellipse((x,y,x+rw,y+rh),fill=col)
cloud_layer=cloud_layer.filter(ImageFilter.GaussianBlur(28)); im=Image.alpha_composite(im,cloud_layer)
# sea begins at 70%
sea_top=int(h*.70)
sea=Image.new('RGBA',(w,h),(0,0,0,0)); sd=ImageDraw.Draw(sea,'RGBA')
for y in range(sea_top,h):
 t=(y-sea_top)/(h-sea_top)
 c=(45+int(25*t),25+int(8*t),86+int(20*t),255)
 sd.line((0,y,w,y),fill=c,width=1)
# sun glow and disk
sunx=int(w*.58); suny=int(h*.70)
glow=Image.new('RGBA',(w,h),(0,0,0,0)); gd=ImageDraw.Draw(glow)
for r,a in [(210,14),(150,20),(95,32),(48,80)]: gd.ellipse((sunx-r,suny-r,sunx+r,suny+r),fill=(255,229,166,a))
glow=glow.filter(ImageFilter.GaussianBlur(38)); sea=Image.alpha_composite(sea,glow)
sd=ImageDraw.Draw(sea,'RGBA'); sd.ellipse((sunx-31,suny-31,sunx+31,suny+31),fill=(255,244,201,245))
# sun reflection path, tapered broken shimmering bands
for i in range(115):
 y=suny+random.randint(18,650); t=(y-suny)/650
 half=int(18+115*t); cx=sunx+random.randint(-int(12+50*t),int(12+50*t)); ln=random.randint(8,max(12,half*2))
 x1=max(0,cx-ln//2); x2=min(w,cx+ln//2)
 alpha=random.randint(25,95)
 sd.line((x1,y,x2,y+random.randint(-2,2)),fill=(255,206,139,alpha),width=random.randint(2,7))
# horizontal wave lines
for i in range(300):
 y=random.randint(sea_top+20,h-8); x=random.randint(0,w); ln=random.randint(25,230)
 alpha=random.randint(12,45); col=random.choice([(255,173,145,alpha),(183,126,195,alpha),(255,215,159,alpha)])
 sd.arc((x,y,x+ln,y+random.randint(3,15)),180,350,fill=col,width=random.randint(1,3))
im=Image.alpha_composite(im,sea).convert('RGB').filter(ImageFilter.GaussianBlur(0.35))
im.save('/mnt/data/sunset_style_work/assets/sunset_ocean_background.jpg',quality=91,optimize=True)
