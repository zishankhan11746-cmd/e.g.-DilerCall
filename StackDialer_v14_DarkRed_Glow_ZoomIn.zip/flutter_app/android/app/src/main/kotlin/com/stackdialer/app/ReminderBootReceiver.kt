package com.stackdialer.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restores persisted callback alarms after device/app lifecycle events. */
class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> CallbackReminderReceiver.rescheduleAll(context)
        }
    }
}
