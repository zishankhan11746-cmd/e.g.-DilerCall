package com.stackdialer.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CallActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_ANSWER = "com.stackdialer.app.ACTION_ANSWER"
        const val ACTION_REJECT = "com.stackdialer.app.ACTION_REJECT"
        const val ACTION_DISCONNECT = "com.stackdialer.app.ACTION_DISCONNECT"
        const val ACTION_MUTE = "com.stackdialer.app.ACTION_MUTE"
        const val ACTION_SPEAKER = "com.stackdialer.app.ACTION_SPEAKER"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val number = intent.getStringExtra("number") ?: "Unknown"
        when (intent.action) {
            ACTION_ANSWER -> {
                InCallServiceImpl.answerCurrentCall()
                val appIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    putExtra("answered_number", number)
                }
                if (appIntent != null) context.startActivity(appIntent)
            }
            ACTION_REJECT -> {
                InCallServiceImpl.rejectCurrentCall()
                MainActivity.cancelIncomingCallBanner(context)
            }
            ACTION_DISCONNECT -> {
                InCallServiceImpl.disconnectCurrentCall()
                MainActivity.cancelOngoingCallNotification(context)
                MainActivity.cancelIncomingCallBanner(context)
            }
            ACTION_MUTE -> {
                val currentMute = intent.getBooleanExtra("muted", false)
                val newMute = !currentMute
                InCallServiceImpl.setMuted(context, newMute)
                val isSpeaker = InCallServiceImpl.instance?.callAudioState?.route == android.telecom.CallAudioState.ROUTE_SPEAKER
                MainActivity.showOngoingCallNotification(context, number, null, false, newMute, isSpeaker)
            }
            ACTION_SPEAKER -> {
                val currentSpeaker = intent.getBooleanExtra("speaker", false)
                val newSpeaker = !currentSpeaker
                InCallServiceImpl.setSpeaker(context, newSpeaker)
                val isMuted = InCallServiceImpl.instance?.callAudioState?.isMuted == true
                MainActivity.showOngoingCallNotification(context, number, null, false, isMuted, newSpeaker)
            }
        }
    }
}
