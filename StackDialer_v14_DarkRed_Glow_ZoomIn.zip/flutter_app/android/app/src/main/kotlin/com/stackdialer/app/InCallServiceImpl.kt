package com.stackdialer.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile

class InCallServiceImpl : InCallService() {

    companion object {
        var instance: InCallServiceImpl? = null
        var currentCall: Call? = null
        private val liveCalls = mutableListOf<Call>()
        var onCallStateChangedListener: ((String, String, Int) -> Unit)? = null

        private fun isLive(call: Call): Boolean = call.state != Call.STATE_DISCONNECTED && call.state != Call.STATE_DISCONNECTING

        @Synchronized
        private fun selectCurrentCall(preferred: Call? = null) {
            liveCalls.removeAll { !isLive(it) }
            currentCall = when {
                preferred != null && isLive(preferred) && preferred.state == Call.STATE_RINGING -> preferred
                liveCalls.any { it.state == Call.STATE_RINGING } -> liveCalls.lastOrNull { it.state == Call.STATE_RINGING }
                preferred != null && isLive(preferred) && preferred.state == Call.STATE_ACTIVE -> preferred
                liveCalls.any { it.state == Call.STATE_ACTIVE } -> liveCalls.lastOrNull { it.state == Call.STATE_ACTIVE }
                liveCalls.any { it.state == Call.STATE_HOLDING } -> liveCalls.lastOrNull { it.state == Call.STATE_HOLDING }
                else -> liveCalls.lastOrNull()
            }
        }

        @Synchronized
        fun liveCallCount(): Int = liveCalls.count { isLive(it) }

        fun answerCurrentCall() {
            selectCurrentCall()
            currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }

        fun rejectCurrentCall() {
            selectCurrentCall()
            currentCall?.reject(false, null)
        }

        fun disconnectCurrentCall() {
            selectCurrentCall()
            currentCall?.disconnect()
        }

        private var durationTimerHandler: Handler? = null
        private var durationTimerRunnable: Runnable? = null

        // The notification uses Android's native chronometer (setWhen + setUsesChronometer).
        // Rebuilding/promoting the notification every second is unnecessary and can cause
        // visible notification flicker. The system advances the chronometer itself.
        fun startDurationTicker(context: Context, number: String) {
            stopDurationTicker()
        }

        fun stopDurationTicker() {
            durationTimerRunnable?.let { durationTimerHandler?.removeCallbacks(it) }
            durationTimerHandler = null
            durationTimerRunnable = null
        }

        fun holdCurrentCall(hold: Boolean) {
            selectCurrentCall()
            if (hold) currentCall?.hold() else currentCall?.unhold()
        }

        fun setSpeaker(context: Context?, enabled: Boolean) {
            // 1. Android Telecom InCallService Audio Route
            try {
                instance?.setAudioRoute(if (enabled) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // 2. Hardware AudioManager Fallback
            try {
                val ctx = context ?: instance
                if (ctx != null) {
                    val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    audioManager?.let { am ->
                        am.mode = AudioManager.MODE_IN_COMMUNICATION
                        am.isSpeakerphoneOn = enabled
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun setMuted(context: Context?, muted: Boolean) {
            try {
                instance?.setMuted(muted)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                val ctx = context ?: instance
                if (ctx != null) {
                    val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    audioManager?.let { am ->
                        am.isMicrophoneMute = muted
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun playDtmf(digit: Char) {
            currentCall?.playDtmfTone(digit)
        }

        fun stopDtmf() {
            currentCall?.stopDtmfTone()
        }
    }

    private fun promoteCallNotificationToForeground(number: String) {
        val audio = callAudioState
        val notification = MainActivity.buildOngoingCallNotification(
            this,
            number,
            null,
            false,
            audio?.isMuted == true,
            audio?.route == CallAudioState.ROUTE_SPEAKER
        ) ?: return
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    MainActivity.ONGOING_NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
                )
            } else {
                startForeground(MainActivity.ONGOING_NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            // Telecom still owns the call if the OS disallows foreground promotion.
            MainActivity.showOngoingCallNotification(this, number, null, false, audio?.isMuted == true, audio?.route == CallAudioState.ROUTE_SPEAKER)
        }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        instance = this
        synchronized(InCallServiceImpl::class.java) {
            if (!liveCalls.contains(call)) liveCalls.add(call)
            selectCurrentCall(call)
        }
        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        val state = call.state
        val isOutgoing = call.details?.callDirection == Call.Details.DIRECTION_OUTGOING ||
                         state == Call.STATE_DIALING ||
                         state == Call.STATE_CONNECTING

        // Foreground presentation is driven by the high-priority Telecom call notification
        // and its full-screen PendingIntent. Avoid launching an Activity directly from the
        // background, which can race Samsung's Telecom UI and create duplicate screens.

        if (state == Call.STATE_RINGING && !isOutgoing) {
            // Do not clear the connected call clock when this is call waiting.
            if (liveCalls.none { it != call && (it.state == Call.STATE_ACTIVE || it.state == Call.STATE_HOLDING) }) {
                MainActivity.clearCallConnectedAt(this)
            }
            MainActivity.showIncomingCallBanner(this, number, null)
        } else if (state == Call.STATE_DIALING || state == Call.STATE_CONNECTING || state == Call.STATE_ACTIVE || state == Call.STATE_HOLDING || (state == Call.STATE_RINGING && isOutgoing)) {
            MainActivity.cancelIncomingCallBanner(this)
            if (state == Call.STATE_DIALING || state == Call.STATE_CONNECTING || (state == Call.STATE_RINGING && isOutgoing)) {
                if (liveCalls.none { it != call && (it.state == Call.STATE_ACTIVE || it.state == Call.STATE_HOLDING) }) MainActivity.clearCallConnectedAt(this)
            } else {
                MainActivity.restoreCallConnectedAt(this)
            }
            if (state == Call.STATE_ACTIVE && currentCall == call) {
                val connectedAt = call.details?.connectTimeMillis ?: 0L
                MainActivity.setCallConnectedAt(this, connectedAt.takeIf { it > 0L } ?: System.currentTimeMillis())
            }
            if (currentCall == call) promoteCallNotificationToForeground(number)
        }

        notifyState(number, state)

        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                super.onStateChanged(call, state)
                synchronized(InCallServiceImpl::class.java) { selectCurrentCall(call) }
                val num = call.details?.handle?.schemeSpecificPart ?: "Unknown"
                val callIsOutgoing = call.details?.callDirection == Call.Details.DIRECTION_OUTGOING ||
                                     state == Call.STATE_DIALING ||
                                     state == Call.STATE_CONNECTING

                if (state == Call.STATE_RINGING && !callIsOutgoing) {
                    if (liveCalls.none { it != call && (it.state == Call.STATE_ACTIVE || it.state == Call.STATE_HOLDING) }) {
                        MainActivity.clearCallConnectedAt(this@InCallServiceImpl)
                    }
                    MainActivity.showIncomingCallBanner(this@InCallServiceImpl, num, null)
                } else if (state == Call.STATE_ACTIVE || state == Call.STATE_HOLDING || state == Call.STATE_DIALING || state == Call.STATE_CONNECTING || (state == Call.STATE_RINGING && callIsOutgoing)) {
                    MainActivity.cancelIncomingCallBanner(this@InCallServiceImpl)
                    if (state == Call.STATE_DIALING || state == Call.STATE_CONNECTING || (state == Call.STATE_RINGING && callIsOutgoing)) {
                        if (liveCalls.none { it != call && (it.state == Call.STATE_ACTIVE || it.state == Call.STATE_HOLDING) }) MainActivity.clearCallConnectedAt(this@InCallServiceImpl)
                    } else {
                        MainActivity.restoreCallConnectedAt(this@InCallServiceImpl)
                    }
                    if (state == Call.STATE_ACTIVE && currentCall == call) {
                        val connectedAt = call.details?.connectTimeMillis ?: 0L
                        MainActivity.setCallConnectedAt(this@InCallServiceImpl, connectedAt.takeIf { it > 0L } ?: System.currentTimeMillis())
                    }
                    if (currentCall == call) promoteCallNotificationToForeground(num)
                } else if (state == Call.STATE_DISCONNECTED) {
                    synchronized(InCallServiceImpl::class.java) {
                        liveCalls.remove(call)
                        selectCurrentCall()
                    }
                    MainActivity.cancelIncomingCallBanner(this@InCallServiceImpl)
                    if (currentCall == null) {
                        stopDurationTicker()
                        try {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                                stopForeground(STOP_FOREGROUND_REMOVE)
                            } else {
                                @Suppress("DEPRECATION")
                                stopForeground(true)
                            }
                        } catch (_: Exception) {}
                        MainActivity.cancelOngoingCallNotification(this@InCallServiceImpl)
                        MainActivity.clearCallConnectedAt(this@InCallServiceImpl)
                    } else {
                        val next = currentCall!!
                        val nextNumber = next.details?.handle?.schemeSpecificPart ?: "Unknown"
                        val connectedAt = next.details?.connectTimeMillis ?: 0L
                        if (next.state == Call.STATE_ACTIVE || next.state == Call.STATE_HOLDING) {
                            MainActivity.setCallConnectedAt(this@InCallServiceImpl, connectedAt.takeIf { it > 0L } ?: System.currentTimeMillis())
                            promoteCallNotificationToForeground(nextNumber)
                        }
                    }
                }
                notifyState(num, state)
            }
        })
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        if (audioState != null) {
            val isSpeaker = audioState.route == CallAudioState.ROUTE_SPEAKER
            val isMuted = audioState.isMuted
            val num = currentCall?.details?.handle?.schemeSpecificPart ?: "Unknown"
            if (currentCall != null && currentCall?.state != Call.STATE_DISCONNECTED) {
                MainActivity.showOngoingCallNotification(this, num, null, false, isMuted, isSpeaker)
            }
            Handler(Looper.getMainLooper()).post {
                MainActivity.notifyAudioState(isSpeaker, isMuted)
            }
        }
    }

    private fun notifyState(number: String, state: Int) {
        Handler(Looper.getMainLooper()).post {
            onCallStateChangedListener?.invoke(number, getStateString(state), state)
        }
    }

    private fun getStateString(state: Int): String {
        return when (state) {
            Call.STATE_RINGING -> "RINGING"
            Call.STATE_DIALING -> "DIALING"
            Call.STATE_ACTIVE -> "ACTIVE"
            Call.STATE_HOLDING -> "HOLDING"
            Call.STATE_DISCONNECTED -> "DISCONNECTED"
            else -> "UNKNOWN"
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        stopDurationTicker()
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (_: Exception) {}
        synchronized(InCallServiceImpl::class.java) {
            liveCalls.remove(call)
            selectCurrentCall()
        }
        MainActivity.cancelIncomingCallBanner(this)
        if (currentCall == null) {
            MainActivity.cancelOngoingCallNotification(this)
            MainActivity.clearCallConnectedAt(this)
        } else {
            val next = currentCall!!
            val nextNumber = next.details?.handle?.schemeSpecificPart ?: "Unknown"
            if (next.state == Call.STATE_ACTIVE || next.state == Call.STATE_HOLDING) {
                val connectedAt = next.details?.connectTimeMillis ?: 0L
                MainActivity.setCallConnectedAt(this, connectedAt.takeIf { it > 0L } ?: System.currentTimeMillis())
                promoteCallNotificationToForeground(nextNumber)
            }
        }
        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        notifyState(number, Call.STATE_DISCONNECTED)
    }
}
