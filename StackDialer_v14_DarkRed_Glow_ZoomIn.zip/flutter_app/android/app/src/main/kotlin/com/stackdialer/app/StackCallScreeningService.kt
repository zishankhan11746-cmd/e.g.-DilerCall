package com.stackdialer.app

import android.telecom.Call
import android.telecom.CallScreeningService

/** Rejects numbers explicitly blocked by the user. Android only binds this service
 * after the user grants the Call Screening role to StackDialer. */
class StackCallScreeningService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        if (details.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(details, CallResponse.Builder().setDisallowCall(false).build())
            return
        }
        val handle = details.handle
        val number = handle?.schemeSpecificPart.orEmpty()
        if (number.isBlank() || !isBlocked(number)) {
            respondToCall(details, CallResponse.Builder().setDisallowCall(false).build())
            return
        }
        val response = CallResponse.Builder()
            .setDisallowCall(true)
            .setRejectCall(true)
            .setSkipCallLog(false)
            .setSkipNotification(true)
            .build()
        respondToCall(details, response)
    }

    private fun isBlocked(number: String): Boolean {
        val prefs = getSharedPreferences("stackdialer_blocked_native", MODE_PRIVATE)
        val blocked = prefs.getStringSet("numbers", emptySet()).orEmpty()
        val candidate = normalize(number)
        return candidate.isNotEmpty() && blocked.any { normalize(it) == candidate }
    }

    private fun normalize(value: String): String = value.filter { it.isDigit() }
        .removePrefix("91").let { if (it.length == 10) it else value.filter { c -> c.isDigit() } }
}
