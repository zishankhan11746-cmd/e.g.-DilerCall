import 'package:flutter/material.dart';
import '../models/follow_up_task.dart';
import '../services/follow_up_task_service.dart';

class FollowUpTasksScreen extends StatefulWidget {
  final void Function(String number) onCallNumber;
  const FollowUpTasksScreen({super.key, required this.onCallNumber});
  @override
  State<FollowUpTasksScreen> createState() => _FollowUpTasksScreenState();
}

class _FollowUpTasksScreenState extends State<FollowUpTasksScreen> {
  List<FollowUpTask> _tasks = [];
  bool _loading = true;
  String _filter = 'pending';

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final rows = await FollowUpTaskService.load();
    if (mounted) setState(() { _tasks = rows; _loading = false; });
  }

  bool _isToday(DateTime date) { final n = DateTime.now(); return date.year == n.year && date.month == n.month && date.day == n.day; }
  List<FollowUpTask> get _visible => _tasks.where((t) {
    if (_filter == 'completed') return t.completed;
    if (_filter == 'today') return !t.completed && _isToday(t.dueAt);
    if (_filter == 'all') return true;
    return !t.completed;
  }).toList()..sort((a,b) => a.dueAt.compareTo(b.dueAt));

  Future<void> _addTask() async {
    final name = TextEditingController();
    final number = TextEditingController();
    final note = TextEditingController();
    DateTime due = DateTime.now().add(const Duration(hours: 1));
    final formKey = GlobalKey<FormState>();
    final created = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialogState) => AlertDialog(
      backgroundColor: const Color(0xFF211F29),
      title: const Text('New follow-up call', style: TextStyle(color: Colors.white)),
      content: Form(key: formKey, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextFormField(controller: name, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(labelText: 'Contact name'), validator: (v) => v == null || v.trim().isEmpty ? 'Enter a name' : null),
        TextFormField(controller: number, keyboardType: TextInputType.phone, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(labelText: 'Phone number'), validator: (v) => v == null || v.replaceAll(RegExp(r'[^0-9]'), '').length < 7 ? 'Enter a valid number' : null),
        TextFormField(controller: note, maxLines: 2, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(labelText: 'Task / note (optional)')),
        const SizedBox(height: 12),
        ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.event, color: Color(0xFF10B981)), title: const Text('Due date & time', style: TextStyle(color: Colors.white)), subtitle: Text('${due.day}/${due.month}/${due.year}  ${due.hour.toString().padLeft(2,'0')}:${due.minute.toString().padLeft(2,'0')}', style: const TextStyle(color: Colors.white70)), onTap: () async {
          final date = await showDatePicker(context: ctx, initialDate: due, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 730)));
          if (date == null || !ctx.mounted) return;
          final time = await showTimePicker(context: ctx, initialTime: TimeOfDay.fromDateTime(due));
          if (time != null) setDialogState(() => due = DateTime(date.year, date.month, date.day, time.hour, time.minute));
        }),
      ]))),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), ElevatedButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(ctx, true); }, child: const Text('Save task'))],
    )));
    if (created == true) {
      if (!due.isAfter(DateTime.now())) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose a future date and time')));
      } else {
        final reminder = await FollowUpTaskService.add(name: name.text, number: number.text, note: note.text, dueAt: due);
        await _load();
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reminder ? 'Task saved and reminder scheduled' : 'Task saved, but Android reminder permission/scheduling is not enabled')));
      }
    }
    name.dispose(); number.dispose(); note.dispose();
  }

  String _dateLabel(DateTime d) {
    final n = DateTime.now();
    final today = d.year == n.year && d.month == n.month && d.day == n.day;
    final tomorrowDate = n.add(const Duration(days: 1));
    final tomorrow = d.year == tomorrowDate.year && d.month == tomorrowDate.month && d.day == tomorrowDate.day;
    final day = today ? 'Today' : tomorrow ? 'Tomorrow' : '${d.day}/${d.month}/${d.year}';
    return '$day • ${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';
  }

  @override
  Widget build(BuildContext context) {
    final rows = _visible;
    final pendingCount = _tasks.where((e) => !e.completed).length;
    final completedCount = _tasks.where((e) => e.completed).length;
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(backgroundColor: const Color(0xFF141219), elevation: 0, title: const Text('Follow-up Tasks', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh, color: Colors.white70))]),
      floatingActionButton: FloatingActionButton.extended(onPressed: _addTask, backgroundColor: const Color(0xFF10B981), foregroundColor: Colors.black, icon: const Icon(Icons.add), label: const Text('Add follow-up')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 14), child: Row(children: [
          _summary('Pending', pendingCount, const Color(0xFFF59E0B)), const SizedBox(width: 8), _summary('Completed', completedCount, const Color(0xFF10B981)),
        ])),
        SizedBox(height: 42, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 14), children: [
          _filterChip('pending', 'Pending'), _filterChip('today', 'Today'), _filterChip('completed', 'Completed'), _filterChip('all', 'All'),
        ])),
        const SizedBox(height: 8),
        Expanded(child: _loading ? const Center(child: CircularProgressIndicator()) : rows.isEmpty ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.event_available, color: Colors.white24, size: 54), const SizedBox(height: 10), Text(_filter == 'completed' ? 'No completed tasks yet' : 'No follow-up calls here', style: const TextStyle(color: Colors.white54)), const SizedBox(height: 6), const Text('Add a call task and schedule its reminder', style: TextStyle(color: Colors.white38, fontSize: 12))])) : ListView.builder(padding: const EdgeInsets.fromLTRB(14, 4, 14, 90), itemCount: rows.length, itemBuilder: (ctx, i) => _taskCard(rows[i]))),
      ]),
    );
  }

  Widget _summary(String label, int count, Color color) => Expanded(child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF211F29), borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withOpacity(.25))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$count', style: TextStyle(color: color, fontSize: 24, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12))])));
  Widget _filterChip(String value, String label) => Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(label), selected: _filter == value, onSelected: (_) => setState(() => _filter = value), selectedColor: const Color(0xFF10B981).withOpacity(.22), backgroundColor: const Color(0xFF211F29), labelStyle: TextStyle(color: _filter == value ? const Color(0xFF10B981) : Colors.white70)));

  Widget _taskCard(FollowUpTask task) => Card(color: const Color(0xFF211F29), margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
    Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(task.name, style: TextStyle(color: task.completed ? Colors.white54 : Colors.white, fontWeight: FontWeight.bold, fontSize: 15, decoration: task.completed ? TextDecoration.lineThrough : null)), const SizedBox(height: 3), Text(task.number, style: const TextStyle(color: Colors.white60, fontSize: 12)), if (task.note.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(task.note, style: const TextStyle(color: Colors.white70, fontSize: 12))) ])), Checkbox(value: task.completed, activeColor: const Color(0xFF10B981), onChanged: (v) async { await FollowUpTaskService.setCompleted(task, v ?? false); await _load(); })]),
    const Divider(color: Colors.white12, height: 18), Row(children: [Icon(Icons.schedule, size: 15, color: task.dueAt.isBefore(DateTime.now()) && !task.completed ? Colors.redAccent : const Color(0xFF10B981)), const SizedBox(width: 5), Expanded(child: Text(_dateLabel(task.dueAt), style: const TextStyle(color: Colors.white60, fontSize: 11))), Icon(task.reminderScheduled ? Icons.notifications_active : Icons.notifications_off_outlined, size: 15, color: task.reminderScheduled ? const Color(0xFF10B981) : Colors.orangeAccent), const SizedBox(width: 3), Text(task.reminderScheduled ? 'Reminder on' : 'No alert', style: const TextStyle(color: Colors.white54, fontSize: 10)), const SizedBox(width: 8), if (!task.completed) IconButton(tooltip: 'Call now', visualDensity: VisualDensity.compact, onPressed: () => widget.onCallNumber(task.number), icon: const Icon(Icons.call, color: Color(0xFF10B981))), IconButton(tooltip: 'Delete task', visualDensity: VisualDensity.compact, onPressed: () async { await FollowUpTaskService.delete(task); await _load(); }, icon: const Icon(Icons.delete_outline, color: Colors.redAccent))])
  ])));
}
