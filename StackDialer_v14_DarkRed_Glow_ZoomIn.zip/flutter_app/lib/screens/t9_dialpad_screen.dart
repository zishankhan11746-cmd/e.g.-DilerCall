import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/app_haptics.dart';
import '../models/contact.dart';
import '../services/speed_dial_service.dart';
import '../widgets/settings_dialog.dart';

/// Realme UI 7.0 O-Haptics Vibration Engine
/// Delivers crisp mechanical micro-ticks on dialpad numbers and solid thuds on Call action.
class RealmeOHaptics {
  static const MethodChannel _telecomChannel = MethodChannel('com.stackdialer.app/telecom');

  /// Crisp mechanical micro-tick for dialpad digits & keyboard taps
  static void microTick() {
    if (!AppHaptics.enabled) return;
    AppHaptics.lightImpact();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'microTick'});
    } catch (_) {}
  }

  /// Solid mechanical thud for Call button press
  static void solidThud() {
    if (!AppHaptics.enabled) return;
    AppHaptics.mediumImpact();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'solidThud'});
    } catch (_) {}
  }

  /// Sharp delete tick for backspace
  static void deleteTick() {
    if (!AppHaptics.enabled) return;
    AppHaptics.lightImpact();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'deleteTick'});
    } catch (_) {}
  }

  /// Deep mechanical recoil for long press clear all or speed dial
  static void heavyConfirm() {
    if (!AppHaptics.enabled) return;
    AppHaptics.heavyImpact();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'solidThud'});
    } catch (_) {}
  }

  /// Selection toggle click
  static void selectionTick() {
    if (!AppHaptics.enabled) return;
    AppHaptics.selectionClick();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'microTick'});
    } catch (_) {}
  }
}

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> {
  String _digits = '';

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    setState(() {
      _digits += digit;
    });
  }

  void _onBackspace() {
    RealmeOHaptics.deleteTick();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    RealmeOHaptics.heavyConfirm();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Container(
        color: Theme.of(context).scaffoldBackgroundColor,
        child: SafeArea(
          bottom: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              // Realme UI 7.0 circular button sizing
              final double keyDiameter = screenHeight < 600 ? 60.0 : (screenHeight < 700 ? 68.0 : 76.0);
              final double rowSpacing = screenHeight < 600 ? 8.0 : (screenHeight < 700 ? 12.0 : 15.0);
              final double callBtnHeight = screenHeight < 600 ? 62.0 : (screenHeight < 700 ? 70.0 : 76.0);

              return Column(
                children: [
                  const SizedBox(height: 6),

                  // Top Status / Action Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Spacer(),
                        // Settings Button
                        IconButton(
                          icon: const Icon(Icons.tune_rounded, color: Colors.white70, size: 20),
                          tooltip: 'Dialer Settings',
                          onPressed: _openSettings,
                        ),
                      ],
                    ),
                  ),

                  // Number display matching Realme UI 7.0 high-contrast typography
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: _digits.isEmpty
                            ? const FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  'Dial number',
                                  style: TextStyle(
                                    fontSize: 38,
                                    fontWeight: FontWeight.w300,
                                    letterSpacing: 0.5,
                                    color: Color(0xFF454550),
                                  ),
                                ),
                              )
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: AnimatedSwitcher(
                                      duration: const Duration(milliseconds: 260),
                                      switchInCurve: Curves.easeOutCubic,
                                      switchOutCurve: Curves.easeInCubic,
                                      transitionBuilder: (child, animation) {
                                        final slide = Tween<Offset>(
                                          begin: const Offset(0.0, 0.12),
                                          end: Offset.zero,
                                        ).animate(CurvedAnimation(
                                          parent: animation,
                                          curve: Curves.easeOutCubic,
                                        ));
                                        final scale = Tween<double>(
                                          begin: 0.96,
                                          end: 1.0,
                                        ).animate(CurvedAnimation(
                                          parent: animation,
                                          curve: Curves.easeOutCubic,
                                        ));
                                        return SlideTransition(
                                          position: slide,
                                          child: FadeTransition(
                                            opacity: animation,
                                            child: ScaleTransition(
                                              scale: scale,
                                              child: child,
                                            ),
                                          ),
                                        );
                                      }
                                      child: Text(
                                        _digits,
                                        key: ValueKey<String>(_digits),
                                        style: const TextStyle(
                                          fontSize: 42,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 2.2,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                  if (matches.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.08),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(color: Colors.white12),
                                      ),
                                      child: Text(
                                        '${matches.first.name} • ${matches.first.number}',
                                        style: const TextStyle(color: Color(0xFF00E676), fontSize: 13, fontWeight: FontWeight.w500),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                      ),
                    ),
                  ),

                  // Realme UI 7.0 4x3 Circular Keypad
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildKeyRow(['1', '2', '3'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['4', '5', '6'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['7', '8', '9'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['*', '0', '#'], keyDiameter),
                      ],
                    ),
                  ),

                  SizedBox(height: rowSpacing + 8),

                  // Bottom Action Row: Call CTA and Backspace
                  Padding(
                    padding: const EdgeInsets.only(left: 32, right: 32, bottom: 14),
                    child: SizedBox(
                      height: callBtnHeight,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // 1-Tap Direct WhatsApp Chat Button on Left
                          if (_digits.isNotEmpty)
                            Align(
                              alignment: Alignment.centerLeft,
                              child: RealmeActionButton(
                                size: 56,
                                color: const Color(0x3525D366),
                                borderColor: const Color(0xFF25D366).withOpacity(0.65),
                                shadowColor: const Color(0xFF25D366).withOpacity(0.4),
                                onTap: () async {
                                  RealmeOHaptics.microTick();
                                  final clean = _digits.replaceAll(RegExp(r'[^\d+]'), '');
                                  final uri = Uri.parse('https://wa.me/$clean');
                                  if (await canLaunchUrl(uri)) {
                                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                                  } else {
                                    await launchUrl(uri);
                                  }
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text('Opening WhatsApp for $_digits...'),
                                      duration: const Duration(seconds: 1),
                                      behavior: SnackBarBehavior.floating,
                                    ),
                                  );
                                },
                                child: const Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 24),
                              ),
                            ),

                          // Centered Call Button with Realme UI 7.0 elastic press & glow
                          RealmeActionButton(
                            size: callBtnHeight,
                            color: const Color(0xFF00C853),
                            shadowColor: const Color(0xFF00E676).withOpacity(0.45),
                            isCallButton: true,
                            onTap: () {
                              if (_digits.isNotEmpty) {
                                widget.onCallNumber(_digits);
                              }
                            },
                            child: const Icon(Icons.call_rounded, color: Colors.white, size: 34),
                          ),

                          // Backspace Button on Right
                          if (_digits.isNotEmpty)
                            Align(
                              alignment: Alignment.centerRight,
                              child: RealmeActionButton(
                                size: 56,
                                color: const Color(0x40374151),
                                borderColor: Colors.white.withOpacity(0.45),
                                shadowColor: Colors.black.withOpacity(0.55),
                                onTap: _onBackspace,
                                onLongPress: _onClearAll,
                                child: const Icon(Icons.backspace_outlined, color: Colors.white, size: 22),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildKeyRow(List<String> keys, double diameter) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: keys.map((k) => RealmeDialKey(
        digit: k,
        subLetters: _t9Map[k] ?? '',
        size: diameter,
        onTap: () => _onDigitPress(k),
        onLongPress: () {
          if (k == '0') {
            _onDigitPress('+');
          } else if (k == '1') {
            AppHaptics.heavyImpact();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Calling Voicemail (*123#)...')),
            );
            widget.onCallNumber('*123#');
          } else {
            final intKey = int.tryParse(k);
            if (intKey != null && intKey >= 2 && intKey <= 9) {
              final entry = SpeedDialService.getEntry(intKey);
              if (entry != null) {
                AppHaptics.heavyImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('⚡ Speed Dial #$intKey: Calling ${entry.name} (${entry.number})'),
                    duration: const Duration(seconds: 2),
                  ),
                );
                widget.onCallNumber(entry.number);
              }
            }
          }
        },
      )).toList(),
    );
  }
}

/// Matte charcoal dial key with a quick deep-green radial ripple and
/// a restrained dark-green bloom emerging from the pressed key.
class RealmeDialKey extends StatefulWidget {
  final String digit;
  final String subLetters;
  final double size;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const RealmeDialKey({
    super.key,
    required this.digit,
    required this.subLetters,
    required this.size,
    required this.onTap,
    this.onLongPress,
  });

  @override
  State<RealmeDialKey> createState() => _RealmeDialKeyState();
}

class _RealmeDialKeyState extends State<RealmeDialKey>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rippleAnimation;
  Timer? _longPressTimer;
  bool _longPressTriggered = false;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      // Keep the complete press + red glow effect visible for 0.3 seconds.
      duration: const Duration(milliseconds: 300),
    );

    // A quick zoom-IN on touch, followed by a smooth return to normal size.
    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 1.085)
            .chain(CurveTween(curve: Curves.easeOutCubic)),
        weight: 34,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.085, end: 1.0)
            .chain(CurveTween(curve: Curves.easeOutBack)),
        weight: 66,
      ),
    ]).animate(_animController);

    // The glow blooms quickly, then fades continuously for the full 300 ms.
    _rippleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.0, end: 1.0)
            .chain(CurveTween(curve: Curves.easeOutCubic)),
        weight: 12,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 0.0)
            .chain(CurveTween(curve: Curves.easeInCubic)),
        weight: 88,
      ),
    ]).animate(_animController);
  }

  @override
  void dispose() {
    _longPressTimer?.cancel();
    _animController.dispose();
    super.dispose();
  }

  void _onPointerDown(PointerDownEvent event) {
    _longPressTriggered = false;
    _animController.forward(from: 0.0);
    RealmeOHaptics.microTick();
    if (widget.onLongPress != null) {
      _longPressTimer?.cancel();
      _longPressTimer = Timer(const Duration(milliseconds: 650), () {
        _longPressTriggered = true;
        RealmeOHaptics.heavyConfirm();
        widget.onLongPress!();
      });
    }
  }

  void _onPointerUp(PointerUpEvent event) {
    _longPressTimer?.cancel();
    if (!_longPressTriggered) widget.onTap();
  }

  void _onPointerCancel(PointerCancelEvent event) {
    _longPressTimer?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: _onPointerDown,
      onPointerUp: _onPointerUp,
      onPointerCancel: _onPointerCancel,
      child: AnimatedBuilder(
        animation: _animController,
        builder: (context, child) {
          final ripple = _rippleAnimation.value;
          return Transform.scale(
            scale: _scaleAnimation.value,
            alignment: Alignment.center,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.62),
                    offset: const Offset(0, 4),
                    blurRadius: 7,
                  ),
                  // Broad, bold dark-red bloom outside and below the key outline.
                  // The key face remains untouched; the glow fades over 300 ms.
                  BoxShadow(
                    color: const Color(0xFF65000B).withOpacity(0.98 * ripple),
                    offset: Offset(0, 10 * ripple),
                    blurRadius: 38 * ripple,
                    spreadRadius: 8.0 * ripple,
                  ),
                  BoxShadow(
                    color: const Color(0xFF9B0018).withOpacity(0.96 * ripple),
                    offset: Offset(0, 7 * ripple),
                    blurRadius: 27 * ripple,
                    spreadRadius: 5.5 * ripple,
                  ),
                  BoxShadow(
                    color: const Color(0xFF430008).withOpacity(0.92 * ripple),
                    offset: Offset(0, 5 * ripple),
                    blurRadius: 17 * ripple,
                    spreadRadius: 3.5 * ripple,
                  ),
                ],
              ),
              child: ClipOval(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Color(0xFF41434A),
                            Color(0xFF303138),
                            Color(0xFF24252B),
                          ],
                          stops: [0.0, 0.48, 1.0],
                        ),
                        border: Border.all(
                          color: const Color(0xFF55565D),
                          width: 1.15,
                        ),
                      ),
                    ),
                    // No overlay on the key face; the animated dark-red bloom
                    // stays outside and below the circular outline.
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          widget.digit,
                          style: TextStyle(
                            fontSize: widget.size >= 72
                                ? 33
                                : (widget.size >= 64 ? 29 : 25),
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                            height: 1.0,
                          ),
                        ),
                        if (widget.subLetters.isNotEmpty) ...[
                          const SizedBox(height: 2),
                          Text(
                            widget.subLetters,
                            style: const TextStyle(
                              fontSize: 8.5,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFFB9BAC0),
                              letterSpacing: 1.35,
                              height: 1.0,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Realme UI 7.0 Circular Action Button (Call / Backspace) with matching 0.86 squash & pulse
class RealmeActionButton extends StatefulWidget {
  final double size;
  final Color color;
  final Color? borderColor;
  final Color? shadowColor;
  final bool isCallButton;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final Widget child;

  const RealmeActionButton({
    super.key,
    required this.size,
    required this.color,
    this.borderColor,
    this.shadowColor,
    this.isCallButton = false,
    required this.onTap,
    this.onLongPress,
    required this.child,
  });

  @override
  State<RealmeActionButton> createState() => _RealmeActionButtonState();
}

class _RealmeActionButtonState extends State<RealmeActionButton> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 240),
    );
    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 0.86).chain(CurveTween(curve: Curves.easeOutQuad)),
        weight: 35.0,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.86, end: 1.0).chain(CurveTween(curve: Curves.easeOutBack)),
        weight: 65.0,
      ),
    ]).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTap() {
    _controller.forward(from: 0.0);
    if (widget.isCallButton) {
      RealmeOHaptics.solidThud();
    } else {
      RealmeOHaptics.deleteTick();
    }
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _handleTap,
      onLongPress: widget.onLongPress,
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            alignment: Alignment.center,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.color,
                border: widget.borderColor != null ? Border.all(color: widget.borderColor!, width: 1.4) : null,
                boxShadow: [
                  BoxShadow(
                    color: widget.shadowColor ?? Colors.black.withOpacity(0.35),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Center(child: widget.child),
            ),
          );
        },
      ),
    );
  }
}
