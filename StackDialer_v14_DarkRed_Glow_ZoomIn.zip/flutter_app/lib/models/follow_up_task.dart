class FollowUpTask {
  final String id;
  final String name;
  final String number;
  final String note;
  final DateTime dueAt;
  final bool completed;
  final bool reminderScheduled;

  const FollowUpTask({required this.id, required this.name, required this.number, required this.note, required this.dueAt, this.completed = false, this.reminderScheduled = false});

  FollowUpTask copyWith({String? name, String? number, String? note, DateTime? dueAt, bool? completed, bool? reminderScheduled}) => FollowUpTask(
    id: id, name: name ?? this.name, number: number ?? this.number, note: note ?? this.note,
    dueAt: dueAt ?? this.dueAt, completed: completed ?? this.completed,
    reminderScheduled: reminderScheduled ?? this.reminderScheduled,
  );

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'number': number, 'note': note, 'dueAt': dueAt.toIso8601String(), 'completed': completed, 'reminderScheduled': reminderScheduled};
  static FollowUpTask? fromJson(Map<String, dynamic> json) {
    final due = DateTime.tryParse(json['dueAt']?.toString() ?? '');
    if (due == null) return null;
    return FollowUpTask(id: json['id']?.toString() ?? '', name: json['name']?.toString() ?? '', number: json['number']?.toString() ?? '', note: json['note']?.toString() ?? '', dueAt: due, completed: json['completed'] == true, reminderScheduled: json['reminderScheduled'] == true);
  }
}
