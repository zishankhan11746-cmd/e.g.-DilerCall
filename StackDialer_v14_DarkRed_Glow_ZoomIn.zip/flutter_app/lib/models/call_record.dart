enum CallType {
  incoming,
  outgoing,
  missed,
  rejected,
}

class CallRecord {
  final String id;
  final String name;
  final String number;
  final CallType type;
  final DateTime timestamp;
  final int durationSeconds;
  final int simSlot;
  final String simCarrier;
  final String? note;
  final String? reminderTime;
  final String category;
  final String location;
  final int repeatCount;
  final List<CallRecord>? groupedSubCalls;

  CallRecord({
    required this.id,
    required this.name,
    required this.number,
    required this.type,
    required this.timestamp,
    required this.durationSeconds,
    this.simSlot = 1,
    this.simCarrier = 'SIM 1',
    this.note,
    this.reminderTime,
    this.category = 'Personal',
    this.location = 'Mobile',
    this.repeatCount = 1,
    this.groupedSubCalls,
  });

  CallRecord copyWith({String? name, String? number, CallType? type, DateTime? timestamp,
    int? durationSeconds, int? simSlot, String? simCarrier, String? note,
    String? reminderTime, String? category, String? location, int? repeatCount}) {
    return CallRecord(
      id: id, name: name ?? this.name, number: number ?? this.number,
      type: type ?? this.type, timestamp: timestamp ?? this.timestamp,
      durationSeconds: durationSeconds ?? this.durationSeconds,
      simSlot: simSlot ?? this.simSlot, simCarrier: simCarrier ?? this.simCarrier,
      note: note ?? this.note, reminderTime: reminderTime ?? this.reminderTime,
      category: category ?? this.category, location: location ?? this.location,
      repeatCount: repeatCount ?? this.repeatCount, groupedSubCalls: groupedSubCalls,
    );
  }

  int get duration => durationSeconds;

  String get durationString {
    if (durationSeconds == 0) return 'Missed';
    final mins = durationSeconds ~/ 60;
    final secs = durationSeconds % 60;
    if (mins == 0) return '${secs}s';
    return '${mins}m ${secs}s';
  }

  String get timeFormatted {
    final hour = timestamp.hour.toString().padLeft(2, '0');
    final minute = timestamp.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  String get dateLabel {
    final now = DateTime.now();
    if (timestamp.year == now.year && timestamp.month == now.month && timestamp.day == now.day) {
      return 'Today';
    }
    final yesterday = now.subtract(const Duration(days: 1));
    if (timestamp.year == yesterday.year && timestamp.month == yesterday.month && timestamp.day == yesterday.day) {
      return 'Yesterday';
    }
    return "${timestamp.day}/${timestamp.month}";
  }
}
