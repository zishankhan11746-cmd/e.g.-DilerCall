import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BlockedNumbersService {
  static const String _prefKey = 'stackdialer_blocked_numbers';
  static const MethodChannel _channel = MethodChannel('com.stackdialer.app/telecom');
  static final Set<String> _blockedNumbers = {};

  static String _normalize(String value) {
    final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    return digits.length == 12 && digits.startsWith('91') ? digits.substring(2) : digits;
  }

  static Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _blockedNumbers
        ..clear()
        ..addAll(prefs.getStringList(_prefKey) ?? const []);
      await _syncNative();
    } catch (_) {}
  }

  static List<String> get blockedList => _blockedNumbers.toList();

  static bool isBlocked(String number) {
    final clean = _normalize(number);
    return clean.isNotEmpty && _blockedNumbers.any((b) => _normalize(b) == clean);
  }

  static Future<void> blockNumber(String number) async {
    if (number.trim().isEmpty) return;
    _blockedNumbers.add(number.trim());
    await _persist();
  }

  static Future<void> unblockNumber(String number) async {
    _blockedNumbers.remove(number.trim());
    await _persist();
  }

  static Future<bool> requestCallScreeningRole() async {
    try { return await _channel.invokeMethod<bool>('requestCallScreeningRole') ?? false; }
    catch (_) { return false; }
  }

  static Future<bool> isCallScreeningRoleHeld() async {
    try { return await _channel.invokeMethod<bool>('isCallScreeningRoleHeld') ?? false; }
    catch (_) { return false; }
  }

  static Future<void> _persist() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_prefKey, _blockedNumbers.toList());
      await _syncNative();
    } catch (_) {}
  }

  static Future<void> _syncNative() async {
    try { await _channel.invokeMethod<int>('syncBlockedNumbers', {'numbers': _blockedNumbers.toList()}); }
    catch (_) {}
  }
}
