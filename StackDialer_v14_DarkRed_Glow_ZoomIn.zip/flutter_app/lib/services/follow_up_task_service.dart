import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/follow_up_task.dart';
import 'call_data_service.dart';

class FollowUpTaskService {
  static const _key = 'stackdialer_follow_up_tasks_v1';

  static Future<List<FollowUpTask>> load() async {
    final prefs = await SharedPreferences.getInstance();
    try {
      final decoded = jsonDecode(prefs.getString(_key) ?? '[]');
      if (decoded is! List) return [];
      return decoded.whereType<Map>().map((e) => FollowUpTask.fromJson(Map<String, dynamic>.from(e))).whereType<FollowUpTask>().toList()
        ..sort((a, b) => a.dueAt.compareTo(b.dueAt));
    } catch (_) { return []; }
  }

  static Future<bool> add({required String name, required String number, required String note, required DateTime dueAt}) async {
    final id = 'followup_${DateTime.now().microsecondsSinceEpoch}';
    final scheduled = await CallDataService.scheduleCallbackReminder(callId: id, name: name, number: number, at: dueAt, label: note.trim().isEmpty ? 'Follow-up call' : note.trim());
    final rows = await load();
    rows.add(FollowUpTask(id: id, name: name.trim(), number: number.trim(), note: note.trim(), dueAt: dueAt, reminderScheduled: scheduled));
    await _save(rows);
    return scheduled;
  }

  static Future<void> reschedulePendingReminders() async {
    if (!await CallDataService.canScheduleReminders()) return;
    final rows = await load();
    var changed = false;
    for (var i = 0; i < rows.length; i++) {
      final task = rows[i];
      if (task.completed || task.reminderScheduled || !task.dueAt.isAfter(DateTime.now())) continue;
      final ok = await CallDataService.scheduleCallbackReminder(callId: task.id, name: task.name, number: task.number, at: task.dueAt, label: task.note.isEmpty ? 'Follow-up call' : task.note);
      if (ok) { rows[i] = task.copyWith(reminderScheduled: true); changed = true; }
    }
    if (changed) await _save(rows);
  }

  static Future<void> setCompleted(FollowUpTask task, bool completed) async {
    final rows = await load();
    final index = rows.indexWhere((e) => e.id == task.id);
    if (index < 0) return;
    var reminderScheduled = task.reminderScheduled;
    if (completed) {
      final reminders = await CallDataService.loadReminders();
      for (final r in reminders.where((e) => (e['callId'] ?? '') == task.id)) {
        await CallDataService.cancelReminder(r['id'].toString());
      }
      reminderScheduled = false;
    } else if (task.dueAt.isAfter(DateTime.now())) {
      reminderScheduled = await CallDataService.scheduleCallbackReminder(callId: task.id, name: task.name, number: task.number, at: task.dueAt, label: task.note.isEmpty ? 'Follow-up call' : task.note);
    }
    rows[index] = task.copyWith(completed: completed, reminderScheduled: reminderScheduled);
    await _save(rows);
  }

  static Future<void> delete(FollowUpTask task) async {
    final rows = await load();
    rows.removeWhere((e) => e.id == task.id);
    final reminders = await CallDataService.loadReminders();
    for (final r in reminders.where((e) => (e['callId'] ?? '') == task.id)) {
      await CallDataService.cancelReminder(r['id'].toString());
    }
    await _save(rows);
  }

  static Future<void> _save(List<FollowUpTask> rows) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(rows.map((e) => e.toJson()).toList()));
  }
}
