import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Persistent app-wide appearance preferences.
class AppAppearanceService extends ChangeNotifier {
  AppAppearanceService._();
  static final AppAppearanceService instance = AppAppearanceService._();

  static const _modeKey = 'stackdialer_appearance_mode_v1';
  static const _accentKey = 'stackdialer_accent_theme_v1';
  static const _callStyleKey = 'stackdialer_call_screen_style_v1';

  ThemeMode mode = ThemeMode.dark;
  String modeName = 'dark';
  bool get amoled => modeName == 'amoled';
  String accentName = 'emerald';
  String callScreenStyle = 'classic';

  static const Map<String, Color> accents = {
    'emerald': Color(0xFF10B981),
    'blue': Color(0xFF3B82F6),
    'violet': Color(0xFF8B5CF6),
    'amber': Color(0xFFF59E0B),
    'rose': Color(0xFFF43F5E),
  };

  Color get accent => accents[accentName] ?? accents['emerald']!;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final savedMode = prefs.getString(_modeKey) ?? 'dark';
    modeName = ['dark', 'amoled'].contains(savedMode) ? savedMode : 'dark';
    mode = ThemeMode.dark;
    accentName = prefs.getString(_accentKey) ?? 'emerald';
    callScreenStyle = prefs.getString(_callStyleKey) ?? 'classic';
    notifyListeners();
  }

  Future<void> setMode(String value) async {
    modeName = ['dark', 'amoled'].contains(value) ? value : 'dark';
    mode = ThemeMode.dark;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_modeKey, modeName);
    notifyListeners();
  }

  Future<void> setAccent(String value) async {
    if (!accents.containsKey(value)) return;
    accentName = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accentKey, value);
    notifyListeners();
  }

  Future<void> setCallScreenStyle(String value) async {
    callScreenStyle = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_callStyleKey, value);
    notifyListeners();
  }
}
