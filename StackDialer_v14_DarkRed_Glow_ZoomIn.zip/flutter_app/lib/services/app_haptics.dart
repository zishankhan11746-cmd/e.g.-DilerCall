import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Centralized haptics so the user's vibration preference is respected everywhere.
class AppHaptics {
  static bool enabled = true;
  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    enabled = prefs.getBool('stackdialer_haptics_enabled') ?? true;
  }
  static Future<void> setEnabled(bool value) async {
    enabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('stackdialer_haptics_enabled', value);
  }
  static void lightImpact() { if (enabled) HapticFeedback.lightImpact(); }
  static void mediumImpact() { if (enabled) HapticFeedback.mediumImpact(); }
  static void heavyImpact() { if (enabled) HapticFeedback.heavyImpact(); }
  static void selectionClick() { if (enabled) HapticFeedback.selectionClick(); }
  static void vibrate() { if (enabled) HapticFeedback.vibrate(); }
}
