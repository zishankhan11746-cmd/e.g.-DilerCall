# StackDialer v16 (Latest Release)

## Updates & Features in this Build:
1. **Keypad Frosted Glass (No Artificial Key Glow)**:
   - High-contrast frosted specular glass rim border (crisp white resting, smooth transition on tap).
   - Removed tacky 32px blinding neon halo/glow bloom.
   - Clean translucent smoky spherical lens with BackdropFilter blur and elastic recoil squash.
   - Sharp, solid white numbers with crisp contrast drop shadow.

2. **Realme UI 7.0 O-Haptics (Native Linear Motor Haptics)**:
   - Connected directly to Android native telecom MethodChannel (`dialpadHaptic`).
   - Android 10+ uses `VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)` for micro-ticks and `VibrationEffect.EFFECT_HEAVY_CLICK` for solid thuds.
   - High-amplitude fallback (195-250) ensures physical vibration pulses on every Android manufacturer skin.

3. **iOS 18 Style 1: 5 Premium Themes (Theme 5: Sunset Dream)**:
   - Theme 5 (Sunset Dream) with vibrant coral ocean horizon and amber card glass is fully wired and defaulted.
   - Direct 1-tap **iOS 18 Themes Sheet** accessible right from the Theme Chip on the Recents header.
   - Synchronized across both `ios18_theme_variant` and `stackdialer_ios18_appearance`.

4. **Swipe-to-Action on Recent Cards**:
   - Right swipe: Instant Call (Green gradient backdrop + medium thud).
   - Left swipe: Quick SMS Message modal (Blue gradient backdrop + message chips).

## Build Instructions:
Run `./build_apk.sh` or:
```bash
flutter pub get
flutter build apk --release
```
Output APK: `build/app/outputs/flutter-apk/app-release.apk`
