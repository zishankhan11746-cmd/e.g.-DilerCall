import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/app_haptics.dart';
import '../models/contact.dart';
import '../services/speed_dial_service.dart';
import '../widgets/settings_dialog.dart';

/// Realme UI 7.0 O-Haptics Vibration Engine
/// Delivers crisp mechanical micro-ticks on dialpad numbers and solid thuds on Call action.
class RealmeOHaptics {
  static const MethodChannel _telecomChannel = MethodChannel('com.stackdialer.app/telecom');

  /// Crisp mechanical micro-tick for dialpad digits & keyboard taps
  static void microTick() {
    if (!AppHaptics.enabled) return;
    AppHaptics.lightImpact();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'microTick'});
    } catch (_) {}
  }

  /// Solid mechanical thud for Call button press
  static void solidThud() {
    if (!AppHaptics.enabled) return;
    AppHaptics.mediumImpact();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'solidThud'});
    } catch (_) {}
  }

  /// Sharp delete tick for backspace
  static void deleteTick() {
    if (!AppHaptics.enabled) return;
    AppHaptics.lightImpact();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'deleteTick'});
    } catch (_) {}
  }

  /// Deep mechanical recoil for long press clear all or speed dial
  static void heavyConfirm() {
    if (!AppHaptics.enabled) return;
    AppHaptics.heavyImpact();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'solidThud'});
    } catch (_) {}
  }

  /// Selection toggle click
  static void selectionTick() {
    if (!AppHaptics.enabled) return;
    AppHaptics.selectionClick();
    try {
      _telecomChannel.invokeMethod('dialpadHaptic', {'kind': 'microTick'});
    } catch (_) {}
  }
}

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final void Function(String number, {required int simSlot}) onCallNumber;
  final VoidCallback? onSimulateIncoming;
  final bool overlay;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
    this.overlay = false,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> {
  String _digits = '';
  Color _glowColor = const Color(0xFF00E676);

  @override
  void initState() { super.initState(); dialpadGlowColorNotifier.addListener(_syncGlowColor); _loadGlow(); }

  void _syncGlowColor() { if (mounted) setState(() => _glowColor = dialpadGlowColorNotifier.value); }

  @override
  void dispose() { dialpadGlowColorNotifier.removeListener(_syncGlowColor); super.dispose(); }

  Future<void> _loadGlow() async {
    final p = await SharedPreferences.getInstance();
    final saved = p.getInt('dialpad_glow_color_v2');
    if (saved != null) dialpadGlowColorNotifier.value = Color(saved);
    if (mounted) setState(() => _glowColor = dialpadGlowColorNotifier.value);
  }

  void _onGlowColorChanged(Color color) {
    setState(() => _glowColor = color);
  }

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    setState(() {
      _digits += digit;
    });
  }

  void _onBackspace() {
    RealmeOHaptics.deleteTick();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    RealmeOHaptics.heavyConfirm();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
        onDialpadGlowColorChanged: _onGlowColorChanged,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    final dialpadContent = Container(
        color: widget.overlay ? Colors.transparent : Theme.of(context).scaffoldBackgroundColor,
        child: SafeArea(
          top: !widget.overlay,
          bottom: !widget.overlay,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              // Compact dimensions are used only in the floating keypad card.
              // The regular full dialpad layout remains unchanged.
              final double keyDiameter = widget.overlay
                  ? ((screenHeight - 155.0) / 4.0).clamp(58.0, 84.0).toDouble()
                  : (screenHeight < 600 ? 76.0 : (screenHeight < 700 ? 86.0 : 96.0));
              final double rowSpacing = widget.overlay
                  ? 4.0
                  : (screenHeight < 600 ? 9.0 : (screenHeight < 700 ? 13.0 : 16.0));

              return Column(
                children: [
                  SizedBox(height: widget.overlay ? 12 : 6),

                  // Full dialer has its toolbar; the floating keypad reference has none.
                  if (!widget.overlay)
                    Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Spacer(),
                        // Settings Button
                        IconButton(
                          visualDensity: widget.overlay ? VisualDensity.compact : VisualDensity.standard,
                          icon: Icon(Icons.tune_rounded, color: Colors.white70, size: widget.overlay ? 17 : 20),
                          tooltip: 'Dialer Settings',
                          onPressed: _openSettings,
                        ),
                      ],
                    ),
                  ),

                  // Compact number line in the floating keypad; full layout otherwise.
                  if (widget.overlay)
                    AnimatedSize(
                      duration: const Duration(milliseconds: 280),
                      curve: Curves.easeOutCubic,
                      alignment: Alignment.topCenter,
                      child: _digits.isEmpty
                          ? const SizedBox(width: 1, height: 0)
                          : SizedBox(
                              height: 34,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Flexible(child: AnimatedSwitcher(
                                    duration: const Duration(milliseconds: 180),
                                    transitionBuilder: (child, animation) => FadeTransition(opacity: animation, child: SlideTransition(position: Tween<Offset>(begin: const Offset(0, .12), end: Offset.zero).animate(animation), child: child)),
                                    child: Text(_digits, key: ValueKey(_digits), maxLines: 1, overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white)),
                                  )),
                                  IconButton(
                                    padding: EdgeInsets.zero,
                                    constraints: const BoxConstraints.tightFor(width: 30, height: 30),
                                    onPressed: _onBackspace,
                                    icon: const Icon(Icons.backspace_outlined, color: Colors.white70, size: 18),
                                  ),
                                ],
                              ),
                            ),
                    )
                  else if (!widget.overlay)
                    Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: _digits.isEmpty
                            ? const FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  'Dial number',
                                  style: TextStyle(
                                    fontSize: 38,
                                    fontWeight: FontWeight.w300,
                                    letterSpacing: 0.5,
                                    color: Color(0xFF454550),
                                  ),
                                ),
                              )
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: AnimatedSwitcher(
                                      duration: const Duration(milliseconds: 260),
                                      switchInCurve: Curves.easeOutCubic,
                                      switchOutCurve: Curves.easeInCubic,
                                      transitionBuilder: (child, animation) {
                                        final slide = Tween<Offset>(
                                          begin: const Offset(0.0, 0.12),
                                          end: Offset.zero,
                                        ).animate(CurvedAnimation(
                                          parent: animation,
                                          curve: Curves.easeOutCubic,
                                        ));
                                        final scale = Tween<double>(
                                          begin: 0.96,
                                          end: 1.0,
                                        ).animate(CurvedAnimation(
                                          parent: animation,
                                          curve: Curves.easeOutCubic,
                                        ));
                                        return SlideTransition(
                                          position: slide,
                                          child: FadeTransition(
                                            opacity: animation,
                                            child: ScaleTransition(
                                              scale: scale,
                                              child: child,
                                            ),
                                          ),
                                        );
                                      },
                                      child: Text(
                                        _digits,
                                        key: ValueKey<String>(_digits),
                                        style: const TextStyle(
                                          fontSize: 42,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 2.2,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                  if (matches.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.08),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(color: Colors.white12),
                                      ),
                                      child: Text(
                                        '${matches.first.name} • ${matches.first.number}',
                                        style: const TextStyle(color: Color(0xFF00E676), fontSize: 13, fontWeight: FontWeight.w500),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                      ),
                    ),
                  ),

                  // Unified 5-row keypad: the final row is part of the keypad grid,
                  // not a detached bottom action bar.
                  Padding(
                    padding: EdgeInsets.fromLTRB(widget.overlay ? 10 : 30, 0, widget.overlay ? 10 : 30, widget.overlay ? 8 : 10),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildKeyRow(['1', '2', '3'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['4', '5', '6'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['7', '8', '9'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['*', '0', '#'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        SizedBox(
                          height: (keyDiameter * 0.76).clamp(56.0, 72.0).toDouble(),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              RealmeActionButton(
                                size: (keyDiameter * 0.62).clamp(48.0, 60.0).toDouble(),
                                color: const Color(0xFF123B2A),
                                borderColor: const Color(0xFF25D366).withOpacity(0.28),
                                shadowColor: Colors.transparent,
                                onTap: () async {
                                  if (_digits.isEmpty) return;
                                  RealmeOHaptics.microTick();
                                  final clean = _digits.replaceAll(RegExp(r'[^\d+]'), '');
                                  final uri = Uri.parse('https://wa.me/$clean');
                                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                                },
                                child: const Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 23),
                              ),
                              RealmeActionButton(
                                size: (keyDiameter * 0.72).clamp(58.0, 68.0).toDouble(),
                                color: const Color(0xFF075E35),
                                borderColor: const Color(0xFF168A50),
                                shadowColor: Colors.transparent,
                                isCallButton: true,
                                onTap: _digits.isEmpty ? () {} : () => widget.onCallNumber(_digits, simSlot: 1),
                                child: const Icon(Icons.call_rounded, color: Colors.white, size: 29),
                              ),
                              RealmeActionButton(
                                size: (keyDiameter * 0.62).clamp(48.0, 60.0).toDouble(),
                                color: const Color(0xFF252932),
                                borderColor: Colors.white.withOpacity(0.20),
                                shadowColor: const Color(0xFF00E676).withOpacity(0.95),
                                glowOnPress: true,
                                onTap: _onBackspace,
                                onLongPress: _onClearAll,
                                child: const Icon(Icons.backspace_outlined, color: Colors.white, size: 23),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      );
    return widget.overlay
        ? dialpadContent
        : Scaffold(
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            body: dialpadContent,
          );
  }

  Widget _buildKeyRow(List<String> keys, double diameter) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: keys.map((k) {
        final letters = _t9Map[k] ?? '';
        final onLongPress = () {
          if (k == '0') {
            _onDigitPress('+');
          } else if (k == '1') {
            AppHaptics.heavyImpact();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Calling Voicemail (*123#)...')),
            );
            widget.onCallNumber('*123#', simSlot: 1);
          } else {
            final intKey = int.tryParse(k);
            if (intKey != null && intKey >= 2 && intKey <= 9) {
              final entry = SpeedDialService.getEntry(intKey);
              if (entry != null) {
                AppHaptics.heavyImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('⚡ Speed Dial #$intKey: Calling ${entry.name} (${entry.number})'),
                    duration: const Duration(seconds: 2),
                  ),
                );
                widget.onCallNumber(entry.number, simSlot: 1);
              }
            }
          }
        };
        if (!widget.overlay) {
          return RealmeDialKey(
            digit: k,
            subLetters: letters,
            size: diameter,
            glowColor: _glowColor,
            onTap: () => _onDigitPress(k),
            onLongPress: onLongPress,
          );
        }
        return Expanded(
          child: Center(
            child: RealmeDialKey(
              digit: k,
              subLetters: letters,
              size: diameter,
              glowColor: _glowColor,
              onTap: () => _onDigitPress(k),
              onLongPress: onLongPress,
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// Matte charcoal dial key with a quick bright-white flash and radial halo.
class RealmeDialKey extends StatefulWidget {
  final String digit;
  final String subLetters;
  final double size;
  final Color glowColor;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const RealmeDialKey({
    super.key,
    required this.digit,
    required this.subLetters,
    required this.size,
    this.glowColor = Colors.white,
    required this.onTap,
    this.onLongPress,
  });

  @override
  State<RealmeDialKey> createState() => _RealmeDialKeyState();
}

class _RealmeDialKeyState extends State<RealmeDialKey>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rippleAnimation;
  Timer? _longPressTimer;
  bool _longPressTriggered = false;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      // Keep the bright white flash visible for half a second.
      duration: const Duration(milliseconds: 500),
    );

    // A quick zoom-IN on touch, followed by a smooth return to normal size.
    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 1.085)
            .chain(CurveTween(curve: Curves.easeOutCubic)),
        weight: 34,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.085, end: 1.0)
            .chain(CurveTween(curve: Curves.easeOutBack)),
        weight: 66,
      ),
    ]).animate(_animController);

    // The glow blooms quickly, then fades continuously for the full 500 ms.
    _rippleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.0, end: 1.0)
            .chain(CurveTween(curve: Curves.easeOutCubic)),
        weight: 12,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 0.0)
            .chain(CurveTween(curve: Curves.easeInCubic)),
        weight: 88,
      ),
    ]).animate(_animController);
  }

  @override
  void dispose() {
    _longPressTimer?.cancel();
    _animController.dispose();
    super.dispose();
  }

  void _onPointerDown(PointerDownEvent event) {
    _longPressTriggered = false;
    _animController.forward(from: 0.0);
    RealmeOHaptics.microTick();
    if (widget.onLongPress != null) {
      _longPressTimer?.cancel();
      _longPressTimer = Timer(const Duration(milliseconds: 650), () {
        _longPressTriggered = true;
        RealmeOHaptics.heavyConfirm();
        widget.onLongPress!();
      });
    }
  }

  void _onPointerUp(PointerUpEvent event) {
    _longPressTimer?.cancel();
    if (!_longPressTriggered) widget.onTap();
  }

  void _onPointerCancel(PointerCancelEvent event) {
    _longPressTimer?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: _onPointerDown,
      onPointerUp: _onPointerUp,
      onPointerCancel: _onPointerCancel,
      child: AnimatedBuilder(
        animation: _animController,
        builder: (context, child) {
          final ripple = _rippleAnimation.value;
          return Transform.scale(
            scale: _scaleAnimation.value,
            alignment: Alignment.center,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.62),
                    offset: const Offset(0, 4),
                    blurRadius: 7,
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.045),
                    blurRadius: 5,
                    spreadRadius: 0.2,
                  ),
                  // Bright white flash ring, matching the supplied reference video.
                  // It blooms immediately and disappears within the 500 ms press.
                  BoxShadow(
                    color: widget.glowColor.withOpacity(0.98 * ripple),
                    offset: Offset.zero,
                    blurRadius: 24 * ripple,
                    spreadRadius: 3.0 * ripple,
                  ),
                  BoxShadow(
                    color: widget.glowColor.withOpacity(0.72 * ripple),
                    offset: Offset.zero,
                    blurRadius: 39 * ripple,
                    spreadRadius: 6.0 * ripple,
                  ),
                  BoxShadow(
                    color: widget.glowColor.withOpacity(0.70 * ripple),
                    offset: Offset(0, 2 * ripple),
                    blurRadius: 13 * ripple,
                    spreadRadius: 1.5 * ripple,
                  ),
                ],
              ),
              child: ClipOval(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Color(0xFF41434A),
                            Color(0xFF303138),
                            Color(0xFF24252B),
                          ],
                          stops: [0.0, 0.48, 1.0],
                        ),
                        border: Border.all(
                          color: const Color(0xFF55565D),
                          width: 1.15,
                        ),
                      ),
                    ),
                    // A sharp white radial flash blooms across the key face
                    // like the supplied video, then fades with the outer halo.
                    if (ripple > 0.01)
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            center: Alignment.center,
                            radius: 0.88,
                            colors: [
                              widget.glowColor.withOpacity(0.46 * ripple),
                              widget.glowColor.withOpacity(0.23 * ripple),
                              Colors.white.withOpacity(0.0),
                            ],
                            stops: const [0.0, 0.48, 1.0],
                          ),
                        ),
                      ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          widget.digit,
                          style: TextStyle(
                            fontSize: widget.size >= 72
                                ? 33
                                : (widget.size >= 64 ? 29 : 25),
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                            height: 1.0,
                          ),
                        ),
                        if (widget.subLetters.isNotEmpty) ...[
                          const SizedBox(height: 2),
                          Text(
                            widget.subLetters,
                            style: const TextStyle(
                              fontSize: 8.5,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFFB9BAC0),
                              letterSpacing: 1.35,
                              height: 1.0,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Realme UI 7.0 Circular Action Button (Call / Backspace) with matching 0.86 squash & pulse
class RealmeActionButton extends StatefulWidget {
  final double size;
  final Color color;
  final Color? borderColor;
  final Color? shadowColor;
  final bool isCallButton;
  final bool glowOnPress;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final Widget child;

  const RealmeActionButton({
    super.key,
    required this.size,
    required this.color,
    this.borderColor,
    this.shadowColor,
    this.isCallButton = false,
    this.glowOnPress = false,
    required this.onTap,
    this.onLongPress,
    required this.child,
  });

  @override
  State<RealmeActionButton> createState() => _RealmeActionButtonState();
}

class _RealmeActionButtonState extends State<RealmeActionButton> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 240),
    );
    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 0.86).chain(CurveTween(curve: Curves.easeOutQuad)),
        weight: 35.0,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.86, end: 1.0).chain(CurveTween(curve: Curves.easeOutBack)),
        weight: 65.0,
      ),
    ]).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTap() {
    _controller.forward(from: 0.0);
    if (widget.isCallButton) {
      RealmeOHaptics.solidThud();
    } else {
      RealmeOHaptics.deleteTick();
    }
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _handleTap,
      onLongPress: widget.onLongPress,
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          final double pulse = (1.0 - (2.0 * _controller.value - 1.0).abs()).clamp(0.0, 1.0).toDouble();
          return Transform.scale(
            scale: _scaleAnimation.value,
            alignment: Alignment.center,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.color,
                border: widget.borderColor != null ? Border.all(color: widget.borderColor!, width: 1.4) : null,
                boxShadow: [
                  BoxShadow(
                    color: (widget.shadowColor ?? Colors.black.withOpacity(0.35)).withOpacity(
                      (widget.shadowColor ?? Colors.black.withOpacity(0.35)).opacity * (widget.glowOnPress ? pulse : 1.0),
                    ),
                    blurRadius: widget.glowOnPress ? 20 * pulse : (widget.isCallButton ? 34 : 24),
                    spreadRadius: widget.glowOnPress ? 4 * pulse : (widget.isCallButton ? 7 : 3),
                  ),
                ],
              ),
              child: Center(child: widget.child),
            ),
          );
        },
      ),
    );
  }
}
