import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/call_record.dart';
import '../services/blocked_numbers_service.dart';
import '../services/call_data_service.dart';

class CallDetailBottomSheet extends StatefulWidget {
  final CallRecord call;
  final Function(String number) onCallNumber;
  final Function(String id) onDeleteCall;
  final List<CallRecord> allCalls;
  final Future<void> Function(String id, String note, String category)? onSaveMetadata;

  const CallDetailBottomSheet({
    super.key,
    required this.call,
    required this.onCallNumber,
    required this.onDeleteCall,
    this.allCalls = const [],
    this.onSaveMetadata,
  });

  @override
  State<CallDetailBottomSheet> createState() => _CallDetailBottomSheetState();
}

class _CallDetailBottomSheetState extends State<CallDetailBottomSheet> {
  late String _category;
  late TextEditingController _noteController;
  bool _copied = false;
  late TextEditingController _tagsController;
  List<String> _tags = [];
  List<CallRecord> _numberHistory = []; 
  final List<String> _categories = ['Personal', 'Work', 'Finance', 'Family', 'VIP', 'Spam'];

  @override
  void initState() {
    super.initState();
    _category = widget.call.category;
    _noteController = TextEditingController(text: widget.call.note ?? '');
    _tagsController = TextEditingController();
    final normalized = CallDataService.normalizeNumber(widget.call.number);
    _numberHistory = widget.allCalls.where((c) => CallDataService.normalizeNumber(c.number) == normalized).toList()..sort((a,b) => b.timestamp.compareTo(a.timestamp));
    CallDataService.getNumberMetadata(widget.call.number).then((data) {
      if (!mounted) return;
      if (_noteController.text.isEmpty && data['note'] is String) _noteController.text = data['note'] as String;
      _tags = (data['tags'] as List? ?? []).map((e) => e.toString()).toList();
      _tagsController.text = _tags.join(', ');
      setState(() {});
    });
    CallDataService.getCallMetadata(widget.call.id).then((data) {
      if (!mounted) return;
      if (_noteController.text.isEmpty && data['note'] is String) _noteController.text = data['note'] as String;
      if (data['category'] is String && _categories.contains(data['category'])) setState(() => _category = data['category'] as String);
    });
  }

  Future<void> _saveCallDetails() async {
    final note = _noteController.text.trim();
    _tags = _tagsController.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList();
    await CallDataService.saveNumberMetadata(widget.call.number, note: note, tags: _tags);
    await CallDataService.saveCallMetadata(widget.call.id, note: note, category: _category);
    await widget.onSaveMetadata?.call(widget.call.id, note, _category);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Call note and category saved')));
  }

  @override
  void dispose() {
    _noteController.dispose();
    _tagsController.dispose();
    super.dispose();
  }

  void _copyNumber() {
    Clipboard.setData(ClipboardData(text: widget.call.number));
    HapticFeedback.lightImpact();
    setState(() => _copied = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  void _openWhatsApp() async {
    final clean = widget.call.number.replaceAll(RegExp(r'[^\d]'), '');
    final uri = Uri.parse('https://wa.me/$clean');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  void _sendSms() async {
    final uri = Uri(scheme: 'sms', path: widget.call.number);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _toggleBlockNumber() async {
    final isBlocked = BlockedNumbersService.isBlocked(widget.call.number);
    if (isBlocked) {
      await BlockedNumbersService.unblockNumber(widget.call.number);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unblocked ${widget.call.number}')),
      );
    } else {
      await BlockedNumbersService.blockNumber(widget.call.number);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Blocked ${widget.call.number} and added to spam list')),
      );
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final isMissed = widget.call.type == CallType.missed || widget.call.type == CallType.rejected;
    final isBlocked = BlockedNumbersService.isBlocked(widget.call.number);

    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF1E1A26),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(top: BorderSide(color: Colors.white24, width: 1)),
      ),
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Drag handle
          Center(
            child: Container(
              width: 38,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Header: Avatar, Name, Number, Copy
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: isMissed ? Colors.red.withOpacity(0.2) : const Color(0xFF10B981).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: isMissed ? Colors.redAccent.withOpacity(0.4) : const Color(0xFF10B981).withOpacity(0.4),
                  ),
                ),
                child: Center(
                  child: Text(
                    widget.call.name.isNotEmpty ? widget.call.name[0].toUpperCase() : '?',
                    style: TextStyle(
                      color: isMissed ? Colors.redAccent : const Color(0xFF10B981),
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            widget.call.name,
                            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (isBlocked) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFFEF4444).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              'BLOCKED',
                              style: TextStyle(color: Color(0xFFEF4444), fontSize: 9, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Text(
                          widget.call.number,
                          style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 13),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: _copyNumber,
                          child: Icon(
                            _copied ? Icons.check_circle : Icons.copy,
                            size: 14,
                            color: _copied ? const Color(0xFF10B981) : Colors.white38,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 18),

          // Details Grid (Type, Carrier, Duration, Time)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white10),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildInfoItem(
                  'Type',
                  isMissed ? 'Missed' : widget.call.type == CallType.outgoing ? 'Outgoing' : 'Incoming',
                  isMissed ? Colors.redAccent : const Color(0xFF10B981),
                ),
                _buildInfoItem('Carrier', 'SIM ${widget.call.simSlot} (${widget.call.simCarrier})', Colors.white),
                _buildInfoItem('Duration', widget.call.durationString, Colors.white),
                _buildInfoItem('Time', widget.call.timeFormatted, Colors.white70),
              ],
            ),
          ),

          if (_numberHistory.isNotEmpty) ...[
            const SizedBox(height: 14),
            Text('Complete call history • ${_numberHistory.length}', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Container(
              constraints: const BoxConstraints(maxHeight: 170),
              padding: const EdgeInsets.symmetric(vertical: 4),
              decoration: BoxDecoration(color: Colors.white.withOpacity(.045), borderRadius: BorderRadius.circular(14)),
              child: ListView.builder(shrinkWrap: true, itemCount: _numberHistory.length, itemBuilder: (_, i) {
                final item = _numberHistory[i];
                final missed = item.type == CallType.missed || item.type == CallType.rejected;
                return ListTile(dense: true, leading: Icon(item.type == CallType.outgoing ? Icons.call_made : missed ? Icons.call_missed : Icons.call_received, color: missed ? Colors.redAccent : const Color(0xFF10B981), size: 18), title: Text(item.type.name.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 11)), subtitle: Text('${item.dateLabel} • ${item.timeFormatted} • ${item.durationString}', style: const TextStyle(color: Colors.white54, fontSize: 10)));
              }),
            ),
          ],

          // Smart Grouped Missed Calls History
          if (widget.call.repeatCount > 1 && widget.call.groupedSubCalls != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.08),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.redAccent.withOpacity(0.25)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.auto_awesome, color: Color(0xFFF87171), size: 14),
                      const SizedBox(width: 6),
                      Text(
                        'Smart Grouped: ${widget.call.repeatCount} Missed Calls',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ...widget.call.groupedSubCalls!.map((subCall) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.call_missed, color: Colors.redAccent, size: 13),
                            const SizedBox(width: 6),
                            Text(
                              subCall.dateLabel,
                              style: const TextStyle(color: Colors.white70, fontSize: 11.5),
                            ),
                          ],
                        ),
                        Text(
                          subCall.timeFormatted,
                          style: const TextStyle(color: Colors.white60, fontSize: 11.5, fontFamily: 'monospace'),
                        ),
                      ],
                    ),
                  )),
                ],
              ),
            ),
          ],

          const SizedBox(height: 14),

          // Quick Action Bar: WhatsApp, SMS, Block, Delete
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildQuickPill(
                icon: Icons.chat_bubble_outline,
                label: 'WhatsApp',
                color: const Color(0xFF25D366),
                onTap: _openWhatsApp,
              ),
              _buildQuickPill(
                icon: Icons.sms_outlined,
                label: 'Message',
                color: const Color(0xFF38BDF8),
                onTap: _sendSms,
              ),
              _buildQuickPill(
                icon: isBlocked ? Icons.check : Icons.block,
                label: isBlocked ? 'Unblock' : 'Block',
                color: const Color(0xFFEF4444),
                onTap: _toggleBlockNumber,
              ),
              _buildQuickPill(
                icon: Icons.delete_outline,
                label: 'Delete',
                color: Colors.white54,
                onTap: () {
                  Navigator.pop(context);
                  widget.onDeleteCall(widget.call.id);
                },
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Smart Category Chips
          const Text('Category', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          SizedBox(
            height: 32,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 6),
              itemBuilder: (context, i) {
                final cat = _categories[i];
                final isSel = _category == cat;
                return GestureDetector(
                  onTap: () => setState(() => _category = cat),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: isSel ? const Color(0xFF10B981) : Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        cat,
                        style: TextStyle(
                          color: isSel ? Colors.black : Colors.white70,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 16),
          const Text('Call Note', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 7),
          TextField(
            controller: _noteController,
            minLines: 2,
            maxLines: 4,
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Add a note for this call...', hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
              filled: true, fillColor: Colors.white.withOpacity(0.06),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.all(12),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Tags (comma separated)', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 7),
          TextField(controller: _tagsController, style: const TextStyle(color: Colors.white, fontSize: 13), decoration: InputDecoration(hintText: 'VIP, Work, Follow-up', hintStyle: const TextStyle(color: Colors.white30, fontSize: 12), filled: true, fillColor: Colors.white.withOpacity(.06), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none), contentPadding: const EdgeInsets.all(12))),
          if (_tags.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Wrap(spacing: 6, runSpacing: 6, children: _tags.map((tag) => Chip(label: Text(tag, style: const TextStyle(fontSize: 10)), visualDensity: VisualDensity.compact, backgroundColor: const Color(0xFF10B981).withOpacity(.18))).toList())),
          const SizedBox(height: 9),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(
            onPressed: _saveCallDetails,
            icon: const Icon(Icons.save_outlined, size: 16),
            label: const Text('Save Note, Tags & Category'),
            style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF10B981), side: const BorderSide(color: Color(0xFF10B981))),
          )),
          const SizedBox(height: 12),

          // Call Buttons Row (Direct SIM 1 & SIM 2)
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    widget.onCallNumber(widget.call.number);
                  },
                  icon: const Icon(Icons.call, size: 16),
                  label: const Text('Call SIM 1', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF10B981),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    widget.onCallNumber(widget.call.number);
                  },
                  icon: const Icon(Icons.call, size: 16),
                  label: const Text('Call SIM 2', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF38BDF8),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ],
          ),
        ],
      )),
    );
  }

  Widget _buildQuickPill({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 4),
            Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(label, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10)),
        const SizedBox(height: 2),
        Text(value, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
      ],
    );
  }
}
