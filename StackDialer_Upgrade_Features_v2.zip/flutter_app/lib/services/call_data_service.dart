import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/call_record.dart';

/// Durable per-call metadata, callback reminders and portable JSON backup.
class CallDataService {
  static const MethodChannel _channel = MethodChannel('com.stackdialer.app/telecom');
  static const String _metadataKey = 'stackdialer_call_metadata_v1';
  static const String _remindersKey = 'stackdialer_callback_reminders_v1';
  static const String _historyKey = 'stackdialer_local_call_history_v1';
  static const String _numberMetadataKey = 'stackdialer_number_metadata_v1';
  static final ValueNotifier<int> reminderRevision = ValueNotifier<int>(0);

  static Future<Map<String, dynamic>> _readMap(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.isEmpty) return {};
    try {
      final decoded = jsonDecode(raw);
      return decoded is Map<String, dynamic> ? decoded : {};
    } catch (_) { return {}; }
  }

  static Future<void> saveCallMetadata(String callId, {String? note, String? category}) async {
    final data = await _readMap(_metadataKey);
    final existing = Map<String, dynamic>.from(data[callId] is Map ? data[callId] as Map : {});
    if (note != null) existing['note'] = note.trim();
    if (category != null) existing['category'] = category;
    existing['updatedAt'] = DateTime.now().toIso8601String();
    data[callId] = existing;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_metadataKey, jsonEncode(data));
  }

  static Future<Map<String, dynamic>> getCallMetadata(String callId) async {
    final data = await _readMap(_metadataKey);
    final value = data[callId];
    return value is Map ? Map<String, dynamic>.from(value) : {};
  }

  static String normalizeNumber(String number) => number.replaceAll(RegExp(r'[^0-9]'), '').replaceFirst(RegExp(r'^91(?=.{10}$)'), '');

  /// Notes and tags belong to a phone number, not to an individual call row.
  static Future<void> saveNumberMetadata(String number, {String? note, List<String>? tags}) async {
    final key = normalizeNumber(number);
    if (key.isEmpty) return;
    final data = await _readMap(_numberMetadataKey);
    final existing = Map<String, dynamic>.from(data[key] is Map ? data[key] as Map : {});
    if (note != null) existing['note'] = note.trim();
    if (tags != null) existing['tags'] = tags.map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList();
    existing['updatedAt'] = DateTime.now().toIso8601String();
    data[key] = existing;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_numberMetadataKey, jsonEncode(data));
  }

  static Future<Map<String, dynamic>> getNumberMetadata(String number) async {
    final key = normalizeNumber(number);
    if (key.isEmpty) return {};
    final data = await _readMap(_numberMetadataKey);
    final value = data[key];
    return value is Map ? Map<String, dynamic>.from(value) : {};
  }

  static Future<bool> deleteDeviceCallLog(String id) async {
    try { return await _channel.invokeMethod<bool>('deleteCallLog', {'id': id}) ?? false; }
    on PlatformException { return false; }
  }

  static Future<List<Map<String, dynamic>>> getDeletedDeviceCallLogs() async {
    try {
      final raw = await _channel.invokeMethod<String>('getDeletedCallLogs');
      final decoded = jsonDecode(raw ?? '[]');
      return decoded is List ? decoded.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];
    } catch (_) { return []; }
  }

  static Future<String?> restoreDeletedDeviceCallLog(String id) async {
    try { return await _channel.invokeMethod<String>('restoreDeletedCallLog', {'id': id}); }
    catch (_) { return null; }
  }

  static Future<void> deleteSavedCall(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final rows = await loadSavedCalls();
    await prefs.setString(_historyKey, jsonEncode(rows.where((c) => c.id != id).map(_callToJson).toList()));
  }

  static Future<void> saveCompletedCall(CallRecord call) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_historyKey);
    List<dynamic> rows = [];
    try { final value = jsonDecode(raw ?? '[]'); if (value is List) rows = value; } catch (_) {}
    rows.removeWhere((item) => item is Map && item['id'] == call.id);
    rows.insert(0, _callToJson(call));
    if (rows.length > 2000) rows = rows.take(2000).toList();
    await prefs.setString(_historyKey, jsonEncode(rows));
  }

  static Future<List<CallRecord>> loadSavedCalls() async {
    final prefs = await SharedPreferences.getInstance();
    try {
      final raw = jsonDecode(prefs.getString(_historyKey) ?? '[]');
      if (raw is! List) return [];
      return raw.whereType<Map>().map((m) => _callFromJson(Map<String, dynamic>.from(m))).whereType<CallRecord>().toList();
    } catch (_) { return []; }
  }

  static Future<bool> scheduleCallbackReminder({required String callId, required String name, required String number, required DateTime at, required String label}) async {
    if (at.isBefore(DateTime.now().add(const Duration(seconds: 5)))) return false;
    // Android 13+ requires notification permission; Android 12+ may require exact-alarm access.
    if (!await Permission.notification.isGranted) {
      final status = await Permission.notification.request();
      if (!status.isGranted) return false;
    }
    try {
      final exactAllowed = await _channel.invokeMethod<bool>('requestExactAlarmPermission') ?? false;
      if (!exactAllowed) return false;
    } catch (_) { return false; }
    final id = '${callId}_${at.millisecondsSinceEpoch}';
    final item = {'id': id, 'callId': callId, 'name': name, 'number': number, 'at': at.toIso8601String(), 'label': label};
    try {
      final scheduled = await _channel.invokeMethod<bool>('scheduleCallbackReminder', {
        'id': id, 'name': name, 'number': number, 'atMillis': at.millisecondsSinceEpoch, 'label': label,
      }) ?? false;
      if (!scheduled) return false;
      final prefs = await SharedPreferences.getInstance();
      final reminders = await _readMap(_remindersKey);
      reminders[id] = item;
      await prefs.setString(_remindersKey, jsonEncode(reminders));
      reminderRevision.value++;
      return true;
    } on PlatformException catch (_) {
      return false;
    }
  }

  static Future<List<Map<String, dynamic>>> loadReminders() async {
    final data = await _readMap(_remindersKey);
    final now = DateTime.now();
    data.removeWhere((key, value) {
      final at = value is Map ? DateTime.tryParse(value['at']?.toString() ?? '') : null;
      return at == null || !at.isAfter(now);
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_remindersKey, jsonEncode(data));
    return data.values.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
      ..sort((a, b) => (a['at'] ?? '').toString().compareTo((b['at'] ?? '').toString()));
  }

  static Future<void> cancelReminder(String id) async {
    final reminders = await _readMap(_remindersKey);
    reminders.remove(id);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_remindersKey, jsonEncode(reminders));
    reminderRevision.value++;
    try { await _channel.invokeMethod('cancelCallbackReminder', {'id': id}); } catch (_) {}
  }

  static Future<bool> exportBackup(List<CallRecord> calls) async {
    final prefs = await SharedPreferences.getInstance();
    final payload = {
      'format': 'StackDialerBackup', 'version': 1, 'createdAt': DateTime.now().toIso8601String(),
      'calls': calls.map(_callToJson).toList(),
      'localCalls': (await loadSavedCalls()).map(_callToJson).toList(),
      'metadata': await _readMap(_metadataKey),
      'numberMetadata': await _readMap(_numberMetadataKey),
      'reminders': await _readMap(_remindersKey),
      'settings': prefs.getKeys().where((k) => k.startsWith('stackdialer_') || k.startsWith('reminder_')).fold<Map<String, dynamic>>({}, (m, k) { final v = prefs.get(k); if (v is String || v is bool || v is int || v is double) m[k] = v; return m; }),
    };
    try { return await _channel.invokeMethod<bool>('exportBackup', {'json': jsonEncode(payload)}) ?? false; }
    catch (_) { return false; }
  }

  static Future<Map<String, dynamic>?> importBackup() async {
    try {
      final raw = await _channel.invokeMethod<String>('importBackup');
      if (raw == null || raw.isEmpty) return null;
      final decoded = jsonDecode(raw);
      if (decoded is! Map || decoded['format'] != 'StackDialerBackup' || decoded['version'] != 1) return null;
      final prefs = await SharedPreferences.getInstance();
      if (decoded['metadata'] is Map) await prefs.setString(_metadataKey, jsonEncode(decoded['metadata']));
      if (decoded['numberMetadata'] is Map) await prefs.setString(_numberMetadataKey, jsonEncode(decoded['numberMetadata']));
      if (decoded['reminders'] is Map) {
        final reminders = Map<String, dynamic>.from(decoded['reminders']);
        await prefs.setString(_remindersKey, jsonEncode(reminders));
        reminderRevision.value++;
        for (final item in reminders.values.whereType<Map>()) {
          final at = DateTime.tryParse(item['at']?.toString() ?? '');
          if (at != null && at.isAfter(DateTime.now())) {
            try { await _channel.invokeMethod('scheduleCallbackReminder', {'id': item['id'], 'name': item['name'], 'number': item['number'], 'atMillis': at.millisecondsSinceEpoch, 'label': item['label'] ?? 'Callback'}); } catch (_) {}
          }
        }
      }
      final restoredRows = <dynamic>[];
      if (decoded['localCalls'] is List) restoredRows.addAll(decoded['localCalls'] as List);
      if (decoded['calls'] is List) restoredRows.addAll(decoded['calls'] as List);
      if (restoredRows.isNotEmpty) {
        final byId = <String, dynamic>{};
        for (final row in restoredRows.whereType<Map>()) {
          final id = row['id']?.toString() ?? '${row['number']}_${row['timestamp']}';
          byId[id] = row;
        }
        await prefs.setString(_historyKey, jsonEncode(byId.values.toList()));
      }
      if (decoded['settings'] is Map) {
        final settings = Map<String, dynamic>.from(decoded['settings']);
        for (final entry in settings.entries) {
          final value = entry.value;
          if (value is String) await prefs.setString(entry.key, value);
          else if (value is bool) await prefs.setBool(entry.key, value);
          else if (value is int) await prefs.setInt(entry.key, value);
          else if (value is double) await prefs.setDouble(entry.key, value);
        }
      }
      return Map<String, dynamic>.from(decoded);
    } catch (_) { return null; }
  }

  static Map<String, dynamic> _callToJson(CallRecord c) => {
    'id': c.id, 'name': c.name, 'number': c.number, 'type': c.type.name,
    'timestamp': c.timestamp.toIso8601String(), 'durationSeconds': c.durationSeconds,
    'simSlot': c.simSlot, 'simCarrier': c.simCarrier, 'note': c.note,
    'reminderTime': c.reminderTime, 'category': c.category, 'location': c.location,
    'repeatCount': c.repeatCount,
  };

  static CallRecord? _callFromJson(Map<String, dynamic> m) {
    final timestamp = DateTime.tryParse(m['timestamp']?.toString() ?? '');
    if (timestamp == null || (m['number']?.toString().isEmpty ?? true)) return null;
    final typeName = m['type']?.toString() ?? 'incoming';
    final type = CallType.values.firstWhere((e) => e.name == typeName, orElse: () => CallType.incoming);
    return CallRecord(
      id: m['id']?.toString() ?? 'import_${timestamp.microsecondsSinceEpoch}',
      name: m['name']?.toString() ?? m['number'].toString(), number: m['number'].toString(),
      type: type, timestamp: timestamp, durationSeconds: (m['durationSeconds'] as num?)?.toInt() ?? 0,
      simSlot: (m['simSlot'] as num?)?.toInt() ?? 1, simCarrier: m['simCarrier']?.toString() ?? 'SIM 1',
      note: m['note']?.toString(), reminderTime: m['reminderTime']?.toString(),
      category: m['category']?.toString() ?? 'Personal', location: m['location']?.toString() ?? 'Mobile',
      repeatCount: (m['repeatCount'] as num?)?.toInt() ?? 1,
    );
  }
}
