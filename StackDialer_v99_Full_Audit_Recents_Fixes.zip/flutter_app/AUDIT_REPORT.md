# StackDialer v99 — Full Source Audit & Recents Fixes

## Scope reviewed

- 21 Dart source files (approximately 10.6k lines)
- Android Kotlin telecom, call-log, notification and reminder integration
- Android manifest and permissions
- Flutter dependencies and assets
- Android Gradle configuration and GitHub Actions build workflow

This is a source-level audit. Device-only behavior (real SIM routing, Android CallLog provider permissions, alarm delivery, notification presentation and visual animation quality) still requires testing on the target phone.

## Changes applied in this ZIP

1. **Call Button colour persistence:** load saved Call Button, bottom navigation pill, floating dialpad and keypad-glow colours before `runApp()`. The app no longer waits for Settings to be opened before restoring the saved colours.
2. **Recents contact photos:** the normal/default Recents card style now displays saved profile photos as well as the DHSES and Bottom Dock styles. The existing initials and card styling remain as the fallback.
3. **Photo scroll performance:** Base64 photo decoding is prewarmed through a worker isolate before the photo map is announced to the screens. Stable `MemoryImage` providers and gapless playback are used to reduce photo-related card rebuild flicker/jank.
4. **Full phone number in DHSES cards:** the number uses scale-down fitting rather than ellipsis so a 12-digit number is not silently cut off when the card narrows.
5. **Call deletion / Undo:** local completed-call IDs and Android CallLog provider IDs are now kept separately when matching records are merged. Matching accounts for the local record being timestamped at hang-up while Android stores the call-log timestamp near call start. Deleting a merged card targets the real Android row and removes its local record; Undo restores the Android row and its local metadata record.
6. **Default Calling SIM:** `SIM 1`, `SIM 2` and `Always Ask` preferences are now applied when calls are placed from the dialpad, Recents and contact actions. Outgoing call records also retain the selected SIM slot.
7. **Call details readability:** the sheet text scaler is now 1.05 (5% larger); the sheet remains scrollable and its information rows allow wrapping.
8. **Backup settings:** the keypad glow preference (`dialpad_glow_color_v2`) is now included in backup export/restore settings.

## Recents checklist — source status

| Area | Source audit result |
|---|---|
| All / Missed filters | Present |
| Smart missed-call grouping | Present; default is enabled and controlled in Settings |
| 17 card styles and saved style selection | Present |
| DHSES horizontal card-width shrink / reverse expansion | Present in the style transform code; visual smoothness needs device/video verification |
| Style 17 Bottom Dock Flow preset/studio | Present |
| Saved contact photo in Recents | Fixed for the default style; existing special styles retained |
| Photo decode work during scrolling | Reduced by provider prewarming; profile-photo-heavy scrolling still needs device profiling |
| Full 12-digit number in DHSES | Fixed to scale down rather than ellipsize |
| 12-hour clock | App forces 12-hour formatting; shared clock formatter is used in call/contact history |
| Delete and 5-second Undo | 5-second snackbar exists; provider/local ID merge and restore path fixed in source |
| Call detail sheet | All Call History is above Smart Category; call time/location/SIM rows wrap instead of ellipsizing |
| Call detail profile photo set/remove | Present |
| WhatsApp action | Present with web/app fallback in call details |
| Callback reminder presets/custom date-time | Present |
| Bottom-most card visibility / exact stack positioning | Geometry is implemented, but must be visually verified on the target screen size and with the selected style |

## Other feature audit

| Feature | Source audit result |
|---|---|
| Native outgoing calls | Android Telecom `placeCall` uses the selected `PhoneAccountHandle`; no generic SIM-agnostic fallback |
| Incoming call answer/reject | Native InCallService actions exist; answer controls are hidden while the UI is in the connecting/answering state |
| Speaker, mute, hold, DTMF | Flutter-to-native method-channel paths are present |
| Contacts and favorites | Present |
| Contact photos | Shared photo store used by Contacts, Recents and active-call UI |
| Contact notes/tags/history | Present |
| Speed dial | Persistent keys 1–9 and long-press handling are present |
| Blocked numbers | Native Call Screening implementation exists; actual rejection requires the user to grant Android's Call Screening role |
| Callback reminders | Exact-alarm and notification permission flow, native receiver and boot/time-change rescheduling are present |
| Call metadata / local history | SharedPreferences persistence and JSON conversion are present |
| Backup export/import | Native file-picker channel and JSON payload are present |
| App theme/accent/call-screen style | Persistent appearance service is present |
| Haptics | Persistent haptics toggle/service is present |
| GitHub Actions build | Gradle cache and Maven Central 429 retry backoff are preserved |

## Remaining issues found — not represented as completed

1. **Spam Number Detection is currently only a saved preference.** The Settings switch writes `stackdialer_spam_detection_enabled`, but no spam classifier or detection path reads that key. Explicitly blocked numbers do work through the Call Screening role; that is separate from automatic spam detection.
2. **Per-contact ringtone is currently a saved label/preference only.** The Contacts picker stores a selected name but does not assign an actual Android contact ringtone or play a corresponding sound.
3. **SIM information on imported/native call-log rows is incomplete.** `fetchDeviceCallLogs()` currently assigns `simSlot: 1` and `simCarrier: 'Carrier SIM'`; outgoing calls made through StackDialer now record the selected SIM, but older/incoming native CallLog rows may show an inaccurate SIM slot.
4. **Analytics and Follow-up Tasks screens are present as Dart classes but are not connected to the app's current navigation.** They cannot currently be opened through the two-item Recents/Contacts navigation.
5. **Reminder notification tap routing is incomplete.** The native reminder notification adds `reminder_number` and `reminder_id` extras, but the current MainActivity/Dart startup path does not consume those extras to open the matching reminder/contact action.
6. **Dependency reproducibility:** `pubspec.lock` is not included in this ZIP. `flutter pub get` resolves the declared version ranges at build time, so dependency versions can drift over time.

## Build configuration preserved

- Android Gradle Plugin: **9.3.1**
- Kotlin Gradle Plugin: **2.4.20**
- Gradle wrapper distribution: **9.5.0**
- Java/Kotlin JVM target: **17**
- compileSdk / targetSdk: **36**
- NDK: **28.2.13676358**
- `android.builtInKotlin=false`
- GitHub Actions Gradle dependency cache and Maven 429 exponential backoff retained

## Validation performed

- ZIP source extracted and reviewed.
- Relative Dart imports checked: no missing relative imports found.
- Lightweight Dart delimiter scan: no unmatched/unclosed delimiters found across the 21 Dart files.
- Key source assertions for the persistence, photo, deletion, SIM and backup patches passed.
- Gradle/workflow values checked against the saved successful baseline.

**Not run:** `flutter analyze`, `flutter test`, `flutter build apk`, Kotlin/Android compilation, or physical-device UI/telephony tests. Flutter and Dart SDKs are not installed in this audit environment, and the project currently contains no `test/` directory. The next authoritative compile check is the GitHub Actions build.
