import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/app_haptics.dart';
import '../models/call_record.dart';
import '../services/blocked_numbers_service.dart';
import '../services/call_data_service.dart';


class CallDetailBottomSheet extends StatefulWidget {
  final CallRecord call;
  final Function(String number) onCallNumber;
  final Function(String id) onDeleteCall;
  final List<CallRecord> allCalls;
  final Future<void> Function(String id, String note, String category)? onSaveMetadata;

  const CallDetailBottomSheet({
    super.key,
    required this.call,
    required this.onCallNumber,
    required this.onDeleteCall,
    this.allCalls = const [],
    this.onSaveMetadata,
  });

  @override
  State<CallDetailBottomSheet> createState() => _CallDetailBottomSheetState();
}

class _CallDetailBottomSheetState extends State<CallDetailBottomSheet> {
  static const Color _panel = Color(0xFF24212B);
  static const Color _field = Color(0xFF191720);
  static const Color _cyan = Color(0xFF00AEEF);
  static const Color _muted = Color(0xFF9A98A2);
  static const Color _line = Color(0xFF3A3742);

  late String _category;
  late TextEditingController _noteController;
  late TextEditingController _tagsController;
  final TextEditingController _reminderReasonController = TextEditingController();
  bool _copied = false;
  String? _profilePhotoBase64;
  static const String _profilePhotoKey = 'stackdialer_call_profile_photos_v1';
  bool _noteEditing = false;
  bool _historyExpanded = false;
  bool _reminderExpanded = false;
  String _historyFilter = 'All';
  List<String> _tags = [];
  List<CallRecord> _numberHistory = [];
  List<Map<String, dynamic>> _activeReminders = [];
  DateTime _customReminderAt = DateTime.now().add(const Duration(hours: 1));
  final List<String> _categories = ['Personal', 'Work', 'Finance', 'Delivery', 'Services', 'Spam'];

  @override
  void initState() {
    super.initState();
    _category = _categories.contains(widget.call.category) ? widget.call.category : 'Personal';
    _noteController = TextEditingController(text: widget.call.note ?? '');
    _tagsController = TextEditingController();
    final normalized = CallDataService.normalizeNumber(widget.call.number);
    _numberHistory = widget.allCalls
        .where((c) => CallDataService.normalizeNumber(c.number) == normalized)
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
    _loadMetadata();
    _loadReminders();
    _loadProfilePhoto();
  }

  Future<void> _loadMetadata() async {
    final numberData = await CallDataService.getNumberMetadata(widget.call.number);
    final callData = await CallDataService.getCallMetadata(widget.call.id);
    if (!mounted) return;
    final note = (callData['note'] is String && (callData['note'] as String).isNotEmpty)
        ? callData['note'] as String
        : numberData['note'] as String?;
    if (_noteController.text.isEmpty && note != null) _noteController.text = note;
    _tags = (numberData['tags'] as List? ?? []).map((e) => e.toString()).toList();
    _tagsController.text = _tags.join(', ');
    if (_categories.contains(callData['category'])) _category = callData['category'] as String;
    setState(() {});
  }

  Future<void> _loadReminders() async {
    final rows = await CallDataService.loadReminders();
    if (!mounted) return;
    setState(() {
      _activeReminders = rows.where((r) =>
        r['callId'] == widget.call.id ||
        CallDataService.normalizeNumber(r['number']?.toString() ?? '') ==
            CallDataService.normalizeNumber(widget.call.number)).toList();
    });
  }

  Future<void> _saveCallDetails() async {
    final note = _noteController.text.trim();
    _tags = _tagsController.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList();
    await CallDataService.saveNumberMetadata(widget.call.number, note: note, tags: _tags);
    await CallDataService.saveCallMetadata(widget.call.id, note: note, category: _category);
    await widget.onSaveMetadata?.call(widget.call.id, note, _category);
    if (!mounted) return;
    setState(() => _noteEditing = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Call note, tags and category saved')));
  }

  @override
  void dispose() {
    _noteController.dispose();
    _tagsController.dispose();
    _reminderReasonController.dispose();
    super.dispose();
  }

  void _copyNumber() {
    Clipboard.setData(ClipboardData(text: widget.call.number));
    AppHaptics.lightImpact();
    setState(() => _copied = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  Future<void> _loadProfilePhoto() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_profilePhotoKey);
    if (raw == null || raw.isEmpty) return;
    try {
      final photos = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      final encoded = photos[CallDataService.normalizeNumber(widget.call.number)]?.toString();
      if (mounted && encoded != null && encoded.isNotEmpty) {
        // Validate stored bytes before using them in the avatar decoration.
        base64Decode(encoded);
        setState(() => _profilePhotoBase64 = encoded);
      }
    } catch (_) {}
  }

  Future<void> _pickProfilePhoto() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 82,
        maxWidth: 900,
      );
      if (picked == null) return;
      final key = CallDataService.normalizeNumber(widget.call.number);
      final encoded = base64Encode(await picked.readAsBytes());
      final prefs = await SharedPreferences.getInstance();
      Map<String, dynamic> photos = {};
      try {
        photos = Map<String, dynamic>.from(jsonDecode(prefs.getString(_profilePhotoKey) ?? '{}') as Map);
      } catch (_) {}
      photos[key] = encoded;
      await prefs.setString(_profilePhotoKey, jsonEncode(photos));
      if (mounted) setState(() => _profilePhotoBase64 = encoded);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open gallery or save the profile photo. Please try again.')),
        );
      }
    }
  }

  Future<void> _openWhatsApp() async {
    var clean = widget.call.number.replaceAll(RegExp(r'[^0-9]'), '');
    if (clean.length == 10) clean = '91$clean';
    if (clean.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('This phone number is not valid for WhatsApp.')),
      );
      return;
    }
    final webUri = Uri.parse('https://wa.me/$clean');
    try {
      final opened = await launchUrl(webUri, mode: LaunchMode.externalApplication);
      if (opened) return;
      final appUri = Uri.parse('whatsapp://send?phone=$clean');
      final appOpened = await launchUrl(appUri, mode: LaunchMode.externalApplication);
      if (!appOpened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('WhatsApp could not be opened. Check that WhatsApp is installed.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('WhatsApp could not be opened. Check that WhatsApp is installed.')),
        );
      }
    }
  }

  Future<void> _sendSms() async {
    final uri = Uri(scheme: 'sms', path: widget.call.number);
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  Future<void> _toggleBlockNumber() async {
    final isBlocked = BlockedNumbersService.isBlocked(widget.call.number);
    if (isBlocked) {
      await BlockedNumbersService.unblockNumber(widget.call.number);
    } else {
      await BlockedNumbersService.blockNumber(widget.call.number);
    }
    if (mounted) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(isBlocked ? 'Number unblocked' : 'Number blocked and added to spam list'),
      ));
    }
  }

  Future<void> _scheduleReminder(DateTime at, String label) async {
    if (!at.isAfter(DateTime.now())) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose a future reminder time')));
      return;
    }
    final reason = _reminderReasonController.text.trim();
    final ok = await CallDataService.scheduleCallbackReminder(
      callId: widget.call.id,
      name: widget.call.name,
      number: widget.call.number,
      at: at,
      label: reason.isEmpty ? label : '$label • $reason',
    );
    if (!mounted) return;
    if (ok) {
      _reminderReasonController.clear();
      setState(() => _reminderExpanded = false);
      await _loadReminders();
    }
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(ok ? 'Callback reminder scheduled' : 'Allow notifications and exact alarms, then try again'),
    ));
  }

  Future<void> _pickCustomReminder() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: _customReminderAt.isAfter(now) ? _customReminderAt : now.add(const Duration(days: 1)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 365)),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: const ColorScheme.dark(primary: _cyan, surface: _panel),
        ),
        child: child!,
      ),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_customReminderAt),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: const ColorScheme.dark(primary: _cyan, surface: _panel),
        ),
        child: child!,
      ),
    );
    if (time == null || !mounted) return;
    final at = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    setState(() => _customReminderAt = at);
    await _scheduleReminder(at, 'Custom callback');
  }

  Future<void> _removeReminder(Map<String, dynamic> reminder) async {
    await CallDataService.cancelReminder(reminder['id'].toString());
    await _loadReminders();
  }

  String _formatReminder(DateTime at) {
    final today = DateTime.now();
    final sameDay = at.year == today.year && at.month == today.month && at.day == today.day;
    final tomorrow = at.difference(DateTime(today.year, today.month, today.day)).inDays == 1;
    final time = TimeOfDay.fromDateTime(at).format(context);
    if (sameDay) return 'Today at $time';
    if (tomorrow) return 'Tomorrow at $time';
    return '${at.day.toString().padLeft(2, '0')}/${at.month.toString().padLeft(2, '0')}/${at.year} • $time';
  }

  Widget _sectionHeader(IconData icon, String title, {Color color = _cyan, Widget? trailing}) {
    return Row(children: [
      Icon(icon, color: color, size: 18),
      const SizedBox(width: 9),
      Text(title, style: const TextStyle(color: Color(0xFFE5E4E9), fontSize: 14, fontWeight: FontWeight.w600)),
      const Spacer(),
      if (trailing != null) trailing,
    ]);
  }

  Widget _divider() => const Padding(
    padding: EdgeInsets.symmetric(vertical: 16),
    child: Divider(height: 1, color: _line),
  );

  Widget _categoryChip(String category) {
    final selected = _category == category;
    return GestureDetector(
      onTap: () async {
        setState(() => _category = category);
        await CallDataService.saveCallMetadata(widget.call.id, note: _noteController.text.trim(), category: category);
        await widget.onSaveMetadata?.call(widget.call.id, _noteController.text.trim(), category);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 190),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? _cyan : _field,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: selected ? _cyan : const Color(0xFF302D37)),
          boxShadow: selected ? [BoxShadow(color: _cyan.withOpacity(.24), blurRadius: 12, spreadRadius: 1)] : [],
        ),
        child: Text(category, style: TextStyle(
          color: selected ? Colors.white : const Color(0xFFB7B5BE),
          fontSize: 12, fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
        )),
      ),
    );
  }

  Widget _infoRow(IconData icon, String title, String value, Color iconColor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      decoration: BoxDecoration(color: _field, borderRadius: BorderRadius.circular(15)),
      child: Row(children: [
        Icon(icon, color: iconColor, size: 19),
        const SizedBox(width: 12),
        Text(title, style: const TextStyle(color: _muted, fontSize: 13)),
        const Spacer(),
        Flexible(child: Text(value, textAlign: TextAlign.right, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Color(0xFFE4E2E8), fontSize: 13, fontWeight: FontWeight.w500))),
      ]),
    );
  }

  Widget _reminderPanel() {
    return AnimatedSize(
      duration: const Duration(milliseconds: 260),
      curve: Curves.easeInOutCubic,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (_activeReminders.isNotEmpty) ...[
          Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: _field, borderRadius: BorderRadius.circular(18), border: Border.all(color: _line)),
            child: Column(children: _activeReminders.map((r) {
              final at = DateTime.tryParse(r['at']?.toString() ?? '') ?? DateTime.now();
              return Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Row(children: [
                  Container(width: 38, height: 38, decoration: BoxDecoration(color: _cyan.withOpacity(.16), borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.calendar_month_rounded, color: _cyan, size: 19)),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_formatReminder(at), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    Text(r['label']?.toString() ?? 'Callback reminder', maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: _muted, fontSize: 11)),
                  ])),
                  IconButton(onPressed: () => _removeReminder(r), icon: const Icon(Icons.check_circle_outline, color: _muted, size: 22)),
                ]),
              );
            }).toList()),
          ),
          const SizedBox(height: 10),
        ],
        if (_reminderExpanded) Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: _field, borderRadius: BorderRadius.circular(18), border: Border.all(color: _cyan.withOpacity(.55))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('QUICK PRESETS', style: TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: .7)),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              _preset('⚡  In 15 minutes', const Duration(minutes: 15)),
              _preset('⌛  In 1 hour', const Duration(hours: 1)),
              _preset('🌇  Evening 6:00 PM', null, evening: true),
              _preset('🌅  Tomorrow 10:00 AM', null, tomorrow: true),
            ]),
            const SizedBox(height: 16),
            const Text('CUSTOM DATE & TIME', style: TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: .7)),
            const SizedBox(height: 8),
            InkWell(
              onTap: _pickCustomReminder,
              borderRadius: BorderRadius.circular(13),
              child: Container(width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 13),
                decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(13), border: Border.all(color: _cyan)),
                child: Row(children: [
                  Expanded(child: Text('${_customReminderAt.day.toString().padLeft(2, '0')}/${_customReminderAt.month.toString().padLeft(2, '0')}/${_customReminderAt.year}, ${TimeOfDay.fromDateTime(_customReminderAt).format(context)}',
                    style: const TextStyle(color: Colors.white, fontSize: 13))),
                  const Icon(Icons.keyboard_arrow_down_rounded, color: _muted),
                ]),
              ),
            ),
            const SizedBox(height: 14),
            const Text('REMINDER REASON / NOTE (OPTIONAL)', style: TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: .5)),
            const SizedBox(height: 8),
            TextField(controller: _reminderReasonController, style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(hintText: 'e.g. Discuss project contract, follow up on quote',
                hintStyle: const TextStyle(color: Colors.white38, fontSize: 12), filled: true, fillColor: _panel,
                contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: _line)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: _line)))),
            const SizedBox(height: 12),
            Row(children: [
              TextButton(onPressed: () => setState(() => _reminderExpanded = false),
                child: const Text('Cancel', style: TextStyle(color: _muted))),
              const Spacer(),
              ElevatedButton.icon(onPressed: _pickCustomReminder,
                icon: const Icon(Icons.check_rounded, size: 17), label: const Text('Save Reminder'),
                style: ElevatedButton.styleFrom(backgroundColor: _cyan, foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)), padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 12))),
            ]),
          ]),
        ),
      ]),
    );
  }

  Widget _preset(String label, Duration? delay, {bool evening = false, bool tomorrow = false}) {
    return InkWell(
      onTap: () {
        final now = DateTime.now();
        DateTime at;
        if (evening) {
          at = DateTime(now.year, now.month, now.day, 18);
          if (!at.isAfter(now)) at = at.add(const Duration(days: 1));
        } else if (tomorrow) {
          final d = now.add(const Duration(days: 1));
          at = DateTime(d.year, d.month, d.day, 10);
        } else {
          at = now.add(delay!);
        }
        _scheduleReminder(at, label.replaceAll(RegExp(r'^[^ ]+\s+'), ''));
      },
      borderRadius: BorderRadius.circular(11),
      child: Container(width: (MediaQuery.of(context).size.width - 86) / 2,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
        decoration: BoxDecoration(color: const Color(0xFF2B2832), borderRadius: BorderRadius.circular(11), border: Border.all(color: _line)),
        child: Text(label, style: const TextStyle(color: Color(0xFFD5D3DA), fontSize: 12)),
      ),
    );
  }

  Widget _historyPanel() {
    final rows = _numberHistory.where((c) {
      if (_historyFilter == 'Incoming') return c.type == CallType.incoming;
      if (_historyFilter == 'Outgoing') return c.type == CallType.outgoing;
      if (_historyFilter == 'Missed') return c.type == CallType.missed || c.type == CallType.rejected;
      return true;
    }).toList();
    return Column(children: [
      InkWell(
        onTap: () => setState(() => _historyExpanded = !_historyExpanded),
        borderRadius: BorderRadius.circular(17),
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(color: const Color(0xFF1C2D3A), borderRadius: BorderRadius.circular(17),
            border: Border.all(color: _cyan.withOpacity(.45))),
          child: Row(children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(color: _cyan.withOpacity(.18), borderRadius: BorderRadius.circular(13)),
              child: const Icon(Icons.history_rounded, color: _cyan, size: 22)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Text('All Call History', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(width: 9),
                Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: _cyan.withOpacity(.18), borderRadius: BorderRadius.circular(7), border: Border.all(color: _cyan.withOpacity(.45))),
                  child: Text('${_numberHistory.length}', style: const TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w700))),
              ]),
              const SizedBox(height: 3),
              Text(_historyExpanded ? 'Hide call history list' : 'View every call with this contact',
                style: const TextStyle(color: _muted, fontSize: 11)),
            ])),
            Icon(_historyExpanded ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded, color: _cyan, size: 23),
          ]),
        ),
      ),
      AnimatedSize(duration: const Duration(milliseconds: 250), curve: Curves.easeInOutCubic,
        child: !_historyExpanded ? const SizedBox.shrink() : Column(children: [
          const SizedBox(height: 10),
          Wrap(spacing: 7, children: ['All', 'Incoming', 'Outgoing', 'Missed'].map((f) {
            final selected = _historyFilter == f;
            return GestureDetector(onTap: () => setState(() => _historyFilter = f),
              child: AnimatedContainer(duration: const Duration(milliseconds: 170),
                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                decoration: BoxDecoration(color: selected ? _cyan : _field, borderRadius: BorderRadius.circular(20)),
                child: Text(f, style: TextStyle(color: selected ? Colors.white : _muted, fontSize: 11, fontWeight: FontWeight.w600))));
          }).toList()),
          const SizedBox(height: 8),
          Container(width: double.infinity, constraints: const BoxConstraints(maxHeight: 190),
            padding: const EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(color: _field, borderRadius: BorderRadius.circular(15)),
            child: rows.isEmpty
              ? const Center(child: Padding(padding: EdgeInsets.all(18), child: Text('No matching calls found', style: TextStyle(color: _muted, fontSize: 12))))
              : ListView.builder(shrinkWrap: true, itemCount: rows.length, itemBuilder: (_, i) {
                  final c = rows[i];
                  final missed = c.type == CallType.missed || c.type == CallType.rejected;
                  final color = missed ? const Color(0xFFFF5A67) : c.type == CallType.outgoing ? const Color(0xFF10C994) : _cyan;
                  final icon = missed ? Icons.call_missed_rounded : c.type == CallType.outgoing ? Icons.call_made_rounded : Icons.call_received_rounded;
                  return ListTile(dense: true, leading: Icon(icon, color: color, size: 18),
                    title: Text(c.type.name[0].toUpperCase() + c.type.name.substring(1), style: const TextStyle(color: Colors.white, fontSize: 12)),
                    subtitle: Text('${c.dateLabel} • ${c.timeFormatted} • ${c.durationString}', style: const TextStyle(color: _muted, fontSize: 10)));
                }),
          ),
        ]),
      ),
    ]);
  }

  Widget _bottomAction({required IconData icon, required String label, required Color color, required VoidCallback onTap, bool filled = false}) {
    return Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4),
      child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(16),
        child: Container(height: 54, decoration: BoxDecoration(
          color: filled ? color : color.withOpacity(.13), borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(filled ? .0 : .35)),
          boxShadow: filled ? [BoxShadow(color: color.withOpacity(.2), blurRadius: 14, offset: const Offset(0, 5))] : [],
        ), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: filled ? Colors.white : color, size: 18), const SizedBox(width: 5),
          Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text(label,
            maxLines: 1, softWrap: false,
            style: TextStyle(color: filled ? Colors.white : color, fontSize: 12.5, fontWeight: FontWeight.w700)))),
        ])),
      )));
  }

  @override
  Widget build(BuildContext context) {
    final isMissed = widget.call.type == CallType.missed || widget.call.type == CallType.rejected;
    final isBlocked = BlockedNumbersService.isBlocked(widget.call.number);
    final callType = isMissed ? 'Missed' : widget.call.type == CallType.outgoing ? 'Outgoing' : 'Incoming';
    final timeLabel = '${widget.call.dateLabel}  ·  ${widget.call.timeFormatted}';
    return Container(
      height: MediaQuery.of(context).size.height * .94,
      decoration: const BoxDecoration(
        color: _panel,
        borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        border: Border(top: BorderSide(color: Color(0xFF4B4853), width: 1)),
      ),
      child: SafeArea(top: false, child: Column(children: [
        const SizedBox(height: 12),
        Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(4))),
        Expanded(child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.fromLTRB(20, 22, 20, MediaQuery.of(context).viewInsets.bottom + 22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              GestureDetector(
                onTap: _pickProfilePhoto,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 64, height: 64,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1260E8),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [BoxShadow(color: _cyan.withOpacity(.12), blurRadius: 15)],
                        image: _profilePhotoBase64 != null
                            ? DecorationImage(image: MemoryImage(base64Decode(_profilePhotoBase64!)), fit: BoxFit.cover)
                            : null,
                      ),
                      child: _profilePhotoBase64 == null
                          ? Center(child: Text(widget.call.name.isNotEmpty ? widget.call.name[0].toUpperCase() : '?',
                              style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w700)))
                          : null,
                    ),
                    Positioned(
                      right: -5, bottom: -5,
                      child: Container(
                        width: 24, height: 24,
                        decoration: BoxDecoration(color: _cyan, shape: BoxShape.circle, border: Border.all(color: _panel, width: 2)),
                        child: const Icon(Icons.photo_camera_rounded, color: Colors.white, size: 13),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 15),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.call.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800)),
                const SizedBox(height: 5),
                Row(children: [
                  Flexible(child: Text(widget.call.number, style: const TextStyle(color: _muted, fontSize: 14))),
                  const SizedBox(width: 7),
                  GestureDetector(onTap: _copyNumber, child: Icon(_copied ? Icons.check_circle : Icons.copy_rounded,
                    color: _copied ? const Color(0xFF10C994) : _muted, size: 15)),
                ]),
                if (isBlocked) const Padding(padding: EdgeInsets.only(top: 4), child: Text('BLOCKED', style: TextStyle(color: Color(0xFFFF5A67), fontSize: 9, fontWeight: FontWeight.w800))),
              ])),
              IconButton(onPressed: () => Navigator.pop(context),
                style: IconButton.styleFrom(backgroundColor: const Color(0xFF35323D), foregroundColor: _muted),
                icon: const Icon(Icons.close_rounded, size: 20)),
            ]),
            _divider(),
            _sectionHeader(Icons.sell_outlined, 'Smart Category',
              trailing: Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
                decoration: BoxDecoration(color: _cyan.withOpacity(.12), borderRadius: BorderRadius.circular(18), border: Border.all(color: _cyan.withOpacity(.35))),
                child: Text(_category, style: const TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w700)))),
            const SizedBox(height: 11),
            Wrap(spacing: 8, runSpacing: 8, children: _categories.map(_categoryChip).toList()),
            _divider(),
            _sectionHeader(Icons.description_outlined, 'Call Note', color: const Color(0xFFFFC02E),
              trailing: TextButton.icon(onPressed: () {
                if (_noteEditing) { _saveCallDetails(); } else { setState(() => _noteEditing = true); }
              }, icon: Icon(_noteEditing ? Icons.check_rounded : Icons.edit_outlined, color: _cyan, size: 17),
                label: Text(_noteEditing ? 'Save' : 'Edit', style: const TextStyle(color: _cyan, fontWeight: FontWeight.w600))),
            ),
            const SizedBox(height: 7),
            if (_noteEditing) ...[
              TextField(controller: _noteController, minLines: 2, maxLines: 4,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(hintText: 'Add a note for this call...', hintStyle: const TextStyle(color: Colors.white38, fontSize: 12),
                  filled: true, fillColor: _field, contentPadding: const EdgeInsets.all(13),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
              const SizedBox(height: 8),
              TextField(controller: _tagsController, style: const TextStyle(color: Colors.white, fontSize: 12),
                decoration: InputDecoration(hintText: 'Tags: VIP, Work, Follow-up', hintStyle: const TextStyle(color: Colors.white38, fontSize: 11),
                  filled: true, fillColor: _field, contentPadding: const EdgeInsets.all(13),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
              if (_tags.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 7), child: Wrap(spacing: 6, children: _tags.map((t) => Chip(
                label: Text(t, style: const TextStyle(fontSize: 10)), backgroundColor: _cyan.withOpacity(.15),
                visualDensity: VisualDensity.compact)).toList())),
            ] else Container(width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
              decoration: BoxDecoration(color: _field, borderRadius: BorderRadius.circular(15)),
              child: Text(_noteController.text.isEmpty ? 'No call note added' : _noteController.text,
                style: TextStyle(color: _noteController.text.isEmpty ? Colors.white38 : const Color(0xFFE3E1E8), fontSize: 13))),
            _divider(),
            _sectionHeader(Icons.alarm_rounded, 'Callback Reminder',
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                if (_activeReminders.isNotEmpty) Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(color: const Color(0xFFFFC02E).withOpacity(.13), borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFFFC02E).withOpacity(.4))),
                  child: const Text('Scheduled', style: TextStyle(color: Color(0xFFFFC02E), fontSize: 10, fontWeight: FontWeight.w700))),
                const SizedBox(width: 6),
                TextButton.icon(onPressed: () => setState(() => _reminderExpanded = !_reminderExpanded),
                  icon: Icon(_activeReminders.isNotEmpty ? Icons.edit_outlined : Icons.notifications_active_outlined, size: 16, color: _cyan),
                  label: Text(_activeReminders.isNotEmpty ? 'Change' : '+ Schedule', style: const TextStyle(color: _cyan, fontSize: 12, fontWeight: FontWeight.w700))),
              ])),
            const SizedBox(height: 7),
            _reminderPanel(),
            _divider(),
            _infoRow(Icons.access_time_rounded, 'Call Time', timeLabel, _cyan),
            _infoRow(Icons.location_on_outlined, 'Location', widget.call.location.isEmpty ? 'Unknown' : widget.call.location, const Color(0xFF10C994)),
            _infoRow(Icons.shield_outlined, 'SIM Slot', 'SIM ${widget.call.simSlot} (${widget.call.simCarrier})', const Color(0xFFFFC02E)),
            _divider(),
            _historyPanel(),
            const SizedBox(height: 17),
            Row(children: [
              _bottomAction(icon: Icons.call_rounded, label: 'Call Back', color: const Color(0xFF00C78A), filled: true, onTap: () {
                Navigator.pop(context); widget.onCallNumber(widget.call.number);
              }),
              _bottomAction(icon: _copied ? Icons.check_rounded : Icons.copy_rounded, label: _copied ? 'Copied' : 'Copy',
                color: const Color(0xFFD0CED6), onTap: _copyNumber),
              _bottomAction(icon: Icons.delete_outline_rounded, label: 'Delete', color: const Color(0xFFFF5964), onTap: () async {
                final confirm = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                  backgroundColor: _panel, title: const Text('Delete call record?', style: TextStyle(color: Colors.white)),
                  content: const Text('This call entry will be removed from your history.', style: TextStyle(color: _muted)),
                  actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete', style: TextStyle(color: Color(0xFFFF5964))))]));
                if (confirm == true && mounted) { Navigator.pop(context); widget.onDeleteCall(widget.call.id); }
              }),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: _openWhatsApp, icon: const Icon(Icons.chat_rounded, size: 16),
                label: const FittedBox(fit: BoxFit.scaleDown, child: Text('WhatsApp', maxLines: 1, softWrap: false)), style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF25D366), side: const BorderSide(color: Color(0x5525D366))))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: _sendSms, icon: const Icon(Icons.sms_outlined, size: 16),
                label: const FittedBox(fit: BoxFit.scaleDown, child: Text('Message', maxLines: 1, softWrap: false)), style: OutlinedButton.styleFrom(foregroundColor: _cyan, side: const BorderSide(color: Color(0x5500AEEF))))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: _toggleBlockNumber, icon: Icon(isBlocked ? Icons.check : Icons.block, size: 16),
                label: FittedBox(fit: BoxFit.scaleDown, child: Text(isBlocked ? 'Unblock' : 'Block', maxLines: 1, softWrap: false)), style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFFF5964), side: const BorderSide(color: Color(0x55FF5964))))),
            ]),
          ]),
        )),
      ])),
    );
  }
}
