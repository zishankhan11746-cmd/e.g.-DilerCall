Style 15 reference-match update

Updated the Style 15 Realme Notification Flow presentation to match the supplied reference:
- tall frosted light-blue call cards with larger rounded corners and white edge
- larger initial avatar tile, contact text, and green call action
- increased natural spacing and a tighter layered end stack with visible card lips
- Style 15 only; other style configurations were not intentionally changed

Validation: ZIP archive integrity checked. Flutter/Dart SDK was not available in this environment, so an APK build and device animation test were not performed.
