package com.stackdialer.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONObject

class CallbackReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_FIRE) showReminder(context, intent)
    }

    companion object {
        const val ACTION_FIRE = "com.stackdialer.app.ACTION_CALLBACK_REMINDER"
        private const val CHANNEL_ID = "stackdialer_callback_reminders"
        private const val PREFS = "stackdialer_native_reminders"

        fun schedule(context: Context, id: String, name: String, number: String, atMillis: Long, label: String) {
            val data = JSONObject().apply {
                put("id", id); put("name", name); put("number", number); put("atMillis", atMillis); put("label", label)
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(id, data.toString()).apply()
            scheduleIntent(context, id, name, number, atMillis, label)
        }

        fun cancel(context: Context, id: String) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pending = PendingIntent.getBroadcast(context, id.hashCode(), Intent(context, CallbackReminderReceiver::class.java).setAction(ACTION_FIRE).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.cancel(pending)
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(id).apply()
        }

        private fun scheduleIntent(context: Context, id: String, name: String, number: String, atMillis: Long, label: String) {
            if (atMillis <= System.currentTimeMillis()) return
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, CallbackReminderReceiver::class.java).setAction(ACTION_FIRE).apply {
                putExtra("id", id); putExtra("name", name); putExtra("number", number); putExtra("label", label)
            }
            val pending = PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pending)
        }

        fun rescheduleAll(context: Context) {
            val all = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all
            for ((id, raw) in all) {
                try {
                    val item = JSONObject(raw as String)
                    scheduleIntent(context, id, item.optString("name"), item.optString("number"), item.optLong("atMillis"), item.optString("label"))
                } catch (_: Exception) { }
            }
        }

        private fun showReminder(context: Context, intent: Intent) {
            val id = intent.getStringExtra("id") ?: return
            val name = intent.getStringExtra("name") ?: "Contact"
            val number = intent.getStringExtra("number") ?: ""
            val label = intent.getStringExtra("label") ?: "Callback reminder"
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Callback reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Reminders to call someone back"
                })
            }
            val open = Intent(context, MainActivity::class.java).apply {
                action = "com.stackdialer.app.OPEN_CALLBACK_REMINDER"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("reminder_number", number)
                putExtra("reminder_id", id)
            }
            val content = PendingIntent.getActivity(context, id.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_call_white)
                .setContentTitle("Call back: $name")
                .setContentText("$label · $number")
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(content)
                .build()
            manager.notify(id.hashCode(), notification)
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(id).apply()
        }
    }
}
