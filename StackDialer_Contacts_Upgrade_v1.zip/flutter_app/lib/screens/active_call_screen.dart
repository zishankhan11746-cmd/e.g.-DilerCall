import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/call_record.dart';
import '../services/blocked_numbers_service.dart';
import '../services/telecom_service.dart';

enum CallUIState {
  ringing, // Incoming Call UI
  dialing, // Outgoing Call UI
  active,  // Connected in-call
  holding, // On Hold
  ended,   // Call Ended Summary
}

class ActiveCallScreen extends StatefulWidget {
  final String phoneNumber;
  final String? contactName;
  final String? callerCategory;
  final int simSlot;
  final bool isIncoming;
  final bool initiallyActive;
  final bool initiallyHolding;
  final Function(CallRecord completedCall)? onCallEnded;

  const ActiveCallScreen({
    super.key,
    required this.phoneNumber,
    this.contactName,
    this.callerCategory,
    this.simSlot = 1,
    this.isIncoming = false,
    this.initiallyActive = false,
    this.initiallyHolding = false,
    this.onCallEnded,
  });

  @override
  State<ActiveCallScreen> createState() => _ActiveCallScreenState();
}

class _ActiveCallScreenState extends State<ActiveCallScreen> with SingleTickerProviderStateMixin {
  // Shared across temporary screen rebuilds/routes so reopening the call UI never resets elapsed time.
  static DateTime? _sharedCallStartedAt;
  static String? _sharedCallNumber;
  late CallUIState _state;
  bool _isMuted = false;
  bool _isSpeaker = false;
  bool _isOnHold = false;
  bool _isRecording = false;
  bool _addCallEffect = false;
  bool _videoCallEffect = false;
  bool _showDtmfPad = false;
  String _dtmfHistory = '';
  String _callNote = '';
  int _durationSeconds = 0;
  Timer? _callTimer;
  void Function()? _removeCallListener;

  @override
  void initState() {
    super.initState();
    _state = widget.isIncoming
        ? CallUIState.ringing
        : (widget.initiallyHolding
            ? CallUIState.holding
            : (widget.initiallyActive ? CallUIState.active : CallUIState.dialing));
    _isOnHold = widget.initiallyHolding;
    if (widget.initiallyActive || widget.initiallyHolding) {
      _startTimer();
      _restoreNativeCallClock();
    }

    // Initial check for real speaker status
    TelecomService.isSpeakerOn().then((on) {
      if (mounted && on != _isSpeaker) {
        setState(() => _isSpeaker = on);
      }
    });

    // Listen to real Android InCallService native call state events
    _removeCallListener = TelecomService.addCallListener((number, nativeState) {
      if (!mounted) return;
      if (nativeState == 'ACTIVE' && _state != CallUIState.active) {
        _transitionToActive();
      } else if (nativeState == 'HOLDING') {
        setState(() {
          _isOnHold = true;
          _state = CallUIState.holding;
        });
      } else if (nativeState == 'DISCONNECTED') {
        _endCall();
      }
    });

    // Listen for confirmed Android audio route changes (earpiece / speaker / bluetooth)
    TelecomService.setupAudioRouteListener((isSpeaker, isMuted) {
      if (!mounted) return;
      setState(() {
        _isSpeaker = isSpeaker;
        _isMuted = isMuted;
      });
    });
  }

  Future<void> _restoreNativeCallClock() async {
    final connectedAt = await TelecomService.getCallStartTimeMillis();
    if (!mounted || connectedAt <= 0) return;
    if (_sharedCallNumber != widget.phoneNumber ||
        _sharedCallStartedAt == null ||
        _sharedCallStartedAt!.millisecondsSinceEpoch != connectedAt) {
      _sharedCallNumber = widget.phoneNumber;
      _sharedCallStartedAt = DateTime.fromMillisecondsSinceEpoch(connectedAt);
    }
    final elapsed = DateTime.now().difference(_sharedCallStartedAt!).inSeconds.clamp(0, 24 * 60 * 60);
    if (mounted && elapsed != _durationSeconds) {
      setState(() => _durationSeconds = elapsed);
      _startTimer();
    }
  }

  void _transitionToActive() {
    if (_state == CallUIState.active) return;
    HapticFeedback.heavyImpact();
    if (_sharedCallNumber != widget.phoneNumber) {
      _sharedCallNumber = widget.phoneNumber;
      _sharedCallStartedAt = DateTime.now();
    } else {
      _sharedCallStartedAt ??= DateTime.now();
    }
    setState(() {
      _state = CallUIState.active;
      _durationSeconds = DateTime.now().difference(_sharedCallStartedAt!).inSeconds;
    });
    _startTimer();
    // Reconcile the UI clock against Android Telecom's authoritative connection time.
    _restoreNativeCallClock();
  }

  void _startTimer() {
    // Do not restart the clock on duplicate ACTIVE callbacks.
    if (_sharedCallNumber != widget.phoneNumber) {
      _sharedCallNumber = widget.phoneNumber;
      _sharedCallStartedAt = DateTime.now();
    } else {
      _sharedCallStartedAt ??= DateTime.now();
    }
    _callTimer?.cancel();
    _durationSeconds = DateTime.now().difference(_sharedCallStartedAt!).inSeconds;
    _callTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && (_state == CallUIState.active || _state == CallUIState.holding)) {
        final elapsed = DateTime.now().difference(_sharedCallStartedAt!).inSeconds;
        if (elapsed != _durationSeconds) {
          setState(() => _durationSeconds = elapsed);
        }
      }
    });
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _removeCallListener?.call();
    super.dispose();
  }

  String _formatDuration(int seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  void _answerCall() async {
    HapticFeedback.heavyImpact();
    // Wait for Android Telecom's real ACTIVE callback before starting the timer.
    // Starting it on the answer-button tap can count ringing/answer latency as call time.
    await TelecomService.answerCall();
  }

  void _rejectCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.rejectCall();
    _endCall();
  }

  void _hangupCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.disconnectCall();
    _endCall();
  }

  void _endCall() {
    if (_state == CallUIState.ended) return;
    _callTimer?.cancel();
    if (_sharedCallNumber == widget.phoneNumber) {
      _sharedCallStartedAt = null;
      _sharedCallNumber = null;
    }
    TelecomService.cancelIncomingBanner();
    TelecomService.cancelOngoingNotification();
    HapticFeedback.mediumImpact();
    setState(() {
      _state = CallUIState.ended;
    });

    final record = CallRecord(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: widget.contactName ?? widget.phoneNumber,
      number: widget.phoneNumber,
      type: widget.isIncoming
          ? (_durationSeconds > 0 ? CallType.incoming : CallType.missed)
          : CallType.outgoing,
      timestamp: DateTime.now(),
      durationSeconds: _durationSeconds,
      simSlot: widget.simSlot,
      simCarrier: 'SIM ${widget.simSlot}',
      category: widget.callerCategory ?? 'Personal',
      location: 'Cellular Call',
      note: _callNote.isNotEmpty ? _callNote : null,
    );

    widget.onCallEnded?.call(record);
  }

  void _toggleMute() async {
    HapticFeedback.selectionClick();
    final newMute = !_isMuted;
    await TelecomService.setMuted(newMute);
    setState(() {
      _isMuted = newMute;
    });
  }

  void _toggleSpeaker() async {
    HapticFeedback.selectionClick();
    final newSpeaker = !_isSpeaker;
    await TelecomService.setSpeaker(newSpeaker);
    setState(() {
      _isSpeaker = newSpeaker;
    });
  }

  void _toggleHold() async {
    HapticFeedback.selectionClick();
    final newHold = !_isOnHold;
    await TelecomService.holdCall(newHold);
    setState(() {
      _isOnHold = newHold;
      _state = newHold ? CallUIState.holding : CallUIState.active;
    });
  }

  void _toggleRecord() {
    HapticFeedback.mediumImpact();
    setState(() {
      _isRecording = !_isRecording;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              _isRecording ? Icons.fiber_manual_record : Icons.stop_circle_outlined,
              color: _isRecording ? Colors.redAccent : Colors.white70,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(_isRecording ? '🔴 Call recording in progress' : '⏹️ Call recording saved'),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1E1E22),
      ),
    );
  }

  void _onPressDtmfDigit(String digit) {
    HapticFeedback.lightImpact();
    TelecomService.playDtmf(digit);
    setState(() {
      _dtmfHistory += digit;
    });
    Future.delayed(const Duration(milliseconds: 200), () {
      TelecomService.stopDtmf();
    });
  }

  void _showQuickSmsSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141416),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final messages = [
          "Can't talk now. What's up?",
          "I'll call you right back.",
          "I'm in a meeting right now.",
          "Driving right now, will call later.",
        ];
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _state == CallUIState.ringing ? 'Quick Reply' : 'Quick SMS',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ...messages.map(
                (msg) => ListTile(
                  title: Text(msg, style: const TextStyle(color: Colors.white70)),
                  trailing: const Icon(Icons.send_rounded, color: Color(0xFF10B981), size: 18),
                  onTap: () async {
                    Navigator.pop(ctx);
                    if (_state == CallUIState.ringing) _rejectCall();
                    final uri = Uri(
                      scheme: 'sms',
                      path: widget.phoneNumber,
                      queryParameters: {'body': msg},
                    );
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri);
                    }
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showInCallNoteDialog() {
    final controller = TextEditingController(text: _callNote);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF18181C),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Summarise / In-Call Note', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        content: TextField(
          controller: controller,
          maxLines: 4,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Add call notes, summary or follow-up details...',
            hintStyle: const TextStyle(color: Colors.white38),
            filled: true,
            fillColor: const Color(0xFF222226),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFDC2626),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () {
              setState(() {
                _callNote = controller.text.trim();
              });
              Navigator.pop(ctx);
            },
            child: const Text('Save Note', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _onAddCall() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Add Call: Conference and 2nd line calling active'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF1E1E22),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _onVideoCall() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Carrier ViLTE Video calling is available for 5G/VoLTE lines'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF1E1E22),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final displayName = widget.contactName?.isNotEmpty == true
        ? widget.contactName!
        : widget.phoneNumber;

    return Scaffold(
      backgroundColor: const Color(0xFF100F13),
      body: SafeArea(
        child: _state == CallUIState.ended
            ? _buildCallEndedSummary(displayName)
            : LayoutBuilder(
                builder: (context, constraints) => Center(
                  // Fixed, non-scrollable call layout. FittedBox only scales the
                  // complete layout down on short screens; it never translates
                  // individual controls or lets the End Call button fall below
                  // the navigation-safe area.
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.center,
                    child: SizedBox(
                      width: constraints.maxWidth,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(22, 8, 22, 12),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // SIM / Cellular Call pills intentionally removed
                            // from the top of the active calling screen.
                            _buildCallerIdentity(displayName),
                            const SizedBox(height: 20),
                            if (_state == CallUIState.ringing)
                              _buildIncomingCallControls()
                            else if (_showDtmfPad) ...[
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('In-call keypad', style: TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w600)),
                                  TextButton.icon(
                                    onPressed: () => setState(() => _showDtmfPad = false),
                                    icon: const Icon(Icons.keyboard_hide_rounded, size: 18, color: Color(0xFF16B58B)),
                                    label: const Text('Hide keypad', style: TextStyle(color: Color(0xFF16B58B))),
                                  ),
                                ],
                              ),
                              _buildInCallDialpad(),
                              const SizedBox(height: 14),
                              _buildEndCallButton(),
                            ] else ...[
                              _buildReferenceThreeByThreeGrid(),
                              const SizedBox(height: 18),
                              _buildEndCallButton(),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
      ),
    );
  }

  Widget _buildCallHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          onPressed: () => Navigator.maybePop(context),
          icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Color(0xFFBFC0C5), size: 32),
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(minWidth: 40, minHeight: 42),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
          decoration: BoxDecoration(
            color: const Color(0xFF242B2B),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: const Color(0xFF3B4A48), width: 1.2),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.sim_card_rounded, color: Color(0xFF18B98D), size: 18),
            const SizedBox(width: 8),
            Text('SIM ${widget.simSlot}', style: const TextStyle(color: Color(0xFFC6C9CA), fontSize: 16, fontWeight: FontWeight.w700)),
          ]),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
          decoration: BoxDecoration(color: const Color(0xFF20292A), borderRadius: BorderRadius.circular(28)),
          child: const Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.cell_tower_rounded, color: Color(0xFF39B9F0), size: 17),
            SizedBox(width: 7),
            Text('Cellular Call', style: TextStyle(color: Color(0xFF42B8F0), fontSize: 15, fontWeight: FontWeight.w700)),
          ]),
        ),
      ],
    );
  }

  Widget _buildCallerIdentity(String displayName) {
    final isConnected = _state == CallUIState.active || _state == CallUIState.holding;
    final title = widget.contactName?.isNotEmpty == true ? displayName : widget.phoneNumber;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 118, height: 118,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFF24202D),
            border: Border.all(color: const Color(0xFF10B98D), width: 3),
          ),
          child: const Center(child: Icon(Icons.add_rounded, color: Colors.white, size: 76)),
        ),
        const SizedBox(height: 30),
        Text(title, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 34, height: 1.12, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: -0.6)),
        if (widget.contactName?.isNotEmpty == true) ...[
          const SizedBox(height: 5),
          Text(widget.phoneNumber, style: const TextStyle(fontSize: 16, color: Color(0xFFB5B3BA))),
        ],
        const SizedBox(height: 30),
        if (isConnected)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 19, vertical: 7),
            decoration: BoxDecoration(color: const Color(0xFF1D1C22), borderRadius: BorderRadius.circular(26)),
            child: Text(_formatDuration(_durationSeconds), style: const TextStyle(color: Color(0xFF14B88D), fontSize: 18, fontWeight: FontWeight.w700, fontFeatures: [ui.FontFeature.tabularFigures()])),
          )
        else
          Text(_state == CallUIState.ringing ? 'Incoming call' : 'Calling…', style: const TextStyle(color: Color(0xFF9A98A0), fontSize: 15)),
      ],
    );
  }

  Widget _buildCallSecurityHint() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: const [
        Icon(Icons.lock_rounded, color: Colors.white30, size: 12),
        SizedBox(width: 6),
        Text('Private cellular call', style: TextStyle(color: Colors.white38, fontSize: 10.5, letterSpacing: 0.4)),
      ],
    );
  }

  Widget _buildBlurredCallBackdrop() {
    return const ColoredBox(color: Color(0xFF100F13));
  }

  // =========================================================================
  // Reference layout: exact 3 rows x 3 columns.
  // =========================================================================
  Widget _buildReferenceThreeByThreeGrid() {
    return Column(
      children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          _buildReferenceAction(Icons.mic_none_rounded, 'Mute', _isMuted, _toggleMute),
          _buildReferenceAction(Icons.dialpad_rounded, 'Keypad', _showDtmfPad, () => setState(() => _showDtmfPad = true)),
          _buildReferenceAction(Icons.volume_up_rounded, _isSpeaker ? 'Speaker On' : 'Speaker', _isSpeaker, _toggleSpeaker),
        ]),
        const SizedBox(height: 19),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          _buildReferenceAction(_isOnHold ? Icons.play_arrow_rounded : Icons.pause_rounded, 'Hold', _isOnHold, _toggleHold),
          _buildReferenceAction(Icons.message_outlined, 'Quick SMS', false, _showQuickSmsSheet),
          _buildReferenceAction(Icons.note_alt_outlined, 'Add Note', false, _showInCallNoteDialog),
        ]),
      ],
    );
  }

  Widget _buildReferenceAction(IconData icon, String label, bool active, VoidCallback onTap, {bool speaker = false}) {
    // Every actual toggle uses the same green active state, not Speaker alone.
    final activeGreen = active;
    final color = activeGreen ? const Color(0xFF103A30) : const Color(0xFF242328);
    final border = activeGreen ? const Color(0xFF16B58B) : const Color(0xFF3B3A40);
    return SizedBox(
      width: (MediaQuery.sizeOf(context).width - 64) / 3,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        InkWell(
          onTap: () { HapticFeedback.selectionClick(); onTap(); },
          customBorder: const CircleBorder(),
          child: Container(
            width: 60, height: 60,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color, border: Border.all(color: border, width: 2.2)),
            child: Icon(icon, color: activeGreen ? const Color(0xFF16B58B) : Colors.white, size: 31),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: 16, color: activeGreen ? const Color(0xFF16B58B) : const Color(0xFFA5A2AA), fontWeight: activeGreen ? FontWeight.w700 : FontWeight.w500)),
      ]),
    );
  }

  Widget _buildEndCallButton() {
    return InkWell(
      onTap: _hangupCall,
      customBorder: const CircleBorder(),
      child: Container(
        width: 72, height: 72,
        decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFEF4148)),
        child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 34),
      ),
    );
  }

  // =========================================================================
  // IN-CALL DIALPAD (Exact Frame 00:01-00:03 from Video)
  // Full circular number keys sending DTMF tones
  // =========================================================================
  Widget _buildInCallDialpad() {
    final dialKeys = [
      {'digit': '1', 'letters': ''},
      {'digit': '2', 'letters': 'ABC'},
      {'digit': '3', 'letters': 'DEF'},
      {'digit': '4', 'letters': 'GHI'},
      {'digit': '5', 'letters': 'JKL'},
      {'digit': '6', 'letters': 'MNO'},
      {'digit': '7', 'letters': 'PQRS'},
      {'digit': '8', 'letters': 'TUV'},
      {'digit': '9', 'letters': 'WXYZ'},
      {'digit': '*', 'letters': ''},
      {'digit': '0', 'letters': '+'},
      {'digit': '#', 'letters': ''},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_dtmfHistory.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                _dtmfHistory,
                style: const TextStyle(fontSize: 20, color: Colors.white, fontFamily: 'monospace', letterSpacing: 2),
              ),
            ),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 12,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 16,
              crossAxisSpacing: 24,
              childAspectRatio: 1.0,
            ),
            itemBuilder: (ctx, idx) {
              final item = dialKeys[idx];
              final digit = item['digit']!;
              final letters = item['letters']!;

              return InkWell(
                onTap: () => _onPressDtmfDigit(digit),
                borderRadius: BorderRadius.circular(36),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF222226),
                    border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          digit,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        if (letters.isNotEmpty)
                          Text(
                            letters,
                            style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF9CA3AF),
                              letterSpacing: 0.8,
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // INCOMING CALL CONTROLS (Decline & Answer with SMS reply)
  // =========================================================================
  Widget _buildIncomingCallControls() {
    return Column(
      children: [
        TextButton.icon(
          onPressed: _showQuickSmsSheet,
          icon: const Icon(Icons.message_outlined, color: Colors.white70, size: 16),
          label: const Text(
            'Reply with message',
            style: TextStyle(color: Colors.white70, fontSize: 13),
          ),
        ),
        const SizedBox(height: 32),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Decline Button (Red)
              Column(
                children: [
                  InkWell(
                    onTap: _rejectCall,
                    borderRadius: BorderRadius.circular(36),
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFFDC2626),
                      ),
                      child: const Center(
                        child: Icon(Icons.call_end_rounded, color: Colors.white, size: 34),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Decline', style: TextStyle(color: Colors.white70, fontSize: 13)),
                ],
              ),

              // Answer Button (Green)
              Column(
                children: [
                  InkWell(
                    onTap: _answerCall,
                    borderRadius: BorderRadius.circular(36),
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF16A34A),
                      ),
                      child: const Center(
                        child: Icon(Icons.call_rounded, color: Colors.white, size: 34),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Answer', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  // =========================================================================
  // CALL ENDED SUMMARY
  // =========================================================================
  Widget _buildCallEndedSummary(String displayName) {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(24),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: const Color(0xFF18181C),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle_outline, color: Color(0xFF10B981), size: 48),
            const SizedBox(height: 12),
            const Text(
              'Call Ended',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white),
            ),
            const SizedBox(height: 6),
            Text(
              displayName,
              style: const TextStyle(fontSize: 16, color: Colors.white70),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                'Duration: ${_formatDuration(_durationSeconds)}',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF10B981)),
              ),
            ),
            if (_callNote.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                'Note: "$_callNote"',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Color(0xFF38BDF8), fontStyle: FontStyle.italic),
              ),
            ],
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildSummaryAction(
                  icon: Icons.chat_bubble_outline,
                  label: 'WhatsApp',
                  color: const Color(0xFF25D366),
                  onTap: () async {
                    final clean = widget.phoneNumber.replaceAll(RegExp(r'[^\d]'), '');
                    final uri = Uri.parse('https://wa.me/$clean');
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _buildSummaryAction(
                  icon: Icons.sms_outlined,
                  label: 'SMS',
                  color: const Color(0xFF38BDF8),
                  onTap: () async {
                    final uri = Uri(scheme: 'sms', path: widget.phoneNumber);
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _buildSummaryAction(
                  icon: Icons.block,
                  label: 'Block',
                  color: const Color(0xFFEF4444),
                  onTap: () {
                    BlockedNumbersService.blockNumber(widget.phoneNumber);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Blocked ${widget.phoneNumber}')),
                    );
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFDC2626),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () => Navigator.pop(context),
                child: const Text('Back to Dialer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryAction({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.15),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}
