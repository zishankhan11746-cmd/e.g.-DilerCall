import 'package:flutter/material.dart';
import '../models/call_record.dart';
import '../services/call_data_service.dart';

class InsightsScreen extends StatelessWidget {
  final List<CallRecord> calls;
  final Function(String number) onCallNumber;
  final VoidCallback? onBackupRestored;

  const InsightsScreen({
    super.key,
    required this.calls,
    required this.onCallNumber,
    this.onBackupRestored,
  });

  @override
  Widget build(BuildContext context) {
    final totalCalls = calls.length;
    final missedCalls = calls.where((c) => c.type == CallType.missed || c.type == CallType.rejected).length;
    final outgoingCalls = calls.where((c) => c.type == CallType.outgoing).length;
    final incomingCalls = calls.where((c) => c.type == CallType.incoming).length;
    final totalDuration = calls.fold<int>(0, (sum, c) => sum + c.duration);
    final totalMinutes = (totalDuration / 60).round();
    final answeredCalls = calls.where((c) => c.durationSeconds > 0).length;
    final averageDuration = answeredCalls == 0 ? 0 : (totalDuration / answeredCalls).round();
    final now = DateTime.now();
    final weekStart = DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday - 1));
    final thisWeek = calls.where((c) => !c.timestamp.isBefore(weekStart)).toList();
    final thisWeekMissed = thisWeek.where((c) => c.type == CallType.missed || c.type == CallType.rejected).length;

    // Group contact frequency by normalized number so renamed contacts are not split.
    final Map<String, int> contactCounts = {};
    final Map<String, CallRecord> contactRepresentatives = {};
    String normalizeNumber(String value) => value.replaceAll(RegExp(r'[^0-9+]'), '');
    for (final call in calls) {
      final key = normalizeNumber(call.number);
      if (key.isEmpty) continue;
      contactCounts[key] = (contactCounts[key] ?? 0) + 1;
      contactRepresentatives.putIfAbsent(key, () => call);
    }
    final sortedContacts = contactCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topFrequent = sortedContacts.take(5).toList();

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1B1822),
              Color(0xFF141219),
              Color(0xFF0D0C11),
            ],
          ),
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            children: [
              // Executive Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Color(0xFF10B981),
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            'Call Analytics',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              letterSpacing: -0.5,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      const Text(
                        'Insights & Call Intelligence',
                        style: TextStyle(color: Colors.white38, fontSize: 12),
                      ),
                    ],
                  ),
                  Row(children: [
                    IconButton(
                      tooltip: 'Export backup', icon: const Icon(Icons.backup_outlined, color: Color(0xFF10B981)),
                      onPressed: () async {
                        final ok = await CallDataService.exportBackup(calls);
                        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Backup saved. Choose a folder in the file picker.' : 'Backup cancelled or could not be saved.')));
                      },
                    ),
                    IconButton(
                      tooltip: 'Restore backup', icon: const Icon(Icons.restore_rounded, color: Colors.white70),
                      onPressed: () async {
                        final result = await CallDataService.importBackup();
                        if (result != null) onBackupRestored?.call();
                        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result != null ? 'Backup restored. Call history and reminders refreshed.' : 'Restore cancelled or backup file is invalid.')));
                      },
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: const Color(0xFF10B981).withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF10B981).withOpacity(0.3))),
                      child: const Text('PRO', style: TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold, fontSize: 11)),
                    ),
                  ]),
                ],
              ),
              const SizedBox(height: 20),

              // KPI Grid: 4 Squircle Metric Cards
              Row(
                children: [
                  Expanded(
                    child: _buildMetricCard(
                      title: 'Total Calls',
                      value: '$totalCalls',
                      icon: Icons.phone_in_talk,
                      color: Colors.blueAccent,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _buildMetricCard(
                      title: 'Talk Time',
                      value: '${totalMinutes}m',
                      icon: Icons.timer,
                      color: Colors.purpleAccent,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: _buildMetricCard(
                      title: 'Outgoing',
                      value: '$outgoingCalls',
                      icon: Icons.call_made,
                      color: const Color(0xFF10B981),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _buildMetricCard(
                      title: 'Missed',
                      value: '$missedCalls',
                      icon: Icons.call_missed,
                      color: Colors.redAccent,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _buildMetricCard(title: 'Avg. Duration', value: '${averageDuration ~/ 60}m ${averageDuration % 60}s', icon: Icons.av_timer, color: Colors.tealAccent)),
                const SizedBox(width: 10),
                Expanded(child: _buildMetricCard(title: 'This Week Missed', value: '$thisWeekMissed', icon: Icons.notifications_off_outlined, color: Colors.orangeAccent)),
              ]),
              const SizedBox(height: 22),

              // Ratio Bar
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF201E27).withOpacity(0.8),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Call Distribution Ratio',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Row(
                        children: [
                          if (incomingCalls > 0)
                            Expanded(
                              flex: incomingCalls,
                              child: Container(
                                height: 10,
                                color: Colors.blueAccent,
                              ),
                            ),
                          if (outgoingCalls > 0)
                            Expanded(
                              flex: outgoingCalls,
                              child: Container(
                                height: 10,
                                color: const Color(0xFF10B981),
                              ),
                            ),
                          if (missedCalls > 0)
                            Expanded(
                              flex: missedCalls,
                              child: Container(
                                height: 10,
                                color: Colors.redAccent,
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildLegendItem('Incoming ($incomingCalls)', Colors.blueAccent),
                        _buildLegendItem('Outgoing ($outgoingCalls)', const Color(0xFF10B981)),
                        _buildLegendItem('Missed ($missedCalls)', Colors.redAccent),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),

              // Persisted callback reminders (survive app restarts and device reboot).
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Upcoming Callback Reminders', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
              ]),
              ValueListenableBuilder<int>(
                valueListenable: CallDataService.reminderRevision,
                builder: (context, revision, child) => FutureBuilder<List<Map<String, dynamic>>>(
                future: CallDataService.loadReminders(),
                builder: (context, snapshot) {
                  final reminders = snapshot.data ?? [];
                  if (reminders.isEmpty) {
                    return Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF201E27), borderRadius: BorderRadius.circular(14)), child: const Text('No upcoming reminders', style: TextStyle(color: Colors.white38, fontSize: 12)));
                  }
                  return Column(children: reminders.map((item) {
                    final at = DateTime.tryParse(item['at']?.toString() ?? '');
                    final id = item['id']?.toString() ?? '';
                    final whenText = at == null ? '' : '${at.day}/${at.month} ${at.hour.toString().padLeft(2, '0')}:${at.minute.toString().padLeft(2, '0')}';
                    return Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: const Color(0xFF201E27), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white10)), child: Row(children: [
                      const Icon(Icons.alarm, color: Color(0xFF10B981), size: 20), const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(item['name']?.toString() ?? item['number']?.toString() ?? 'Contact', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 12)),
                        Text('${item['number'] ?? ''} · $whenText', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                      ])),
                      Text(item['label']?.toString() ?? 'Callback', style: const TextStyle(color: Color(0xFF10B981), fontSize: 10, fontWeight: FontWeight.w600)),
                      IconButton(tooltip: 'Cancel reminder', icon: const Icon(Icons.close, color: Colors.white54, size: 16), onPressed: () => CallDataService.cancelReminder(id)),
                    ]));
                  }).toList());
                },
              )),
              const SizedBox(height: 22),

              // Frequent Contacts Section
              const Text(
                'Top Contact Frequency',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              ...topFrequent.map((entry) {
                final callRecord = contactRepresentatives[entry.key]!;
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF201E27).withOpacity(0.7),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFF10B981).withOpacity(0.25)),
                        ),
                        child: Center(
                          child: Text(
                            callRecord.name.isNotEmpty ? callRecord.name[0].toUpperCase() : '?',
                            style: const TextStyle(
                              color: Color(0xFF10B981),
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              callRecord.name,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            Text(
                              '${entry.value} interactions recorded',
                              style: const TextStyle(color: Colors.white38, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.call, color: Color(0xFF10B981), size: 20),
                        onPressed: () => onCallNumber(callRecord.number),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMetricCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF201E27).withOpacity(0.85),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(color: Colors.white54, fontSize: 12),
              ),
              Icon(icon, color: color, size: 18),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(color: Colors.white60, fontSize: 10),
        ),
      ],
    );
  }
}
