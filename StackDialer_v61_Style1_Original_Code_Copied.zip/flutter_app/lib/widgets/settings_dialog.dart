import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/blocked_numbers_service.dart';
import '../services/speed_dial_service.dart';
import '../services/telecom_service.dart';
import '../services/app_appearance_service.dart';
import '../services/app_haptics.dart';

final ValueNotifier<Color> dialpadGlowColorNotifier = ValueNotifier<Color>(const Color(0xFF00E676));
final ValueNotifier<Color> bottomPillColorNotifier = ValueNotifier<Color>(const Color(0xFFFF0000));
final ValueNotifier<Color> floatingDialpadColorNotifier = ValueNotifier<Color>(const Color(0xFFFF0000));

class DialerSettingsDialog extends StatefulWidget {
  final VoidCallback? onSimulateIncoming;
  final bool showIos18Appearance;
  final String ios18Appearance;
  final ValueChanged<String>? onIos18AppearanceChanged;
  final ValueChanged<Color>? onDialpadGlowColorChanged;

  const DialerSettingsDialog({super.key, this.onSimulateIncoming, this.showIos18Appearance = false, this.ios18Appearance = 'sunset', this.onIos18AppearanceChanged, this.onDialpadGlowColorChanged});

  @override
  State<DialerSettingsDialog> createState() => _DialerSettingsDialogState();
}

class _DialerSettingsDialogState extends State<DialerSettingsDialog> {
  bool _isDefault = false;
  bool _autoRecord = false;
  bool _hapticEnabled = true;
  String _preferredSim = 'SIM 1';
  String _appearanceMode = 'dark';
  String _accentTheme = 'emerald';
  String _callScreenStyle = 'classic';
  Color _dialpadGlowColor = const Color(0xFF00E676);
  Color _bottomPillColor = const Color(0xFFFF0000);
  Color _floatingDialpadColor = const Color(0xFFFF0000);
  late String _ios18AppearanceChoice;

  @override
  void initState() {
    super.initState();
    _ios18AppearanceChoice = widget.ios18Appearance;
    _checkDefaultDialer();
    _loadGeneralSettings();
  }


  Future<void> _loadGeneralSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _preferredSim = prefs.getString('stackdialer_preferred_sim') ?? 'SIM 1';
      _autoRecord = prefs.getBool('stackdialer_spam_detection_enabled') ?? false;
      _hapticEnabled = prefs.getBool('stackdialer_haptics_enabled') ?? true;
      _appearanceMode = ['dark', 'amoled'].contains(prefs.getString('stackdialer_appearance_mode_v1')) ? prefs.getString('stackdialer_appearance_mode_v1')! : 'dark';
      _accentTheme = prefs.getString('stackdialer_accent_theme_v1') ?? 'emerald';
      _callScreenStyle = prefs.getString('stackdialer_call_screen_style_v1') ?? 'classic';
      final glowValue = prefs.getInt('dialpad_glow_color_v2');
      if (glowValue != null) {
        _dialpadGlowColor = Color(glowValue);
        dialpadGlowColorNotifier.value = _dialpadGlowColor;
      }
      _bottomPillColor = Color(prefs.getInt('stackdialer_bottom_pill_color_v1') ?? 0xFFFF0000);
      _floatingDialpadColor = Color(prefs.getInt('stackdialer_floating_dialpad_color_v1') ?? 0xFFFF0000);
      bottomPillColorNotifier.value = _bottomPillColor;
      floatingDialpadColorNotifier.value = _floatingDialpadColor;
    });
  }


  Future<void> _showDialpadGlowPicker() async {
    await _showColorPicker(
      initialColor: _dialpadGlowColor,
      preferenceKey: 'dialpad_glow_color_v2',
      onSelected: (selected) {
        setState(() => _dialpadGlowColor = selected);
        dialpadGlowColorNotifier.value = selected;
        widget.onDialpadGlowColorChanged?.call(selected);
      },
    );
  }

  Future<void> _showColorPicker({
    required Color initialColor,
    required String preferenceKey,
    required ValueChanged<Color> onSelected,
  }) async {
    Color working = initialColor;
    String tab = 'Swatches';

    Color shade(Color base, int row) {
      if (row == 0) return Color.lerp(Colors.white, base, .35)!;
      if (row == 1) return Color.lerp(Colors.white, base, .65)!;
      if (row == 2) return base;
      return Color.lerp(base, Colors.black, (row - 2) / 6)!;
    }

    const palette = <Color>[
      Colors.grey,
      Color(0xFFFF3B30),
      Color(0xFFFF9500),
      Color(0xFFFFFF00),
      Color(0xFF00E600),
      Color(0xFF00DFA0),
      Color(0xFF00E5E5),
      Color(0xFF168BFF),
      Color(0xFF1717F5),
      Color(0xFF7900F5),
      Color(0xFFE600E6),
    ];

    final selected = await showDialog<Color>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setPicker) => Dialog(
          backgroundColor: const Color(0xFFF8F8F8),
          insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: ['Swatches', 'Spectrum'].map((label) => Expanded(
                    child: InkWell(
                      onTap: () => setPicker(() => tab = label),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: tab == label ? Colors.black12 : Colors.transparent,
                          borderRadius: BorderRadius.circular(28),
                        ),
                        child: Center(
                          child: Text(label, style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                            color: tab == label ? Colors.black : Colors.black45,
                          )),
                        ),
                      ),
                    ),
                  )).toList(),
                ),
                const SizedBox(height: 10),
                if (tab == 'Swatches')
                  ClipRRect(
                    borderRadius: BorderRadius.circular(9),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: List.generate(9, (r) {
                        return SizedBox(
                          height: 27,
                          child: Row(
                            children: List.generate(11, (c) {
                              return Expanded(
                                child: GestureDetector(
                                  onTap: () => setPicker(() {
                                    working = shade(palette[c], r);
                                  }),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: shade(palette[c], r),
                                      border: working.value == shade(palette[c], r).value
                                          ? Border.all(color: Colors.black, width: 2.2)
                                          : null,
                                    ),
                                  ),
                                ),
                              );
                            }),
                          ),
                        );
                      }),
                    ),
                  ),
                if (tab == 'Spectrum')
                  Column(
                    children: [
                      Container(
                        height: 190,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: const LinearGradient(colors: [
                            Colors.red, Colors.orange, Colors.yellow, Colors.green,
                            Colors.cyan, Colors.blue, Colors.indigo, Colors.purple,
                            Colors.pink, Colors.red,
                          ]),
                        ),
                        child: LayoutBuilder(
                          builder: (context, bounds) => GestureDetector(
                            onPanDown: (details) => setPicker(() {
                              final hue = (details.localPosition.dx / bounds.maxWidth * 360)
                                  .clamp(0.0, 360.0);
                              working = HSVColor.fromAHSV(1, hue, 1, 1).toColor();
                            }),
                            onPanUpdate: (details) => setPicker(() {
                              final hue = (details.localPosition.dx / bounds.maxWidth * 360)
                                  .clamp(0.0, 360.0);
                              working = HSVColor.fromAHSV(1, hue, 1, 1).toColor();
                            }),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 9,
                        children: [Colors.white, Colors.black, Colors.red, Colors.orange,
                          Colors.yellow, Colors.green, Colors.cyan, Colors.blue,
                          Colors.purple, Colors.pink].map((c) => GestureDetector(
                            onTap: () => setPicker(() => working = c),
                            child: CircleAvatar(radius: 13, backgroundColor: c),
                          )).toList(),
                      ),
                    ],
                  ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Container(
                      width: 54,
                      height: 48,
                      decoration: BoxDecoration(
                        color: working,
                        border: Border.all(color: Colors.black12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Hex', style: TextStyle(
                            color: Colors.black54, fontWeight: FontWeight.w600,
                          )),
                          Text(
                            '#${working.value.toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}',
                            style: const TextStyle(
                              color: Colors.black, fontWeight: FontWeight.bold, fontSize: 17,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      'R ${working.red}\nG ${working.green}\nB ${working.blue}',
                      style: const TextStyle(
                        color: Colors.black, fontWeight: FontWeight.w600, height: 1.4,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Recently used colours', style: TextStyle(
                    color: Colors.black54, fontWeight: FontWeight.bold,
                  )),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    working, Colors.grey.shade300, Colors.grey.shade300,
                    Colors.grey.shade300, Colors.grey.shade300, Colors.grey.shade300,
                  ].map((c) => Expanded(
                    child: GestureDetector(
                      onTap: () => setPicker(() => working = c),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 3),
                        child: CircleAvatar(backgroundColor: c, radius: 20),
                      ),
                    ),
                  )).toList(),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: OutlinedButton.styleFrom(
                          backgroundColor: const Color(0xFFE5E7EB),
                          foregroundColor: const Color(0xFF202124),
                          side: const BorderSide(color: Color(0xFFD1D5DB)),
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        child: const Text('Cancel', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(ctx, working),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF202020),
                          foregroundColor: Colors.white,
                        ),
                        child: const Text('Done', style: TextStyle(fontSize: 17)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (selected != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(preferenceKey, selected.value);
      onSelected(selected);
    }
  }

  void _checkDefaultDialer() async {
    final def = await TelecomService.isDefaultDialer();
    if (mounted) {
      setState(() => _isDefault = def);
    }
  }

  void _showBlockedNumbersSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1C25),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final blocked = BlockedNumbersService.blockedList;
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Blocked / Spam Numbers',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              FutureBuilder<bool>(
                future: BlockedNumbersService.isCallScreeningRoleHeld(),
                builder: (context, snapshot) => Card(
                  color: const Color(0xFF302A36),
                  child: ListTile(
                    leading: Icon(snapshot.data == true ? Icons.verified_user : Icons.shield_outlined, color: snapshot.data == true ? const Color(0xFF10B981) : const Color(0xFFF59E0B)),
                    title: Text(snapshot.data == true ? 'Real call blocking is enabled' : 'Enable Android call-screening role', style: const TextStyle(color: Colors.white, fontSize: 13)),
                    subtitle: Text(snapshot.data == true ? 'Blocked callers will be rejected by Android.' : 'Required for the system to reject blocked callers.', style: const TextStyle(color: Colors.white60, fontSize: 11)),
                    trailing: snapshot.data == true ? const Icon(Icons.check, color: Color(0xFF10B981)) : TextButton(onPressed: () async { await BlockedNumbersService.requestCallScreeningRole(); if (ctx.mounted) { Navigator.pop(ctx); _showBlockedNumbersSheet(); } }, child: const Text('Enable')),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              if (blocked.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Center(
                    child: Text('No numbers blocked yet', style: TextStyle(color: Colors.white54)),
                  ),
                )
              else
                ...blocked.map(
                  (num) => ListTile(
                    leading: const Icon(Icons.block, color: Color(0xFFEF4444)),
                    title: Text(num, style: const TextStyle(color: Colors.white)),
                    trailing: TextButton(
                      child: const Text('Unblock', style: TextStyle(color: Color(0xFF38BDF8))),
                      onPressed: () async {
                        await BlockedNumbersService.unblockNumber(num);
                        Navigator.pop(ctx);
                        _showBlockedNumbersSheet();
                      },
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFEF4444).withOpacity(0.2),
                    foregroundColor: const Color(0xFFEF4444),
                    side: const BorderSide(color: Color(0xFFEF4444)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Block a Phone Number'),
                  onPressed: () {
                    final ctrl = TextEditingController();
                    showDialog(
                      context: ctx,
                      builder: (dCtx) => AlertDialog(
                        backgroundColor: const Color(0xFF1E1C25),
                        title: const Text('Block Number', style: TextStyle(color: Colors.white)),
                        content: TextField(
                          controller: ctrl,
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(color: Colors.white),
                          decoration: const InputDecoration(
                            hintText: '+91 99999 00000',
                            hintStyle: TextStyle(color: Colors.white38),
                          ),
                        ),
                        actions: [
                          TextButton(
                            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
                            onPressed: () => Navigator.pop(dCtx),
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFEF4444)),
                            child: const Text('Block', style: TextStyle(color: Colors.white)),
                            onPressed: () async {
                              if (ctrl.text.trim().isNotEmpty) {
                                await BlockedNumbersService.blockNumber(ctrl.text.trim());
                              }
                              Navigator.pop(dCtx);
                              Navigator.pop(ctx);
                              _showBlockedNumbersSheet();
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showSpeedDialSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF16141F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) {
        final entries = SpeedDialService.getAll();
        final presets = [
          {'name': 'Mom ❤️', 'key': 2},
          {'name': 'Dad 👔', 'key': 3},
          {'name': 'Best Friend ⭐', 'key': 4},
          {'name': 'Bro 👊', 'key': 5},
          {'name': 'Work 💼', 'key': 6},
          {'name': 'Home 🏡', 'key': 7},
          {'name': 'Doctor 🩺', 'key': 8},
          {'name': 'Emergency 🚨', 'key': 9},
        ];

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.speed, color: Color(0xFFA855F7), size: 22),
                        SizedBox(width: 8),
                        Text(
                          'Visual Speed Dial (3x3 Grid)',
                          style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white54),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                const Text(
                  'Tap any key to set Mom, Dad, or Best Friend for instant long-press dialing.',
                  style: TextStyle(color: Colors.white54, fontSize: 11),
                ),
                const SizedBox(height: 14),
                // 3x3 Grid of Keys 1 to 9
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 1.05,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: 9,
                  itemBuilder: (context, idx) {
                    final k = idx + 1;
                    final entry = entries[k];
                    final isAssigned = entry != null && entry.number.isNotEmpty;
                    final isVoicemail = k == 1;

                    return InkWell(
                      onTap: () {
                        AppHaptics.selectionClick();
                        final defaultPreset = presets.firstWhere((p) => p['key'] == k, orElse: () => {'name': 'Contact #$k'});
                        final nameCtrl = TextEditingController(text: entry?.name ?? defaultPreset['name'].toString());
                        final numCtrl = TextEditingController(text: entry?.number ?? '');

                        showDialog(
                          context: ctx,
                          builder: (dlgCtx) => AlertDialog(
                            backgroundColor: const Color(0xFF1E1C25),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                            title: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFA855F7).withOpacity(0.2),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Text('$k', style: const TextStyle(color: Color(0xFFA855F7), fontWeight: FontWeight.bold, fontSize: 16)),
                                ),
                                const SizedBox(width: 10),
                                Text('Set Speed Dial #$k', style: const TextStyle(color: Colors.white, fontSize: 16)),
                              ],
                            ),
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // Quick suggestion chips
                                Wrap(
                                  spacing: 6,
                                  runSpacing: 4,
                                  children: [
                                    'Mom ❤️', 'Dad 👔', 'Best Friend ⭐', 'Emergency 🚨'
                                  ].map((label) => ActionChip(
                                    backgroundColor: Colors.white.withOpacity(0.08),
                                    label: Text(label, style: const TextStyle(fontSize: 10, color: Colors.white70)),
                                    onPressed: () {
                                      nameCtrl.text = label;
                                    },
                                  )).toList(),
                                ),
                                const SizedBox(height: 10),
                                TextField(
                                  controller: nameCtrl,
                                  style: const TextStyle(color: Colors.white),
                                  decoration: const InputDecoration(labelText: 'Contact Name', labelStyle: TextStyle(color: Colors.white60)),
                                ),
                                TextField(
                                  controller: numCtrl,
                                  style: const TextStyle(color: Colors.white),
                                  keyboardType: TextInputType.phone,
                                  decoration: const InputDecoration(labelText: 'Phone Number', labelStyle: TextStyle(color: Colors.white60)),
                                ),
                              ],
                            ),
                            actions: [
                              if (isAssigned && !isVoicemail)
                                TextButton(
                                  onPressed: () {
                                    SpeedDialService.removeEntry(k);
                                    Navigator.pop(dlgCtx);
                                    Navigator.pop(ctx);
                                    _showSpeedDialSheet();
                                  },
                                  child: const Text('Remove', style: TextStyle(color: Color(0xFFEF4444))),
                                ),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF10B981),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                onPressed: () {
                                  if (numCtrl.text.trim().isNotEmpty) {
                                    SpeedDialService.setEntry(
                                      k,
                                      nameCtrl.text.trim().isEmpty ? 'Key #$k' : nameCtrl.text.trim(),
                                      numCtrl.text.trim(),
                                    );
                                  }
                                  Navigator.pop(dlgCtx);
                                  Navigator.pop(ctx);
                                  _showSpeedDialSheet();
                                },
                                child: const Text('Save Speed Dial', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                              ),
                            ],
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: isAssigned
                              ? (isVoicemail ? const Color(0xFF3B82F6).withOpacity(0.12) : const Color(0xFFA855F7).withOpacity(0.15))
                              : Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isAssigned ? (isVoicemail ? const Color(0xFF38BDF8) : const Color(0xFFA855F7)) : Colors.white12,
                            width: isAssigned ? 1.2 : 0.8,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFA855F7).withOpacity(0.25),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text('$k', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                                ),
                                if (isAssigned)
                                  const Icon(Icons.check_circle, color: Color(0xFF10B981), size: 14)
                                else
                                  const Icon(Icons.add, color: Colors.white24, size: 14),
                              ],
                            ),
                            const Spacer(),
                            Text(
                              isAssigned ? entry.name : 'Tap to set',
                              style: TextStyle(
                                color: isAssigned ? Colors.white : Colors.white54,
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              isAssigned ? entry.number : 'Key #$k',
                              style: TextStyle(
                                color: isAssigned ? const Color(0xFF38BDF8) : Colors.white24,
                                fontSize: 9,
                                fontFamily: 'monospace',
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF181620),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.settings, color: Color(0xFF10B981), size: 24),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'All App Settings',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        Text('All features and preferences in one place', style: TextStyle(fontSize: 12, color: Colors.white54)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // Default Dialer Banner
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _isDefault
                      ? const Color(0xFF10B981).withOpacity(0.12)
                      : const Color(0xFF6366F1).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _isDefault
                        ? const Color(0xFF10B981).withOpacity(0.4)
                        : const Color(0xFF6366F1).withOpacity(0.4),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _isDefault ? Icons.check_circle : Icons.phone_android,
                      color: _isDefault ? const Color(0xFF10B981) : const Color(0xFF818CF8),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _isDefault ? 'Default Phone App: Active' : 'Set as Default Phone App',
                            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 13),
                          ),
                          Text(
                            _isDefault
                                ? 'Custom incoming/outgoing UI active'
                                : 'Enables custom incoming call screen for all SIM calls',
                            style: const TextStyle(fontSize: 11, color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                    if (!_isDefault)
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF6366F1),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          minimumSize: Size.zero,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        onPressed: () async {
                          await TelecomService.requestDefaultDialer();
                          _checkDefaultDialer();
                        },
                        child: const Text('Set', style: TextStyle(fontSize: 12, color: Colors.white)),
                      ),
                  ],
                ),
              ),

              if (widget.showIos18Appearance) ...[
                const SizedBox(height: 12),
                const Divider(color: Colors.white12),
                const Text('iOS 18 Style 1 — Appearance', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 4),
                const Text('Choose a background and card design. This setting affects iOS 18 Style 1 only.', style: TextStyle(color: Colors.white54, fontSize: 11)),
                const SizedBox(height: 8),
                ...const [
                  ('original', '0. Original iOS 18', Color(0xFF77717F), Color(0xFF22202C)),
                  ('purple', '1. Purple Glow', Color(0xFF9B4DFF), Color(0xFF24104D)),
                  ('gold', '2. Gold Luxury', Color(0xFFFFC247), Color(0xFF38250B)),
                  ('sky', '3. Sky Premium', Color(0xFF64B5FF), Color(0xFFBDE8FF)),
                  ('green', '4. Green Nature', Color(0xFF45D66B), Color(0xFF102D18)),
                  ('sunset', '5. Sunset Dream', Color(0xFFFFA36B), Color(0xFF6B286C)),
                ].map((item) => RadioListTile<String>(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  activeColor: item.$3,
                  value: item.$1,
                  groupValue: _ios18AppearanceChoice,
                  title: Text(item.$2, style: const TextStyle(color: Colors.white, fontSize: 13)),
                  secondary: Container(width: 30, height: 30, decoration: BoxDecoration(gradient: LinearGradient(colors: [item.$3, item.$4]), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.white38))),
                  onChanged: (value) { if (value != null) { setState(() => _ios18AppearanceChoice = value); widget.onIos18AppearanceChanged?.call(value); } },
                )),
              ],

              const SizedBox(height: 16),

              const SizedBox(height: 10),
              const Divider(color: Colors.white12),
              const Text('Advanced Personalization', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 8),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.color_lens_outlined, color: _dialpadGlowColor),
                title: const Text('Number key glow color', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Choose any hue, shade and brightness for keypad touch glow', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: Container(width: 28, height: 28, decoration: BoxDecoration(color: _dialpadGlowColor, shape: BoxShape.circle, border: Border.all(color: Colors.white70), boxShadow: [BoxShadow(color: _dialpadGlowColor.withOpacity(.65), blurRadius: 12)])),
                onTap: _showDialpadGlowPicker,
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.circle_outlined, color: _bottomPillColor),
                title: const Text('Bottom navigation pill colour', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Change the selected Recents / Contacts pill highlight', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: Container(width: 28, height: 28, decoration: BoxDecoration(color: _bottomPillColor, shape: BoxShape.circle, border: Border.all(color: Colors.white70))),
                onTap: () => _showColorPicker(
                  initialColor: _bottomPillColor,
                  preferenceKey: 'stackdialer_bottom_pill_color_v1',
                  onSelected: (selected) {
                    setState(() => _bottomPillColor = selected);
                    bottomPillColorNotifier.value = selected;
                  },
                ),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.dialpad_rounded, color: _floatingDialpadColor),
                title: const Text('Floating dialpad button colour', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Change the floating dialpad button background', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: Container(width: 28, height: 28, decoration: BoxDecoration(color: _floatingDialpadColor, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.white70))),
                onTap: () => _showColorPicker(
                  initialColor: _floatingDialpadColor,
                  preferenceKey: 'stackdialer_floating_dialpad_color_v1',
                  onSelected: (selected) {
                    setState(() => _floatingDialpadColor = selected);
                    floatingDialpadColorNotifier.value = selected;
                  },
                ),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.brightness_6_outlined, color: Color(0xFF38BDF8)),
                title: const Text('App theme', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Switch between dark and true-black AMOLED themes', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: DropdownButton<String>(value: _appearanceMode, dropdownColor: const Color(0xFF1E1C25), underline: const SizedBox(), style: const TextStyle(color: Colors.white, fontSize: 12), items: const [DropdownMenuItem(value: 'dark', child: Text('Dark')), DropdownMenuItem(value: 'amoled', child: Text('AMOLED'))], onChanged: (v) { if (v != null) { setState(() => _appearanceMode = v); AppAppearanceService.instance.setMode(v); } }),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.palette_outlined, color: Color(0xFFA78BFA)),
                title: const Text('Accent colour', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Changes Material controls and highlights', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: DropdownButton<String>(value: _accentTheme, dropdownColor: const Color(0xFF1E1C25), underline: const SizedBox(), style: const TextStyle(color: Colors.white, fontSize: 12), items: const [DropdownMenuItem(value: 'emerald', child: Text('Emerald')), DropdownMenuItem(value: 'blue', child: Text('Blue')), DropdownMenuItem(value: 'violet', child: Text('Violet')), DropdownMenuItem(value: 'amber', child: Text('Amber')), DropdownMenuItem(value: 'rose', child: Text('Rose'))], onChanged: (v) { if (v != null) { setState(() => _accentTheme = v); AppAppearanceService.instance.setAccent(v); } }),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.call, color: Color(0xFF10B981)),
                title: const Text('Incoming / active call screen', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Customize the in-app call screen layout', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: DropdownButton<String>(value: _callScreenStyle, dropdownColor: const Color(0xFF1E1C25), underline: const SizedBox(), style: const TextStyle(color: Colors.white, fontSize: 12), items: const [DropdownMenuItem(value: 'classic', child: Text('Classic')), DropdownMenuItem(value: 'compact', child: Text('Compact')), DropdownMenuItem(value: 'gradient', child: Text('Gradient'))], onChanged: (v) { if (v != null) { setState(() => _callScreenStyle = v); AppAppearanceService.instance.setCallScreenStyle(v); } }),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.music_note, color: Color(0xFFF59E0B)),
                title: const Text('Phone ringtone', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Choose the actual device ringtone in Android settings', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: const Icon(Icons.open_in_new, color: Colors.white54, size: 18),
                onTap: () async { final ok = await TelecomService.openSystemRingtoneSettings(); if (!ok && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open Android sound settings'))); },
              ),

              // Dual SIM preference
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.sim_card, color: Color(0xFF38BDF8)),
                title: const Text('Default Calling SIM', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: Text(_preferredSim, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: DropdownButton<String>(
                  value: _preferredSim,
                  dropdownColor: const Color(0xFF1E1C25),
                  underline: const SizedBox(),
                  style: const TextStyle(color: Color(0xFF38BDF8), fontSize: 12),
                  items: const [
                    DropdownMenuItem(value: 'SIM 1', child: Text('SIM 1')),
                    DropdownMenuItem(value: 'SIM 2', child: Text('SIM 2')),
                    DropdownMenuItem(value: 'Always Ask', child: Text('Always Ask')),
                  ],
                  onChanged: (val) {
                    if (val != null) {
                      setState(() => _preferredSim = val);
                      SharedPreferences.getInstance().then((p) => p.setString('stackdialer_preferred_sim', val));
                    }
                  },
                ),
              ),

              // Auto Record Toggle
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.record_voice_over, color: Color(0xFFEF4444)),
                title: const Text('Spam Number Detection', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Enable spam-flag preference for supported checks', style: TextStyle(color: Colors.white54, fontSize: 11)),
                value: _autoRecord,
                activeColor: const Color(0xFF10B981),
                onChanged: (val) {
                  setState(() => _autoRecord = val);
                  SharedPreferences.getInstance().then((p) => p.setBool('stackdialer_spam_detection_enabled', val));
                },
              ),

              // Haptic Feedback
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.vibration, color: Color(0xFFF59E0B)),
                title: const Text('App vibration feedback', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Turn vibration feedback across the app on or off', style: TextStyle(color: Colors.white54, fontSize: 11)),
                value: _hapticEnabled,
                activeColor: const Color(0xFF10B981),
                onChanged: (val) {
                  setState(() => _hapticEnabled = val);
                  AppHaptics.setEnabled(val);
                },
              ),

              const Divider(color: Colors.white12),

              const Divider(color: Colors.white12),

              // Speed Dial Management
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.speed, color: Color(0xFFA855F7)),
                title: const Text('Speed Dial Shortcuts', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Configure long-press contacts for keys 1-9', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                onTap: _showSpeedDialSheet,
              ),

              // Blocked Numbers Management
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.shield_outlined, color: Color(0xFFEF4444)),
                title: const Text('Blocked & Spam Numbers', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Manage blacklisted caller IDs and spam filters', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                onTap: _showBlockedNumbersSheet,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
