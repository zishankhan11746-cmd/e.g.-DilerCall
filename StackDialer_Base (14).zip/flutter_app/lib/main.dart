import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'models/call_record.dart';
import 'models/contact.dart';
import 'screens/active_call_screen.dart';
import 'screens/stacked_recents_screen.dart';
import 'screens/t9_dialpad_screen.dart';
import 'screens/contacts_screen.dart';
import 'screens/insights_screen.dart';
import 'services/blocked_numbers_service.dart';
import 'services/speed_dial_service.dart';
import 'services/telecom_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0D0C11),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Initialize persistent services
  await SpeedDialService.init();
  await BlockedNumbersService.init();

  runApp(const StackDialerApp());
}

class StackDialerApp extends StatelessWidget {
  const StackDialerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StackDialer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF141219),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(
          ThemeData(brightness: Brightness.dark).textTheme,
        ),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF10B981),
          surface: Color(0xFF1E1C25),
        ),
      ),
      home: const MainDialerHost(),
    );
  }
}

class MainDialerHost extends StatefulWidget {
  const MainDialerHost({super.key});

  @override
  State<MainDialerHost> createState() => _MainDialerHostState();
}

class _MainDialerHostState extends State<MainDialerHost> with WidgetsBindingObserver {
  int _currentIndex = 0;
  List<CallRecord> _callLogs = [];
  List<ContactModel> _contacts = [];
  bool _isLoading = true;
  bool _hasActiveCallScreen = false;
  bool _isDefaultDialer = false;
  String? _incomingBannerNumber;
  String? _incomingBannerName;
  String? _activeCallBannerNumber;
  String? _activeCallBannerName;
  bool _activeCallBannerIsIncoming = false;
  Offset _bubbleOffset = const Offset(18, 120);
  final List<CallRecord> _recentDialedCalls = [];

  Timer? _activeCallDurationTimer;
  int _activeCallDurationSeconds = 0;

  void _startActiveCallDurationTimer() {
    _activeCallDurationTimer?.cancel();
    _activeCallDurationTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && _activeCallBannerNumber != null) {
        setState(() {
          _activeCallDurationSeconds++;
        });
      }
    });
  }

  void _stopActiveCallDurationTimer() {
    _activeCallDurationTimer?.cancel();
    _activeCallDurationTimer = null;
    _activeCallDurationSeconds = 0;
  }

  String _formatCallDuration(int totalSeconds) {
    final mins = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final secs = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initDeviceData();
    _checkDefaultDialer();
    _setupTelecomInCallListener();
    _checkPendingCall();
  }

  @override
  void dispose() {
    _activeCallDurationTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Whenever user returns from making a phone call or switching back,
      // reload live device call logs and update default dialer status!
      _checkDefaultDialer();
      _checkPendingCall();
      _refreshCallLogs();
    }
  }

  Future<void> _checkPendingCall() async {
    try {
      final pending = await TelecomService.getPendingIncomingCall();
      if (pending != null && mounted) {
        final number = pending['number'] ?? '';
        final state = pending['state'] ?? '';
        if (number.isNotEmpty && (state == 'RINGING' || state == 'ACTIVE')) {
          final matched = _findContact(number);
          setState(() {
            _incomingBannerNumber = number;
            _incomingBannerName = matched?.name ?? number;
          });
          _openIncomingCallScreen(number, matched?.name);
        }
      }
    } catch (_) {}
  }

  Future<void> _checkDefaultDialer() async {
    try {
      final isDef = await TelecomService.isDefaultDialer();
      if (mounted) {
        setState(() => _isDefaultDialer = isDef);
      }
    } catch (_) {}
  }

  void _setupTelecomInCallListener() {
    TelecomService.setupCallListener((number, state) {
      if (!mounted) return;
      final matched = _findContact(number);
      if (state == 'RINGING') {
        setState(() {
          _incomingBannerNumber = number;
          _incomingBannerName = matched?.name ?? number;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
        _openIncomingCallScreen(number, matched?.name);
      } else if (state == 'ACTIVE') {
        _startActiveCallDurationTimer();
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = number;
          _activeCallBannerName = matched?.name ?? number;
        });
        if (!_hasActiveCallScreen) {
          _openIncomingCallScreen(number, matched?.name);
        }
      } else if (state == 'DISCONNECTED' || state == 'IDLE') {
        _stopActiveCallDurationTimer();
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
        // Call ended, refresh live device call log after slight buffer for Android CallLog provider to sync!
        Future.delayed(const Duration(milliseconds: 700), () {
          if (mounted) _refreshCallLogs();
        });
      }
    });
  }

  Future<void> _initDeviceData() async {
    setState(() => _isLoading = true);
    await TelecomService.requestPermissions();
    final logs = await TelecomService.fetchDeviceCallLogs();
    final contacts = await TelecomService.fetchDeviceContacts();
    if (mounted) {
      setState(() {
        _callLogs = _mergeCalls(logs, _recentDialedCalls);
        _contacts = contacts;
        _isLoading = false;
      });
    }
  }

  Future<void> _refreshCallLogs() async {
    try {
      final logs = await TelecomService.fetchDeviceCallLogs();
      if (mounted) {
        setState(() {
          _callLogs = _mergeCalls(logs, _recentDialedCalls);
        });
      }
    } catch (_) {}
  }

  List<CallRecord> _mergeCalls(List<CallRecord> deviceLogs, List<CallRecord> localCalls) {
    final Map<String, CallRecord> map = {};
    // Add local calls first
    for (final c in localCalls) {
      map['${c.number}_${c.timestamp.millisecondsSinceEpoch ~/ 30000}'] = c;
    }
    // Add or override with real device logs
    for (final c in deviceLogs) {
      map['${c.number}_${c.timestamp.millisecondsSinceEpoch ~/ 30000}'] = c;
    }
    final merged = map.values.toList();
    merged.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    return merged;
  }

  ContactModel? _findContact(String number) {
    final clean = number.replaceAll(RegExp(r'[^\d]'), '');
    if (clean.isEmpty) return null;
    return _contacts.cast<ContactModel?>().firstWhere(
          (c) => c != null && c.number.replaceAll(RegExp(r'[^\d]'), '').endsWith(clean),
          orElse: () => null,
        );
  }

  void _openIncomingCallScreen(String number, [String? name]) {
    if (_hasActiveCallScreen) return;
    _hasActiveCallScreen = true;
    final matched = _findContact(number);
    final displayName = name ?? matched?.name ?? number;

    setState(() {
      _activeCallBannerNumber = number;
      _activeCallBannerName = displayName;
    });

    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 380),
        reverseTransitionDuration: const Duration(milliseconds: 300),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
            reverseCurve: Curves.easeInCubic,
          );
          return FadeTransition(
            opacity: animation,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.88, end: 1.0).animate(curved),
              child: child,
            ),
          );
        },
        pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
          phoneNumber: number,
          contactName: displayName,
          callerCategory: 'Incoming Call',
          isIncoming: true,
          simSlot: 1,
          onCallEnded: (record) {
            _hasActiveCallScreen = false;
            _stopActiveCallDurationTimer();
            TelecomService.cancelIncomingBanner();
            TelecomService.cancelOngoingNotification();
            setState(() {
              _activeCallBannerNumber = null;
              _activeCallBannerName = null;
              _incomingBannerNumber = null;
              _incomingBannerName = null;
              _recentDialedCalls.insert(0, record);
              _callLogs = _mergeCalls(_callLogs, _recentDialedCalls);
            });
            Future.delayed(const Duration(milliseconds: 700), () {
              if (mounted) _refreshCallLogs();
            });
          },
        ),
      ),
    ).then((_) {
      _hasActiveCallScreen = false;
    });
  }

  void _onCallNumber(String number, {int simSlot = 1}) async {
    HapticFeedback.heavyImpact();
    final clean = number.replaceAll(RegExp(r'[^\d+*#]'), '');
    if (clean.isEmpty) return;

    final matched = _findContact(clean);
    final displayName = matched?.name ?? clean;

    // 1. Immediately create a real CallRecord and insert it at the TOP of recent calls
    final newOutgoingRecord = CallRecord(
      id: 'call_${DateTime.now().millisecondsSinceEpoch}',
      name: displayName,
      number: clean,
      type: CallType.outgoing,
      timestamp: DateTime.now(),
      durationSeconds: 0,
      simSlot: simSlot,
      simCarrier: 'SIM $simSlot',
      category: matched?.company ?? 'Personal',
      location: 'Mobile Outgoing',
    );

    _startActiveCallDurationTimer();

    setState(() {
      _recentDialedCalls.insert(0, newOutgoingRecord);
      _callLogs.insert(0, newOutgoingRecord);
      _activeCallBannerNumber = clean;
      _activeCallBannerName = displayName;
    });

    // 2. Immediately present the executive Outgoing ActiveCallScreen
    if (!_hasActiveCallScreen) {
      _hasActiveCallScreen = true;
      if (mounted) {
        Navigator.of(context).push(
          PageRouteBuilder(
            opaque: true,
            transitionDuration: const Duration(milliseconds: 380),
            reverseTransitionDuration: const Duration(milliseconds: 300),
            transitionsBuilder: (context, animation, secondaryAnimation, child) {
              final curved = CurvedAnimation(
                parent: animation,
                curve: Curves.easeOutCubic,
                reverseCurve: Curves.easeInCubic,
              );
              return FadeTransition(
                opacity: animation,
                child: ScaleTransition(
                  scale: Tween<double>(begin: 0.88, end: 1.0).animate(curved),
                  child: child,
                ),
              );
            },
            pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
              phoneNumber: clean,
              contactName: displayName,
              callerCategory: matched?.company ?? 'Mobile',
              isIncoming: false,
              simSlot: simSlot,
              onCallEnded: (record) {
                _hasActiveCallScreen = false;
                _stopActiveCallDurationTimer();
                TelecomService.cancelOngoingNotification();
                TelecomService.cancelIncomingBanner();
                setState(() {
                  _activeCallBannerNumber = null;
                  _activeCallBannerName = null;
                  _recentDialedCalls.insert(0, record);
                  _callLogs = _mergeCalls(_callLogs, _recentDialedCalls);
                });
                Future.delayed(const Duration(milliseconds: 700), () {
                  if (mounted) _refreshCallLogs();
                });
              },
            ),
          ),
        ).then((_) {
          _hasActiveCallScreen = false;
        });
      }
    }

    // 3. Launch real native SIM call via Android Carrier & Show Sticky Notification
    TelecomService.makeRealCall(clean);
    TelecomService.showOngoingNotification(clean, name: displayName, isIncoming: false);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Color(0xFF10B981),
                  ),
                )
              : Column(
                  children: [
                    // Default dialer alert banner if not set
                    if (!_isDefaultDialer)
                      SafeArea(
                        bottom: false,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          color: const Color(0xFF10B981).withOpacity(0.12),
                          child: Row(
                            children: [
                              const Icon(Icons.shield_outlined, color: Color(0xFF10B981), size: 16),
                              const SizedBox(width: 8),
                              const Expanded(
                                child: Text(
                                  'Set StackDialer as Default Phone App for full lock-screen UI',
                                  style: TextStyle(color: Colors.white70, fontSize: 11),
                                ),
                              ),
                              InkWell(
                                onTap: () async {
                                  await TelecomService.requestDefaultDialer();
                                  Future.delayed(const Duration(seconds: 1), _checkDefaultDialer);
                                },
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'Set Default',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    Expanded(
                      child: IndexedStack(
                        index: _currentIndex,
                        children: [
                          T9DialpadScreen(
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                          ),
                          StackedRecentsScreen(
                            calls: _callLogs,
                            onRefresh: _refreshCallLogs,
                            onCallNumber: _onCallNumber,
                          ),
                          ContactsScreen(
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                          ),
                          DialerSearchScreen(
                            calls: _callLogs,
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                            isActive: _currentIndex == 3,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

          // 1. Floating Incoming Call Heads-Up Banner at top of the app
          if (_incomingBannerNumber != null)
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 14,
              right: 14,
              child: Material(
                elevation: 24,
                borderRadius: BorderRadius.circular(20),
                color: const Color(0xFF1F1D2B),
                child: InkWell(
                  onTap: () => _openIncomingCallScreen(_incomingBannerNumber!, _incomingBannerName),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF10B981), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF10B981).withOpacity(0.35),
                          blurRadius: 20,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.call_received, color: Color(0xFF10B981), size: 24),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                _incomingBannerName ?? _incomingBannerNumber!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              Text(
                                'Incoming Call... • ${_incomingBannerNumber!}',
                                style: const TextStyle(
                                  color: Color(0xFF10B981),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Reject Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.rejectCall();
                            await TelecomService.cancelIncomingBanner();
                            setState(() {
                              _incomingBannerNumber = null;
                              _incomingBannerName = null;
                            });
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFFEF4444),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call_end, color: Colors.white, size: 18),
                          ),
                        ),
                        // Answer Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.answerCall();
                            await TelecomService.cancelIncomingBanner();
                            final num = _incomingBannerNumber!;
                            final name = _incomingBannerName;
                            setState(() {
                              _incomingBannerNumber = null;
                              _incomingBannerName = null;
                            });
                            _openIncomingCallScreen(num, name);
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFF10B981),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call, color: Colors.white, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          // 2. Sleek Draggable Floating Mini Call Bubble (Picture-in-Picture)
          if (_activeCallBannerNumber != null && _incomingBannerNumber == null)
            Positioned(
              top: _bubbleOffset.dy.clamp(MediaQuery.of(context).padding.top + 8, MediaQuery.of(context).size.height - 150),
              left: _bubbleOffset.dx.clamp(10.0, MediaQuery.of(context).size.width - 220),
              child: GestureDetector(
                onPanUpdate: (details) {
                  setState(() {
                    _bubbleOffset += details.delta;
                  });
                },
                child: Material(
                  elevation: 24,
                  borderRadius: BorderRadius.circular(32),
                  color: Colors.transparent,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(32),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xE614131B),
                          borderRadius: BorderRadius.circular(32),
                          border: Border.all(color: const Color(0xFF10B981).withOpacity(0.7), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF10B981).withOpacity(0.35),
                              blurRadius: 20,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Glowing Call Avatar Bubble
                            InkWell(
                              onTap: () => _openIncomingCallScreen(_activeCallBannerNumber!, _activeCallBannerName),
                              borderRadius: BorderRadius.circular(20),
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [Color(0xFF10B981), Color(0xFF047857)],
                                  ),
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xFF10B981).withOpacity(0.5),
                                      blurRadius: 10,
                                    ),
                                  ],
                                ),
                                child: const Center(
                                  child: Icon(Icons.phone_in_talk_rounded, color: Colors.white, size: 20),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            // Caller details & return CTA
                            InkWell(
                              onTap: () => _openIncomingCallScreen(_activeCallBannerNumber!, _activeCallBannerName),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  ConstrainedBox(
                                    constraints: const BoxConstraints(maxWidth: 105),
                                    child: Text(
                                      _activeCallBannerName ?? _activeCallBannerNumber!,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Container(
                                        width: 6,
                                        height: 6,
                                        decoration: const BoxDecoration(
                                          color: Color(0xFF10B981),
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        _formatCallDuration(_activeCallDurationSeconds),
                                        style: const TextStyle(
                                          color: Color(0xFF10B981),
                                          fontSize: 10,
                                          fontWeight: FontWeight.w800,
                                          fontFamily: 'monospace',
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      const Text(
                                        '• Tap',
                                        style: TextStyle(
                                          color: Colors.white70,
                                          fontSize: 9,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 10),
                            // End Call Mini CTA
                            InkWell(
                              onTap: () async {
                                HapticFeedback.mediumImpact();
                                _stopActiveCallDurationTimer();
                                await TelecomService.disconnectCall();
                                await TelecomService.cancelIncomingBanner();
                                setState(() {
                                  _activeCallBannerNumber = null;
                                  _activeCallBannerName = null;
                                });
                              },
                              borderRadius: BorderRadius.circular(16),
                              child: Container(
                                padding: const EdgeInsets.all(7),
                                decoration: const BoxDecoration(
                                  color: Color(0xFFEF4444),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.call_end, color: Colors.white, size: 14),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(10, 7, 10, 9),
        child: Container(
          height: 70,
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: const Color(0xFF242428),
            borderRadius: BorderRadius.circular(42),
            border: Border.all(color: Colors.white.withOpacity(0.035), width: 1),
            boxShadow: const [
              BoxShadow(color: Color(0x33000000), blurRadius: 16, offset: Offset(0, 5)),
            ],
          ),
          child: Row(
            children: [
              _buildPillNavItem(0, Icons.dialpad_rounded, 'Keypad'),
              _buildPillNavItem(1, Icons.phone_forwarded_rounded, 'Recents'),
              _buildPillNavItem(2, Icons.person_outline_rounded, 'Contacts'),
              _buildPillNavItem(3, Icons.search_rounded, 'Search'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPillNavItem(int index, IconData icon, String label) {
    final selected = _currentIndex == index;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => _currentIndex = index);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFF414145) : Colors.transparent,
            borderRadius: BorderRadius.circular(38),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 26, color: selected ? Colors.white : Colors.white.withOpacity(0.88)),
              const SizedBox(height: 3),
              Text(label, style: TextStyle(
                color: selected ? Colors.white : Colors.white.withOpacity(0.86),
                fontSize: 12,
                fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                letterSpacing: 0.1,
              )),
            ],
          ),
        ),
      ),
    );
  }
}


class DialerSearchScreen extends StatefulWidget {
  final List<CallRecord> calls;
  final List<ContactModel> contacts;
  final void Function(String number, {int simSlot}) onCallNumber;
  final bool isActive;

  const DialerSearchScreen({
    super.key,
    required this.calls,
    required this.contacts,
    required this.onCallNumber,
    this.isActive = false,
  });

  @override
  State<DialerSearchScreen> createState() => _DialerSearchScreenState();
}

class _DialerSearchScreenState extends State<DialerSearchScreen> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  @override
  void didUpdateWidget(covariant DialerSearchScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && widget.isActive) {
          _searchFocusNode.requestFocus();
        }
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  bool _matches(String name, String number) {
    final query = _controller.text.trim().toLowerCase();
    return query.isEmpty || name.toLowerCase().contains(query) || number.toLowerCase().contains(query);
  }

  @override
  Widget build(BuildContext context) {
    final contacts = widget.contacts.where((c) => _matches(c.name, c.number)).take(30).toList();
    final calls = widget.calls.where((c) => _matches(c.name, c.number)).take(30).toList();
    return Scaffold(
      backgroundColor: const Color(0xFF141219),
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 18, 20, 12),
              child: Text('Search', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w700)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                height: 52,
                decoration: BoxDecoration(
                  color: const Color(0xFF242428),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: Colors.white12),
                ),
                child: TextField(
                  controller: _controller,
                  focusNode: _searchFocusNode,
                  autofocus: false,
                  onChanged: (_) => setState(() {}),
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  decoration: InputDecoration(
                    hintText: 'Search contacts and calls',
                    hintStyle: const TextStyle(color: Colors.white54),
                    prefixIcon: const Icon(Icons.search_rounded, color: Colors.white70),
                    suffixIcon: _controller.text.isEmpty ? null : IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white70),
                      onPressed: () { _controller.clear(); setState(() {}); },
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 15),
                  ),
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 16, 14, 20),
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(6, 2, 6, 8),
                    child: Text('CONTACTS', style: TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  ),
                  if (contacts.isEmpty)
                    const Padding(padding: EdgeInsets.all(10), child: Text('No matching contacts', style: TextStyle(color: Colors.white38, fontSize: 13)))
                  else
                    ...contacts.map((contact) => _searchResultTile(
                      icon: Icons.person_outline_rounded,
                      title: contact.name,
                      subtitle: contact.number,
                      onTap: () => widget.onCallNumber(contact.number),
                    )),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(6, 18, 6, 8),
                    child: Text('RECENT CALLS', style: TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  ),
                  if (calls.isEmpty)
                    const Padding(padding: EdgeInsets.all(10), child: Text('No matching recent calls', style: TextStyle(color: Colors.white38, fontSize: 13)))
                  else
                    ...calls.map((call) => _searchResultTile(
                      icon: call.type == CallType.missed || call.type == CallType.rejected ? Icons.call_missed_rounded : Icons.call_rounded,
                      title: call.name.isEmpty ? call.number : call.name,
                      subtitle: '${call.number}  ·  ${call.dateLabel} ${call.timeFormatted}',
                      onTap: () => widget.onCallNumber(call.number, simSlot: call.simSlot),
                    )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _searchResultTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      decoration: BoxDecoration(color: const Color(0xFF202024), borderRadius: BorderRadius.circular(17), border: Border.all(color: Colors.white.withOpacity(0.055))),
      child: ListTile(
        onTap: onTap,
        leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF10B981).withOpacity(0.15), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: const Color(0xFF10B981), size: 21)),
        title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        trailing: const Icon(Icons.call_rounded, color: Color(0xFF10B981), size: 20),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      ),
    );
  }
}
