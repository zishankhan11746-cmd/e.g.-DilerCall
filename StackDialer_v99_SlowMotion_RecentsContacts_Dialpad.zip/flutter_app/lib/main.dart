import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'utils/clock_format.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'models/call_record.dart';
import 'models/contact.dart';
import 'screens/active_call_screen.dart';
import 'screens/stacked_recents_screen.dart';
import 'screens/t9_dialpad_screen.dart';
import 'screens/contacts_screen.dart';
import 'screens/insights_screen.dart';
import 'screens/follow_up_tasks_screen.dart';
import 'services/blocked_numbers_service.dart';
import 'services/speed_dial_service.dart';
import 'services/telecom_service.dart';
import 'services/call_data_service.dart';
import 'services/app_appearance_service.dart';
import 'services/app_haptics.dart';
import 'services/follow_up_task_service.dart';
import 'widgets/settings_dialog.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0D0C11),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Initialize persistent services
  await SpeedDialService.init();
  await BlockedNumbersService.init();
  await AppAppearanceService.instance.init();
  await AppHaptics.init();
  // Restore persisted button/pill colours before the first frame is rendered.
  await loadPersistedColorPreferences();

  runApp(const StackDialerApp());
}

class StackDialerApp extends StatelessWidget {
  const StackDialerApp({super.key});

  ThemeData _theme(Brightness brightness, Color accent) {
    final base = ThemeData(brightness: brightness, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: brightness == Brightness.dark ? (AppAppearanceService.instance.amoled ? Colors.black : const Color(0xFF141219)) : const Color(0xFFF4F5F8),
      colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: brightness),
      textTheme: GoogleFonts.plusJakartaSansTextTheme(base.textTheme),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppAppearanceService.instance,
      builder: (context, _) {
        final appearance = AppAppearanceService.instance;
        return MaterialApp(
          title: 'StackDialer', debugShowCheckedModeBanner: false,
          theme: _theme(Brightness.light, appearance.accent),
          darkTheme: _theme(Brightness.dark, appearance.accent),
          themeMode: appearance.mode,
          builder: (context, child) {
            final media = MediaQuery.of(context);
            return MediaQuery(data: media.copyWith(alwaysUse24HourFormat: false), child: child ?? const SizedBox.shrink());
          },
          home: const MainDialerHost(),
        );
      },
    );
  }
}

class MainDialerHost extends StatefulWidget {
  const MainDialerHost({super.key});

  @override
  State<MainDialerHost> createState() => _MainDialerHostState();
}

class _MainDialerHostState extends State<MainDialerHost> with WidgetsBindingObserver, TickerProviderStateMixin {
  int _currentIndex = 1;
  bool _showDialpadOverlay = false;
  late final PageController _mainTabsController;
  late final AnimationController _dialpadAnimationController;
  late final Animation<double> _dialpadProgress;
  List<CallRecord> _callLogs = [];
  List<ContactModel> _contacts = [];
  bool _isLoading = true;
  bool _hasActiveCallScreen = false;
  bool _isDefaultDialer = false;
  String? _incomingBannerNumber;
  String? _incomingBannerName;
  String? _activeCallBannerNumber;
  String? _activeCallBannerName;
  bool _activeCallBannerIsIncoming = false;
  final List<CallRecord> _recentDialedCalls = [];

  bool _isCurrentCallIncoming = false;
  int _pendingCallSimSlot = 1;


  @override
  void initState() {
    super.initState();
    _mainTabsController = PageController(initialPage: 0);
    _dialpadAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 520),
      reverseDuration: const Duration(milliseconds: 430),
    );
    _dialpadProgress = CurvedAnimation(
      parent: _dialpadAnimationController,
      curve: Curves.easeInOutCubicEmphasized,
      reverseCurve: Curves.easeInCubic,
    );
    WidgetsBinding.instance.addObserver(this);
    _initDeviceData();
    _checkDefaultDialer();
    _setupTelecomInCallListener();
    // Keep reminder taps on TelecomService's shared MethodChannel handler.
    // Registering another handler here would replace onCallStateChanged and
    // prevent both swipe-to-call and reminder calls from opening ActiveCallScreen.
    TelecomService.setupReminderNotificationListener(_consumePendingReminder);
    _checkPendingCall();
  }

  @override
  void dispose() {
    _mainTabsController.dispose();
    _dialpadAnimationController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Whenever user returns from making a phone call or switching back,
      // reload live device call logs and update default dialer status!
      _checkDefaultDialer();
      _refreshCallLogs();
      _checkPendingCall(); // Recover Telecom events that arrived while Flutter was paused.
      FollowUpTaskService.reschedulePendingReminders();
      _consumePendingReminder();
    }
  }

  Future<void> _checkPendingCall() async {
    try {
      final pending = await TelecomService.getPendingIncomingCall();
      if (pending == null || !mounted) return;
      final number = pending['number'] ?? '';
      final state = pending['state'] ?? '';
      if (number.isEmpty || !['RINGING', 'ACTIVE', 'DIALING', 'HOLDING'].contains(state)) return;

      final isIncoming = state == 'RINGING';
      if (isIncoming && _hasActiveCallScreen && _activeCallBannerNumber == number) return;
      final matched = _findContact(number);
      _isCurrentCallIncoming = isIncoming;
      if (isIncoming) {
        // Keep a compact in-app heads-up for a real ringing call. Opening the
        // full call page immediately was hiding this popup and made it appear
        // inconsistently depending on callback timing.
        setState(() {
          _incomingBannerNumber = number;
          _incomingBannerName = matched?.name ?? number;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
      } else {
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = number;
          _activeCallBannerName = matched?.name ?? number;
        });
        _openCallScreen(
          number,
          name: matched?.name,
          isIncoming: false,
          initiallyActive: state == 'ACTIVE',
          initiallyHolding: state == 'HOLDING',
        );
      }
    } catch (_) {}
  }

  Future<void> _checkDefaultDialer() async {
    try {
      final isDef = await TelecomService.isDefaultDialer();
      if (mounted) {
        setState(() => _isDefaultDialer = isDef);
      }
    } catch (_) {}
  }

  void _setupTelecomInCallListener() {
    TelecomService.setupCallListener((number, state) {
      if (!mounted) return;
      if (number.trim().isEmpty || number.trim().toLowerCase() == 'unknown') return;
      final matched = _findContact(number);
      if (state == 'RINGING') {
        // Remote ringback for our outgoing call is not an incoming call.
        if (_activeCallBannerNumber != null && !_isCurrentCallIncoming) return;
        // A ringing event is shown as a compact heads-up. The user can tap it
        // to open the full call UI; do not push a second route automatically.
        if (_hasActiveCallScreen && _activeCallBannerNumber == number && _isCurrentCallIncoming) return;
        _isCurrentCallIncoming = true;
        setState(() {
          _incomingBannerNumber = number;
          _incomingBannerName = matched?.name ?? number;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
      } else if (state == 'ACTIVE' || state == 'DIALING' || state == 'HOLDING') {
        final wasIncoming = _isCurrentCallIncoming;
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = number;
          _activeCallBannerName = matched?.name ?? number;
        });
        // If the task was removed from Recents, a notification/capsule tap can
        // recreate MainActivity. Re-open the active call route instead of leaving
        // the user on the dial pad. Existing call route is not duplicated.
        if (!_hasActiveCallScreen) {
          _openCallScreen(number, name: matched?.name, isIncoming: wasIncoming, initiallyActive: state == 'ACTIVE', initiallyHolding: state == 'HOLDING');
        }
      } else if (state == 'DISCONNECTED' || state == 'IDLE') {
        _isCurrentCallIncoming = false;
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
        // Call ended, refresh live device call log after slight buffer for Android CallLog provider to sync!
        Future.delayed(const Duration(milliseconds: 700), () {
          if (mounted) _refreshCallLogs();
        });
      }
    });
  }

  Future<void> _initDeviceData() async {
    setState(() => _isLoading = true);
    await TelecomService.requestPermissions();
    await FollowUpTaskService.reschedulePendingReminders();
    final logs = await TelecomService.fetchDeviceCallLogs();
    final savedCalls = await CallDataService.loadSavedCalls();
    final contacts = await TelecomService.fetchDeviceContacts();
    if (mounted) {
      setState(() {
        _recentDialedCalls
          ..clear()
          ..addAll(savedCalls);
        _callLogs = _mergeCalls(logs, _recentDialedCalls);
        _contacts = contacts;
        _isLoading = false;
      });
      await _consumePendingReminder();
    }
  }

  Future<void> _consumePendingReminder() async {
    try {
      final payload = await const MethodChannel('com.stackdialer.app/telecom').invokeMapMethod<String, dynamic>('consumePendingReminder');
      if (!mounted || payload == null) return;
      final number = payload['number']?.toString() ?? '';
      if (number.isEmpty) return;
      final contact = _findContact(number);
      setState(() { _currentIndex = 1; _showDialpadOverlay = false; });
      if (_mainTabsController.hasClients) _mainTabsController.jumpToPage(0);
      _dialpadAnimationController.reverse();
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF211F29),
        title: const Text('Callback reminder', style: TextStyle(color: Colors.white)),
        content: Text('Time to call ${contact?.name ?? number}\n$number', style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          ElevatedButton.icon(onPressed: () { Navigator.pop(ctx); _onCallNumber(number); }, icon: const Icon(Icons.call), label: const Text('Call now')),
        ],
      ));
    } catch (_) {}
  }

  Future<void> _refreshCallLogs() async {
    try {
      final logs = await TelecomService.fetchDeviceCallLogs();
      final savedCalls = await CallDataService.loadSavedCalls();
      if (mounted) {
        setState(() {
          _recentDialedCalls
            ..clear()
            ..addAll(savedCalls);
          _callLogs = _mergeCalls(logs, _recentDialedCalls);
        });
      }
    } catch (_) {}
  }

  List<CallRecord> _mergeCalls(List<CallRecord> deviceLogs, List<CallRecord> localCalls) {
    final Map<String, CallRecord> map = {};
    final Map<String, List<CallRecord>> deviceByNumber = {};
    final Set<String> matchedDeviceIds = {};
    String normalized(CallRecord call) => CallDataService.normalizeNumber(call.number);
    String bucketKey(CallRecord call) =>
        '${normalized(call)}_${call.timestamp.millisecondsSinceEpoch ~/ 30000}';
    String deviceKey(CallRecord call) => '${bucketKey(call)}_${call.deviceLogId ?? call.id}';

    // Android stores the call-log timestamp near call start, while the local
    // completed-call record is timestamped at hang-up. Index the provider rows
    // by normalized number, then compare against the local estimated start.
    for (final device in deviceLogs) {
      map[deviceKey(device)] = device;
      deviceByNumber.putIfAbsent(normalized(device), () => <CallRecord>[]).add(device);
    }

    for (final local in localCalls) {
      final estimatedStartMs = local.timestamp.millisecondsSinceEpoch -
          (local.durationSeconds * 1000);
      final candidates = deviceByNumber[normalized(local)] ?? const <CallRecord>[];
      CallRecord? bestMatch;
      var bestDifference = 90001;
      for (final candidate in candidates) {
        final providerId = candidate.deviceLogId ??
            (RegExp(r'^\d{1,20}$').hasMatch(candidate.id) ? candidate.id : null);
        if (providerId == null || matchedDeviceIds.contains(providerId) || candidate.type != local.type) {
          continue;
        }
        final difference = (candidate.timestamp.millisecondsSinceEpoch - estimatedStartMs).abs();
        if (difference <= 90000 && difference < bestDifference) {
          bestDifference = difference;
          bestMatch = candidate;
        }
      }

      if (bestMatch == null) {
        map['local_${local.id}'] = local;
        continue;
      }

      final providerId = bestMatch.deviceLogId ?? bestMatch.id;
      matchedDeviceIds.add(providerId);
      // Keep the local ID for notes/categories and carry the real Android row
      // ID separately so deleting/undoing a merged record targets both stores.
      map[deviceKey(bestMatch)] = local.copyWith(deviceLogId: providerId);
    }

    final merged = map.values.toList();
    merged.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    return merged;
  }

  void _saveCompletedCallRecord(CallRecord record) {
    CallDataService.saveCompletedCall(record);
    if ((record.note ?? '').trim().isNotEmpty) {
      CallDataService.saveCallMetadata(record.id, note: record.note, category: record.category);
    }
    if (!mounted) return;
    setState(() {
      // Replace the outgoing placeholder with the completed record, not a duplicate.
      _recentDialedCalls.removeWhere((item) => item.number == record.number && item.id.startsWith('call_'));
      _callLogs.removeWhere((item) => item.number == record.number && item.id.startsWith('call_'));
      _recentDialedCalls.insert(0, record);
      _callLogs = _mergeCalls(_callLogs, _recentDialedCalls);
    });
  }

  ContactModel? _findContact(String number) {
    final clean = number.replaceAll(RegExp(r'[^\d]'), '');
    if (clean.isEmpty) return null;
    return _contacts.cast<ContactModel?>().firstWhere(
          (c) => c != null && c.number.replaceAll(RegExp(r'[^\d]'), '').endsWith(clean),
          orElse: () => null,
        );
  }

  void _openCallScreen(String number, {String? name, bool isIncoming = false, bool initiallyActive = false, bool initiallyHolding = false}) {
    if (_hasActiveCallScreen) return;
    _hasActiveCallScreen = true;
    _isCurrentCallIncoming = isIncoming;
    final matched = _findContact(number);
    final displayName = name ?? matched?.name ?? number;

    setState(() {
      _activeCallBannerNumber = number;
      _activeCallBannerName = displayName;
      // The full-screen call page replaces the compact in-app incoming banner.
      // Keeping both visible caused a duplicate call popup over the call UI.
      _incomingBannerNumber = null;
      _incomingBannerName = null;
    });

    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 160),
        reverseTransitionDuration: const Duration(milliseconds: 120),
        // Full-size fade only; do not scale the call screen like a bottom sheet.
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final fade = CurvedAnimation(parent: animation, curve: Curves.easeOut);
          return FadeTransition(opacity: fade, child: child);
        },
        pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
          phoneNumber: number,
          contactName: displayName,
          callerCategory: isIncoming ? 'Incoming Call' : 'Mobile Call',
          isIncoming: isIncoming,
          initiallyActive: initiallyActive,
          initiallyHolding: initiallyHolding,
          simSlot: isIncoming ? 1 : _pendingCallSimSlot,
          onCallEnded: (record) {
            _hasActiveCallScreen = false;
            _isCurrentCallIncoming = false;
            _pendingCallSimSlot = 1;
            TelecomService.cancelIncomingBanner();
            TelecomService.cancelOngoingNotification();
            setState(() {
              _activeCallBannerNumber = null;
              _activeCallBannerName = null;
              _incomingBannerNumber = null;
              _incomingBannerName = null;
              _saveCompletedCallRecord(record);
            });
            Future.delayed(const Duration(milliseconds: 700), () {
              if (mounted) _refreshCallLogs();
            });
          },
        ),
      ),
    ).then((_) {
      _hasActiveCallScreen = false;
    });
  }

  Future<int?> _resolveCallingSimSlot(int requestedSlot) async {
    final prefs = await SharedPreferences.getInstance();
    final preference = prefs.getString('stackdialer_preferred_sim') ?? 'SIM 1';
    if (preference == 'SIM 2') return 2;
    if (preference == 'SIM 1') return 1;
    if (preference != 'Always Ask') return requestedSlot;
    if (!mounted) return null;
    return showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF24212B),
        title: const Text('Choose calling SIM', style: TextStyle(color: Colors.white)),
        content: const Text('Select which SIM should place this call.', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, null), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(dialogContext, 1), child: const Text('SIM 1')),
          ElevatedButton(onPressed: () => Navigator.pop(dialogContext, 2), child: const Text('SIM 2')),
        ],
      ),
    );
  }

  void _onCallNumber(String number, {int simSlot = 1}) async {
    final clean = number.replaceAll(RegExp(r'[^\d+*#]'), '');
    if (clean.isEmpty) return;
    final selectedSimSlot = await _resolveCallingSimSlot(simSlot);
    if (!mounted || selectedSimSlot == null) return;
    AppHaptics.heavyImpact();
    _pendingCallSimSlot = selectedSimSlot;
    _isCurrentCallIncoming = false;

    // Do not fabricate a recent-call card, an active-call screen, or an ongoing
    // notification just because the dial button was tapped. Android Telecom is
    // the source of truth: _setupTelecomInCallListener opens the call UI only
    // after it reports a real DIALING/ACTIVE call.
    try {
      final launched = await TelecomService.makeRealCall(clean, simSlot: selectedSimSlot);
      if (launched) {
        // Telecom may deliver its first DIALING callback while Flutter is
        // resuming from a notification or a Recents gesture. Reconcile against
        // Android's live call state as a fallback so the call page is not lost
        // if that one event arrives before the Dart listener is ready.
        Future.delayed(const Duration(milliseconds: 350), () {
          if (mounted && !_hasActiveCallScreen) _checkPendingCall();
        });
        Future.delayed(const Duration(milliseconds: 1000), () {
          if (mounted && !_hasActiveCallScreen) _checkPendingCall();
        });
      }
      if (!launched && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('SIM $selectedSimSlot se call start nahi ho saki. SIM availability, Phone permission aur default dialer setting check karein.')),
        );
      }
    } on PlatformException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? 'SIM $selectedSimSlot se call start nahi ho saki.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('SIM $selectedSimSlot se call start nahi ho saki.')),
        );
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([bottomPillColorNotifier, floatingDialpadColorNotifier]),
      builder: (context, _) => Scaffold(
      backgroundColor: Colors.transparent,
      extendBody: true,
      body: Stack(
        children: [
          _isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Color(0xFF10B981),
                  ),
                )
              : Column(
                  children: [
                    // Default dialer alert banner if not set
                    if (!_isDefaultDialer)
                      SafeArea(
                        bottom: false,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          color: const Color(0xFF10B981).withOpacity(0.12),
                          child: Row(
                            children: [
                              const Icon(Icons.shield_outlined, color: Color(0xFF10B981), size: 16),
                              const SizedBox(width: 8),
                              const Expanded(
                                child: Text(
                                  'Set StackDialer as Default Phone App for full lock-screen UI',
                                  style: TextStyle(color: Colors.white70, fontSize: 11),
                                ),
                              ),
                              InkWell(
                                onTap: () async {
                                  await TelecomService.requestDefaultDialer();
                                  Future.delayed(const Duration(seconds: 1), _checkDefaultDialer);
                                },
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'Set Default',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    Expanded(
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          // A real PageView drives both page movement and the
                          // bottom highlight from the same gesture progress.
                          Positioned.fill(
                            child: IgnorePointer(
                              ignoring: _currentIndex != 1 && _currentIndex != 2,
                              child: PageView(
                                controller: _mainTabsController,
                                physics: const BouncingScrollPhysics(parent: PageScrollPhysics()),
                                onPageChanged: (page) {
                                  final nextIndex = page + 1;
                                  if (_currentIndex != nextIndex) {
                                    setState(() {
                                      _currentIndex = nextIndex;
                                      _showDialpadOverlay = false;
                                    });
                                    _dialpadAnimationController.reverse();
                                  }
                                },
                                children: [
                                  StackedRecentsScreen(
                                    calls: _callLogs,
                                    onRefresh: _refreshCallLogs,
                                    onCallNumber: _onCallNumber,
                                  ),
                                  ContactsScreen(
                                    contacts: _contacts,
                                    calls: _callLogs,
                                    onCallNumber: _onCallNumber,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          _buildAnimatedTab(3, DialerSearchScreen(
                            calls: _callLogs,
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                            isActive: _currentIndex == 3,
                          )),
                          _buildAnimatedTab(4, InsightsScreen(calls: _callLogs, onCallNumber: _onCallNumber, onBackupRestored: _refreshCallLogs)),
                          _buildAnimatedTab(5, FollowUpTasksScreen(onCallNumber: _onCallNumber)),
                          // The keypad is a floating panel over the current page,
                          // not a replacement tab. Keep it mounted so entered digits persist.
                          Positioned.fill(
                            child: AnimatedBuilder(
                              animation: _dialpadProgress,
                              builder: (context, _) {
                                final t = _dialpadProgress.value;
                                final size = MediaQuery.of(context).size;
                                final safeBottom = MediaQuery.of(context).padding.bottom;
                                final collapsedLeft = size.width / 2 + 69;
                                final collapsedRight = size.width / 2 - 115;
                                final expandedHeight = (size.height * 0.32).clamp(238.0, 278.0).toDouble();
                                final expandedInset = size.width * 0.08;
                                final left = lerpDouble(collapsedLeft, expandedInset, t)!;
                                final right = lerpDouble(collapsedRight, expandedInset, t)!;
                                final bottom = lerpDouble(safeBottom + 5, safeBottom + 62, t)!;
                                final height = lerpDouble(46, expandedHeight, t)!;
                                final radius = lerpDouble(24, 22, t)!;
                                return Stack(
                                  children: [
                                    if (t > 0.001)
                                      Positioned.fill(
                                        child: GestureDetector(
                                          behavior: HitTestBehavior.opaque,
                                          onTap: _closeDialpad,
                                          child: BackdropFilter(
                                            filter: ImageFilter.blur(sigmaX: 0, sigmaY: 0),
                                            child: Container(color: Colors.black.withOpacity(0.025 * t)),
                                          ),
                                        ),
                                      ),
                                    Positioned(
                                      left: left,
                                      right: right,
                                      bottom: bottom,
                                      height: height,
                                      child: IgnorePointer(
                                        ignoring: t < 0.98,
                                        child: Opacity(
                                          opacity: t,
                                          child: Transform.scale(
                                            alignment: Alignment.bottomRight,
                                            scale: lerpDouble(0.12, 1.0, Curves.easeOutBack.transform(t))!,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(radius),
                                              child: DecoratedBox(
                                                decoration: BoxDecoration(
                                                  color: const Color(0xFF292929),
                                                  border: Border.all(color: Colors.white.withOpacity(0.08 * t)),
                                                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.34 * t), blurRadius: 28 * t, spreadRadius: t, offset: Offset(0, 8 * t))],
                                                ),
                                                child: t > 0.001
                                                    ? Stack(
                                                        children: [
                                                          Positioned.fill(
                                                            child: BackdropFilter(
                                                              filter: ImageFilter.blur(sigmaX: 22 * t, sigmaY: 22 * t),
                                                              child: Container(color: Colors.black.withOpacity(0.16)),
                                                            ),
                                                          ),
                                                          T9DialpadScreen(
                                                            key: const ValueKey('gesture_morph_dialpad'),
                                                            contacts: _contacts,
                                                            onCallNumber: _onCallNumber,
                                                            overlay: true,
                                                          ),
                                                        ],
                                                      )
                                                    : const SizedBox.expand(),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

          // 1. Floating Incoming Call Heads-Up Banner at top of the app
          if (_incomingBannerNumber != null)
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 14,
              right: 14,
              child: Material(
                elevation: 24,
                borderRadius: BorderRadius.circular(20),
                color: const Color(0xFF1F1D2B),
                child: InkWell(
                  onTap: () => _openCallScreen(_incomingBannerNumber!, name: _incomingBannerName, isIncoming: true),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF10B981), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF10B981).withOpacity(0.35),
                          blurRadius: 20,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.call_received, color: Color(0xFF10B981), size: 24),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                _incomingBannerName ?? _incomingBannerNumber!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              Text(
                                'Incoming Call... • ${_incomingBannerNumber!}',
                                style: const TextStyle(
                                  color: Color(0xFF10B981),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Reject Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.rejectCall();
                            await TelecomService.cancelIncomingBanner();
                            setState(() {
                              _incomingBannerNumber = null;
                              _incomingBannerName = null;
                            });
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFFEF4444),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call_end, color: Colors.white, size: 18),
                          ),
                        ),
                        // Answer Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.answerCall();
                            await TelecomService.cancelIncomingBanner();
                            final num = _incomingBannerNumber!;
                            final name = _incomingBannerName;
                            setState(() {
                              _incomingBannerNumber = null;
                              _incomingBannerName = null;
                            });
                            _openCallScreen(num, name: name, isIncoming: true);
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFF10B981),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call, color: Colors.white, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(12, 2, 12, 5),
        child: SizedBox(
          height: 52,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // The selected capsule is positioned from PageController.page,
              // so it follows the user's finger continuously during a swipe.
              ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                  child: Container(
                    width: 176,
                    height: 46,
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: const Color(0x887D86B8),
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: Colors.white.withOpacity(0.32), width: 1),
                      boxShadow: const [BoxShadow(color: Color(0x44000000), blurRadius: 14, offset: Offset(0, 4))],
                    ),
                    child: AnimatedBuilder(
                      animation: _mainTabsController,
                      builder: (context, _) {
                        final page = (_mainTabsController.hasClients ? (_mainTabsController.page ?? 0.0) : (_currentIndex == 2 ? 1.0 : 0.0)).clamp(0.0, 1.0);
                        return LayoutBuilder(builder: (context, constraints) {
                          final half = constraints.maxWidth / 2;
                          return Stack(children: [
                            Positioned(
                              left: page * half,
                              top: 0,
                              bottom: 0,
                              width: half,
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  color: bottomPillColorNotifier.value,
                                  borderRadius: BorderRadius.circular(24),
                                  boxShadow: [BoxShadow(color: bottomPillColorNotifier.value.withOpacity(0.24), blurRadius: 9, spreadRadius: 0.5)],
                                ),
                              ),
                            ),
                            Row(children: [
                              _buildPillNavItem(1, Icons.call_rounded, 'Recents', 1.0 - page),
                              _buildPillNavItem(2, Icons.contacts_rounded, 'Contacts', page),
                            ]),
                          ]);
                        });
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              Material(
                color: const Color(0xFF10B981),
                shape: const CircleBorder(),
                elevation: 7,
                shadowColor: const Color(0x6610B981),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () {
                    final page = _mainTabsController.hasClients ? (_mainTabsController.page ?? 0.0) : (_currentIndex == 2 ? 1.0 : 0.0);
                    if (page >= 0.5) {
                      _openCreateContact();
                    } else {
                      _toggleDialpad();
                    }
                  },
                  child: SizedBox(
                    width: 46,
                    height: 46,
                    child: AnimatedBuilder(
                      animation: Listenable.merge([_mainTabsController, _dialpadProgress]),
                      builder: (context, _) {
                        final page = (_mainTabsController.hasClients ? (_mainTabsController.page ?? 0.0) : (_currentIndex == 2 ? 1.0 : 0.0)).clamp(0.0, 1.0);
                        final contactsSelected = page >= 0.5;
                        final icon = contactsSelected ? Icons.add_rounded : Icons.dialpad_rounded;
                        return AnimatedSwitcher(
                          duration: const Duration(milliseconds: 260),
                          reverseDuration: const Duration(milliseconds: 210),
                          switchInCurve: Curves.easeOutBack,
                          switchOutCurve: Curves.easeInCubic,
                          transitionBuilder: (child, animation) => ScaleTransition(
                            scale: animation,
                            child: FadeTransition(opacity: animation, child: child),
                          ),
                          child: Icon(
                            icon,
                            key: ValueKey(contactsSelected ? 'add' : 'dial'),
                            color: const Color(0xFF07140D),
                            size: contactsSelected ? 29 : 23,
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ));
  }

  Widget _buildAnimatedTab(int index, Widget child) {
    final active = _currentIndex == index;
    return Positioned.fill(
      child: IgnorePointer(
        ignoring: !active,
        child: Offstage(
          offstage: !active,
          child: TickerMode(enabled: active, child: child),
        ),
      ),
    );
  }

  void _toggleDialpad() {
    AppHaptics.selectionClick();
    if (_dialpadAnimationController.status == AnimationStatus.completed || _dialpadAnimationController.status == AnimationStatus.forward) {
      _closeDialpad();
    } else {
      setState(() => _showDialpadOverlay = true);
      _dialpadAnimationController.forward();
    }
  }

  void _closeDialpad() {
    if (!_showDialpadOverlay && _dialpadAnimationController.value == 0) return;
    setState(() => _showDialpadOverlay = false);
    _dialpadAnimationController.reverse();
  }

  Future<void> _openCreateContact() async {
    AppHaptics.selectionClick();
    try {
      await FlutterContacts.openExternalInsert();
      if (mounted) await _refreshContacts();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Contact form open nahi ho saka. Contacts permission check karein.')),
        );
      }
    }
  }

  Future<void> _refreshContacts() async {
    final contacts = await TelecomService.fetchDeviceContacts();
    if (mounted) setState(() => _contacts = contacts);
  }

  Widget _buildPillNavItem(int index, IconData icon, String label, double selectedProgress) {
    final activeColor = Color.lerp(Colors.white.withOpacity(0.92), const Color(0xFF07140D), selectedProgress)!;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          AppHaptics.selectionClick();
          _closeDialpad();
          _mainTabsController.animateToPage(index - 1, duration: const Duration(milliseconds: 430), curve: Curves.easeInOutCubicEmphasized);
        },
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 20, color: activeColor),
              const SizedBox(height: 1),
              Text(label, style: TextStyle(
                color: activeColor,
                fontSize: 10.5,
                fontWeight: selectedProgress > 0.5 ? FontWeight.w700 : FontWeight.w500,
                letterSpacing: 0.1,
              )),
            ],
          ),
        ),
      ),
    );
  }
}


class DialerSearchScreen extends StatefulWidget {
  final List<CallRecord> calls;
  final List<ContactModel> contacts;
  final void Function(String number, {int simSlot}) onCallNumber;
  final bool isActive;

  const DialerSearchScreen({
    super.key,
    required this.calls,
    required this.contacts,
    required this.onCallNumber,
    this.isActive = false,
  });

  @override
  State<DialerSearchScreen> createState() => _DialerSearchScreenState();
}

class _DialerSearchScreenState extends State<DialerSearchScreen> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  @override
  void didUpdateWidget(covariant DialerSearchScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && widget.isActive) {
          _searchFocusNode.requestFocus();
        }
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  bool _matches(String name, String number) {
    final query = _controller.text.trim().toLowerCase();
    return query.isEmpty || name.toLowerCase().contains(query) || number.toLowerCase().contains(query);
  }

  @override
  Widget build(BuildContext context) {
    final contacts = widget.contacts.where((c) => _matches(c.name, c.number)).take(30).toList();
    final calls = widget.calls.where((c) => _matches(c.name, c.number)).take(30).toList();
    return Scaffold(
      backgroundColor: const Color(0xFF141219),
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 18, 20, 12),
              child: Text('Search', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w700)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                height: 52,
                decoration: BoxDecoration(
                  color: const Color(0xFF242428),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: Colors.white12),
                ),
                child: TextField(
                  controller: _controller,
                  focusNode: _searchFocusNode,
                  autofocus: false,
                  onChanged: (_) => setState(() {}),
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  decoration: InputDecoration(
                    hintText: 'Search contacts and calls',
                    hintStyle: const TextStyle(color: Colors.white54),
                    prefixIcon: const Icon(Icons.search_rounded, color: Colors.white70),
                    suffixIcon: _controller.text.isEmpty ? null : IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white70),
                      onPressed: () { _controller.clear(); setState(() {}); },
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 15),
                  ),
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 16, 14, 20),
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(6, 2, 6, 8),
                    child: Text('CONTACTS', style: TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  ),
                  if (contacts.isEmpty)
                    const Padding(padding: EdgeInsets.all(10), child: Text('No matching contacts', style: TextStyle(color: Colors.white38, fontSize: 13)))
                  else
                    ...contacts.map((contact) => _searchResultTile(
                      icon: Icons.person_outline_rounded,
                      title: contact.name,
                      subtitle: contact.number,
                      onTap: () => widget.onCallNumber(contact.number),
                    )),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(6, 18, 6, 8),
                    child: Text('RECENT CALLS', style: TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  ),
                  if (calls.isEmpty)
                    const Padding(padding: EdgeInsets.all(10), child: Text('No matching recent calls', style: TextStyle(color: Colors.white38, fontSize: 13)))
                  else
                    ...calls.map((call) => _searchResultTile(
                      icon: call.type == CallType.missed || call.type == CallType.rejected ? Icons.call_missed_rounded : Icons.call_rounded,
                      title: call.name.isEmpty ? call.number : call.name,
                      subtitle: '${call.number}  ·  ${call.dateLabel} ${call.timeFormatted}',
                      onTap: () => widget.onCallNumber(call.number, simSlot: call.simSlot),
                    )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _searchResultTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      decoration: BoxDecoration(color: const Color(0xFF202024), borderRadius: BorderRadius.circular(17), border: Border.all(color: Colors.white.withOpacity(0.055))),
      child: ListTile(
        onTap: onTap,
        leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF10B981).withOpacity(0.15), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: const Color(0xFF10B981), size: 21)),
        title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        trailing: const Icon(Icons.call_rounded, color: Color(0xFF10B981), size: 20),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      ),
    );
  }
}
