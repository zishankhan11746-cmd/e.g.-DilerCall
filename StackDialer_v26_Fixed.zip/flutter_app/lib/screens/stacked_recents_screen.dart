import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/call_record.dart';
import '../services/telecom_service.dart';
import '../widgets/call_detail_bottom_sheet.dart';
import '../widgets/settings_dialog.dart';
import 'package:url_launcher/url_launcher.dart';
import 't9_dialpad_screen.dart';

class StackStyleConfig {
  final String id;
  final int number;
  final String name;
  final String hindiName;
  final String badge;
  final Color badgeBg;
  final Color badgeTextColor;
  final String description;
  final List<Color> highlightGradient;

  const StackStyleConfig({
    required this.id,
    required this.number,
    required this.name,
    required this.hindiName,
    required this.badge,
    required this.badgeBg,
    required this.badgeTextColor,
    required this.description,
    required this.highlightGradient,
  });
}

const List<StackStyleConfig> STACK_STYLES = [
  StackStyleConfig(
    id: 'ios-depth',
    number: 1,
    name: 'iOS Depth Stack',
    hindiName: 'क्लासिक iOS शेड',
    badge: 'iOS 18',
    badgeBg: Color(0x330284C7),
    badgeTextColor: Color(0xFF7DD3FC),
    description: 'Apple notification shade with 3D lip rollup and gentle scale compression.',
    highlightGradient: [Color(0xFF38BDF8), Color(0xFF3B82F6)],
  ),
  StackStyleConfig(
    id: 'coverflow-3d',
    number: 2,
    name: '3D Coverflow Deck',
    hindiName: 'कवरफ्लो 3D टिल्ट',
    badge: 'macOS 3D',
    badgeBg: Color(0x333B82F6),
    badgeTextColor: Color(0xFF93C5FD),
    description: 'Perspective 3D tilt with metallic edge reflection and depth perspective.',
    highlightGradient: [Color(0xFF60A5FA), Color(0xFF6366F1)],
  ),
  StackStyleConfig(
    id: 'cascade-waterfall',
    number: 3,
    name: 'Cascade Waterfall',
    hindiName: 'झरना कैस्केड वेव',
    badge: 'Fluid Wave',
    badgeBg: Color(0x3314B8A6),
    badgeTextColor: Color(0xFF5EEAD4),
    description: 'Fluid staggered waterfall with alternating wave offsets (translateX glide).',
    highlightGradient: [Color(0xFF2DD4BF), Color(0xFF10B981)],
  ),
  StackStyleConfig(
    id: 'cyberpunk-neon',
    number: 4,
    name: 'Cyberpunk Neon',
    hindiName: 'साइबरपंक नियॉन',
    badge: 'Cyber Neon',
    badgeBg: Color(0x33D946EF),
    badgeTextColor: Color(0xFFF0ABFC),
    description: 'Sci-fi stack with horizontal tilt, cyan & magenta edge glows.',
    highlightGradient: [Color(0xFF22D3EE), Color(0xFFE879F9)],
  ),
  StackStyleConfig(
    id: 'origami-fold',
    number: 5,
    name: 'Origami 3D Fold',
    hindiName: 'ओरिगेमी फोल्ड',
    badge: 'Papercraft',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFCD34D),
    description: 'Geometric papercraft folding motion as cards stack at top and bottom.',
    highlightGradient: [Color(0xFFFBBF24), Color(0xFFF97316)],
  ),
  StackStyleConfig(
    id: 'tinder-arc',
    number: 6,
    name: 'Tinder Arc Fan',
    hindiName: 'कार्ड्स फैन आर्क',
    badge: 'Cards Fan',
    badgeBg: Color(0x33F43F5E),
    badgeTextColor: Color(0xFFFDA4AF),
    description: 'Radial deck fanning like a hand of playing cards with smooth rotateZ arc curves.',
    highlightGradient: [Color(0xFFFB7185), Color(0xFFEF4444)],
  ),
  StackStyleConfig(
    id: 'accordion-spring',
    number: 7,
    name: 'Accordion Spring',
    hindiName: 'एलास्टिक स्प्रिंग बाउंस',
    badge: 'Elastic Bounce',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Dynamic elastic compression physics with playful spring recoil.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF22C55E)],
  ),
  StackStyleConfig(
    id: 'dynamic-island',
    number: 8,
    name: 'Dynamic Island',
    hindiName: 'डायनामिक कैप्सूल',
    badge: 'Apple Pill',
    badgeBg: Color(0x338B5CF6),
    badgeTextColor: Color(0xFFC4B5FD),
    description: 'Morphing rounded capsule pill stack with status ring beacons.',
    highlightGradient: [Color(0xFFA78BFA), Color(0xFF8B5CF6)],
  ),
  StackStyleConfig(
    id: 'visionos-glass',
    number: 9,
    name: 'VisionOS Frosted',
    hindiName: 'विज़नओएस ग्लास',
    badge: 'Spatial Glass',
    badgeBg: Color(0x336366F1),
    badgeTextColor: Color(0xFFA5B4FC),
    description: 'Spatial translucent frosted glass with iridescent rim highlights.',
    highlightGradient: [Color(0xFF818CF8), Color(0xFF38BDF8)],
  ),
  StackStyleConfig(
    id: 'charcoal-executive',
    number: 10,
    name: 'Charcoal Executive',
    hindiName: 'प्रीमियम चारकोल स्टैक',
    badge: 'Pro Executive',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Deep luxury matte obsidian charcoal with specular highlights and precision bevels.',
    highlightGradient: [Color(0xFF10B981), Color(0xFF059669)],
  ),
  StackStyleConfig(
    id: 'notification-stack-deck',
    number: 11,
    name: 'Notification Stack Deck',
    hindiName: 'iOS नोटिफिकेशन स्टैक',
    badge: 'Frosted Deck',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Wide overlapping notification cards with 0.96 scale lips, 12px stack spacing, frosted-glass surface and spring-like motion.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'android-notification-flow',
    number: 12,
    name: 'Notification Flow',
    hindiName: 'स्मूद नोटिफिकेशन फ्लो',
    badge: 'Android Shade',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Android notification shade style: separated cards near the top, gradually forming a smooth overlapping deck at the bottom.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'realme-flux-engine',
    number: 13,
    name: 'Realme Flux Engine',
    hindiName: 'रियलमी फ्लक्स इंजन 7.0',
    badge: 'Flux 7.0',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFBBF24),
    description: 'Realme UI 7.0 Flux Engine: 78dp rigid cards with dynamic progressFactor, 6% bottom-center scale compression, and 0.82 vertical stack displacement.',
    highlightGradient: [Color(0xFFF59E0B), Color(0xFFEF4444)],
  ),

  StackStyleConfig(
    id: 'dynamic-shrink-expand-stack',
    number: 14,
    name: 'Dynamic Shrink & Expand',
    hindiName: 'डायनामिक श्रिंक-एक्सपैंड स्टैक',
    badge: 'Bottom Dock',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF86EFAC),
    description: 'Cards 1-8 keep full width; cards 9 and 10 narrow smoothly to 90% and 85% while joining a compact fixed bottom stack. Card height and finger-following motion remain unchanged.',
    highlightGradient: [Color(0xFF22C55E), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'bottom-dock-flow',
    number: 15,
    name: 'Bottom Dock Flow',
    hindiName: 'बॉटम डॉक फ्लो',
    badge: 'Dock Pro',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Clean top edge with continuous bottom-only 3-layer tucked deck & horizontal shrink-expand animation at every scroll position.',
    highlightGradient: [Color(0xFF0B8261), Color(0xFF10B981)],
  ),
  StackStyleConfig(
    id: 'fluid-stack',
    number: 16,
    name: 'Fluid-Stack',
    hindiName: 'फ्लूइड-स्टैक 3D स्प्रिंग',
    badge: 'Spring 3D',
    badgeBg: Color(0x3306B6D4),
    badgeTextColor: Color(0xFF67E8F9),
    description: 'Spring-physics base (stiffness: 400, damping: 25) with 3D-perspective Y-axis tilt and subtle background bokeh shift as cards fan out.',
    highlightGradient: [Color(0xFF22D3EE), Color(0xFF6366F1)],
  ),
];

class StackedRecentsScreen extends StatefulWidget {
  final List<CallRecord> calls;
  final VoidCallback onRefresh;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const StackedRecentsScreen({
    super.key,
    required this.calls,
    required this.onRefresh,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<StackedRecentsScreen> createState() => _StackedRecentsScreenState();
}

class _StackedRecentsScreenState extends State<StackedRecentsScreen>
    with TickerProviderStateMixin {
  late Ticker _ticker;
  late AnimationController _fluidSpringController;
  static const SpringDescription _fluidSpring = SpringDescription(
    mass: 1.0,
    stiffness: 400.0,
    damping: 25.0,
  );
  double _fluidFanProgress = 1.0;
  double _scrollPos = 0.0;
  double _targetScroll = 0.0;
  double _velocity = 0.0;
  bool _isDragging = false;
  double _lastDragY = 0.0;
  DateTime _lastDragTime = DateTime.now();
  double _viewportHeight = 600.0;
  Duration _lastTickElapsed = Duration.zero;

  static const String _stylePreferenceKey = 'stackdialer_selected_card_style_index';
  int _currentStyleIndex = 0;
  bool _stylePreferenceLoaded = false;
  double _scrollSpeedMultiplier = 1.5;
  String _ios18Appearance = 'sunset';
  String _bottomStackStyle = 'three_layer';
  bool _isStackCollapsed = false;
  String _searchQuery = '';
  String _selectedFilter = 'all'; // 'all', 'missed', 'incoming', 'outgoing'
  bool _smartSortEnabled = true;
  final Set<String> _expandedGroupIds = {};
  List<CallRecord> _cachedFilteredCalls = [];

  void _updateFilteredCalls() {
    final baseFiltered = widget.calls.where((call) {
      if (_selectedFilter == 'missed') {
        if (call.type != CallType.missed && call.type != CallType.rejected) return false;
      } else if (_selectedFilter == 'incoming') {
        if (call.type != CallType.incoming) return false;
      } else if (_selectedFilter == 'outgoing') {
        if (call.type != CallType.outgoing) return false;
      }

      if (_searchQuery.trim().isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        return call.name.toLowerCase().contains(q) ||
            call.number.contains(q);
      }
      return true;
    }).toList();

    if (!_smartSortEnabled) {
      _cachedFilteredCalls = baseFiltered;
      return;
    }

    // Smart Sort: Group repeated missed calls from the same number into a single collapsible entry
    final List<CallRecord> smartSorted = [];
    final Map<String, List<CallRecord>> missedGroups = {};
    final Set<String> processedMissedNumbers = {};

    for (final call in baseFiltered) {
      if (call.type == CallType.missed || call.type == CallType.rejected) {
        final clean = call.number.replaceAll(RegExp(r'[^\d+]'), '');
        missedGroups.putIfAbsent(clean, () => []).add(call);
      }
    }

    for (final call in baseFiltered) {
      final isMissed = call.type == CallType.missed || call.type == CallType.rejected;
      if (!isMissed) {
        smartSorted.add(call);
      } else {
        final clean = call.number.replaceAll(RegExp(r'[^\d+]'), '');
        if (!processedMissedNumbers.contains(clean)) {
          processedMissedNumbers.add(clean);
          final group = missedGroups[clean] ?? [call];
          if (group.length > 1) {
            smartSorted.add(CallRecord(
              id: 'group_${call.id}',
              name: call.name,
              number: call.number,
              type: call.type,
              timestamp: group.first.timestamp,
              durationSeconds: 0,
              simSlot: call.simSlot,
              simCarrier: call.simCarrier,
              note: call.note,
              reminderTime: call.reminderTime,
              category: call.category,
              location: call.location,
              repeatCount: group.length,
              groupedSubCalls: group,
            ));
          } else {
            smartSorted.add(call);
          }
        }
      }
    }

    _cachedFilteredCalls = smartSorted;
  }

  // Card physics constants
  static const double cardHeight = 90.0;
  static const double cardGap = 8.0;
  static const double cardStep = cardHeight + cardGap; // 98.0 for styles 1-10
  static const double notificationCardHeight = 176.0;
  static const double notificationCardStep = 152.0; // Style 11: overlapping notification deck
  static const double notificationFlowCardHeight = 78.0;
  static const double notificationFlowCardStep = 98.0; // Style 12: slim cards with visible overlap as they gather into the deck
  static const double fluxCardHeight = 78.0; // Style 13: Realme UI 7.0 rigid card height
  static const double fluxCardStep = 92.0; // Style 13: 78dp card with 14dp gap in free viewport
  static const double dynamicStackCardHeight = 68.0; // Style 14: compact notification-like card
  static const double dynamicStackCardStep = 72.0; // Style 14: 68dp card + tight 4dp gap
  static const double bottomDockFlowCardHeight = 68.0; // Style 15: compact slate pill card matching video
  static const double bottomDockFlowCardStep = 74.0; // Style 15: 68dp card + 6dp gap
  static const double fluidStackCardHeight = 86.0; // Style 16: Fluid-Stack 3D card
  static const double fluidStackCardStep = 94.0; // Style 16: 86dp card + 8dp gap
  static const double headerOffset = 10.0;

  double get _activeCardStep {
    if (_currentStyleIndex == 10) return notificationCardStep;
    if (_currentStyleIndex == 11) return notificationFlowCardStep;
    if (_currentStyleIndex == 12) return fluxCardStep;
    if (_currentStyleIndex == 13) return dynamicStackCardStep;
    if (_currentStyleIndex == 14) return bottomDockFlowCardStep;
    if (_currentStyleIndex == 15) return fluidStackCardStep;
    return cardStep;
  }
  double get _activeCardHeight {
    if (_currentStyleIndex == 10) return notificationCardHeight;
    if (_currentStyleIndex == 11) return notificationFlowCardHeight;
    if (_currentStyleIndex == 12) return fluxCardHeight;
    if (_currentStyleIndex == 13) return dynamicStackCardHeight;
    if (_currentStyleIndex == 14) return bottomDockFlowCardHeight;
    if (_currentStyleIndex == 15) return fluidStackCardHeight;
    return cardHeight;
  }

  @override
  void initState() {
    super.initState();
    _updateFilteredCalls();
    _fluidSpringController = AnimationController.unbounded(
      vsync: this,
      value: 1.0,
    )..addListener(() {
        if (mounted) {
          setState(() {
            _fluidFanProgress = _fluidSpringController.value;
          });
        }
      });
    _ticker = createTicker(_onTick);
    _ticker.start();
    _loadSavedStyle();
    _loadStackMotionPreferences();
  }

  void _runFluidSpring(double fromValue, double toValue) {
    _fluidSpringController.value = fromValue;
    _fluidSpringController.animateWith(
      SpringSimulation(_fluidSpring, fromValue, toValue, 0.0),
    );
  }

  @override
  void didUpdateWidget(covariant StackedRecentsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    _updateFilteredCalls();
    if (widget.calls.length != oldWidget.calls.length ||
        (widget.calls.isNotEmpty && oldWidget.calls.isNotEmpty && widget.calls.first.id != oldWidget.calls.first.id)) {
      _scrollPos = 0.0;
      _targetScroll = 0.0;
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    _fluidSpringController.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    if (!mounted) return;

    final filtered = _cachedFilteredCalls;
    final double maxScroll = math.max(
      0.0,
      headerOffset + filtered.length * _activeCardStep - _viewportHeight +
          (_currentStyleIndex == 13
              ? 0.0
              : (_currentStyleIndex == 14 ? 40.0 : _activeCardHeight)),
    ).toDouble();
    if (_lastTickElapsed == Duration.zero) {
      _lastTickElapsed = elapsed;
      return;
    }
    // Use elapsed frame time so animation speed is consistent on 60/90/120 Hz screens.
    final frameMs = (elapsed - _lastTickElapsed).inMicroseconds / 1000.0;
    _lastTickElapsed = elapsed;
    final dt = frameMs.clamp(0.0, 40.0);
    if (dt <= 0) return;
    final frameFactor = dt / 16.6667;

    bool changed = false;

    // 1. Time-based kinetic momentum decay (independent of refresh rate).
    if (!_isDragging && _velocity.abs() > 0.08) {
      _targetScroll += _velocity * frameFactor;
      // High-precision silky friction for fluid inertial glide across all 14 styles
      const double friction = 0.942;
      _velocity *= math.pow(friction, frameFactor).toDouble();
      if (_targetScroll < 0) {
        _targetScroll = 0;
        _velocity = 0;
      } else if (_targetScroll > maxScroll) {
        _targetScroll = maxScroll;
        _velocity = 0;
      }
      changed = true;
    } else if (!_isDragging) {
      _velocity = 0;
    }

    // 2. High-performance finger tracking & frame-rate-independent settling across all 14 styles
    final diff = _targetScroll - _scrollPos;
    if (_isDragging) {
      // Instant direct finger tracking during drag eliminates any visible touch latency on 60/90/120Hz screens
      if (diff.abs() > 0.001) {
        _scrollPos = _targetScroll;
        changed = true;
      }
    } else if (diff.abs() > 0.05) {
      // Ultra-smooth 24ms critical damping response for silky glide settling
      const double responseMs = 24.0;
      final interpolation = 1.0 - math.exp(-dt / responseMs);
      _scrollPos += diff * interpolation;
      changed = true;
    } else if (_scrollPos != _targetScroll) {
      _scrollPos = _targetScroll;
      changed = true;
    }

    if (changed) {
      setState(() {});
    }
  }

  List<CallRecord> _getFilteredCalls() {
    return _cachedFilteredCalls;
  }

  Future<void> _loadStackMotionPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _ios18Appearance = prefs.getString('stackdialer_ios18_appearance') ?? 'sunset';
      _scrollSpeedMultiplier = (prefs.getDouble('stack12_scroll_speed') ?? 1.5).clamp(0.5, 3.0).toDouble();
      _bottomStackStyle = prefs.getString('stack12_bottom_style') ?? 'three_layer';
    });
  }

  Future<void> _loadSavedStyle() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedIndex = prefs.getInt(_stylePreferenceKey) ?? 0;
      if (!mounted) return;
      setState(() {
        _currentStyleIndex = savedIndex >= 0 && savedIndex < STACK_STYLES.length
            ? savedIndex
            : 0;
        // Prevent a stale animation/scroll offset from placing every Style 12
        // card outside the viewport when restoring the saved style on launch.
        _scrollPos = 0.0;
        _targetScroll = 0.0;
        _velocity = 0.0;
        _isDragging = false;
        _stylePreferenceLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _stylePreferenceLoaded = true);
    }
  }

  Future<void> _saveSelectedStyle(int index) async {
    final safeIndex = index >= 0 && index < STACK_STYLES.length ? index : 0;
    // Update the UI immediately; persist the selection across app restarts.
    if (mounted) {
      setState(() {
        _currentStyleIndex = safeIndex;
        // Each style can use a different card step/height. Reset the previous
        // style's scroll offset so Style 12 never opens with every card off-screen.
        _scrollPos = 0.0;
        _targetScroll = 0.0;
        _velocity = 0.0;
        _isDragging = false;
        if (safeIndex == 15) {
          _isStackCollapsed = false;
        }
      });
      if (safeIndex == 15) {
        _runFluidSpring(0.0, 1.0);
      }
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_stylePreferenceKey, safeIndex);
    } catch (_) {
      // Keep the in-memory selection even if device storage is temporarily unavailable.
    }
  }

  void _cycleNextStyle() {
    HapticFeedback.lightImpact();
    _saveSelectedStyle((_currentStyleIndex + 1) % STACK_STYLES.length);
  }

  void _restoreDefaultStyle() {
    HapticFeedback.mediumImpact();
    _saveSelectedStyle(0);
  }

  void _toggleStackCollapsed() {
    HapticFeedback.lightImpact();
    setState(() {
      _isStackCollapsed = !_isStackCollapsed;
    });
    if (_currentStyleIndex == 15) {
      _runFluidSpring(_fluidFanProgress, _isStackCollapsed ? 0.0 : 1.0);
    }
  }

  // Exact 3D math engine matching web preview
  Map<String, dynamic> _computeCardTransforms({
    required String styleId,
    required int index,
    required double naturalY,
    required double topBoundary,
    required double bottomBoundary,
    required double dockTopY,
    required double step,
    required int totalCards,
  }) {
    double yPos = 0;
    double xPos = 0;
    double scale = 1.0;
    double rotateX = 0;
    double rotateY = 0;
    double rotateZ = 0;
    double skewX = 0;
    double opacity = 1.0;
    bool isStacked = false;
    Alignment transformOrigin = Alignment.center;
    int zIndex = 200 - index * 4;

    if (styleId == 'dynamic-shrink-expand-stack') {
      // Style 14: the final card is the fixed bottom anchor. As the user
      // approaches the end of the list, every card smoothly joins the same
      // bottom-anchored deck. This avoids leaving a gap above a dock made from
      // only the last three cards. The top card remains the highest visible
      // layer; deeper cards sit 13dp lower, behind it.
      const double lip = 13.0;
      final int layerFromBottom = (totalCards - 1 - index).clamp(0, totalCards).toInt();
      final double maxScroll = math.max(
        1.0,
        headerOffset + totalCards * step - _viewportHeight,
      ).toDouble();
      final double scrollProgress = (_scrollPos / maxScroll).clamp(0.0, 1.0).toDouble();
      // Begin gathering in the final 45% of the scroll range and finish
      // exactly at max scroll. Smoothstep has no abrupt start/stop velocity.
      final double gatherT = ((scrollProgress - 0.55) / 0.45).clamp(0.0, 1.0).toDouble();
      final double dockProgress = gatherT * gatherT * (3.0 - 2.0 * gatherT);
      final double targetY = dockTopY - layerFromBottom * lip;

      yPos = naturalY + (targetY - naturalY) * dockProgress;
      opacity = 1.0;
      scale = 1.0;
      rotateX = rotateY = rotateZ = skewX = 0.0;
      transformOrigin = Alignment.bottomCenter;
      isStacked = dockProgress > 0.98;
    } else if (styleId == 'bottom-dock-flow') {
      // Style 15 (Video Exact Match):
      // - Top cards scroll cleanly straight off the top edge with zero top bunching
      // - Bottom cards tuck continuously into a 3-layer horizontal shrink/expand dock at EVERY scroll position
      if (naturalY <= bottomBoundary) {
        yPos = naturalY;
        scale = 1.0;
        opacity = 1.0;
        isStacked = false;
        rotateX = rotateY = rotateZ = skewX = 0.0;
        transformOrigin = Alignment.center;
      } else {
        isStacked = true;
        final double bottomOverflow = naturalY - bottomBoundary;
        final double progress = (bottomOverflow / math.max(step, 1.0)).clamp(0.0, 4.0).toDouble();
        final double dockOffset = 44.0 * (2.0 / (1.0 + math.exp(-progress * 0.72)) - 1.0);
        yPos = (bottomBoundary + dockOffset).toDouble();
        scale = 1.0; // Card height & typography stay crisp; width narrows via layout inset
        rotateX = rotateY = rotateZ = skewX = 0.0;
        opacity = progress <= 2.8
            ? (1.0 - progress * 0.085).clamp(0.0, 1.0).toDouble()
            : (0.762 - (progress - 2.8) * 0.95).clamp(0.0, 1.0).toDouble();
        transformOrigin = Alignment.bottomCenter;
      }
    } else if (_isStackCollapsed && (styleId == 'android-notification-flow' || styleId == 'realme-flux-engine')) {
      const double deckBaseY = 16.0;
      final int stackIndex = math.min(index, 6);
      isStacked = true;
      zIndex = 200 - index * 4;
      yPos = deckBaseY + stackIndex * 14.0;
      scale = (math.max(1.0 - stackIndex * 0.024, 0.88)).toDouble();
      rotateX = (math.min(stackIndex * 2.0, 7.0)).toDouble();
      opacity = (index > 6 ? 0.35 : math.max(1.0 - stackIndex * 0.11, 0.40)).toDouble();
      transformOrigin = Alignment.bottomCenter;
    } else if (styleId == 'fluid-stack' && (_isStackCollapsed || _fluidFanProgress < 0.998)) {
      const double deckBaseY = 14.0;
      final int stackIndex = math.min(index, 6);
      final double collapseT = (1.0 - _fluidFanProgress).clamp(0.0, 1.4).toDouble();
      final double collapsedY = deckBaseY + stackIndex * 14.0;
      final double collapsedScale = math.max(1.0 - stackIndex * 0.03, 0.85);
      final double collapsedRotY = -8.0 + stackIndex * 3.2;
      final double collapsedX = stackIndex * 5.0;
      final double collapsedOpacity = index > 6 ? 0.0 : math.max(1.0 - stackIndex * 0.11, 0.35);

      yPos = naturalY + (collapsedY - naturalY) * collapseT;
      xPos = collapsedX * collapseT;
      scale = 1.0 + (collapsedScale - 1.0) * collapseT;
      rotateY = collapsedRotY * collapseT;
      opacity = (1.0 + (collapsedOpacity - 1.0) * collapseT).clamp(0.0, 1.0);
      isStacked = collapseT > 0.05;
      zIndex = 200 - index * 4;
      transformOrigin = Alignment.center;
    } else {
      if (naturalY >= topBoundary && naturalY <= bottomBoundary) {
        // NATURAL IN-VIEW POSITION: 100% fully visible, crisp and responsive
        yPos = naturalY;
        isStacked = false;
        scale = 1.0;
        opacity = 1.0;
        rotateX = 0;
        rotateY = 0;
        rotateZ = 0;
        skewX = 0;
        transformOrigin = Alignment.center;
      } else if (naturalY < topBoundary && styleId == 'ios-depth') {
        // iOS 18 Style 1: remove the upper stacking/bunching effect entirely.
        // Cards travel out of the viewport at their natural list positions;
        // the iOS 18 lower stack and every other style remain unchanged.
        yPos = naturalY;
        isStacked = false;
        scale = 1.0;
        opacity = 1.0;
        rotateX = 0.0;
        rotateY = 0.0;
        rotateZ = 0.0;
        skewX = 0.0;
        transformOrigin = Alignment.center;
      } else if (naturalY < topBoundary) {
        // TOP STACK BUNCHING for styles that retain an upper stack.
        isStacked = true;
        final double topOverflow = topBoundary - naturalY;
        final double stackFactor = math.min(topOverflow / step, 3.5).toDouble();
        yPos = (topBoundary - math.pow(stackFactor, 0.7) * 12.0).toDouble();
        scale = (math.max(1.0 - stackFactor * 0.02, 0.94)).toDouble();
        rotateX = (-math.min(stackFactor * 1.5, 4.5)).toDouble();
        // Safe top opacity floor - NEVER black or invisible
        opacity = (math.max(1.0 - stackFactor * 0.18, 0.35)).toDouble();

        if (styleId == 'realme-flux-engine') {
          // Realme UI 7.0 "Flux Engine" Top Overlapping Stack Logic:
          // Fixed item height: exactly 78dp
          const double totalItemHeight = fluxCardHeight; // 78.0dp
          // Rigid progressFactor dynamically calculated: (-itemTopPosition / totalItemHeight).clamp(0.0, 1.0)
          final double progressFactor = (topOverflow / totalItemHeight).clamp(0.0, 1.0);

          // Overlapping Y Displacement: Intercept linear displacement vector and offset it dynamically
          // by (progressFactor * totalItemHeight * 0.82) to tightly compress subsequent cards directly underneath active foreground card
          final double linearDisplacement = -topOverflow; // = naturalY - topBoundary
          final double overlappingOffset = progressFactor * totalItemHeight * 0.82;
          yPos = (topBoundary + linearDisplacement + overlappingOffset).toDouble();

          // Smooth background stack tuck as scrolling goes deeper:
          if (topOverflow > totalItemHeight) {
            final double deepOverflow = topOverflow - totalItemHeight;
            final double stackProgress = math.min(deepOverflow / totalItemHeight, 4.0);
            yPos = (topBoundary - (totalItemHeight * 0.18) - stackProgress * 8.0).toDouble();
          }

          // Scale Transform Matrix: Compress top-sliding overlapping cards by exactly 6%
          // (down to 0.94 scale factor) using bottom-center alignment vector:
          scale = (1.0 - progressFactor * 0.06).toDouble();
          transformOrigin = Alignment.bottomCenter;

          // Alpha Translucency Level: Apply smooth opacity degradation layer where cards
          // compressing into background stack drop alpha/opacity by up to 45% (down to 0.55 opacity threshold):
          opacity = (1.0 - progressFactor * 0.45).toDouble();

          // Performance Optimizer: Viewport boundary clause to prune cards scrolled completely away
          if (topOverflow > totalItemHeight * 5.0) {
            opacity = 0.0;
          }
        } else if (styleId == 'notification-stack-deck') {
          yPos = (topBoundary - math.min(stackFactor, 5.0) * 12.0).toDouble();
          scale = math.pow(0.96, math.min(stackFactor, 5.0)).toDouble();
          rotateX = (-math.min(stackFactor * 0.8, 2.5)).toDouble();
          opacity = math.max(1.0 - stackFactor * 0.07, 0.68).toDouble();
        } else if (styleId == 'android-notification-flow') {
          final double deckProgress = math.min(topOverflow / math.max(step, 1.0), 4.0).toDouble();
          yPos = (topBoundary - deckProgress * 8.0).toDouble();
          scale = math.max(1.0 - deckProgress * 0.025, 0.92).toDouble();
          rotateX = -math.min(deckProgress * 1.2, 4.0).toDouble();
          opacity = math.max(1.0 - deckProgress * 0.12, 0.40).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'coverflow-3d') {
          rotateX = (-math.min(stackFactor * 2.2, 5.5)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'origami-fold') {
          rotateX = (-math.min(stackFactor * 2.5, 6.0)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.022, 0.93)).toDouble();
        } else if (styleId == 'tinder-arc') {
          rotateZ = (((index % 5) - 2) * math.min(stackFactor * 1.5, 4.5)).toDouble();
          xPos = (((index % 5) - 2) * math.min(stackFactor * 2.0, 7.5)).toDouble();
        } else if (styleId == 'cascade-waterfall') {
          xPos = ((index % 2 == 0 ? -10.0 : 10.0) * math.min(stackFactor, 1.8)).toDouble();
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = ((index % 2 == 0 ? 3.0 : -3.0) * math.min(stackFactor, 1.6)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.022, 0.93)).toDouble();
        } else if (styleId == 'accordion-spring') {
          yPos = (topBoundary - math.sin(math.min(stackFactor, 3.0) * 1.2) * 12.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'dynamic-island') {
          scale = (math.max(1.0 - stackFactor * 0.03, 0.90)).toDouble();
          yPos = (topBoundary - math.pow(stackFactor, 0.75) * 12.0).toDouble();
        } else if (styleId == 'visionos-glass') {
          opacity = (math.max(1.0 - stackFactor * 0.20, 0.35)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.02, 0.95)).toDouble();
        } else if (styleId == 'charcoal-executive') {
          yPos = (topBoundary - math.pow(stackFactor, 0.75) * 10.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.02, 0.94)).toDouble();
        } else if (styleId == 'fluid-stack') {
          yPos = (topBoundary - math.pow(stackFactor, 0.72) * 14.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.032, 0.88)).toDouble();
          rotateX = 0.0;
          rotateY = ((index % 2 == 0 ? -1.0 : 1.0) * math.min(stackFactor * 7.5, 18.0)).toDouble();
          xPos = ((index % 2 == 0 ? -6.0 : 6.0) * math.min(stackFactor, 2.0)).toDouble();
          opacity = (math.max(1.0 - stackFactor * 0.20, 0.30)).toDouble();
        }
      } else if (naturalY > bottomBoundary) {
        // BOTTOM STACK OVERLAP: cards gather into smooth 3D layered deck
        isStacked = true;
        final double bottomOverflow = naturalY - bottomBoundary;
        final double stackFactor = bottomOverflow / step;
        yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        scale = (math.max(1.0 - math.min(stackFactor, 4.0) * 0.025, 0.90)).toDouble();
        rotateX = (math.min(stackFactor * 1.5, 4.5)).toDouble();
        // Safe bottom opacity: NEVER 0.0!
        opacity = (math.max(1.0 - stackFactor * 0.08, 0.50)).toDouble();

        if (styleId == 'dynamic-shrink-expand-stack') {
          // Fixed bottom dock; continuous progress keeps the animation tied to finger movement.
          final double progress = (bottomOverflow / math.max(step, 1.0)).clamp(0.0, 5.0).toDouble();
          final double dockProgress = 1.0 - math.exp(-progress * 0.92);
          yPos = (bottomBoundary + dockProgress * 18.0).toDouble();
          scale = 1.0; // Never shrink card height.
          rotateX = 0.0;
          rotateY = 0.0;
          rotateZ = 0.0;
          opacity = (1.0 - dockProgress * 0.14).clamp(0.82, 1.0).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'realme-flux-engine') {
          // Realme UI 7.0 "Flux Engine" Bottom Notification Stack:
          // Continuous elastic unstacking & docking animation exactly matching the Realme UI 7.0 update video
          final double progress = (bottomOverflow / step).clamp(0.0, 5.0);

          // 1. Fluid asymptotic docking displacement: cards nest into the bottom deck with 12-14px lip tiers
          // Using continuous exponential deceleration (zero discrete step cuts)
          final double dockOffset = (1.0 - math.exp(-progress * 0.75)) * 26.0;
          yPos = (bottomBoundary + dockOffset).toDouble();

          // 2. Continuous scale compression: scales smoothly from 1.0 (active emerging) down to 0.92 (stacked deep)
          // When swiped up, the card expands smoothly out of the bottom stack!
          scale = (1.0 - (1.0 - math.exp(-progress * 0.70)) * 0.08).clamp(0.88, 1.0).toDouble();

          // 3. Smooth alpha degradation: top 2 stacked cards remain crisp & clear with frosted look
          opacity = (1.0 - progress * 0.10).clamp(0.45, 1.0).toDouble();

          // Bottom-center vector so the card expands outwards and upwards when peeling out of the stack
          transformOrigin = Alignment.bottomCenter;
        } else if (styleId == 'notification-stack-deck') {
          yPos = (bottomBoundary + math.min(stackFactor, 5.0) * 12.0).toDouble();
          scale = math.pow(0.96, math.min(stackFactor, 5.0)).toDouble();
          rotateX = math.min(stackFactor * 0.8, 2.5).toDouble();
          opacity = math.max(1.0 - stackFactor * 0.045, 0.65).toDouble();
        } else if (styleId == 'android-notification-flow') {
          final int layer = math.max(1, stackFactor.ceil());
          final double layerIndex = (layer - 1).toDouble();
          yPos = (bottomBoundary + math.min(layerIndex, 5.0) * 12.0).toDouble();
          scale = (math.max(1.0 - math.min(layerIndex, 5.0) * 0.03, 0.88)).toDouble();
          rotateX = (math.min(layerIndex * 0.6, 2.5)).toDouble();
          opacity = (math.max(1.0 - layerIndex * 0.09, 0.40)).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'coverflow-3d') {
          rotateX = (math.min(stackFactor * 2.0, 5.0)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'cascade-waterfall') {
          xPos = ((index % 2 == 0 ? -8.0 : 8.0) * math.min(stackFactor, 1.8)).toDouble();
        } else if (styleId == 'origami-fold') {
          rotateX = (math.min(stackFactor * 2.2, 5.5)).toDouble();
        } else if (styleId == 'tinder-arc') {
          rotateZ = (((index % 5) - 2) * math.min(stackFactor * 1.2, 3.5)).toDouble();
          xPos = (((index % 5) - 2) * math.min(stackFactor * 1.8, 6.0)).toDouble();
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = ((index % 2 == 0 ? -2.5 : 2.5) * math.min(stackFactor, 1.4)).toDouble();
        } else if (styleId == 'accordion-spring') {
          yPos = (bottomBoundary + math.sin(math.min(stackFactor, 3.0) * 1.0) * 16.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'dynamic-island') {
          scale = (math.max(1.0 - stackFactor * 0.03, 0.90)).toDouble();
        } else if (styleId == 'visionos-glass') {
          opacity = (math.max(1.0 - stackFactor * 0.08, 0.60)).toDouble();
        } else if (styleId == 'charcoal-executive') {
          yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        } else if (styleId == 'fluid-stack') {
          yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.0) * 24.0)).toDouble();
          scale = (math.max(1.0 - math.min(stackFactor, 4.0) * 0.03, 0.89)).toDouble();
          rotateX = 0.0;
          rotateY = ((index % 2 == 0 ? -1.0 : 0.85) * math.min(stackFactor * 6.5, 16.0)).toDouble();
          xPos = ((index % 2 == 0 ? -5.0 : 5.0) * math.min(stackFactor, 2.2)).toDouble();
          opacity = (math.max(1.0 - stackFactor * 0.08, 0.50)).toDouble();
        }
      }
    }

    return {
      'yPos': yPos,
      'xPos': xPos,
      'scale': scale,
      'rotateX': rotateX,
      'rotateY': rotateY,
      'rotateZ': rotateZ,
      'skewX': skewX,
      'opacity': opacity.clamp(0.0, 1.0),
      'isStacked': isStacked,
      'zIndex': zIndex,
      'transformOrigin': transformOrigin,
    };
  }

  void _showStyleSelectorSheet() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141219),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Sheet Grab handle
              Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.style, color: Color(0xFF10B981), size: 18),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Card Stack Animation Styles',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '${STACK_STYLES.length} Distinct Card Motion Styles',
                            style: const TextStyle(color: Colors.white38, fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  TextButton.icon(
                    onPressed: () {
                      _restoreDefaultStyle();
                      Navigator.pop(ctx);
                    },
                    icon: const Icon(Icons.refresh, size: 14, color: Colors.blueAccent),
                    label: const Text('Reset', style: TextStyle(color: Colors.blueAccent, fontSize: 12)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView.builder(
                  itemCount: STACK_STYLES.length,
                  itemBuilder: (context, idx) {
                    final style = STACK_STYLES[idx];
                    final isSelected = idx == _currentStyleIndex;
                    return InkWell(
                      onTap: () {
                        HapticFeedback.selectionClick();
                        _saveSelectedStyle(idx);
                        Navigator.pop(ctx);
                      },
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFF10B981).withOpacity(0.12)
                              : const Color(0xFF1F1D27).withOpacity(0.8),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF10B981).withOpacity(0.6)
                                : Colors.white.withOpacity(0.08),
                            width: isSelected ? 1.5 : 1.0,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: isSelected ? const Color(0xFF10B981) : Colors.white10,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Text(
                                  style.number.toString().padLeft(2, '0'),
                                  style: TextStyle(
                                    color: isSelected ? Colors.white : Colors.white70,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        style.name,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '(${style.hindiName})',
                                        style: const TextStyle(color: Colors.white38, fontSize: 11),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    style.description,
                                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: style.badgeBg,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                style.badge,
                                style: TextStyle(
                                  color: style.badgeTextColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  static const Map<String, Map<String, Color>> _ios18Palettes = {
    // Original iOS 18 Style 1 appearance remains available as a separate option.
    'original': {'bg1': Color(0xFF1B1822), 'bg2': Color(0xFF141219), 'bg3': Color(0xFF0D0C11), 'card1': Color(0xF522202C), 'card2': Color(0xF522202C), 'edge': Color(0x33FFFFFF), 'text': Color(0xFFFFFFFF)},
    'purple': {'bg1': Color(0xFF160B35), 'bg2': Color(0xFF35106B), 'bg3': Color(0xFF100A27), 'card1': Color(0xA83B1B82), 'card2': Color(0xA81B3B91), 'edge': Color(0xFFE7CFFF), 'text': Color(0xFFFFFFFF)},
    'gold': {'bg1': Color(0xFF090A0D), 'bg2': Color(0xFF34230B), 'bg3': Color(0xFF08090C), 'card1': Color(0xB52B2414), 'card2': Color(0xB58A5B16), 'edge': Color(0xFFFFD978), 'text': Color(0xFFFFF4D8)},
    'sky': {'bg1': Color(0xFF0755B8), 'bg2': Color(0xFF8BCBFF), 'bg3': Color(0xFFE8F5FF), 'card1': Color(0xBDF4FBFF), 'card2': Color(0xC9B9DFFF), 'edge': Color(0xFFFFFFFF), 'text': Color(0xFF102C4B)},
    'green': {'bg1': Color(0xFF031B0A), 'bg2': Color(0xFF145326), 'bg3': Color(0xFF020C05), 'card1': Color(0xB51A4824), 'card2': Color(0xB51C6A35), 'edge': Color(0xFFB8F5BD), 'text': Color(0xFFF0FFF1)},
    'sunset': {'bg1': Color(0xFF51218B), 'bg2': Color(0xFFE8798D), 'bg3': Color(0xFFFFA34E), 'card1': Color(0xCFFCE0D7), 'card2': Color(0xDFFFCB9F), 'edge': Color(0xFFFFF4EE), 'text': Color(0xFF32152E)},
  };

  Map<String, Color> get _activeIos18Palette => _ios18Palettes[_ios18Appearance] ?? _ios18Palettes['original']!;

  String? get _activeIos18WallpaperAsset => _ios18Appearance == 'original'
      ? null
      : 'assets/${_ios18Appearance}_wallpaper.jpg';

  String? get _activeIos18CardTextureAsset => _ios18Appearance == 'original'
      ? null
      : 'assets/${_ios18Appearance}_card_texture.png';

  Future<void> _setIos18Appearance(String value) async {
    setState(() => _ios18Appearance = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('stackdialer_ios18_appearance', value);
  }

  BoxDecoration _getCardBoxDecoration(String styleId, bool isMissed) {
    if (styleId == 'fluid-stack') {
      return BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isMissed
              ? const [Color(0xEA2B1528), Color(0xEA1D101D)]
              : const [Color(0xE8171C2E), Color(0xE8101423)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: (isMissed ? const Color(0xFFFB7185) : const Color(0xFF22D3EE)).withOpacity(0.32),
          width: 1.1,
        ),
        boxShadow: [
          BoxShadow(
            color: (isMissed ? const Color(0xFFF43F5E) : const Color(0xFF6366F1)).withOpacity(0.18),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.42),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      );
    }
    if (isMissed && styleId != 'dynamic-shrink-expand-stack' && styleId != 'bottom-dock-flow') {
      if (styleId == 'visionos-glass') {
        return BoxDecoration(
          color: Colors.redAccent.withOpacity(0.18),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.redAccent.withOpacity(0.55), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.redAccent.withOpacity(0.2),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        );
      } else if (styleId == 'cyberpunk-neon') {
        return BoxDecoration(
          color: const Color(0xFF281120).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.pinkAccent.withOpacity(0.8), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.pinkAccent.withOpacity(0.35),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        );
      } else if (styleId == 'ios-depth') {
        final palette = _activeIos18Palette;
        return BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [palette['card1']!.withOpacity(0.92), palette['card2']!.withOpacity(0.92)]),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: palette['edge']!.withOpacity(0.82), width: 1.1),
          boxShadow: [
            BoxShadow(color: palette['bg1']!.withOpacity(0.24), blurRadius: 16, offset: const Offset(0, 6)),
          ],
        );
      } else if (styleId == 'realme-flux-engine') {
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFA2C1E26),
              const Color(0xFA1F151B),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: const Color(0xFFF43F5E).withOpacity(0.35),
            width: 0.9,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.40),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: const Color(0xFFF43F5E).withOpacity(0.12),
              blurRadius: 12,
              offset: const Offset(0, 2),
            ),
          ],
        );
      }
      return BoxDecoration(
        color: const Color(0xFF2B161E).withOpacity(0.96),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFEF4444).withOpacity(0.2),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      );
    }

    switch (styleId) {
      case 'bottom-dock-flow':
        return BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xF5252630), Color(0xF51B1C25)],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFB7BACB).withOpacity(0.22), width: 1.05),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.46),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: const Color(0xFF7C83A8).withOpacity(0.06),
              blurRadius: 10,
              spreadRadius: -2,
            ),
          ],
        );
      case 'dynamic-shrink-expand-stack':
        // Style 14: match the supplied notification reference—matte charcoal,
        // a fine cool rim, soft depth shadow, and a consistent rounded corner.
        return BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xF0252630), Color(0xF01B1C25)],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFB7BACB).withOpacity(0.20), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.34),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
            BoxShadow(
              color: const Color(0xFF7C83A8).withOpacity(0.055),
              blurRadius: 10,
              spreadRadius: -2,
            ),
          ],
        );
      case 'realme-flux-engine':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFA28272F),
              const Color(0xFA1F1E26),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: Colors.white.withOpacity(0.10),
            width: 0.8,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.04),
              blurRadius: 1,
              offset: const Offset(0, -1),
            ),
          ],
        );
      case 'android-notification-flow':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF25232F).withOpacity(0.96),
              const Color(0xFF1D1B24).withOpacity(0.96),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFF34D399).withOpacity(0.40),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.12),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.55),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'notification-stack-deck':
        return BoxDecoration(
          color: const Color(0xE61B1B20), // dark 90% frosted-glass base
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(0.16), width: 1.1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.42),
              blurRadius: 22,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: const Color(0xFF34D399).withOpacity(0.07),
              blurRadius: 18,
              spreadRadius: -3,
            ),
          ],
        );
      case 'coverflow-3d':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF1E283C).withOpacity(0.95),
              const Color(0xFF141C2B).withOpacity(0.95),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF60A5FA).withOpacity(0.45), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF3B82F6).withOpacity(0.2),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'cyberpunk-neon':
        return BoxDecoration(
          color: const Color(0xFF141724).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF22D3EE).withOpacity(0.7), width: 1.3),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF22D3EE).withOpacity(0.25),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'cascade-waterfall':
        return BoxDecoration(
          color: const Color(0xFF132626).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF2DD4BF).withOpacity(0.45), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF14B8A6).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'origami-fold':
        return BoxDecoration(
          color: const Color(0xFF262016).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFBBF24).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF59E0B).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'tinder-arc':
        return BoxDecoration(
          color: const Color(0xFF2A1522).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFB7185).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF43F5E).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'accordion-spring':
        return BoxDecoration(
          color: const Color(0xFF13281E).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF34D399).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'dynamic-island':
        return BoxDecoration(
          color: const Color(0xFF141120).withOpacity(0.96),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: const Color(0xFFA78BFA).withOpacity(0.55), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF8B5CF6).withOpacity(0.25),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'visionos-glass':
        return BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.1),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'charcoal-executive':
        return BoxDecoration(
          color: const Color(0xFF1E1E26).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF10B981).withOpacity(0.35), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'ios-depth':
        final palette = _activeIos18Palette;
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isMissed
                ? [palette['card1']!.withOpacity(0.92), palette['card2']!.withOpacity(0.92)]
                : [palette['card1']!, palette['card2']!, palette['card1']!.withOpacity(0.88)],
          ),
          image: _activeIos18CardTextureAsset == null
              ? null
              : DecorationImage(
                  image: AssetImage(_activeIos18CardTextureAsset!),
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: palette['edge']!.withOpacity(0.78), width: 1.15),
          boxShadow: [
            BoxShadow(color: palette['bg1']!.withOpacity(0.28), blurRadius: 18, offset: const Offset(0, 7)),
            BoxShadow(color: Colors.white.withOpacity(0.22), blurRadius: 1, offset: const Offset(0, -1)),
          ],
        );
      default:
        return BoxDecoration(
          color: const Color(0xFF22202C).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
    }
  }

  String _formatTimeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays == 1) return 'Yesterday';
    return '${dt.day}/${dt.month}';
  }

  List<Color> _sunsetAvatarColors(CallRecord call) {
    final int palette = call.name.hashCode.abs() % 3;
    switch (palette) {
      case 0:
        return const [Color(0xFF4F7BFF), Color(0xFF2555D8)];
      case 1:
        return const [Color(0xFFE65AAE), Color(0xFF8B2BAA)];
      default:
        return const [Color(0xFF35CDB8), Color(0xFF087F9D)];
    }
  }

  Future<void> _openWhatsApp(String number) async {
    RealmeOHaptics.microTick();
    final clean = number.replaceAll(RegExp(r'[^\d+]'), '');
    final uri = Uri.parse('https://wa.me/$clean');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(uri);
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Opening WhatsApp for $number (without saving)...'),
          duration: const Duration(seconds: 1),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _setCallbackReminder(CallRecord call, String label, Duration delay) {
    RealmeOHaptics.microTick();
    SharedPreferences.getInstance().then((prefs) {
      final key = 'reminder_${call.id}_${DateTime.now().millisecondsSinceEpoch}';
      prefs.setString(key, '${call.name}|${call.number}|$label|${DateTime.now().add(delay).toIso8601String()}');
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.alarm_on, color: Color(0xFF10B981), size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '⏰ Callback Reminder set: "${call.name}" ($label)',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1F1F2B),
      ),
    );
  }

  void _showLeftSwipeActionSheet(CallRecord call) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1C1A24),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF0284C7), Color(0xFF38BDF8)],
                        ),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Center(
                        child: Text(
                          call.name.isNotEmpty ? call.name[0].toUpperCase() : '?',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            call.name,
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            call.number,
                            style: const TextStyle(color: Colors.white60, fontSize: 12, fontFamily: 'monospace'),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white54),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Divider(color: Colors.white12),
                const SizedBox(height: 6),
                // Quick SMS Action
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: const Color(0xFF0284C7).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.sms_rounded, color: Color(0xFF38BDF8), size: 20),
                  ),
                  title: const Text('Send Quick SMS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Open default SMS composer', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () async {
                    Navigator.pop(ctx);
                    final uri = Uri.parse('sms:${call.number}');
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                // 1-Tap Direct WhatsApp Chat
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: const Color(0xFF25D366).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 20),
                  ),
                  title: const Text('1-Tap WhatsApp Chat', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Chat instantly without saving number to contacts', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () {
                    Navigator.pop(ctx);
                    _openWhatsApp(call.number);
                  },
                ),
                // Quick Callback Reminder 15m
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: const Color(0xFFF59E0B).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.alarm, color: Color(0xFFFBBF24), size: 20),
                  ),
                  title: const Text('Remind me in 15 mins', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Set 1-tap quick callback alarm', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () {
                    Navigator.pop(ctx);
                    _setCallbackReminder(call, 'In 15 mins', const Duration(minutes: 15));
                  },
                ),
                // Delete Call
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: const Color(0xFFEF4444).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.delete_outline, color: Color(0xFFEF4444), size: 20),
                  ),
                  title: const Text('Delete from Recent Calls', style: TextStyle(color: Color(0xFFEF4444), fontWeight: FontWeight.w600)),
                  onTap: () {
                    Navigator.pop(ctx);
                    setState(() {
                      widget.calls.removeWhere((c) => c.id == call.id);
                      _updateFilteredCalls();
                    });
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCardContent(CallRecord call, bool isMissed, {String styleId = ''}) {
    final bool sunsetStyle = styleId == 'ios-depth';
    final bool bottomDockFlowStyle = styleId == 'bottom-dock-flow';
    final Color ios18Text = _activeIos18Palette['text']!;
    IconData typeIcon;
    Color typeColor;
    if (isMissed) {
      typeIcon = Icons.call_missed;
      typeColor = Colors.redAccent;
    } else if (call.type == CallType.outgoing) {
      typeIcon = Icons.call_made;
      typeColor = Colors.lightBlueAccent;
    } else {
      typeIcon = Icons.call_received;
      typeColor = const Color(0xFF10B981);
    }

    final durationText = call.duration > 0
        ? '${(call.duration ~/ 60)}m ${(call.duration % 60)}s'
        : '0s';

    return Row(
      children: [
        // Avatar
        Container(
          width: bottomDockFlowStyle ? 40 : 42,
          height: bottomDockFlowStyle ? 40 : 42,
          decoration: BoxDecoration(
            color: bottomDockFlowStyle ? const Color(0xFF313946) : null,
            gradient: bottomDockFlowStyle
                ? null
                : LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: sunsetStyle
                        ? (isMissed
                            ? [const Color(0xFFE45A7A), const Color(0xFF8D3D9B)]
                            : _sunsetAvatarColors(call))
                        : (isMissed
                            ? [Colors.redAccent.withOpacity(0.35), Colors.purpleAccent.withOpacity(0.2)]
                            : [const Color(0xFF10B981).withOpacity(0.35), Colors.blueAccent.withOpacity(0.2)]),
                  ),
            borderRadius: BorderRadius.circular(bottomDockFlowStyle ? 20 : 13),
            border: Border.all(
              color: bottomDockFlowStyle
                  ? Colors.white.withOpacity(0.12)
                  : (sunsetStyle ? Colors.white.withOpacity(0.48) : (isMissed ? Colors.redAccent.withOpacity(0.3) : Colors.white12)),
            ),
          ),
          child: Center(
            child: Text(
              call.name.isNotEmpty ? call.name[0].toUpperCase() : '?',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        // Name, Number & Info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      call.name,
                      style: TextStyle(
                        color: sunsetStyle
                            ? ios18Text
                            : (bottomDockFlowStyle
                                ? Colors.white
                                : (isMissed ? const Color(0xFFFF8B8B) : Colors.white)),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (call.repeatCount > 1) ...[
                    const SizedBox(width: 5),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEF4444).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.6), width: 0.8),
                      ),
                      child: Text(
                        '(${call.repeatCount})',
                        style: const TextStyle(
                          color: Color(0xFFF87171),
                          fontSize: 9.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                    decoration: BoxDecoration(
                      color: sunsetStyle ? ios18Text.withOpacity(0.12) : Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                      'SIM ${call.simSlot}',
                      style: TextStyle(color: sunsetStyle ? ios18Text.withOpacity(0.82) : Colors.white60, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _formatTimeAgo(call.timestamp),
                    style: TextStyle(
                      color: sunsetStyle ? ios18Text.withOpacity(0.68) : Colors.white38,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 4),
                  if (DateTime.now().difference(call.timestamp).inMinutes < 5) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: sunsetStyle ? const Color(0xFF10B981).withOpacity(0.16) : const Color(0xFF10B981).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: const Color(0xFF10B981), width: 0.8),
                      ),
                      child: const Text(
                        'LIVE',
                        style: TextStyle(
                          color: Color(0xFF10B981),
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                  if (isMissed) ...[
                    const SizedBox(width: 4),
                    InkWell(
                      onTap: () => _setCallbackReminder(call, '15m', const Duration(minutes: 15)),
                      borderRadius: BorderRadius.circular(5),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF59E0B).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: const Color(0xFFF59E0B), width: 0.8),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.alarm, color: Color(0xFFF59E0B), size: 8),
                            SizedBox(width: 2),
                            Text(
                              'Remind 15m',
                              style: TextStyle(
                                color: Color(0xFFFBBF24),
                                fontSize: 8,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 3),
              Row(
                children: [
                  Icon(typeIcon, color: typeColor, size: 12),
                  const SizedBox(width: 4),
                  Text(
                    call.number,
                    style: TextStyle(color: sunsetStyle ? ios18Text.withOpacity(0.92) : Colors.white60, fontSize: 11, fontFamily: 'monospace'),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    call.repeatCount > 1 ? '• ${call.repeatCount} Missed Calls (Grouped)' : '• $durationText',
                    style: TextStyle(
                      color: call.repeatCount > 1 ? const Color(0xFFF87171) : (sunsetStyle ? ios18Text.withOpacity(0.68) : Colors.white38),
                      fontSize: 10,
                      fontWeight: call.repeatCount > 1 ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        // Action Buttons: WhatsApp, Copy & Direct Call CTA
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 1-Tap Direct WhatsApp Chat
            InkWell(
              onTap: () => _openWhatsApp(call.number),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: const Color(0xFF25D366).withOpacity(0.18),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFF25D366).withOpacity(0.4), width: 0.8),
                ),
                child: const Center(
                  child: Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 15),
                ),
              ),
            ),
            IconButton(
              icon: Icon(Icons.copy, color: sunsetStyle ? ios18Text.withOpacity(0.8) : Colors.white38, size: 16),
              tooltip: 'Copy Number',
              onPressed: () {
                Clipboard.setData(ClipboardData(text: call.number));
                HapticFeedback.lightImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Copied ${call.number} to clipboard'),
                    duration: const Duration(seconds: 1),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
            InkWell(
              onTap: () {
                HapticFeedback.heavyImpact();
                widget.onCallNumber(call.number);
              },
              borderRadius: BorderRadius.circular(bottomDockFlowStyle ? 20 : 14),
              child: Container(
                width: bottomDockFlowStyle ? 38 : 40,
                height: bottomDockFlowStyle ? 38 : 40,
                decoration: BoxDecoration(
                  gradient: bottomDockFlowStyle
                      ? const LinearGradient(
                          colors: [Color(0xFF0B8261), Color(0xFF0A7355)],
                        )
                      : const LinearGradient(
                          colors: [Color(0xFF10B981), Color(0xFF059669)],
                        ),
                  borderRadius: BorderRadius.circular(bottomDockFlowStyle ? 19 : 14),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF10B981).withOpacity(bottomDockFlowStyle ? 0.25 : 0.4),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Center(
                  child: Icon(Icons.call, color: Colors.white, size: 19),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _cachedFilteredCalls;
    final currentStyle = STACK_STYLES[_currentStyleIndex];

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: BoxDecoration(
          image: currentStyle.id == 'ios-depth' && _activeIos18WallpaperAsset != null
              ? DecorationImage(image: AssetImage(_activeIos18WallpaperAsset!), fit: BoxFit.cover, alignment: Alignment.center)
              : null,
          gradient: currentStyle.id == 'ios-depth'
              ? LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_activeIos18Palette['bg1']!, _activeIos18Palette['bg2']!, _activeIos18Palette['bg3']!])
              : (currentStyle.id == 'bottom-dock-flow'
                  ? const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF0C0F13), Color(0xFF0A0D11), Color(0xFF07090C)])
                  : (currentStyle.id == 'fluid-stack'
                      ? const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF0D1120), Color(0xFF0A0D18), Color(0xFF080912)])
                      : const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF1B1822), Color(0xFF141219), Color(0xFF0D0C11)]))),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              // 1. Top Executive Control Strip
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: currentStyle.id == 'ios-depth' ? _activeIos18Palette['bg2']!.withOpacity(0.68) : const Color(0xFF141417).withOpacity(0.95),
                  border: const Border(
                    bottom: BorderSide(color: Colors.white10, width: 0.5),
                  ),
                ),
                child: Column(
                  children: [
                    // Row 1: Title, 11 Styles Dropdown, Cycle, Reset, Stack Toggle
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Title with pulse beacon
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: Color(0xFF10B981),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              'Recent Calls',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '(${filtered.length})',
                              style: const TextStyle(
                                color: Colors.white38,
                                fontSize: 12,
                                fontFamily: 'monospace',
                              ),
                            ),
                          ],
                        ),
                        // Right Controls: 11 Styles Picker + Cycle Next + Restore + Stack Toggle
                        Row(
                          children: [
                            // Combined top pill: style picker + quick settings button.
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.06),
                                borderRadius: BorderRadius.circular(22),
                                border: Border.all(color: Colors.white12),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  InkWell(
                                    onTap: _showStyleSelectorSheet,
                                    borderRadius: BorderRadius.circular(16),
                                    child: Row(
                                      children: [
                                        const Icon(Icons.auto_awesome, color: Color(0xFF10B981), size: 12),
                                        const SizedBox(width: 4),
                                        Text(
                                          '${currentStyle.number}. ${currentStyle.name.split(' ')[0]}',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        const SizedBox(width: 4),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                          decoration: BoxDecoration(
                                            color: const Color(0xFF10B981).withOpacity(0.2),
                                            borderRadius: BorderRadius.circular(4),
                                          ),
                                          child: Text(
                                            '${STACK_STYLES.length}',
                                            style: const TextStyle(
                                              color: Color(0xFF10B981),
                                              fontSize: 9,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 2),
                                        const Icon(Icons.arrow_drop_down, color: Colors.white54, size: 14),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 5),
                                  Container(width: 1, height: 18, color: Colors.white24),
                                  const SizedBox(width: 3),
                                  InkWell(
                                    onTap: () {
                                      HapticFeedback.selectionClick();
                                      showDialog(
                                        context: context,
                                        builder: (ctx) => DialerSettingsDialog(
                                          onSimulateIncoming: widget.onSimulateIncoming,
                                          showIos18Appearance: currentStyle.id == 'ios-depth',
                                          ios18Appearance: _ios18Appearance,
                                          onIos18AppearanceChanged: _setIos18Appearance,
                                        ),
                                      ).then((_) => _loadStackMotionPreferences());
                                    },
                                    borderRadius: BorderRadius.circular(18),
                                    child: const Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                      child: Icon(Icons.settings_outlined, size: 16, color: Colors.white70),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 4),
                            // Cycle next style button
                            IconButton(
                              icon: const Icon(Icons.shuffle, size: 16, color: Colors.white60),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                              tooltip: 'Cycle Next Style (1-${STACK_STYLES.length})',
                              onPressed: _cycleNextStyle,
                            ),
                            // Restore default style button
                            IconButton(
                              icon: const Icon(Icons.restore, size: 16, color: Colors.lightBlueAccent),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                              tooltip: 'Restore Style 1 (iOS Depth)',
                              onPressed: _restoreDefaultStyle,
                            ),
                            // Stack Deck vs Fan Out toggle for notification deck & Fluid-Stack styles (12, 13 & 16)
                            if (_currentStyleIndex == 11 || _currentStyleIndex == 12 || _currentStyleIndex == 15) InkWell(
                              onTap: _toggleStackCollapsed,
                              borderRadius: BorderRadius.circular(10),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                decoration: BoxDecoration(
                                  color: _isStackCollapsed
                                      ? Colors.amber.withOpacity(0.25)
                                      : Colors.white.withOpacity(0.06),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: _isStackCollapsed ? Colors.amber : Colors.white12,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.layers,
                                      size: 13,
                                      color: _isStackCollapsed ? Colors.amber : Colors.white70,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      _isStackCollapsed ? 'Fan Out' : 'Stack',
                                      style: TextStyle(
                                        color: _isStackCollapsed ? Colors.amber : Colors.white70,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            // Live Device Call Log Refresh button
                            IconButton(
                              icon: const Icon(Icons.refresh, size: 16, color: Color(0xFF10B981)),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 26, minHeight: 26),
                              tooltip: 'Sync Live Call Logs from Phone',
                              onPressed: () {
                                HapticFeedback.lightImpact();
                                setState(() {
                                  _scrollPos = 0.0;
                                  _targetScroll = 0.0;
                                });
                                widget.onRefresh();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('⚡ Syncing live call logs from phone...'),
                                    duration: Duration(seconds: 1),
                                    behavior: SnackBarBehavior.floating,
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),

                    // Slim unified pill for call filters; search lives in the bottom navigation.
                    Container(
                      height: 34,
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: currentStyle.id == 'ios-depth' ? _activeIos18Palette['card2']!.withOpacity(0.38) : const Color(0xFF242428),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: Colors.white.withOpacity(0.055)),
                      ),
                      child: Row(
                        children: [
                          Expanded(child: _buildFilterPill('all', 'All')),
                          Expanded(child: _buildFilterPill('missed', 'Missed')),
                          Expanded(child: _buildFilterPill('incoming', 'In')),
                          Expanded(child: _buildFilterPill('outgoing', 'Out')),
                          const SizedBox(width: 4),
                          _buildSmartSortToggle(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // 2. 3D Kinetic Card Stack Stage Viewport
              Expanded(
                child: filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.phone_missed, color: Colors.white.withOpacity(0.15), size: 54),
                            const SizedBox(height: 12),
                            const Text(
                              'No recent calls found',
                              style: TextStyle(color: Colors.white54, fontSize: 14),
                            ),
                          ],
                        ),
                      )
                    : LayoutBuilder(
                        builder: (context, constraints) {
                          final double containerHeight = constraints.maxHeight;
                          _viewportHeight = containerHeight;
                          final double topStackBoundary = headerOffset;
                          // Style 14: the third-from-bottom card marks the dock entrance; at max scroll,
                          // cards 1-8 stay full width and only cards 9-10 narrow into the dock.
                          // Other styles keep their original boundary.
                          final double bottomStackBoundary = _currentStyleIndex == 13
                              ? math.max(topStackBoundary + _activeCardStep, containerHeight - 3 * _activeCardStep).toDouble()
                              : (_currentStyleIndex == 14
                                  ? math.max(topStackBoundary + _activeCardStep, containerHeight - _activeCardHeight - 46.0).toDouble()
                                  : containerHeight - 140.0);
                          final double maxScroll = math.max(
                            0.0,
                            headerOffset + filtered.length * _activeCardStep - containerHeight +
                                (_currentStyleIndex == 13
                                    ? 0.0
                                    : (_currentStyleIndex == 14 ? 40.0 : _activeCardHeight)),
                          ).toDouble();
                          // Defensive clamp: if the call count, filter, or card style
                          // changes, don't retain an offset beyond the new scroll range.
                          _scrollPos = _scrollPos.clamp(0.0, maxScroll).toDouble();
                          _targetScroll = _targetScroll.clamp(0.0, maxScroll).toDouble();

                          return GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onVerticalDragStart: (details) {
                              _isDragging = true;
                              _velocity = 0;
                            },
                            onVerticalDragUpdate: (details) {
                              // Flutter native primary delta - immune to child layout rebuilds or localPosition coordinate shifts!
                              final deltaY = -details.delta.dy;
                              if (deltaY.isNaN || deltaY.isInfinite) return;
                              // The adjustable motion control is exclusive to Style 12.
                              // Preserve the previous drag feel for every other card style.
                              final double activeSpeed = _currentStyleIndex == 11 ? _scrollSpeedMultiplier : 1.5;
                              _velocity = (deltaY * 1.12 * activeSpeed).clamp(-60.0, 60.0).toDouble();
                              final double dragGain = activeSpeed;
                              _targetScroll = (_targetScroll + deltaY * dragGain).clamp(0.0, maxScroll).toDouble();
                              // Let the ticker's frame-based interpolation follow the finger;
                              // avoid assigning _scrollPos directly, which causes visible micro-jumps.
                              setState(() {});
                            },
                            onVerticalDragEnd: (details) {
                              _isDragging = false;
                              final pv = details.primaryVelocity;
                              if (pv != null && pv.abs() > 40) {
                                final double activeSpeed = _currentStyleIndex == 11 ? _scrollSpeedMultiplier : 1.5;
                                final double flingDivisor = 52.0 / activeSpeed;
                                final double maxFling = 25.0 * activeSpeed;
                                _velocity = (-pv / flingDivisor).clamp(-maxFling, maxFling).toDouble();
                              } else {
                                _velocity = _velocity.clamp(-16.0, 16.0).toDouble();
                              }
                            },
                            child: SizedBox(
                              width: constraints.maxWidth,
                              height: containerHeight,
                              child: ClipRect(
                                child: Stack(
                                  fit: StackFit.expand,
                                  clipBehavior: Clip.none,
                                  children: [
                                    const SizedBox.expand(),
                                    if (currentStyle.id == 'fluid-stack') ...[
                                      // Subtle Background Bokeh Shift as Fluid-Stack cards fan out / scroll
                                      Positioned(
                                        top: -40 + 22 * _fluidFanProgress - (_scrollPos / math.max(maxScroll, 1.0)) * 16.0,
                                        left: -35 + 26 * _fluidFanProgress + (_scrollPos / math.max(maxScroll, 1.0)) * 14.0,
                                        child: IgnorePointer(
                                          child: Container(
                                            width: 220,
                                            height: 220,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              gradient: RadialGradient(
                                                colors: [
                                                  const Color(0xFF06B6D4).withOpacity(0.14 + 0.12 * _fluidFanProgress.clamp(0.0, 1.0)),
                                                  const Color(0xFF06B6D4).withOpacity(0.0),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        top: containerHeight * 0.28 - 18 * _fluidFanProgress + (_scrollPos / math.max(maxScroll, 1.0)) * 18.0,
                                        right: -45 - 18 * _fluidFanProgress,
                                        child: IgnorePointer(
                                          child: Container(
                                            width: 240,
                                            height: 240,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              gradient: RadialGradient(
                                                colors: [
                                                  const Color(0xFF6366F1).withOpacity(0.14 + 0.12 * _fluidFanProgress.clamp(0.0, 1.0)),
                                                  const Color(0xFF6366F1).withOpacity(0.0),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        bottom: -50 - 20 * _fluidFanProgress,
                                        left: constraints.maxWidth * 0.22 + 14 * _fluidFanProgress,
                                        child: IgnorePointer(
                                          child: Container(
                                            width: 210,
                                            height: 210,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              gradient: RadialGradient(
                                                colors: [
                                                  const Color(0xFFD946EF).withOpacity(0.10 + 0.10 * _fluidFanProgress.clamp(0.0, 1.0)),
                                                  const Color(0xFFD946EF).withOpacity(0.0),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                    for (int i = filtered.length - 1; i >= 0; i--)
                                      _buildCardWidget(
                                        index: i,
                                        call: filtered[i],
                                        currentStyle: currentStyle,
                                        topBoundary: topStackBoundary,
                                        bottomBoundary: bottomStackBoundary,
                                        step: _activeCardStep,
                                        containerWidth: constraints.maxWidth,
                                        totalCards: filtered.length,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCardWidget({
    required int index,
    required CallRecord call,
    required StackStyleConfig currentStyle,
    required double topBoundary,
    required double bottomBoundary,
    required double step,
    required double containerWidth,
    required int totalCards,
  }) {
    final double naturalY = headerOffset + index * step - _scrollPos;
    // Bottom dock sits just above the gesture/navigation area. Two 12dp lips
    // remain visible while every card retains its original 90dp height.
    final double dynamicDockTopY = _viewportHeight - _activeCardHeight - 28.0;
    final bool dynamicShrinkStyle = currentStyle.id == 'dynamic-shrink-expand-stack';
    final bool bottomDockFlowStyle = currentStyle.id == 'bottom-dock-flow';
    final bool fluidStackStyle = currentStyle.id == 'fluid-stack';

    // Viewport pruning uses the card's projected position.
    if (bottomDockFlowStyle) {
      if (naturalY < topBoundary - _activeCardHeight - 10.0 || naturalY > bottomBoundary + step * 3.8) {
        return const SizedBox.shrink();
      }
    } else if (dynamicShrinkStyle) {
      const double lip = 13.0;
      final int layerFromBottom = (totalCards - 1 - index).clamp(0, totalCards).toInt();
      final double maxScroll = math.max(
        1.0,
        headerOffset + totalCards * step - _viewportHeight,
      ).toDouble();
      final double scrollProgress = (_scrollPos / maxScroll).clamp(0.0, 1.0).toDouble();
      final double gatherT = ((scrollProgress - 0.55) / 0.45).clamp(0.0, 1.0).toDouble();
      final double dockProgress = gatherT * gatherT * (3.0 - 2.0 * gatherT);
      final double projectedY = naturalY + (dynamicDockTopY - layerFromBottom * lip - naturalY) * dockProgress;
      if (projectedY < topBoundary - _activeCardHeight || projectedY > _viewportHeight + step) {
        return const SizedBox.shrink();
      }
    } else if (naturalY < topBoundary - step * 3.2 || naturalY > bottomBoundary + step * 3.2) {
      return const SizedBox.shrink();
    }

    final transforms = _computeCardTransforms(
      styleId: currentStyle.id,
      index: index,
      naturalY: naturalY,
      topBoundary: topBoundary,
      bottomBoundary: bottomBoundary,
      dockTopY: dynamicDockTopY,
      step: step,
      totalCards: totalCards,
    );

    double yPos = transforms['yPos'];
    final double xPos = transforms['xPos'];
    double scale = transforms['scale'];
    final double rotateX = transforms['rotateX'];
    final double rotateY = transforms['rotateY'];
    final double rotateZ = transforms['rotateZ'];
    double opacity = transforms['opacity'];
    final Alignment origin = transforms['transformOrigin'];
    final bool isMissed = call.type == CallType.missed || call.type == CallType.rejected;
    final bool fluxEngineStyle = currentStyle.id == 'realme-flux-engine';
    final bool notificationFlowStyle = currentStyle.id == 'android-notification-flow';
    final bool notificationStackStyle = currentStyle.id == 'notification-stack-deck';

    // Universal visibility guard: cards in visible area MUST be 100% visible
    if (!yPos.isFinite) yPos = naturalY;
    if (!scale.isFinite || scale < 0.6) scale = 1.0;
    if (!opacity.isFinite || (!bottomDockFlowStyle && !fluidStackStyle && opacity < 0.20)) {
      opacity = bottomDockFlowStyle ? 0.0 : 0.25;
    }
    final bool fluidCollapsing = fluidStackStyle && (_isStackCollapsed || _fluidFanProgress < 0.998);
    if (!dynamicShrinkStyle && !bottomDockFlowStyle && !fluidCollapsing && naturalY >= topBoundary && naturalY <= bottomBoundary) {
      yPos = naturalY;
      opacity = 1.0;
      scale = 1.0;
    }

    // Horizontal layout shrink/expand (no X/Y scale distortion)
    double dynamicWidthScale = 1.0;
    double dynamicDockProgress = -1.0;
    if (bottomDockFlowStyle && naturalY > bottomBoundary) {
      final double bottomOverflow = naturalY - bottomBoundary;
      final double progress = (bottomOverflow / math.max(step, 1.0)).clamp(0.0, 3.6).toDouble();
      dynamicWidthScale = (1.0 - progress * 0.115).clamp(0.64, 1.0).toDouble();
    } else if (dynamicShrinkStyle) {
      final double maxScroll = math.max(
        1.0,
        headerOffset + totalCards * step - _viewportHeight,
      ).toDouble();
      final double scrollProgress = (_scrollPos / maxScroll).clamp(0.0, 1.0).toDouble();
      final double gatherT = ((scrollProgress - 0.55) / 0.45).clamp(0.0, 1.0).toDouble();
      dynamicDockProgress = gatherT * gatherT * (3.0 - 2.0 * gatherT);
      final int layerFromBottom = (totalCards - 1 - index).clamp(0, totalCards).toInt();
      if (layerFromBottom < 3) {
        // The three lowest cards are a little wider than the previous build:
        // 76%, 84%, and 92% from the fixed base upward.
        final double targetWidth = layerFromBottom == 0 ? 0.76 : (layerFromBottom == 1 ? 0.84 : 0.92);
        dynamicWidthScale = 1.0 - (1.0 - targetWidth) * dynamicDockProgress;
      }
    }

    final double baseHorizontalInset = notificationStackStyle
        ? 20.0
        : (notificationFlowStyle || fluxEngineStyle || bottomDockFlowStyle) ? 12.0 : 14.0;
    final double widthInset = (dynamicShrinkStyle || bottomDockFlowStyle)
        ? math.max(0.0, (containerWidth - baseHorizontalInset * 2) * (1.0 - dynamicWidthScale) / 2.0)
        : 0.0;

    // No X/Y scaling is applied for Style 14: the actual layout width changes,
    // so card height and text size stay intact while left/right edges move inward.
    final matrix3D = Matrix4.identity()
      ..setEntry(3, 2, fluidStackStyle ? 0.0012 : 0.0008)
      ..rotateX(rotateX * math.pi / 180.0)
      ..rotateY(rotateY * math.pi / 180.0)
      ..rotateZ(rotateZ * math.pi / 180.0)
      ..scale(scale, scale, 1.0);

    return Positioned(
      top: yPos,
      left: baseHorizontalInset + xPos + widthInset,
      right: baseHorizontalInset - xPos + widthInset,
      child: Transform(
        transform: matrix3D,
        alignment: origin,
        child: Opacity(
          opacity: opacity.clamp(0.0, 1.0),
          child: Dismissible(
            key: ValueKey('swipe_call_${call.id}_$index'),
            direction: DismissDirection.horizontal,
            confirmDismiss: (direction) async {
              if (direction == DismissDirection.startToEnd) {
                // Right Swipe: Instant Call
                RealmeOHaptics.solidThud();
                widget.onCallNumber(call.number);
                return false;
              } else if (direction == DismissDirection.endToStart) {
                // Left Swipe: Quick Message & Options
                RealmeOHaptics.microTick();
                _showLeftSwipeActionSheet(call);
                return false;
              }
              return false;
            },
            background: Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular((dynamicShrinkStyle || bottomDockFlowStyle) ? 24 : (notificationStackStyle ? 26 : 20)),
                gradient: const LinearGradient(
                  colors: [Color(0xFF00C853), Color(0xFF00E676)],
                ),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.call_rounded, color: Colors.white, size: 22),
                  SizedBox(width: 8),
                  Text(
                    'Instant Call',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            secondaryBackground: Container(
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular((dynamicShrinkStyle || bottomDockFlowStyle) ? 24 : (notificationStackStyle ? 26 : 20)),
                gradient: const LinearGradient(
                  colors: [Color(0xFF0284C7), Color(0xFFEF4444)],
                ),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Quick Message',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(width: 8),
                  Icon(Icons.sms_rounded, color: Colors.white, size: 22),
                ],
              ),
            ),
            child: GestureDetector(
            onTap: () {
              if (_isStackCollapsed) {
                _toggleStackCollapsed();
              } else {
                HapticFeedback.lightImpact();
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (ctx) => CallDetailBottomSheet(
                    call: call,
                    onCallNumber: widget.onCallNumber,
                    onDeleteCall: (id) {
                      setState(() {
                        widget.calls.removeWhere((c) => c.id == id);
                      });
                    },
                  ),
                );
              }
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular((dynamicShrinkStyle || bottomDockFlowStyle) ? 24 : (notificationStackStyle ? 26 : 20)),
              child: Container(
                height: notificationStackStyle
                    ? notificationCardHeight
                    : (notificationFlowStyle
                        ? notificationFlowCardHeight
                        : (fluxEngineStyle
                            ? fluxCardHeight
                            : (bottomDockFlowStyle
                                ? bottomDockFlowCardHeight
                                : (fluidStackStyle
                                    ? fluidStackCardHeight
                                    : (dynamicShrinkStyle ? dynamicStackCardHeight : cardHeight))))),
                padding: EdgeInsets.symmetric(
                  horizontal: (notificationFlowStyle || fluxEngineStyle || dynamicShrinkStyle || bottomDockFlowStyle) ? 12 : 14,
                  vertical: (notificationFlowStyle || fluxEngineStyle || dynamicShrinkStyle || bottomDockFlowStyle) ? 6 : 12,
                ),
                decoration: _getCardBoxDecoration(currentStyle.id, isMissed),
                child: dynamicShrinkStyle
                    ? Stack(
                        fit: StackFit.expand,
                        children: [
                          _buildCardContent(call, isMissed, styleId: currentStyle.id),
                          // A subtle scroll-driven light sweep on the card as it
                          // docks: the effect follows the finger instead of autoplaying.
                          if (dynamicDockProgress >= 0.0 && dynamicDockProgress <= 1.0 && (totalCards - 1 - index) < 3)
                            IgnorePointer(
                              child: Opacity(
                                opacity: (0.16 * (1.0 - (dynamicDockProgress - 0.5).abs() * 2.0))
                                    .clamp(0.0, 0.16)
                                    .toDouble(),
                                child: Align(
                                  alignment: Alignment(dynamicDockProgress * 2.0 - 1.0, 0.0),
                                  child: Container(
                                    width: 76,
                                    decoration: const BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                        colors: [
                                          Color(0x0000E6A0),
                                          Color(0x5576FFD1),
                                          Color(0x0000E6A0),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      )
                    : _buildCardContent(call, isMissed, styleId: currentStyle.id),
              ),
            ),
          ),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterPill(String key, String label) {
    final isSelected = _selectedFilter == key;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() {
          _selectedFilter = key;
          _targetScroll = 0.0;
          _scrollPos = 0.0;
          _updateFilteredCalls();
        });
      },
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF414145) : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white60,
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildSmartSortToggle() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() {
          _smartSortEnabled = !_smartSortEnabled;
          _targetScroll = 0.0;
          _scrollPos = 0.0;
          _updateFilteredCalls();
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3.5),
        decoration: BoxDecoration(
          color: _smartSortEnabled ? const Color(0xFF10B981).withOpacity(0.24) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _smartSortEnabled ? const Color(0xFF10B981).withOpacity(0.65) : Colors.white12,
            width: 0.9,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.auto_awesome,
              size: 11,
              color: _smartSortEnabled ? const Color(0xFF10B981) : Colors.white38,
            ),
            const SizedBox(width: 3),
            Text(
              'Smart',
              style: TextStyle(
                color: _smartSortEnabled ? const Color(0xFF10B981) : Colors.white54,
                fontSize: 10,
                fontWeight: _smartSortEnabled ? FontWeight.bold : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
