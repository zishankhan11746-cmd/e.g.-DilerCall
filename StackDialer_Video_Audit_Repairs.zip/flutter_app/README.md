# StackDialer v16 (Latest Release)

## Updates & Features in this Build:
1. **Keypad Frosted Glass (No Artificial Key Glow)**:
   - High-contrast frosted specular glass rim border (crisp white resting, smooth transition on tap).
   - Removed tacky 32px blinding neon halo/glow bloom.
   - Clean translucent smoky spherical lens with BackdropFilter blur and elastic recoil squash.
   - Sharp, solid white numbers with crisp contrast drop shadow.

2. **Realme UI 7.0 O-Haptics (Native Linear Motor Haptics)**:
   - Connected directly to Android native telecom MethodChannel (`dialpadHaptic`).
   - Android 10+ uses `VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)` for micro-ticks and `VibrationEffect.EFFECT_HEAVY_CLICK` for solid thuds.
   - High-amplitude fallback (195-250) ensures physical vibration pulses on every Android manufacturer skin.

3. **iOS 18 Style 1: 5 Premium Themes (Theme 5: Sunset Dream)**:
   - Theme 5 (Sunset Dream) with vibrant coral ocean horizon and amber card glass is fully wired and defaulted.
   - Direct 1-tap **iOS 18 Themes Sheet** accessible right from the Theme Chip on the Recents header.
   - Synchronized across both `ios18_theme_variant` and `stackdialer_ios18_appearance`.

4. **Swipe-to-Action on Recent Cards**:
   - Right swipe: Instant Call (Green gradient backdrop + medium thud).
   - Left swipe: Quick SMS Message modal (Blue gradient backdrop + message chips).

## Build Instructions:
Run `./build_apk.sh` or:
```bash
flutter pub get
flutter build apk --release
```
Output APK: `build/app/outputs/flutter-apk/app-release.apk`


## Video audit fixes (2026-11)
- Reconcile the active-call screen with the live Android Telecom state when the Flutter Activity is recreated.
- Persist the native connected-at timestamp so the in-call timer continues from the actual connected time.
- Reset the saved timestamp when a call disconnects or a new call begins, preventing stale duration reuse.
- Show "Calling…" in the ongoing notification while the call is still dialing; start its chronometer only after Telecom reports ACTIVE/HOLDING.
- Compact the in-call keypad layout and add Clear, Hide keypad, and an always-visible End Call control.
- Reduce vertical gaps on the active-call screen so the header and controls are less likely to scroll off-screen.
