import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/contact.dart';
import '../services/speed_dial_service.dart';
import '../widgets/settings_dialog.dart';

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> {
  String _digits = '';
  String? _pressedDigit;
  Timer? _glowTimer;
  int _selectedSim = 1;
  bool _hapticsEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadHapticsPreference();
  }

  Future<void> _loadHapticsPreference() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _hapticsEnabled = prefs.getBool('stackdialer_haptics_enabled') ?? true);
  }

  final List<Map<String, String>> _speedDialFavorites = [
    {'label': 'Mom ❤️', 'number': '+91 98201 45892', 'color': '0xFFEC4899'},
    {'label': 'Sanib A.', 'number': '+91 97654 21980', 'color': '0xFF3B82F6'},
    {'label': 'Mo Faisal', 'number': '+91 98711 00982', 'color': '0xFF10B981'},
    {'label': 'Shivi 🦋', 'number': '+91 98450 11223', 'color': '0xFF8B5CF6'},
    {'label': '112 SOS', 'number': '112', 'color': '0xFFEF4444'},
  ];

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    if (_hapticsEnabled) HapticFeedback.lightImpact();
    _glowTimer?.cancel();
    setState(() {
      _digits += digit;
      _pressedDigit = digit;
    });
    _glowTimer = Timer(const Duration(milliseconds: 170), () {
      if (mounted) setState(() => _pressedDigit = null);
    });
  }

  @override
  void dispose() {
    _glowTimer?.cancel();
    super.dispose();
  }

  void _onBackspace() {
    if (_hapticsEnabled) HapticFeedback.lightImpact();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    if (_hapticsEnabled) HapticFeedback.mediumImpact();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    return Scaffold(
      backgroundColor: const Color(0xFFF4F2F8),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFF9F8FC), Color(0xFFEDEAF4)],
          ),
        ),
        child: SafeArea(
          bottom: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              // Match the reference dialer: large, evenly spaced circular keys.
              final double keyHeight = (constraints.maxWidth * 0.158).clamp(56.0, 66.0);
              final double keyWidth = keyHeight;
              final double rowSpacing = screenHeight < 600 ? 8.0 : 11.0;
              final double callBtnHeight = screenHeight < 600 ? 60.0 : (screenHeight < 700 ? 70.0 : 80.0);

              return Column(
                children: [
                  // Keep the top area clean like the reference dial pad.
                  const SizedBox(height: 4),

                  // Number display / placeholder, positioned above the large keypad.
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: _digits.isEmpty
                            ? const FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  'Enter number',
                                  style: TextStyle(
                                    fontSize: 44,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.5,
                                    color: Color(0xFF777482),
                                  ),
                                ),
                              )
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: Text(
                                      _digits,
                                      style: const TextStyle(
                                        fontSize: 36,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 1.5,
                                        color: Color(0xFF24232B),
                                      ),
                                    ),
                                  ),
                                  if (matches.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Text(
                                      '${matches.first.name} • ${matches.first.number}',
                                      style: const TextStyle(color: Color(0xFF777482), fontSize: 13),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ],
                              ),
                      ),
                    ),
                  ),

                  // 3. Squircle Dialpad 4x3 Grid (Compact & Perfectly Spaced)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 22),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildSquircleRow(['1', '2', '3'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['4', '5', '6'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['7', '8', '9'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['*', '0', '#'], keyWidth, keyHeight),
                      ],
                    ),
                  ),

                  SizedBox(height: rowSpacing + 4),

                  // Large round green call button, as in the reference image.
                  SizedBox(height: rowSpacing + 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 24, right: 24, bottom: 8),
                    child: SizedBox(
                      height: callBtnHeight,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          InkWell(
                            onTap: () {
                              if (_digits.isNotEmpty) {
                                if (_hapticsEnabled) HapticFeedback.heavyImpact();
                                widget.onCallNumber(_digits);
                              }
                            },
                            customBorder: const CircleBorder(),
                            child: Container(
                              width: callBtnHeight,
                              height: callBtnHeight,
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFF10B981).withOpacity(0.32),
                                    blurRadius: 26,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: const Center(
                                child: Icon(Icons.call, color: Colors.white, size: 34),
                              ),
                            ),
                          ),
                          if (_digits.isNotEmpty)
                            Align(
                              alignment: Alignment.centerRight,
                              child: GestureDetector(
                                onTap: _onBackspace,
                                onLongPress: _onClearAll,
                                child: Container(
                                  width: 58,
                                  height: 58,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFF0EDF6),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0xFFFFFFFF), width: 1.2),
                                    boxShadow: const [
                                      BoxShadow(color: Color(0x260E0B1A), blurRadius: 9, offset: Offset(0, 4)),
                                      BoxShadow(color: Color(0xDFFFFFFF), blurRadius: 5, offset: Offset(-2, -2)),
                                    ],
                                  ),
                                  child: const Icon(Icons.backspace_outlined, color: Color(0xFF514D5C), size: 24),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSimPill(int slot, String label) {
    final isSelected = _selectedSim == slot;
    return GestureDetector(
      onTap: () {
        if (_hapticsEnabled) HapticFeedback.selectionClick();
        setState(() => _selectedSim = slot);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981).withOpacity(0.2) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? const Color(0xFF10B981) : Colors.white12,
            width: isSelected ? 1.2 : 0.8,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? const Color(0xFF10B981) : Colors.white70,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildSquircleRow(List<String> keys, double width, double height) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (int i = 0; i < keys.length; i++) ...[
          if (i > 0) const SizedBox(width: 14),
          _buildSquircleButton(keys[i], width, height),
        ],
      ],
    );
  }

  Widget _buildSquircleButton(String key, double width, double height) {
    final sub = _t9Map[key] ?? '';
    final bool pressed = _pressedDigit == key;
    return Material(
      color: Colors.transparent,
      shape: const CircleBorder(),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _onDigitPress(key),
        onLongPress: () {
          if (key == '0') {
            _onDigitPress('+');
          } else if (key == '1') {
            if (_hapticsEnabled) HapticFeedback.heavyImpact();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Calling Voicemail (*123#)...')),
            );
            widget.onCallNumber('*123#');
          } else {
            final intKey = int.tryParse(key);
            if (intKey != null && intKey >= 2 && intKey <= 9) {
              final entry = SpeedDialService.getEntry(intKey);
              if (entry != null) {
                if (_hapticsEnabled) HapticFeedback.heavyImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('⚡ Speed Dial #$intKey: Calling ${entry.name} (${entry.number})'),
                    duration: const Duration(seconds: 2),
                  ),
                );
                widget.onCallNumber(entry.number);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Speed Dial key $intKey is not assigned yet. Set it in Settings!'),
                  ),
                );
              }
            }
          }
        },
        customBorder: const CircleBorder(),
        splashColor: const Color(0xFF8D79C7).withOpacity(0.20),
        highlightColor: const Color(0xFF8D79C7).withOpacity(0.10),
        splashFactory: InkRipple.splashFactory,
        child: AnimatedScale(
          scale: pressed ? 0.94 : 1.0,
          duration: const Duration(milliseconds: 105),
          curve: Curves.easeOutBack,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            curve: Curves.easeOutCubic,
            width: height,
            height: height,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: pressed
                    ? const [Color(0xFFE3DFEC), Color(0xFFF1EFF6), Color(0xFFE9E6F0)]
                    : const [Color(0xFFFFFFFF), Color(0xFFF3F1F8), Color(0xFFE8E5F0)],
              ),
              border: Border.all(
                color: Colors.white.withOpacity(pressed ? 0.98 : 0.92),
                width: pressed ? 1.5 : 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF625C70).withOpacity(pressed ? 0.10 : 0.20),
                  blurRadius: pressed ? 3 : 9,
                  offset: Offset(0, pressed ? 1 : 4),
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(pressed ? 0.50 : 0.98),
                  blurRadius: pressed ? 3 : 6,
                  offset: const Offset(-2, -2),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  key,
                  style: TextStyle(
                    fontSize: height >= 74 ? 32 : (height >= 66 ? 28 : 24),
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF282630),
                    height: 1.1,
                  ),
                ),
                if (sub.isNotEmpty)
                  Text(
                    sub,
                    style: TextStyle(
                      fontSize: height >= 74 ? 12 : 10,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF777482),
                      letterSpacing: 1.2,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
