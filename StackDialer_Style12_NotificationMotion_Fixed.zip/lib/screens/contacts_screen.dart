import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/contact.dart';

class ContactsScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;

  const ContactsScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
  });

  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  static const String _prefKey = 'stackdialer_favorite_contacts';
  Set<String> _favoriteIds = {'c1', 'c2'};
  String _searchQuery = '';
  String _selectedTab = 'all'; // 'all' or 'favorites'

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList(_prefKey);
      if (list != null) {
        setState(() {
          _favoriteIds = list.toSet();
        });
      }
    } catch (_) {}
  }

  Future<void> _toggleFavorite(String contactId) async {
    HapticFeedback.selectionClick();
    setState(() {
      if (_favoriteIds.contains(contactId)) {
        _favoriteIds.remove(contactId);
      } else {
        _favoriteIds.add(contactId);
      }
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_prefKey, _favoriteIds.toList());
    } catch (_) {}
  }

  void _showContactDetailSheet(ContactModel contact) {
    final isFav = _favoriteIds.contains(contact.id);
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1C25),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          final currentlyFav = _favoriteIds.contains(contact.id);
          return Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF10B981), Color(0xFF059669)],
                        ),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Center(
                        child: Text(
                          contact.initials,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            contact.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            contact.number,
                            style: const TextStyle(
                              color: Colors.white70,
                              fontFamily: 'monospace',
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        currentlyFav ? Icons.star : Icons.star_border,
                        color: currentlyFav ? const Color(0xFFF59E0B) : Colors.white38,
                        size: 26,
                      ),
                      onPressed: () async {
                        await _toggleFavorite(contact.id);
                        setSheetState(() {});
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF10B981),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        icon: const Icon(Icons.call, color: Colors.white, size: 18),
                        label: const Text(
                          'Call SIM 1',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        onPressed: () {
                          Navigator.pop(ctx);
                          widget.onCallNumber(contact.number);
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF38BDF8),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        icon: const Icon(Icons.call, color: Colors.white, size: 18),
                        label: const Text(
                          'Call SIM 2',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        onPressed: () {
                          Navigator.pop(ctx);
                          widget.onCallNumber(contact.number);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    TextButton.icon(
                      icon: const Icon(Icons.chat_bubble_outline, color: Color(0xFF25D366), size: 18),
                      label: const Text('WhatsApp', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      onPressed: () async {
                        final clean = contact.number.replaceAll(RegExp(r'[^\d]'), '');
                        final uri = Uri.parse('https://wa.me/$clean');
                        if (await canLaunchUrl(uri)) await launchUrl(uri);
                      },
                    ),
                    TextButton.icon(
                      icon: const Icon(Icons.sms_outlined, color: Color(0xFF38BDF8), size: 18),
                      label: const Text('SMS', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      onPressed: () async {
                        final uri = Uri(scheme: 'sms', path: contact.number);
                        if (await canLaunchUrl(uri)) await launchUrl(uri);
                      },
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = widget.contacts.where((c) {
      if (_selectedTab == 'favorites' && !_favoriteIds.contains(c.id)) {
        return false;
      }
      if (_searchQuery.trim().isEmpty) return true;
      final q = _searchQuery.toLowerCase();
      return c.name.toLowerCase().contains(q) || c.number.contains(q);
    }).toList();

    final favoriteCount = widget.contacts.where((c) => _favoriteIds.contains(c.id)).length;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1B1822),
              Color(0xFF141219),
              Color(0xFF0D0C11),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Top Header with Search & Filter Tabs
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: Color(0xFF10B981),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              'Contacts Directory',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                letterSpacing: -0.5,
                              ),
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            '${filtered.length} Contacts',
                            style: const TextStyle(color: Colors.white60, fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    // Search Bar
                    Container(
                      height: 40,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF24222C),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.white10),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.search, color: Colors.white38, size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextField(
                              style: const TextStyle(color: Colors.white, fontSize: 13),
                              decoration: const InputDecoration(
                                hintText: 'Search by name or number...',
                                hintStyle: TextStyle(color: Colors.white30, fontSize: 13),
                                border: InputBorder.none,
                                isDense: true,
                              ),
                              onChanged: (val) => setState(() => _searchQuery = val),
                            ),
                          ),
                          if (_searchQuery.isNotEmpty)
                            GestureDetector(
                              onTap: () => setState(() => _searchQuery = ''),
                              child: const Icon(Icons.close, color: Colors.white54, size: 16),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    // Filter Tabs: All vs Favorites
                    Row(
                      children: [
                        _buildTabChip('all', 'All Contacts (${widget.contacts.length})'),
                        const SizedBox(width: 8),
                        _buildTabChip('favorites', '⭐ Favorites ($favoriteCount)'),
                      ],
                    ),
                  ],
                ),
              ),

              // Contacts List
              Expanded(
                child: filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              _selectedTab == 'favorites' ? Icons.star_border : Icons.person_search,
                              color: Colors.white.withOpacity(0.15),
                              size: 54,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              _selectedTab == 'favorites'
                                  ? 'No favorite contacts yet.\nTap the star icon on any contact to add!'
                                  : 'No matching contacts found',
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.white38, fontSize: 13),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        itemCount: filtered.length,
                        itemBuilder: (context, index) {
                          final c = filtered[index];
                          final isFav = _favoriteIds.contains(c.id);

                          return InkWell(
                            onTap: () => _showContactDetailSheet(c),
                            borderRadius: BorderRadius.circular(18),
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF201E27).withOpacity(0.8),
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(
                                  color: isFav ? const Color(0xFFF59E0B).withOpacity(0.3) : Colors.white.withOpacity(0.08),
                                ),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 42,
                                    height: 42,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: isFav
                                            ? [const Color(0xFFF59E0B).withOpacity(0.4), const Color(0xFFD97706).withOpacity(0.3)]
                                            : [const Color(0xFF10B981).withOpacity(0.35), Colors.indigo.withOpacity(0.25)],
                                      ),
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(color: Colors.white12),
                                    ),
                                    child: Center(
                                      child: Text(
                                        c.initials,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          c.name,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        if (c.number.isNotEmpty)
                                          Text(
                                            c.number,
                                            style: const TextStyle(
                                              color: Colors.white54,
                                              fontSize: 12,
                                              fontFamily: 'monospace',
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      isFav ? Icons.star : Icons.star_border,
                                      color: isFav ? const Color(0xFFF59E0B) : Colors.white30,
                                      size: 20,
                                    ),
                                    onPressed: () => _toggleFavorite(c.id),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.call, color: Color(0xFF10B981), size: 20),
                                    onPressed: () {
                                      HapticFeedback.heavyImpact();
                                      widget.onCallNumber(c.number);
                                    },
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabChip(String tabKey, String label) {
    final isSelected = _selectedTab == tabKey;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _selectedTab = tabKey);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? const Color(0xFF10B981) : Colors.white12,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? Colors.black : Colors.white70,
          ),
        ),
      ),
    );
  }
}
