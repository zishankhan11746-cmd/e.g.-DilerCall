import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/contact.dart';
import '../widgets/settings_dialog.dart';

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> with SingleTickerProviderStateMixin {
  String _digits = '';
  String? _glowOriginDigit;
  late final AnimationController _glowController;
  late final Animation<double> _keyScale;
  late final AnimationController _actionController;
  late final Animation<double> _actionScale;
  late final Animation<double> _actionGlow;
  int _selectedSim = 1;
  bool _hapticsEnabled = true;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _actionController = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
    _actionScale = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.88).chain(CurveTween(curve: Curves.easeOutCubic)), weight: 24),
      TweenSequenceItem(tween: Tween(begin: 0.88, end: 1.0).chain(CurveTween(curve: Curves.elasticOut)), weight: 76),
    ]).animate(_actionController);
    _actionGlow = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0).chain(CurveTween(curve: Curves.easeOut)), weight: 22),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0).chain(CurveTween(curve: Curves.easeOut)), weight: 78),
    ]).animate(_actionController);
    _keyScale = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.86).chain(CurveTween(curve: Curves.easeOutCubic)), weight: 22),
      TweenSequenceItem(tween: Tween(begin: 0.86, end: 1.0).chain(CurveTween(curve: Curves.elasticOut)), weight: 78),
    ]).animate(_glowController);
    _loadHapticsPreference();
  }

  Future<void> _loadHapticsPreference() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _hapticsEnabled = prefs.getBool('stackdialer_haptics_enabled') ?? true);
  }

  final List<Map<String, String>> _speedDialFavorites = [
    {'label': 'Mom ❤️', 'number': '+91 98201 45892', 'color': '0xFFEC4899'},
    {'label': 'Sanib A.', 'number': '+91 97654 21980', 'color': '0xFF3B82F6'},
    {'label': 'Mo Faisal', 'number': '+91 98711 00982', 'color': '0xFF10B981'},
    {'label': 'Shivi 🦋', 'number': '+91 98450 11223', 'color': '0xFF8B5CF6'},
    {'label': '112 SOS', 'number': '112', 'color': '0xFFEF4444'},
  ];

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    if (_hapticsEnabled) HapticFeedback.lightImpact();
    setState(() {
      _digits += digit;
      _glowOriginDigit = digit;
    });
    // A complete 500 ms glow pulse runs even when the finger lifts immediately.
    _glowController.forward(from: 0);
  }

  void _pulseAction() {
    _actionController.forward(from: 0);
  }

  @override
  void dispose() {
    _glowController.dispose();
    _actionController.dispose();
    super.dispose();
  }

  void _onBackspace() {
    if (_hapticsEnabled) HapticFeedback.lightImpact();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    if (_hapticsEnabled) HapticFeedback.mediumImpact();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    return Scaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      body: Container(
        decoration: const BoxDecoration(color: Color(0xFF0C0C0E)),
        child: SafeArea(
          bottom: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              // Match the supplied Realme calculator video: 68dp circular
              // graphite keys, broad horizontal breathing room and a compact
              // vertical rhythm. Scale down proportionally on narrow phones.
              final double keyHeight = math.min(68.0, constraints.maxWidth * 0.189);
              final double keyWidth = keyHeight;
              final double keyGap = math.min(48.0, constraints.maxWidth * 0.1333);
              final double rowSpacing = screenHeight < 600 ? 8.0 : 12.0;
              final double callBtnHeight = screenHeight < 600 ? 58.0 : (screenHeight < 700 ? 68.0 : 76.0);

              return Column(
                children: [
                  // Keep the top area clean like the reference dial pad.
                  const SizedBox(height: 4),

                  // Number display / placeholder, positioned above the large keypad.
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: _digits.isEmpty
                            ? const FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  'Enter number',
                                  style: TextStyle(
                                    fontSize: 44,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.5,
                                    color: Color(0xFFB7BBC3),
                                  ),
                                ),
                              )
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: Text(
                                      _digits,
                                      style: const TextStyle(
                                        fontSize: 36,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 1.5,
                                        color: Color(0xFFF4F5F7),
                                      ),
                                    ),
                                  ),
                                  if (matches.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Text(
                                      '${matches.first.name} • ${matches.first.number}',
                                      style: const TextStyle(color: Color(0xFFB7BBC3), fontSize: 13),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ],
                              ),
                      ),
                    ),
                  ),

                  // 3. Large 3D calculator-style phone keypad.
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildSquircleRow(['1', '2', '3'], keyWidth, keyHeight, keyGap),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['4', '5', '6'], keyWidth, keyHeight, keyGap),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['7', '8', '9'], keyWidth, keyHeight, keyGap),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['*', '0', '#'], keyWidth, keyHeight, keyGap),
                      ],
                    ),
                  ),

                  SizedBox(height: rowSpacing + 2),

                  // Keep the call action prominent below the keypad.
                  SizedBox(height: rowSpacing + 4),
                  Padding(
                    padding: const EdgeInsets.only(left: 24, right: 24, bottom: 8),
                    child: SizedBox(
                      height: callBtnHeight,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          AnimatedBuilder(
                            animation: _actionController,
                            builder: (context, child) => Transform.scale(
                              scale: _actionScale.value,
                              child: InkWell(
                                onTap: () {
                                  if (_digits.isNotEmpty) {
                                    _pulseAction();
                                    if (_hapticsEnabled) HapticFeedback.heavyImpact();
                                    widget.onCallNumber(_digits);
                                  }
                                },
                                customBorder: const CircleBorder(),
                                child: Container(
                                  width: callBtnHeight,
                                  height: callBtnHeight,
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [Color(0xFFB6FF00), Color(0xFF7CFC00), Color(0xFF32CD32)],
                                    ),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0xFFE5FF9A).withOpacity(0.95), width: 2.0),
                                    boxShadow: [
                                      BoxShadow(color: const Color(0xFF7CFC00).withOpacity(0.68), blurRadius: 34, spreadRadius: 5),
                                      BoxShadow(color: const Color(0xFFADFF2F).withOpacity(0.42), blurRadius: 48, spreadRadius: 9),
                                      const BoxShadow(color: Color(0xAA001D0D), blurRadius: 8, offset: Offset(0, 4)),
                                    ],
                                  ),
                                  child: const Center(child: Icon(Icons.call, color: Colors.white, size: 34)),
                                ),
                              ),
                            ),
                          ),
                          if (_digits.isNotEmpty)
                            Align(
                              alignment: Alignment.centerRight,
                              child: GestureDetector(
                                onTap: () { _pulseAction(); _onBackspace(); },
                                onLongPress: () { _pulseAction(); _onClearAll(); },
                                child: AnimatedBuilder(
                                  animation: _actionController,
                                  builder: (context, child) => Transform.scale(
                                    scale: _actionScale.value,
                                    child: Container(
                                  width: 58,
                                  height: 58,
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [Color(0xFF555960), Color(0xFF25282E)],
                                    ),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0x66FFFFFF), width: 1.1),
                                    boxShadow: [
                                      if (_actionGlow.value > 0.015)
                                        BoxShadow(
                                          color: const Color(0xFFFFFFFF).withOpacity(0.95 * _actionGlow.value),
                                          blurRadius: 30 * _actionGlow.value,
                                          spreadRadius: 3.5 * _actionGlow.value,
                                        ),
                                      const BoxShadow(color: Color(0x99000000), blurRadius: 8, offset: Offset(0, 4)),
                                    ],
                                  ),
                                  child: const Icon(Icons.backspace_outlined, color: Color(0xFFFFFFFF), size: 24),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSimPill(int slot, String label) {
    final isSelected = _selectedSim == slot;
    return GestureDetector(
      onTap: () {
        if (_hapticsEnabled) HapticFeedback.selectionClick();
        setState(() => _selectedSim = slot);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981).withOpacity(0.2) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? const Color(0xFF10B981) : Colors.white12,
            width: isSelected ? 1.2 : 0.8,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? const Color(0xFF10B981) : Colors.white70,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildSquircleRow(List<String> keys, double width, double height, double gap) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (int i = 0; i < keys.length; i++) ...[
          if (i > 0) SizedBox(width: gap),
          _buildSquircleButton(keys[i], width, height),
        ],
      ],
    );
  }

  double _keyGridDistance(String key) {
    const positions = <String, Offset>{
      '1': Offset(0, 0), '2': Offset(1, 0), '3': Offset(2, 0),
      '4': Offset(0, 1), '5': Offset(1, 1), '6': Offset(2, 1),
      '7': Offset(0, 2), '8': Offset(1, 2), '9': Offset(2, 2),
      '*': Offset(0, 3), '0': Offset(1, 3), '#': Offset(2, 3),
    };
    final origin = positions[_glowOriginDigit];
    final target = positions[key];
    if (origin == null || target == null) return 99;
    final dx = target.dx - origin.dx;
    final dy = target.dy - origin.dy;
    return math.sqrt(dx * dx + dy * dy);
  }

  double _neighborGlow(String key) {
    // White glass pulse travels from the pressed key into nearby keys
    // and completes its full 500 ms cycle regardless of tap duration.
    final progress = _glowController.value;
    final distance = _keyGridDistance(key);
    if (distance > 1.85 || progress >= 1) return 0;

    final waveRadius = progress * 1.85;
    final ring = (1.0 - (distance - waveRadius).abs() / 1.15).clamp(0.0, 1.0);
    final fade = (1.0 - progress).clamp(0.0, 1.0);
    final originPulse = distance == 0 ? (1.0 - progress * 0.45).clamp(0.0, 1.0) : 0.0;
    return (ring * 0.52 * fade + originPulse * 1.0 * fade).clamp(0.0, 1.0).toDouble();
  }

  Widget _buildSquircleButton(String key, double width, double height) {
    final sub = _t9Map[key] ?? '';
    return AnimatedBuilder(
        animation: _glowController,
        builder: (context, child) {
          final glow = _neighborGlow(key);
          final bool pressed = _glowOriginDigit == key && _glowController.isAnimating;
          return Transform.scale(
            scale: _glowOriginDigit == key ? _keyScale.value : 1.0,
            child: Material(
        color: const Color(0xFF1D1D21),
        shape: const CircleBorder(),
        elevation: pressed ? 0.5 : 2.0 + glow * 2.0,
        shadowColor: Color.lerp(const Color(0x99000000), const Color(0xFFFFFFFF), glow) ?? const Color(0x99000000),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _onDigitPress(key),
          // Disable speed-dial long presses to prevent accidental calls;
          // keep the standard long-press '+' shortcut on the 0 key.
          onLongPress: key == '0' ? () => _onDigitPress('+') : null,
          customBorder: const CircleBorder(),
          // A full-size circular ink ripple spreads from the touch point,
          // matching the soft expanding highlight in the Realme calculator.
          splashColor: const Color(0xFFFFFFFF).withOpacity(0.28),
          highlightColor: const Color(0xFFFFFFFF).withOpacity(0.14),
          splashFactory: InkRipple.splashFactory,
          child: SizedBox(
            width: height,
            height: height,
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Dark graphite raised key with a bright upper rim and
                // deeper lower edge to create the reference 3D cylinder look.
                DecoratedBox(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: pressed
                          ? const [Color(0xFF55565D), Color(0xFF38383F), Color(0xFF1D1D21)]
                          : const [Color(0xFF38383F), Color(0xFF292A30), Color(0xFF1D1D21)],
                      stops: const [0.0, 0.48, 1.0],
                    ),
                    border: Border.all(
                      color: Color.lerp(Colors.white.withOpacity(pressed ? 0.72 : 0.30), const Color(0xFFFFFFFF), glow)!,
                      width: 1.4 + glow * 2.16,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(pressed ? 0.22 : 0.48),
                        blurRadius: pressed ? 2 : 4,
                        offset: Offset(0, pressed ? 1 : 2),
                      ),
                      if (glow > 0.02)
                        BoxShadow(
                          color: const Color(0xFFFFFFFF).withOpacity((glow * 1.0).clamp(0.0, 1.0)),
                          blurRadius: 52 * glow,
                          spreadRadius: 6.0 * glow,
                        ),
                      BoxShadow(
                        color: const Color(0xFFDDE1E8).withOpacity(pressed ? 0.10 : 0.09),
                        blurRadius: 2,
                        offset: const Offset(-1, -1),
                      ),
                    ],
                  ),
                ),
                // Subtle glass sheen on the upper half; it fades rather
                // than turning the entire key into a flat pale gradient.
                IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        center: const Alignment(-0.42, -0.62),
                        radius: 1.05,
                        colors: [
                          Colors.white.withOpacity(pressed ? 0.20 : 0.15),
                          Colors.white.withOpacity(0.035),
                          Colors.transparent,
                        ],
                        stops: const [0.0, 0.42, 1.0],
                      ),
                    ),
                  ),
                ),
                if (glow > 0.015)
                  IgnorePointer(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            const Color(0xFFFFFFFF).withOpacity((glow * 0.86).clamp(0.0, 1.0)),
                            const Color(0xFFF1F4FF).withOpacity((glow * 0.34).clamp(0.0, 1.0)),
                            Colors.transparent,
                          ],
                          stops: const [0.0, 0.58, 1.0],
                        ),
                      ),
                    ),
                  ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      key,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFFF5F6F8),
                        height: 1.0,
                        shadows: const [
                          Shadow(color: Color(0x88000000), blurRadius: 2, offset: Offset(0, 1)),
                          if (glow > 0.02) Shadow(color: Color(0xFFFFFFFF), blurRadius: 18, offset: Offset.zero),
                        ],
                      ),
                    ),
                    if (sub.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(
                        sub,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFFD0D3D9),
                          letterSpacing: 1.7,
                          height: 1.0,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
          );
        },
    );
  }

}
