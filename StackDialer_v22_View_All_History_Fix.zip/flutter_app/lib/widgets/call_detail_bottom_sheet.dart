import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/app_haptics.dart';
import '../models/call_record.dart';
import '../services/blocked_numbers_service.dart';
import '../services/call_data_service.dart';

class CallDetailBottomSheet extends StatefulWidget {
  final CallRecord call;
  final Function(String number) onCallNumber;
  final Function(String id) onDeleteCall;
  final List<CallRecord> allCalls;
  final Future<void> Function(String id, String note, String category)? onSaveMetadata;

  const CallDetailBottomSheet({
    super.key,
    required this.call,
    required this.onCallNumber,
    required this.onDeleteCall,
    this.allCalls = const [],
    this.onSaveMetadata,
  });

  @override
  State<CallDetailBottomSheet> createState() => _CallDetailBottomSheetState();
}

class _CallDetailBottomSheetState extends State<CallDetailBottomSheet> {
  late String _category;
  late TextEditingController _noteController;
  bool _copied = false;
  late TextEditingController _tagsController;
  List<String> _tags = [];
  List<CallRecord> _numberHistory = []; 
  final List<String> _categories = ['Personal', 'Work', 'Finance', 'Family', 'VIP', 'Spam'];

  @override
  void initState() {
    super.initState();
    _category = widget.call.category;
    _noteController = TextEditingController(text: widget.call.note ?? '');
    _tagsController = TextEditingController();
    final normalized = CallDataService.normalizeNumber(widget.call.number);
    _numberHistory = widget.allCalls.where((c) => CallDataService.normalizeNumber(c.number) == normalized).toList()..sort((a,b) => b.timestamp.compareTo(a.timestamp));
    CallDataService.getNumberMetadata(widget.call.number).then((data) {
      if (!mounted) return;
      if (_noteController.text.isEmpty && data['note'] is String) _noteController.text = data['note'] as String;
      _tags = (data['tags'] as List? ?? []).map((e) => e.toString()).toList();
      _tagsController.text = _tags.join(', ');
      setState(() {});
    });
    CallDataService.getCallMetadata(widget.call.id).then((data) {
      if (!mounted) return;
      if (_noteController.text.isEmpty && data['note'] is String) _noteController.text = data['note'] as String;
      if (data['category'] is String && _categories.contains(data['category'])) setState(() => _category = data['category'] as String);
    });
  }

  Future<void> _saveCallDetails() async {
    final note = _noteController.text.trim();
    _tags = _tagsController.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList();
    await CallDataService.saveNumberMetadata(widget.call.number, note: note, tags: _tags);
    await CallDataService.saveCallMetadata(widget.call.id, note: note, category: _category);
    await widget.onSaveMetadata?.call(widget.call.id, note, _category);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Call note and category saved')));
  }

  @override
  void dispose() {
    _noteController.dispose();
    _tagsController.dispose();
    super.dispose();
  }

  void _copyNumber() {
    Clipboard.setData(ClipboardData(text: widget.call.number));
    AppHaptics.lightImpact();
    setState(() => _copied = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  void _openWhatsApp() async {
    final clean = widget.call.number.replaceAll(RegExp(r'[^\d]'), '');
    final uri = Uri.parse('https://wa.me/$clean');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  void _sendSms() async {
    final uri = Uri(scheme: 'sms', path: widget.call.number);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _toggleBlockNumber() async {
    final isBlocked = BlockedNumbersService.isBlocked(widget.call.number);
    if (isBlocked) {
      await BlockedNumbersService.unblockNumber(widget.call.number);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unblocked ${widget.call.number}')),
      );
    } else {
      await BlockedNumbersService.blockNumber(widget.call.number);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Blocked ${widget.call.number} and added to spam list')),
      );
    }
    setState(() {});
  }

  void _showAllCallHistory() {
    final history = List<CallRecord>.from(_numberHistory)
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => DraggableScrollableSheet(
        initialChildSize: .78,
        minChildSize: .45,
        maxChildSize: .94,
        expand: false,
        builder: (context, scrollController) => Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF102C4D), Color(0xFF071629), Color(0xFF050F1E)],
            ),
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            border: Border(top: BorderSide(color: Color(0xFF4B9FE8), width: 1.2)),
          ),
          child: Column(
            children: [
              const SizedBox(height: 11),
              Container(width: 38, height: 4, decoration: BoxDecoration(color: Colors.white38, borderRadius: BorderRadius.circular(4))),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 14, 12),
                child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Complete call history', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text('${history.length} calls • ${widget.call.number}', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12)),
                  ])),
                  IconButton(onPressed: () => Navigator.pop(sheetContext), icon: const Icon(Icons.close_rounded, color: Colors.white70)),
                ]),
              ),
              const Divider(height: 1, color: Color(0x334F83B5)),
              Expanded(
                child: ListView.separated(
                  controller: scrollController,
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                  itemCount: history.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final item = history[index];
                    final missed = item.type == CallType.missed || item.type == CallType.rejected;
                    final color = missed ? const Color(0xFFFF7183) : const Color(0xFF27DDAA);
                    final title = missed ? (item.type == CallType.rejected ? 'Rejected' : 'Missed') : item.type == CallType.outgoing ? 'Outgoing' : 'Incoming';
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFF244D78), Color(0xFF315F91), Color(0xFF244D78)]),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFF79B9F4).withOpacity(.24)),
                      ),
                      child: Row(children: [
                        Icon(item.type == CallType.outgoing ? Icons.call_made_rounded : missed ? Icons.call_missed_rounded : Icons.call_received_rounded, color: color, size: 22),
                        const SizedBox(width: 13),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text('${item.dateLabel} • ${item.timeFormatted} • ${item.durationString}', style: TextStyle(color: Colors.white.withOpacity(.68), fontSize: 11)),
                        ])),
                        Text('SIM ${item.simSlot}', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 10)),
                      ]),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isMissed = widget.call.type == CallType.missed || widget.call.type == CallType.rejected;
    final isBlocked = BlockedNumbersService.isBlocked(widget.call.number);
    const brightBlue = Color(0xFF65B9FF);
    const green = Color(0xFF19D69A);
    final muted = Colors.white.withOpacity(.68);

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF102C4D), Color(0xFF071629), Color(0xFF050F1E)],
        ),
        borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        border: Border(top: BorderSide(color: Color(0xFF4B9FE8), width: 1.2)),
        boxShadow: [BoxShadow(color: Color(0x553B9FEF), blurRadius: 28, spreadRadius: -12)],
      ),
      padding: EdgeInsets.only(
        left: 18,
        right: 18,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 22,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Container(width: 38, height: 4, decoration: BoxDecoration(color: Colors.white38, borderRadius: BorderRadius.circular(3)))),
            const SizedBox(height: 14),
            Row(children: [
              const Text('Call Details', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: .1)),
              const Spacer(),
              InkWell(onTap: () => Navigator.pop(context), borderRadius: BorderRadius.circular(20), child: const Padding(padding: EdgeInsets.all(5), child: Icon(Icons.close_rounded, color: Colors.white70, size: 21))),
            ]),
            const SizedBox(height: 18),
            Row(children: [
              Container(
                width: 54, height: 54,
                decoration: BoxDecoration(shape: BoxShape.circle, gradient: const LinearGradient(colors: [Color(0xFF18D69A), Color(0xFF087B9D)]), boxShadow: [BoxShadow(color: const Color(0xFF24D9B0).withOpacity(.24), blurRadius: 15)], border: Border.all(color: const Color(0xFF8CF5E1), width: 1.2)),
                child: Center(child: Text(widget.call.name.isNotEmpty ? widget.call.name[0].toUpperCase() : '?', style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w700))),
              ),
              const SizedBox(width: 13),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Flexible(child: Text(widget.call.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700))),
                  if (isBlocked) ...[const SizedBox(width: 7), Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3), decoration: BoxDecoration(color: const Color(0x44FF5368), borderRadius: BorderRadius.circular(8)), child: const Text('BLOCKED', style: TextStyle(color: Color(0xFFFF8290), fontSize: 9, fontWeight: FontWeight.bold)))],
                ]),
                const SizedBox(height: 4),
                Text(widget.call.number, style: TextStyle(color: muted, fontSize: 13)),
                const SizedBox(height: 5),
                Row(children: [
                  Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: green.withOpacity(.17), borderRadius: BorderRadius.circular(20)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(isMissed ? Icons.call_missed_rounded : widget.call.type == CallType.outgoing ? Icons.call_made_rounded : Icons.call_received_rounded, color: isMissed ? const Color(0xFFFF6578) : green, size: 12), const SizedBox(width: 4), Text(isMissed ? 'Missed' : widget.call.type == CallType.outgoing ? 'Outgoing' : 'Incoming', style: TextStyle(color: isMissed ? const Color(0xFFFF8290) : green, fontSize: 10, fontWeight: FontWeight.w700))]),),
                  const SizedBox(width: 7),
                  Text('${widget.call.dateLabel} • ${widget.call.timeFormatted}', style: TextStyle(color: Colors.white.withOpacity(.52), fontSize: 10)),
                  const SizedBox(width: 5),
                  GestureDetector(onTap: _copyNumber, child: Icon(_copied ? Icons.check_circle : Icons.copy_rounded, size: 13, color: _copied ? green : brightBlue)),
                ]),
              ])),
            ]),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF3979B7), Color(0xFF234D7B), Color(0xFF17385E)]),
                borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFF8BCBFF).withOpacity(.48)),
                boxShadow: [BoxShadow(color: const Color(0xFF4AA8FF).withOpacity(.14), blurRadius: 16, offset: const Offset(0, 5))],
              ),
              child: GridView.count(
                crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 3.2, mainAxisSpacing: 13, crossAxisSpacing: 10,
                children: [
                  _buildInfoItem('CALL TYPE', isMissed ? 'Missed' : widget.call.type == CallType.outgoing ? 'Outgoing' : 'Incoming', isMissed ? const Color(0xFFFFA0A8) : const Color(0xFF8FFFD6)),
                  _buildInfoItem('SIM', 'SIM ${widget.call.simSlot} • ${widget.call.simCarrier}', Colors.white),
                  _buildInfoItem('DURATION', widget.call.durationString, Colors.white),
                  _buildInfoItem('DATE & TIME', '${widget.call.timestamp.day.toString().padLeft(2, '0')}/${widget.call.timestamp.month.toString().padLeft(2, '0')} • ${widget.call.timeFormatted}', Colors.white),
                ],
              ),
            ),
            if (_numberHistory.isNotEmpty) ...[
              const SizedBox(height: 17),
              Row(children: [Text('Complete call history • ${_numberHistory.length}', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)), const Spacer(), Material(color: Colors.transparent, child: InkWell(onTap: _showAllCallHistory, borderRadius: BorderRadius.circular(8), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5), child: Row(mainAxisSize: MainAxisSize.min, children: [Text('View All', style: TextStyle(color: brightBlue.withOpacity(.98), fontSize: 11, fontWeight: FontWeight.w700)), const SizedBox(width: 2), Icon(Icons.chevron_right_rounded, color: brightBlue, size: 16)]))))]),
              const SizedBox(height: 8),
              ..._numberHistory.take(5).map((item) {
                final missed = item.type == CallType.missed || item.type == CallType.rejected;
                final color = missed ? const Color(0xFFFF6578) : const Color(0xFF27DDAA);
                return Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [Color(0xFF244D78), Color(0xFF315F91), Color(0xFF244D78)],
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFF79B9F4).withOpacity(.24)),
                    boxShadow: [BoxShadow(color: const Color(0xFF2D75B8).withOpacity(.10), blurRadius: 10, offset: const Offset(0, 3))],
                  ),
                  child: Row(children: [
                    Icon(item.type == CallType.outgoing ? Icons.call_made_rounded : missed ? Icons.call_missed_rounded : Icons.call_received_rounded, color: color, size: 21),
                    const SizedBox(width: 13),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(item.type.name[0].toUpperCase() + item.type.name.substring(1), style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 3),
                      Text('${item.dateLabel} • ${item.timeFormatted} • ${item.durationString}', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 11)),
                    ])),
                    const Icon(Icons.chevron_right_rounded, color: Color(0xFFB5C8DE), size: 23),
                  ]),
                );
              }),
            ],
            if (widget.call.repeatCount > 1 && widget.call.groupedSubCalls != null) ...[
              const SizedBox(height: 9),
              Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0x22FF6477), borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0x66FF6477))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [const Icon(Icons.call_missed_rounded, color: Color(0xFFFF8794), size: 15), const SizedBox(width: 6), Text(' ${widget.call.repeatCount} Missed Calls', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold))]),
                const SizedBox(height: 7),
                ...widget.call.groupedSubCalls!.map((subCall) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(subCall.dateLabel, style: const TextStyle(color: Colors.white70, fontSize: 11)), Text(subCall.timeFormatted, style: const TextStyle(color: Colors.white70, fontSize: 11))]))),
              ])),
            ],
            const SizedBox(height: 18),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              _buildRoundAction(Icons.call_rounded, 'Call', const Color(0xFF18D69A), () { Navigator.pop(context); widget.onCallNumber(widget.call.number); }),
              _buildRoundAction(Icons.sms_rounded, 'Message', const Color(0xFF36A9FF), _sendSms),
              _buildRoundAction(isBlocked ? Icons.check_rounded : Icons.block_rounded, isBlocked ? 'Unblock' : 'Block', const Color(0xFFFF5268), _toggleBlockNumber),
              _buildRoundAction(Icons.more_horiz_rounded, 'More', const Color(0xFF7898BD), () => showModalBottomSheet<void>(context: context, backgroundColor: const Color(0xFF102844), shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))), builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [ListTile(leading: const Icon(Icons.chat, color: Color(0xFF25D366)), title: const Text('Open WhatsApp', style: TextStyle(color: Colors.white)), onTap: () { Navigator.pop(ctx); _openWhatsApp(); }), ListTile(leading: const Icon(Icons.delete_outline, color: Color(0xFFFF6578)), title: const Text('Delete call record', style: TextStyle(color: Colors.white)), onTap: () { Navigator.pop(ctx); Navigator.pop(context); widget.onDeleteCall(widget.call.id); })])))),
            ]),
            const SizedBox(height: 19),
            const Text('Category', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Wrap(spacing: 7, runSpacing: 7, children: _categories.map((cat) {
              final selected = _category == cat;
              return GestureDetector(onTap: () => setState(() => _category = cat), child: AnimatedContainer(duration: const Duration(milliseconds: 160), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), decoration: BoxDecoration(gradient: selected ? const LinearGradient(colors: [Color(0xFF4C9FE0), Color(0xFF347BB9)]) : const LinearGradient(colors: [Color(0xFF203B5B), Color(0xFF192F49)]), borderRadius: BorderRadius.circular(22), border: Border.all(color: selected ? const Color(0xFF9BD5FF) : const Color(0xFF6685A8).withOpacity(.24))), child: Text(cat, style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: selected ? FontWeight.w700 : FontWeight.w500))));
            }).toList()),
            const SizedBox(height: 17),
            const Text('Call Note', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
            const SizedBox(height: 7),
            TextField(controller: _noteController, minLines: 2, maxLines: 3, style: const TextStyle(color: Colors.white, fontSize: 14), decoration: InputDecoration(hintText: 'Add a note for this call...', hintStyle: const TextStyle(color: Colors.white54, fontSize: 11), filled: true, fillColor: const Color(0xFF1B3A5B), border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: const Color(0xFF75BFFF).withOpacity(.18))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFF6BB8FF))), contentPadding: const EdgeInsets.all(13))),
            const SizedBox(height: 12),
            const Text('Tags (comma separated)', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
            const SizedBox(height: 7),
            TextField(controller: _tagsController, style: const TextStyle(color: Colors.white, fontSize: 12), decoration: InputDecoration(hintText: 'VIP, Work, Follow-up', hintStyle: const TextStyle(color: Colors.white54, fontSize: 11), filled: true, fillColor: const Color(0xFF1B3A5B), border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: const Color(0xFF75BFFF).withOpacity(.18))), contentPadding: const EdgeInsets.all(13))),
            if (_tags.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 7), child: Wrap(spacing: 6, runSpacing: 5, children: _tags.map((tag) => Chip(label: Text(tag, style: const TextStyle(fontSize: 10, color: Colors.white)), visualDensity: VisualDensity.compact, backgroundColor: const Color(0xFF244C75), side: BorderSide.none)).toList())),
            const SizedBox(height: 13),
            SizedBox(width: double.infinity, child: DecoratedBox(decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFD5ECFF), Color(0xFF8CCAFF)]), borderRadius: BorderRadius.circular(17), boxShadow: [BoxShadow(color: const Color(0xFF70BFFF).withOpacity(.22), blurRadius: 13, offset: const Offset(0, 4))]), child: TextButton.icon(onPressed: _saveCallDetails, icon: const Icon(Icons.bookmark_border_rounded, color: Color(0xFF102D4D), size: 18), label: const Text('Save Note, Tags & Category', style: TextStyle(color: Color(0xFF102D4D), fontWeight: FontWeight.w800, fontSize: 13)), style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 13), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)))))),
          ],
        ),
      ),
    );
  }

  Widget _buildRoundAction(IconData icon, String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(32),
      child: SizedBox(width: 72, child: Column(children: [
        Container(
          width: 54, height: 54,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color.withOpacity(.95), color.withOpacity(.55)]),
            border: Border.all(color: color.withOpacity(.95), width: 1.4),
            boxShadow: [BoxShadow(color: color.withOpacity(.22), blurRadius: 15, offset: const Offset(0, 4))],
          ),
          child: Icon(icon, color: Colors.white, size: 23),
        ),
        const SizedBox(height: 7),
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
      ])),
    );
  }

  Widget _buildInfoItem(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.42), fontSize: 9, letterSpacing: 0.55, fontWeight: FontWeight.w700)),
        const SizedBox(height: 3),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
      ],
    );
  }
}
