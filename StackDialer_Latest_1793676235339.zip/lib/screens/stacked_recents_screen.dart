import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/call_record.dart';
import '../services/telecom_service.dart';
import '../widgets/call_detail_bottom_sheet.dart';
import '../widgets/settings_dialog.dart';

class StackStyleConfig {
  final String id;
  final int number;
  final String name;
  final String hindiName;
  final String badge;
  final Color badgeBg;
  final Color badgeTextColor;
  final String description;
  final List<Color> highlightGradient;

  const StackStyleConfig({
    required this.id,
    required this.number,
    required this.name,
    required this.hindiName,
    required this.badge,
    required this.badgeBg,
    required this.badgeTextColor,
    required this.description,
    required this.highlightGradient,
  });
}

const List<StackStyleConfig> STACK_STYLES = [
  StackStyleConfig(
    id: 'ios-depth',
    number: 1,
    name: 'iOS Depth Stack',
    hindiName: 'क्लासिक iOS शेड',
    badge: 'iOS 18',
    badgeBg: Color(0x330284C7),
    badgeTextColor: Color(0xFF7DD3FC),
    description: 'Apple notification shade with 3D lip rollup and gentle scale compression.',
    highlightGradient: [Color(0xFF38BDF8), Color(0xFF3B82F6)],
  ),
  StackStyleConfig(
    id: 'coverflow-3d',
    number: 2,
    name: '3D Coverflow Deck',
    hindiName: 'कवरफ्लो 3D टिल्ट',
    badge: 'macOS 3D',
    badgeBg: Color(0x333B82F6),
    badgeTextColor: Color(0xFF93C5FD),
    description: 'Perspective 3D tilt with metallic edge reflection and depth perspective.',
    highlightGradient: [Color(0xFF60A5FA), Color(0xFF6366F1)],
  ),
  StackStyleConfig(
    id: 'cascade-waterfall',
    number: 3,
    name: 'Cascade Waterfall',
    hindiName: 'झरना कैस्केड वेव',
    badge: 'Fluid Wave',
    badgeBg: Color(0x3314B8A6),
    badgeTextColor: Color(0xFF5EEAD4),
    description: 'Fluid staggered waterfall with alternating wave offsets (translateX glide).',
    highlightGradient: [Color(0xFF2DD4BF), Color(0xFF10B981)],
  ),
  StackStyleConfig(
    id: 'cyberpunk-neon',
    number: 4,
    name: 'Cyberpunk Neon',
    hindiName: 'साइबरपंक नियॉन',
    badge: 'Cyber Neon',
    badgeBg: Color(0x33D946EF),
    badgeTextColor: Color(0xFFF0ABFC),
    description: 'Sci-fi stack with horizontal tilt, cyan & magenta edge glows.',
    highlightGradient: [Color(0xFF22D3EE), Color(0xFFE879F9)],
  ),
  StackStyleConfig(
    id: 'origami-fold',
    number: 5,
    name: 'Origami 3D Fold',
    hindiName: 'ओरिगेमी फोल्ड',
    badge: 'Papercraft',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFCD34D),
    description: 'Geometric papercraft folding motion as cards stack at top and bottom.',
    highlightGradient: [Color(0xFFFBBF24), Color(0xFFF97316)],
  ),
  StackStyleConfig(
    id: 'tinder-arc',
    number: 6,
    name: 'Tinder Arc Fan',
    hindiName: 'कार्ड्स फैन आर्क',
    badge: 'Cards Fan',
    badgeBg: Color(0x33F43F5E),
    badgeTextColor: Color(0xFFFDA4AF),
    description: 'Radial deck fanning like a hand of playing cards with smooth rotateZ arc curves.',
    highlightGradient: [Color(0xFFFB7185), Color(0xFFEF4444)],
  ),
  StackStyleConfig(
    id: 'accordion-spring',
    number: 7,
    name: 'Accordion Spring',
    hindiName: 'एलास्टिक स्प्रिंग बाउंस',
    badge: 'Elastic Bounce',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Dynamic elastic compression physics with playful spring recoil.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF22C55E)],
  ),
  StackStyleConfig(
    id: 'dynamic-island',
    number: 8,
    name: 'Dynamic Island',
    hindiName: 'डायनामिक कैप्सूल',
    badge: 'Apple Pill',
    badgeBg: Color(0x338B5CF6),
    badgeTextColor: Color(0xFFC4B5FD),
    description: 'Morphing rounded capsule pill stack with status ring beacons.',
    highlightGradient: [Color(0xFFA78BFA), Color(0xFF8B5CF6)],
  ),
  StackStyleConfig(
    id: 'visionos-glass',
    number: 9,
    name: 'VisionOS Frosted',
    hindiName: 'विज़नओएस ग्लास',
    badge: 'Spatial Glass',
    badgeBg: Color(0x336366F1),
    badgeTextColor: Color(0xFFA5B4FC),
    description: 'Spatial translucent frosted glass with iridescent rim highlights.',
    highlightGradient: [Color(0xFF818CF8), Color(0xFF38BDF8)],
  ),
  StackStyleConfig(
    id: 'charcoal-executive',
    number: 10,
    name: 'Charcoal Executive',
    hindiName: 'प्रीमियम चारकोल स्टैक',
    badge: 'Pro Executive',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Deep luxury matte obsidian charcoal with specular highlights and precision bevels.',
    highlightGradient: [Color(0xFF10B981), Color(0xFF059669)],
  ),
  StackStyleConfig(
    id: 'notification-stack-deck',
    number: 11,
    name: 'Notification Stack Deck',
    hindiName: 'iOS नोटिफिकेशन स्टैक',
    badge: 'Frosted Deck',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Wide overlapping notification cards with 0.96 scale lips, 12px stack spacing, frosted-glass surface and spring-like motion.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'android-notification-flow',
    number: 12,
    name: 'Notification Flow',
    hindiName: 'स्मूद नोटिफिकेशन फ्लो',
    badge: 'Android Shade',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Android notification shade style: separated cards near the top, gradually forming a smooth overlapping deck at the bottom.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'realme-flux-engine',
    number: 13,
    name: 'Realme Flux Engine',
    hindiName: 'रियलमी फ्लक्स इंजन 7.0',
    badge: 'Flux 7.0',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFBBF24),
    description: 'Realme UI 7.0 Flux Engine: 78dp rigid cards with dynamic progressFactor, 6% bottom-center scale compression, and 0.82 vertical stack displacement.',
    highlightGradient: [Color(0xFFF59E0B), Color(0xFFEF4444)],
  ),
];

class StackedRecentsScreen extends StatefulWidget {
  final List<CallRecord> calls;
  final VoidCallback onRefresh;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const StackedRecentsScreen({
    super.key,
    required this.calls,
    required this.onRefresh,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<StackedRecentsScreen> createState() => _StackedRecentsScreenState();
}

class _StackedRecentsScreenState extends State<StackedRecentsScreen>
    with SingleTickerProviderStateMixin {
  late Ticker _ticker;
  double _scrollPos = 0.0;
  double _targetScroll = 0.0;
  double _velocity = 0.0;
  bool _isDragging = false;
  double _lastDragY = 0.0;
  DateTime _lastDragTime = DateTime.now();
  double _viewportHeight = 600.0;
  Duration _lastTickElapsed = Duration.zero;

  static const String _stylePreferenceKey = 'stackdialer_selected_card_style_index';
  int _currentStyleIndex = 0;
  bool _stylePreferenceLoaded = false;
  double _scrollSpeedMultiplier = 1.5;
  String _bottomStackStyle = 'three_layer';
  String _ios18ThemeVariant = 'purple_glow';
  bool _isStackCollapsed = false;
  String _searchQuery = '';
  String _selectedFilter = 'all'; // 'all', 'missed', 'incoming', 'outgoing'
  List<CallRecord> _cachedFilteredCalls = [];

  Color _getIOS18ThemeAccentColor() {
    switch (_ios18ThemeVariant) {
      case 'gold_luxury':
        return const Color(0xFFFBBF24);
      case 'sky_premium':
        return const Color(0xFF38BDF8);
      case 'green_nature':
        return const Color(0xFF34D399);
      case 'sunset_dream':
        return const Color(0xFFFB923C);
      case 'purple_glow':
      default:
        return const Color(0xFFC084FC);
    }
  }

  String _getIOS18ThemeName() {
    switch (_ios18ThemeVariant) {
      case 'gold_luxury':
        return 'Gold Luxury';
      case 'sky_premium':
        return 'Sky Premium';
      case 'green_nature':
        return 'Green Nature';
      case 'sunset_dream':
        return 'Sunset Dream';
      case 'purple_glow':
      default:
        return 'Purple Glow';
    }
  }

  void _updateFilteredCalls() {
    _cachedFilteredCalls = widget.calls.where((call) {
      if (_selectedFilter == 'missed') {
        if (call.type != CallType.missed && call.type != CallType.rejected) return false;
      } else if (_selectedFilter == 'incoming') {
        if (call.type != CallType.incoming) return false;
      } else if (_selectedFilter == 'outgoing') {
        if (call.type != CallType.outgoing) return false;
      }

      if (_searchQuery.trim().isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        return call.name.toLowerCase().contains(q) ||
            call.number.contains(q);
      }
      return true;
    }).toList();
  }

  // Card physics constants
  static const double cardHeight = 90.0;
  static const double cardGap = 8.0;
  static const double cardStep = cardHeight + cardGap; // 98.0 for styles 1-10
  static const double notificationCardHeight = 176.0;
  static const double notificationCardStep = 152.0; // Style 11: overlapping notification deck
  static const double notificationFlowCardHeight = 78.0;
  static const double notificationFlowCardStep = 98.0; // Style 12: slim cards with visible overlap as they gather into the deck
  static const double fluxCardHeight = 78.0; // Style 13: Realme UI 7.0 exact 78dp rigid card height
  static const double fluxCardStep = 92.0; // Style 13: 78dp card with 14dp gap in free viewport
  static const double headerOffset = 10.0;

  double get _activeCardStep {
    if (_currentStyleIndex == 10) return notificationCardStep;
    if (_currentStyleIndex == 11) return notificationFlowCardStep;
    if (_currentStyleIndex == 12) return fluxCardStep;
    return cardStep;
  }
  double get _activeCardHeight {
    if (_currentStyleIndex == 10) return notificationCardHeight;
    if (_currentStyleIndex == 11) return notificationFlowCardHeight;
    if (_currentStyleIndex == 12) return fluxCardHeight;
    return cardHeight;
  }

  @override
  void initState() {
    super.initState();
    _updateFilteredCalls();
    _ticker = createTicker(_onTick);
    _ticker.start();
    _loadSavedStyle();
    _loadStackMotionPreferences();
  }

  @override
  void didUpdateWidget(covariant StackedRecentsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    _updateFilteredCalls();
    if (widget.calls.length != oldWidget.calls.length ||
        (widget.calls.isNotEmpty && oldWidget.calls.isNotEmpty && widget.calls.first.id != oldWidget.calls.first.id)) {
      _scrollPos = 0.0;
      _targetScroll = 0.0;
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    if (!mounted) return;

    final filtered = _cachedFilteredCalls;
    final double maxScroll = math.max(
      0.0,
      headerOffset + filtered.length * _activeCardStep - _viewportHeight + _activeCardHeight,
    ).toDouble();
    if (_lastTickElapsed == Duration.zero) {
      _lastTickElapsed = elapsed;
      return;
    }
    // Use elapsed frame time so animation speed is consistent on 60/90/120 Hz screens.
    final frameMs = (elapsed - _lastTickElapsed).inMicroseconds / 1000.0;
    _lastTickElapsed = elapsed;
    final dt = frameMs.clamp(0.0, 40.0);
    if (dt <= 0) return;
    final frameFactor = dt / 16.6667;

    bool changed = false;

    // 1. Time-based kinetic momentum decay (independent of refresh rate).
    if (!_isDragging && _velocity.abs() > 0.08) {
      _targetScroll += _velocity * frameFactor;
      // High-precision silky friction for fluid inertial glide across all 13 styles
      const double friction = 0.942;
      _velocity *= math.pow(friction, frameFactor).toDouble();
      if (_targetScroll < 0) {
        _targetScroll = 0;
        _velocity = 0;
      } else if (_targetScroll > maxScroll) {
        _targetScroll = maxScroll;
        _velocity = 0;
      }
      changed = true;
    } else if (!_isDragging) {
      _velocity = 0;
    }

    // 2. High-performance finger tracking & frame-rate-independent settling across all 13 styles
    final diff = _targetScroll - _scrollPos;
    if (_isDragging) {
      // Instant direct finger tracking during drag eliminates any visible touch latency on 60/90/120Hz screens
      if (diff.abs() > 0.001) {
        _scrollPos = _targetScroll;
        changed = true;
      }
    } else if (diff.abs() > 0.05) {
      // Ultra-smooth 24ms critical damping response for silky glide settling
      const double responseMs = 24.0;
      final interpolation = 1.0 - math.exp(-dt / responseMs);
      _scrollPos += diff * interpolation;
      changed = true;
    } else if (_scrollPos != _targetScroll) {
      _scrollPos = _targetScroll;
      changed = true;
    }

    if (changed) {
      setState(() {});
    }
  }

  List<CallRecord> _getFilteredCalls() {
    return widget.calls.where((call) {
      if (_selectedFilter == 'missed') {
        if (call.type != CallType.missed && call.type != CallType.rejected) return false;
      } else if (_selectedFilter == 'incoming') {
        if (call.type != CallType.incoming) return false;
      } else if (_selectedFilter == 'outgoing') {
        if (call.type != CallType.outgoing) return false;
      }

      if (_searchQuery.trim().isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        return call.name.toLowerCase().contains(q) ||
            call.number.contains(q);
      }
      return true;
    }).toList();
  }

  Future<void> _loadStackMotionPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _scrollSpeedMultiplier = (prefs.getDouble('stack12_scroll_speed') ?? 1.5).clamp(0.5, 3.0).toDouble();
      _bottomStackStyle = prefs.getString('stack12_bottom_style') ?? 'three_layer';
      _ios18ThemeVariant = prefs.getString('ios18_theme_variant') ?? 'purple_glow';
    });
  }

  Future<void> _loadSavedStyle() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedIndex = prefs.getInt(_stylePreferenceKey) ?? 0;
      final savedTheme = prefs.getString('ios18_theme_variant') ?? 'purple_glow';
      if (!mounted) return;
      setState(() {
        _currentStyleIndex = savedIndex >= 0 && savedIndex < STACK_STYLES.length
            ? savedIndex
            : 0;
        _ios18ThemeVariant = savedTheme;
        // Prevent a stale animation/scroll offset from placing every Style 12
        // card outside the viewport when restoring the saved style on launch.
        _scrollPos = 0.0;
        _targetScroll = 0.0;
        _velocity = 0.0;
        _isDragging = false;
        _stylePreferenceLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _stylePreferenceLoaded = true);
    }
  }

  Future<void> _saveSelectedStyle(int index) async {
    final safeIndex = index >= 0 && index < STACK_STYLES.length ? index : 0;
    // Update the UI immediately; persist the selection across app restarts.
    if (mounted) {
      setState(() {
        _currentStyleIndex = safeIndex;
        // Each style can use a different card step/height. Reset the previous
        // style's scroll offset so Style 12 never opens with every card off-screen.
        _scrollPos = 0.0;
        _targetScroll = 0.0;
        _velocity = 0.0;
        _isDragging = false;
      });
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_stylePreferenceKey, safeIndex);
    } catch (_) {
      // Keep the in-memory selection even if device storage is temporarily unavailable.
    }
  }

  void _cycleNextStyle() {
    HapticFeedback.lightImpact();
    _saveSelectedStyle((_currentStyleIndex + 1) % STACK_STYLES.length);
  }

  void _restoreDefaultStyle() {
    HapticFeedback.mediumImpact();
    _saveSelectedStyle(0);
  }

  void _toggleStackCollapsed() {
    HapticFeedback.lightImpact();
    setState(() {
      _isStackCollapsed = !_isStackCollapsed;
    });
  }

  // Exact 3D math engine matching web preview
  Map<String, dynamic> _computeCardTransforms({
    required String styleId,
    required int index,
    required double naturalY,
    required double topBoundary,
    required double bottomBoundary,
    required double step,
  }) {
    double yPos = 0;
    double xPos = 0;
    double scale = 1.0;
    double rotateX = 0;
    double rotateY = 0;
    double rotateZ = 0;
    double skewX = 0;
    double opacity = 1.0;
    bool isStacked = false;
    Alignment transformOrigin = Alignment.center;
    int zIndex = 200 - index * 4;

    if (_isStackCollapsed && (styleId == 'android-notification-flow' || styleId == 'realme-flux-engine')) {
      const double deckBaseY = 16.0;
      final int stackIndex = math.min(index, 6);
      isStacked = true;
      zIndex = 200 - index * 4;
      yPos = deckBaseY + stackIndex * 14.0;
      scale = (math.max(1.0 - stackIndex * 0.024, 0.88)).toDouble();
      rotateX = (math.min(stackIndex * 2.0, 7.0)).toDouble();
      opacity = (index > 6 ? 0.35 : math.max(1.0 - stackIndex * 0.11, 0.40)).toDouble();
      transformOrigin = Alignment.bottomCenter;
    } else {
      if (naturalY >= topBoundary && naturalY <= bottomBoundary) {
        // NATURAL IN-VIEW POSITION: 100% fully visible, crisp and responsive
        yPos = naturalY;
        isStacked = false;
        scale = 1.0;
        opacity = 1.0;
        rotateX = 0;
        rotateY = 0;
        rotateZ = 0;
        skewX = 0;
        transformOrigin = Alignment.center;
      } else if (naturalY < topBoundary) {
        // TOP STACK BUNCHING
        isStacked = true;
        final double topOverflow = topBoundary - naturalY;
        final double stackFactor = math.min(topOverflow / step, 3.5).toDouble();
        yPos = (topBoundary - math.pow(stackFactor, 0.7) * 12.0).toDouble();
        scale = (math.max(1.0 - stackFactor * 0.02, 0.94)).toDouble();
        rotateX = (-math.min(stackFactor * 1.5, 4.5)).toDouble();
        // Safe top opacity floor - NEVER black or invisible
        opacity = (math.max(1.0 - stackFactor * 0.18, 0.35)).toDouble();

        if (styleId == 'realme-flux-engine') {
          // Realme UI 7.0 "Flux Engine" Top Overlapping Stack Logic:
          // Fixed item height: exactly 78dp
          const double totalItemHeight = fluxCardHeight; // 78.0dp
          // Rigid progressFactor dynamically calculated: (-itemTopPosition / totalItemHeight).clamp(0.0, 1.0)
          final double progressFactor = (topOverflow / totalItemHeight).clamp(0.0, 1.0);

          // Overlapping Y Displacement: Intercept linear displacement vector and offset it dynamically
          // by (progressFactor * totalItemHeight * 0.82) to tightly compress subsequent cards directly underneath active foreground card
          final double linearDisplacement = -topOverflow; // = naturalY - topBoundary
          final double overlappingOffset = progressFactor * totalItemHeight * 0.82;
          yPos = (topBoundary + linearDisplacement + overlappingOffset).toDouble();

          // Smooth background stack tuck as scrolling goes deeper:
          if (topOverflow > totalItemHeight) {
            final double deepOverflow = topOverflow - totalItemHeight;
            final double stackProgress = math.min(deepOverflow / totalItemHeight, 4.0);
            yPos = (topBoundary - (totalItemHeight * 0.18) - stackProgress * 8.0).toDouble();
          }

          // Scale Transform Matrix: Compress top-sliding overlapping cards by exactly 6%
          // (down to 0.94 scale factor) using bottom-center alignment vector:
          scale = (1.0 - progressFactor * 0.06).toDouble();
          transformOrigin = Alignment.bottomCenter;

          // Alpha Translucency Level: Apply smooth opacity degradation layer where cards
          // compressing into background stack drop alpha/opacity by up to 45% (down to 0.55 opacity threshold):
          opacity = (1.0 - progressFactor * 0.45).toDouble();

          // Performance Optimizer: Viewport boundary clause to prune cards scrolled completely away
          if (topOverflow > totalItemHeight * 5.0) {
            opacity = 0.0;
          }
        } else if (styleId == 'notification-stack-deck') {
          yPos = (topBoundary - math.min(stackFactor, 5.0) * 12.0).toDouble();
          scale = math.pow(0.96, math.min(stackFactor, 5.0)).toDouble();
          rotateX = (-math.min(stackFactor * 0.8, 2.5)).toDouble();
          opacity = math.max(1.0 - stackFactor * 0.07, 0.68).toDouble();
        } else if (styleId == 'android-notification-flow') {
          final double deckProgress = math.min(topOverflow / math.max(step, 1.0), 4.0).toDouble();
          yPos = (topBoundary - deckProgress * 8.0).toDouble();
          scale = math.max(1.0 - deckProgress * 0.025, 0.92).toDouble();
          rotateX = -math.min(deckProgress * 1.2, 4.0).toDouble();
          opacity = math.max(1.0 - deckProgress * 0.12, 0.40).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'coverflow-3d') {
          rotateX = (-math.min(stackFactor * 2.2, 5.5)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'origami-fold') {
          rotateX = (-math.min(stackFactor * 2.5, 6.0)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.022, 0.93)).toDouble();
        } else if (styleId == 'tinder-arc') {
          rotateZ = (((index % 5) - 2) * math.min(stackFactor * 1.5, 4.5)).toDouble();
          xPos = (((index % 5) - 2) * math.min(stackFactor * 2.0, 7.5)).toDouble();
        } else if (styleId == 'cascade-waterfall') {
          xPos = ((index % 2 == 0 ? -10.0 : 10.0) * math.min(stackFactor, 1.8)).toDouble();
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = ((index % 2 == 0 ? 3.0 : -3.0) * math.min(stackFactor, 1.6)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.022, 0.93)).toDouble();
        } else if (styleId == 'accordion-spring') {
          yPos = (topBoundary - math.sin(math.min(stackFactor, 3.0) * 1.2) * 12.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'dynamic-island') {
          scale = (math.max(1.0 - stackFactor * 0.03, 0.90)).toDouble();
          yPos = (topBoundary - math.pow(stackFactor, 0.75) * 12.0).toDouble();
        } else if (styleId == 'visionos-glass') {
          opacity = (math.max(1.0 - stackFactor * 0.20, 0.35)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.02, 0.95)).toDouble();
        } else if (styleId == 'charcoal-executive') {
          yPos = (topBoundary - math.pow(stackFactor, 0.75) * 10.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.02, 0.94)).toDouble();
        }
      } else if (naturalY > bottomBoundary) {
        // BOTTOM STACK OVERLAP: cards gather into smooth 3D layered deck
        isStacked = true;
        final double bottomOverflow = naturalY - bottomBoundary;
        final double stackFactor = bottomOverflow / step;
        yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        scale = (math.max(1.0 - math.min(stackFactor, 4.0) * 0.025, 0.90)).toDouble();
        rotateX = (math.min(stackFactor * 1.5, 4.5)).toDouble();
        // Safe bottom opacity: NEVER 0.0!
        opacity = (math.max(1.0 - stackFactor * 0.08, 0.50)).toDouble();

        if (styleId == 'realme-flux-engine') {
          // Realme UI 7.0 "Flux Engine" Bottom Notification Stack:
          // Continuous elastic unstacking & docking animation exactly matching the Realme UI 7.0 update video
          final double progress = (bottomOverflow / step).clamp(0.0, 5.0);

          // 1. Fluid asymptotic docking displacement: cards nest into the bottom deck with 12-14px lip tiers
          // Using continuous exponential deceleration (zero discrete step cuts)
          final double dockOffset = (1.0 - math.exp(-progress * 0.75)) * 26.0;
          yPos = (bottomBoundary + dockOffset).toDouble();

          // 2. Continuous scale compression: scales smoothly from 1.0 (active emerging) down to 0.92 (stacked deep)
          // When swiped up, the card expands smoothly out of the bottom stack!
          scale = (1.0 - (1.0 - math.exp(-progress * 0.70)) * 0.08).clamp(0.88, 1.0).toDouble();

          // 3. Smooth alpha degradation: top 2 stacked cards remain crisp & clear with frosted look
          opacity = (1.0 - progress * 0.10).clamp(0.45, 1.0).toDouble();

          // Bottom-center vector so the card expands outwards and upwards when peeling out of the stack
          transformOrigin = Alignment.bottomCenter;
        } else if (styleId == 'notification-stack-deck') {
          yPos = (bottomBoundary + math.min(stackFactor, 5.0) * 12.0).toDouble();
          scale = math.pow(0.96, math.min(stackFactor, 5.0)).toDouble();
          rotateX = math.min(stackFactor * 0.8, 2.5).toDouble();
          opacity = math.max(1.0 - stackFactor * 0.045, 0.65).toDouble();
        } else if (styleId == 'android-notification-flow') {
          final int layer = math.max(1, stackFactor.ceil());
          final double layerIndex = (layer - 1).toDouble();
          yPos = (bottomBoundary + math.min(layerIndex, 5.0) * 12.0).toDouble();
          scale = (math.max(1.0 - math.min(layerIndex, 5.0) * 0.03, 0.88)).toDouble();
          rotateX = (math.min(layerIndex * 0.6, 2.5)).toDouble();
          opacity = (math.max(1.0 - layerIndex * 0.09, 0.40)).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'coverflow-3d') {
          rotateX = (math.min(stackFactor * 2.0, 5.0)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'cascade-waterfall') {
          xPos = ((index % 2 == 0 ? -8.0 : 8.0) * math.min(stackFactor, 1.8)).toDouble();
        } else if (styleId == 'origami-fold') {
          rotateX = (math.min(stackFactor * 2.2, 5.5)).toDouble();
        } else if (styleId == 'tinder-arc') {
          rotateZ = (((index % 5) - 2) * math.min(stackFactor * 1.2, 3.5)).toDouble();
          xPos = (((index % 5) - 2) * math.min(stackFactor * 1.8, 6.0)).toDouble();
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = ((index % 2 == 0 ? -2.5 : 2.5) * math.min(stackFactor, 1.4)).toDouble();
        } else if (styleId == 'accordion-spring') {
          yPos = (bottomBoundary + math.sin(math.min(stackFactor, 3.0) * 1.0) * 16.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'dynamic-island') {
          scale = (math.max(1.0 - stackFactor * 0.03, 0.90)).toDouble();
        } else if (styleId == 'visionos-glass') {
          opacity = (math.max(1.0 - stackFactor * 0.08, 0.60)).toDouble();
        } else if (styleId == 'charcoal-executive') {
          yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        }
      }
    }

    return {
      'yPos': yPos,
      'xPos': xPos,
      'scale': scale,
      'rotateX': rotateX,
      'rotateY': rotateY,
      'rotateZ': rotateZ,
      'skewX': skewX,
      'opacity': opacity.clamp(0.0, 1.0),
      'isStacked': isStacked,
      'zIndex': zIndex,
      'transformOrigin': transformOrigin,
    };
  }

  void _showStyleSelectorSheet() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141219),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Sheet Grab handle
              Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.style, color: Color(0xFF10B981), size: 18),
                      ),
                      const SizedBox(width: 10),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Card Stack Animation Styles',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '13 Distinct Card Motion Styles',
                            style: TextStyle(color: Colors.white38, fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  TextButton.icon(
                    onPressed: () {
                      _restoreDefaultStyle();
                      Navigator.pop(ctx);
                    },
                    icon: const Icon(Icons.refresh, size: 14, color: Colors.blueAccent),
                    label: const Text('Reset', style: TextStyle(color: Colors.blueAccent, fontSize: 12)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView.builder(
                  itemCount: STACK_STYLES.length,
                  itemBuilder: (context, idx) {
                    final style = STACK_STYLES[idx];
                    final isSelected = idx == _currentStyleIndex;
                    return InkWell(
                      onTap: () {
                        HapticFeedback.selectionClick();
                        _saveSelectedStyle(idx);
                        Navigator.pop(ctx);
                      },
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFF10B981).withOpacity(0.12)
                              : const Color(0xFF1F1D27).withOpacity(0.8),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF10B981).withOpacity(0.6)
                                : Colors.white.withOpacity(0.08),
                            width: isSelected ? 1.5 : 1.0,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: isSelected ? const Color(0xFF10B981) : Colors.white10,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Text(
                                  style.number.toString().padLeft(2, '0'),
                                  style: TextStyle(
                                    color: isSelected ? Colors.white : Colors.white70,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        style.name,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '(${style.hindiName})',
                                        style: const TextStyle(color: Colors.white38, fontSize: 11),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    style.description,
                                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: style.badgeBg,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                style.badge,
                                style: TextStyle(
                                  color: style.badgeTextColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  BoxDecoration _getCardBoxDecoration(String styleId, bool isMissed) {
    if (isMissed) {
      if (styleId == 'visionos-glass') {
        return BoxDecoration(
          color: Colors.redAccent.withOpacity(0.18),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.redAccent.withOpacity(0.55), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.redAccent.withOpacity(0.2),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        );
      } else if (styleId == 'cyberpunk-neon') {
        return BoxDecoration(
          color: const Color(0xFF281120).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.pinkAccent.withOpacity(0.8), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.pinkAccent.withOpacity(0.35),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        );
      } else if (styleId == 'realme-flux-engine') {
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFA2C1E26),
              const Color(0xFA1F151B),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: const Color(0xFFF43F5E).withOpacity(0.35),
            width: 0.9,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.40),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: const Color(0xFFF43F5E).withOpacity(0.12),
              blurRadius: 12,
              offset: const Offset(0, 2),
            ),
          ],
        );
      }
      return BoxDecoration(
        color: const Color(0xFF2B161E).withOpacity(0.96),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFEF4444).withOpacity(0.2),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      );
    }

    switch (styleId) {
      case 'realme-flux-engine':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFA28272F),
              const Color(0xFA1F1E26),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: Colors.white.withOpacity(0.10),
            width: 0.8,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.04),
              blurRadius: 1,
              offset: const Offset(0, -1),
            ),
          ],
        );
      case 'android-notification-flow':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF25232F).withOpacity(0.96),
              const Color(0xFF1D1B24).withOpacity(0.96),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFF34D399).withOpacity(0.40),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.12),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.55),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'notification-stack-deck':
        return BoxDecoration(
          color: const Color(0xE61B1B20), // dark 90% frosted-glass base
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(0.16), width: 1.1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.42),
              blurRadius: 22,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: const Color(0xFF34D399).withOpacity(0.07),
              blurRadius: 18,
              spreadRadius: -3,
            ),
          ],
        );
      case 'coverflow-3d':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF1E283C).withOpacity(0.95),
              const Color(0xFF141C2B).withOpacity(0.95),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF60A5FA).withOpacity(0.45), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF3B82F6).withOpacity(0.2),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'cyberpunk-neon':
        return BoxDecoration(
          color: const Color(0xFF141724).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF22D3EE).withOpacity(0.7), width: 1.3),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF22D3EE).withOpacity(0.25),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'cascade-waterfall':
        return BoxDecoration(
          color: const Color(0xFF132626).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF2DD4BF).withOpacity(0.45), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF14B8A6).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'origami-fold':
        return BoxDecoration(
          color: const Color(0xFF262016).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFBBF24).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF59E0B).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'tinder-arc':
        return BoxDecoration(
          color: const Color(0xFF2A1522).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFB7185).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF43F5E).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'accordion-spring':
        return BoxDecoration(
          color: const Color(0xFF13281E).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF34D399).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'dynamic-island':
        return BoxDecoration(
          color: const Color(0xFF141120).withOpacity(0.96),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: const Color(0xFFA78BFA).withOpacity(0.55), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF8B5CF6).withOpacity(0.25),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'visionos-glass':
        return BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.1),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'charcoal-executive':
        return BoxDecoration(
          color: const Color(0xFF1E1E26).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF10B981).withOpacity(0.35), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'ios-depth':
      default:
        if (styleId == 'ios-depth') {
          switch (_ios18ThemeVariant) {
            case 'gold_luxury':
              return BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF191612), Color(0xFF100E0A)],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.55), width: 1.1),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFD97706).withOpacity(0.32),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.55),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              );
            case 'sky_premium':
              return BoxDecoration(
                color: Colors.white.withOpacity(0.88),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.95), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF1E3A8A).withOpacity(0.18),
                    blurRadius: 16,
                    offset: const Offset(0, 5),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              );
            case 'green_nature':
              return BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0C2014), Color(0xFF06140B)],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF10B981).withOpacity(0.6), width: 1.1),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF10B981).withOpacity(0.32),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.55),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              );
            case 'sunset_dream':
              return BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF26121D), Color(0xFF180A12)],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFFB923C).withOpacity(0.6), width: 1.1),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFEA580C).withOpacity(0.32),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.55),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              );
            case 'purple_glow':
            default:
              return BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF16122C), Color(0xFF0F0B1E)],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF8B5CF6).withOpacity(0.55), width: 1.1),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF8B5CF6).withOpacity(0.32),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.55),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              );
          }
        }
        return BoxDecoration(
          color: const Color(0xFF22202C).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
    }
  }

  String _formatTimeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays == 1) return 'Yesterday';
    return '${dt.day}/${dt.month}';
  }

  Widget _buildCardContent(CallRecord call, bool isMissed) {
    final currentStyle = STACK_STYLES[_currentStyleIndex];
    final bool isStyle1 = currentStyle.id == 'ios-depth';
    final bool isSky = isStyle1 && _ios18ThemeVariant == 'sky_premium';
    final bool isGold = isStyle1 && _ios18ThemeVariant == 'gold_luxury';
    final bool isGreen = isStyle1 && _ios18ThemeVariant == 'green_nature';
    final bool isSunset = isStyle1 && _ios18ThemeVariant == 'sunset_dream';

    IconData typeIcon;
    Color typeColor;
    if (isMissed) {
      typeIcon = Icons.call_missed;
      typeColor = isSky ? const Color(0xFFEF4444) : Colors.redAccent;
    } else if (call.type == CallType.outgoing) {
      typeIcon = Icons.call_made;
      typeColor = isSky ? const Color(0xFF0284C7) : Colors.lightBlueAccent;
    } else {
      typeIcon = Icons.call_received;
      typeColor = const Color(0xFF10B981);
    }

    final durationText = call.duration > 0
        ? '${(call.duration ~/ 60)}m ${(call.duration % 60)}s'
        : '0s';

    final Color nameTextColor = isSky
        ? (isMissed ? const Color(0xFFDC2626) : const Color(0xFF0F172A))
        : (isMissed ? const Color(0xFFFF8B8B) : Colors.white);

    final Color simBadgeBg = isSky ? const Color(0xFFE2E8F0) : Colors.white.withOpacity(0.08);
    final Color simBadgeText = isSky ? const Color(0xFF475569) : Colors.white60;
    final Color timeTextColor = isSky ? const Color(0xFF64748B) : Colors.white38;
    final Color numberTextColor = isSky ? const Color(0xFF334155) : Colors.white60;
    final Color durationTextColor = isSky ? const Color(0xFF64748B) : Colors.white38;
    final Color copyIconColor = isSky ? const Color(0xFF64748B) : Colors.white38;

    return Row(
      children: [
        // Avatar
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isStyle1
                  ? (isSky
                      ? const [Color(0xFF38BDF8), Color(0xFF1D4ED8)]
                      : isGold
                          ? const [Color(0xFF382A1B), Color(0xFF1E170F)]
                          : isGreen
                              ? const [Color(0xFF103A22), Color(0xFF081F12)]
                              : isSunset
                                  ? const [Color(0xFF42162C), const Color(0xFF260C19)]
                                  : const [Color(0xFF2A1C54), const Color(0xFF170E32)])
                  : (isMissed
                      ? [Colors.redAccent.withOpacity(0.35), Colors.purpleAccent.withOpacity(0.2)]
                      : [const Color(0xFF10B981).withOpacity(0.35), Colors.blueAccent.withOpacity(0.2)]),
            ),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(
              color: isStyle1
                  ? (isSky
                      ? Colors.white.withOpacity(0.6)
                      : isGold
                          ? const Color(0xFFF59E0B).withOpacity(0.4)
                          : isGreen
                              ? const Color(0xFF10B981).withOpacity(0.4)
                              : isSunset
                                  ? const Color(0xFFFB923C).withOpacity(0.4)
                                  : const Color(0xFF8B5CF6).withOpacity(0.4))
                  : (isMissed ? Colors.redAccent.withOpacity(0.3) : Colors.white12),
            ),
          ),
          child: Center(
            child: Text(
              call.name.isNotEmpty ? call.name[0].toUpperCase() : '?',
              style: TextStyle(
                color: isStyle1
                    ? (isSky
                        ? Colors.white
                        : isGold
                            ? const Color(0xFFFDE68A)
                            : isGreen
                                ? const Color(0xFF6EE7B7)
                                : isSunset
                                    ? const Color(0xFFFDBA74)
                                    : const Color(0xFFD8B4FE))
                    : (isMissed ? Colors.redAccent : Colors.white),
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        // Name, Number & Info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      call.name,
                      style: TextStyle(
                        color: nameTextColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                    decoration: BoxDecoration(
                      color: simBadgeBg,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                      'SIM ${call.simSlot}',
                      style: TextStyle(color: simBadgeText, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _formatTimeAgo(call.timestamp),
                    style: TextStyle(
                      color: timeTextColor,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 4),
                  if (DateTime.now().difference(call.timestamp).inMinutes < 5) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: const Color(0xFF10B981), width: 0.8),
                      ),
                      child: const Text(
                        'LIVE',
                        style: TextStyle(
                          color: Color(0xFF10B981),
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 3),
              Row(
                children: [
                  Icon(typeIcon, color: typeColor, size: 12),
                  const SizedBox(width: 4),
                  Text(
                    call.number,
                    style: TextStyle(color: numberTextColor, fontSize: 11, fontFamily: 'monospace'),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '• $durationText',
                    style: TextStyle(color: durationTextColor, fontSize: 10),
                  ),
                ],
              ),
            ],
          ),
        ),
        // Action Buttons: Copy & Direct Call CTA
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(Icons.copy, color: copyIconColor, size: 16),
              tooltip: 'Copy Number',
              onPressed: () {
                Clipboard.setData(ClipboardData(text: call.number));
                HapticFeedback.lightImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Copied ${call.number} to clipboard'),
                    duration: const Duration(seconds: 1),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
            InkWell(
              onTap: () {
                HapticFeedback.heavyImpact();
                widget.onCallNumber(call.number);
              },
              borderRadius: BorderRadius.circular(14),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isGold
                        ? const [Color(0xFFF59E0B), Color(0xFFD97706)]
                        : const [Color(0xFF10B981), Color(0xFF059669)],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: (isGold ? const Color(0xFFF59E0B) : const Color(0xFF10B981)).withOpacity(0.4),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Center(
                  child: Icon(Icons.call, color: Colors.white, size: 20),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _cachedFilteredCalls;
    final currentStyle = STACK_STYLES[_currentStyleIndex];
    final bool isStyle1 = currentStyle.id == 'ios-depth';

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // Background: iOS 18 dynamic wallpaper if Style 1, default dark gradient otherwise
          Positioned.fill(
            child: isStyle1
                ? IOS18WallpaperBackground(variant: _ios18ThemeVariant)
                : Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFF1B1822),
                          Color(0xFF141219),
                          Color(0xFF0D0C11),
                        ],
                      ),
                    ),
                  ),
          ),
          SafeArea(
            bottom: false,
            child: Column(
              children: [
                // 1. Top Executive Control Strip
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  decoration: BoxDecoration(
                    color: isStyle1
                        ? (_ios18ThemeVariant == 'sky_premium'
                            ? const Color(0xFF1E40AF).withOpacity(0.85)
                            : const Color(0xFF0D0B14).withOpacity(0.78))
                        : const Color(0xFF141417).withOpacity(0.95),
                    border: const Border(
                      bottom: BorderSide(color: Colors.white10, width: 0.5),
                    ),
                  ),
                  child: Column(
                    children: [
                      // Row 1: Title, 11 Styles Dropdown, Cycle, Reset, Stack Toggle
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Title with pulse beacon
                          Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: const BoxDecoration(
                                  color: Color(0xFF10B981),
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                'Recent Calls',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                '(${filtered.length})',
                                style: const TextStyle(
                                  color: Colors.white38,
                                  fontSize: 12,
                                  fontFamily: 'monospace',
                                ),
                              ),
                              if (isStyle1) ...[
                                const SizedBox(width: 8),
                                InkWell(
                                  onTap: () {
                                    showDialog(
                                      context: context,
                                      builder: (ctx) => DialerSettingsDialog(
                                        onSimulateIncoming: widget.onSimulateIncoming,
                                      ),
                                    ).then((_) => _loadStackMotionPreferences());
                                  },
                                  borderRadius: BorderRadius.circular(8),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: _getIOS18ThemeAccentColor().withOpacity(0.2),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: _getIOS18ThemeAccentColor().withOpacity(0.55), width: 0.8),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.palette, color: _getIOS18ThemeAccentColor(), size: 10),
                                        const SizedBox(width: 3),
                                        Text(
                                          _getIOS18ThemeName(),
                                          style: TextStyle(
                                            color: _getIOS18ThemeAccentColor(),
                                            fontSize: 9.5,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                          // Right Controls: 11 Styles Picker + Cycle Next + Restore + Stack Toggle
                          Row(
                            children: [
                              // 10 STYLES PICKER CHIP
                              InkWell(
                                onTap: _showStyleSelectorSheet,
                                borderRadius: BorderRadius.circular(12),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.06),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: Colors.white12),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.auto_awesome, color: Color(0xFF10B981), size: 12),
                                      const SizedBox(width: 4),
                                      Text(
                                        '${currentStyle.number}. ${currentStyle.name.split(' ')[0]}',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFF10B981).withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Text(
                                          '${STACK_STYLES.length}',
                                          style: const TextStyle(
                                            color: Color(0xFF10B981),
                                            fontSize: 9,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 2),
                                      const Icon(Icons.arrow_drop_down, color: Colors.white54, size: 14),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(width: 4),
                              // Cycle next style button
                              IconButton(
                                icon: const Icon(Icons.shuffle, size: 16, color: Colors.white60),
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                                tooltip: 'Cycle Next Style (1-13)',
                                onPressed: _cycleNextStyle,
                              ),
                              // Restore default style button
                              IconButton(
                                icon: const Icon(Icons.restore, size: 16, color: Colors.lightBlueAccent),
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                                tooltip: 'Restore Style 1 (iOS Depth)',
                                onPressed: _restoreDefaultStyle,
                              ),
                              // Stack Deck vs Fan Out toggle for notification deck styles (12 & 13)
                              if (_currentStyleIndex == 11 || _currentStyleIndex == 12) InkWell(
                                onTap: _toggleStackCollapsed,
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: _isStackCollapsed
                                        ? Colors.amber.withOpacity(0.25)
                                        : Colors.white.withOpacity(0.06),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: _isStackCollapsed ? Colors.amber : Colors.white12,
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.layers,
                                        size: 13,
                                        color: _isStackCollapsed ? Colors.amber : Colors.white70,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        _isStackCollapsed ? 'Fan Out' : 'Stack',
                                        style: TextStyle(
                                          color: _isStackCollapsed ? Colors.amber : Colors.white70,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(width: 4),
                              // Live Device Call Log Refresh button
                              IconButton(
                                icon: const Icon(Icons.refresh, size: 16, color: Color(0xFF10B981)),
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 26, minHeight: 26),
                                tooltip: 'Sync Live Call Logs from Phone',
                                onPressed: () {
                                  HapticFeedback.lightImpact();
                                  setState(() {
                                    _scrollPos = 0.0;
                                    _targetScroll = 0.0;
                                  });
                                  widget.onRefresh();
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('⚡ Syncing live call logs from phone...'),
                                      duration: Duration(seconds: 1),
                                      behavior: SnackBarBehavior.floating,
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(width: 2),
                              // Settings Button
                              IconButton(
                                icon: const Icon(Icons.settings_outlined, size: 16, color: Colors.white70),
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 26, minHeight: 26),
                                tooltip: 'Dialer Settings',
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    builder: (ctx) => DialerSettingsDialog(
                                      onSimulateIncoming: widget.onSimulateIncoming,
                                    ),
                                  ).then((_) => _loadStackMotionPreferences());
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 5),

                      // Slim unified pill for call filters
                      Container(
                        height: 34,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: isStyle1
                              ? (_ios18ThemeVariant == 'sky_premium'
                                  ? Colors.white.withOpacity(0.2)
                                  : const Color(0xFF1B1728).withOpacity(0.8))
                              : const Color(0xFF242428),
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(
                            color: isStyle1
                                ? (_ios18ThemeVariant == 'sky_premium'
                                    ? Colors.white.withOpacity(0.3)
                                    : _getIOS18ThemeAccentColor().withOpacity(0.25))
                                : Colors.white.withOpacity(0.055),
                          ),
                        ),
                        child: Row(
                          children: [
                            Expanded(child: _buildFilterPill('all', 'All')),
                            Expanded(child: _buildFilterPill('missed', 'Missed')),
                            Expanded(child: _buildFilterPill('incoming', 'In')),
                            Expanded(child: _buildFilterPill('outgoing', 'Out')),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

              // 2. 3D Kinetic Card Stack Stage Viewport
              Expanded(
                child: filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.phone_missed, color: Colors.white.withOpacity(0.15), size: 54),
                            const SizedBox(height: 12),
                            const Text(
                              'No recent calls found',
                              style: TextStyle(color: Colors.white54, fontSize: 14),
                            ),
                          ],
                        ),
                      )
                    : LayoutBuilder(
                        builder: (context, constraints) {
                          final double containerHeight = constraints.maxHeight;
                          _viewportHeight = containerHeight;
                          final double topStackBoundary = headerOffset;
                          final double bottomStackBoundary = containerHeight - 140.0;
                          final double maxScroll = math.max(
                            0.0,
                            headerOffset + filtered.length * _activeCardStep - containerHeight + _activeCardHeight,
                          ).toDouble();
                          // Defensive clamp: if the call count, filter, or card style
                          // changes, don't retain an offset beyond the new scroll range.
                          _scrollPos = _scrollPos.clamp(0.0, maxScroll).toDouble();
                          _targetScroll = _targetScroll.clamp(0.0, maxScroll).toDouble();

                          return GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onVerticalDragStart: (details) {
                              _isDragging = true;
                              _velocity = 0;
                            },
                            onVerticalDragUpdate: (details) {
                              // Flutter native primary delta - immune to child layout rebuilds or localPosition coordinate shifts!
                              final deltaY = -details.delta.dy;
                              if (deltaY.isNaN || deltaY.isInfinite) return;
                              // The adjustable motion control is exclusive to Style 12.
                              // Preserve the previous drag feel for every other card style.
                              final double activeSpeed = _currentStyleIndex == 11 ? _scrollSpeedMultiplier : 1.5;
                              _velocity = (deltaY * 1.12 * activeSpeed).clamp(-60.0, 60.0).toDouble();
                              final double dragGain = activeSpeed;
                              _targetScroll = (_targetScroll + deltaY * dragGain).clamp(0.0, maxScroll).toDouble();
                              // Let the ticker's frame-based interpolation follow the finger;
                              // avoid assigning _scrollPos directly, which causes visible micro-jumps.
                              setState(() {});
                            },
                            onVerticalDragEnd: (details) {
                              _isDragging = false;
                              final pv = details.primaryVelocity;
                              if (pv != null && pv.abs() > 40) {
                                final double activeSpeed = _currentStyleIndex == 11 ? _scrollSpeedMultiplier : 1.5;
                                final double flingDivisor = 52.0 / activeSpeed;
                                final double maxFling = 25.0 * activeSpeed;
                                _velocity = (-pv / flingDivisor).clamp(-maxFling, maxFling).toDouble();
                              } else {
                                _velocity = _velocity.clamp(-16.0, 16.0).toDouble();
                              }
                            },
                            child: SizedBox(
                              width: constraints.maxWidth,
                              height: containerHeight,
                              child: ClipRect(
                                child: Stack(
                                  fit: StackFit.expand,
                                  clipBehavior: Clip.none,
                                  children: [
                                    const SizedBox.expand(),
                                    for (int i = filtered.length - 1; i >= 0; i--)
                                      _buildCardWidget(
                                        index: i,
                                        call: filtered[i],
                                        currentStyle: currentStyle,
                                        topBoundary: topStackBoundary,
                                        bottomBoundary: bottomStackBoundary,
                                        step: _activeCardStep,
                                        containerWidth: constraints.maxWidth,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

  Widget _buildCardWidget({
    required int index,
    required CallRecord call,
    required StackStyleConfig currentStyle,
    required double topBoundary,
    required double bottomBoundary,
    required double step,
    required double containerWidth,
  }) {
    final double naturalY = headerOffset + index * step - _scrollPos;

    // Viewport Boundary Clause (Performance Optimizer):
    // Prune items that have scrolled completely out of view.
    // In the 'All' tab (20-30 cards), this keeps only ~5-7 active widgets in memory and rendering,
    // achieving identical buttery-smooth ("makkhan") 120fps performance as the 'Missed' tab!
    if (naturalY < topBoundary - step * 3.2 || naturalY > bottomBoundary + step * 3.2) {
      return const SizedBox.shrink();
    }

    final transforms = _computeCardTransforms(
      styleId: currentStyle.id,
      index: index,
      naturalY: naturalY,
      topBoundary: topBoundary,
      bottomBoundary: bottomBoundary,
      step: step,
    );

    double yPos = transforms['yPos'];
    final double xPos = transforms['xPos'];
    double scale = transforms['scale'];
    final double rotateX = transforms['rotateX'];
    final double rotateY = transforms['rotateY'];
    final double rotateZ = transforms['rotateZ'];
    double opacity = transforms['opacity'];
    final Alignment origin = transforms['transformOrigin'];
    final bool isMissed = call.type == CallType.missed || call.type == CallType.rejected;
    final bool fluxEngineStyle = currentStyle.id == 'realme-flux-engine';
    final bool notificationFlowStyle = currentStyle.id == 'android-notification-flow';
    final bool notificationStackStyle = currentStyle.id == 'notification-stack-deck';

    // Universal visibility guard: cards in visible area MUST be 100% visible
    if (!yPos.isFinite) yPos = naturalY;
    if (!scale.isFinite || scale < 0.6) scale = 1.0;
    if (!opacity.isFinite || opacity < 0.20) opacity = 0.25;
    if (naturalY >= topBoundary && naturalY <= bottomBoundary) {
      yPos = naturalY;
      opacity = 1.0;
      scale = 1.0;
    }

    // Safe, harmonious 3D matrix strictly centered on card
    final matrix3D = Matrix4.identity()
      ..setEntry(3, 2, 0.0008) // gentle, safe perspective depth
      ..rotateX(rotateX * math.pi / 180.0)
      ..rotateY(rotateY * math.pi / 180.0)
      ..rotateZ(rotateZ * math.pi / 180.0)
      ..scale(scale, scale, 1.0);

    return Positioned(
      top: yPos,
      left: (notificationStackStyle ? 20.0 : (notificationFlowStyle || fluxEngineStyle) ? 12.0 : 14.0) + xPos,
      right: (notificationStackStyle ? 20.0 : (notificationFlowStyle || fluxEngineStyle) ? 12.0 : 14.0) - xPos,
      child: Transform(
        transform: matrix3D,
        alignment: origin,
        child: Opacity(
          opacity: opacity.clamp(0.0, 1.0),
          child: Dismissible(
            key: ValueKey('swipe_call_${call.id}_$index'),
            direction: DismissDirection.horizontal,
            // Right Swipe background: Green with Call icon
            background: Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(notificationStackStyle ? 26 : (notificationFlowStyle || fluxEngineStyle) ? 20 : 20),
                gradient: const LinearGradient(
                  colors: [Color(0xFF00C853), Color(0xFF00E676)],
                ),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.call_rounded, color: Colors.white, size: 24),
                  SizedBox(width: 8),
                  Text('Call', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                ],
              ),
            ),
            // Left Swipe secondaryBackground: Blue with Message icon
            secondaryBackground: Container(
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(notificationStackStyle ? 26 : (notificationFlowStyle || fluxEngineStyle) ? 20 : 20),
                gradient: const LinearGradient(
                  colors: [Color(0xFF0284C7), Color(0xFF38BDF8)],
                ),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Message', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                  SizedBox(width: 8),
                  Icon(Icons.message_rounded, color: Colors.white, size: 24),
                ],
              ),
            ),
            confirmDismiss: (direction) async {
              if (direction == DismissDirection.startToEnd) {
                // Right Swipe: Instant Call
                HapticFeedback.mediumImpact();
                widget.onCallNumber(call.number);
              } else if (direction == DismissDirection.endToStart) {
                // Left Swipe: Quick Message
                HapticFeedback.lightImpact();
                _showQuickMessageSheet(call);
              }
              // Return false so card snaps back smoothly without removing from list
              return false;
            },
            child: GestureDetector(
              onTap: () {
                if (_isStackCollapsed) {
                  _toggleStackCollapsed();
                } else {
                  HapticFeedback.lightImpact();
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (ctx) => CallDetailBottomSheet(
                      call: call,
                      onCallNumber: widget.onCallNumber,
                      onDeleteCall: (id) {
                        setState(() {
                          widget.calls.removeWhere((c) => c.id == id);
                        });
                      },
                    ),
                  );
                }
              },
              child: ClipRRect(
                borderRadius: BorderRadius.circular(notificationStackStyle ? 26 : (notificationFlowStyle || fluxEngineStyle) ? 20 : 20),
                child: Container(
                  height: notificationStackStyle
                      ? notificationCardHeight
                      : (notificationFlowStyle
                          ? notificationFlowCardHeight
                          : (fluxEngineStyle ? fluxCardHeight : cardHeight)),
                  padding: EdgeInsets.symmetric(
                    horizontal: (notificationFlowStyle || fluxEngineStyle) ? 12 : 14,
                    vertical: (notificationFlowStyle || fluxEngineStyle) ? 9 : 12,
                  ),
                  decoration: _getCardBoxDecoration(currentStyle.id, isMissed),
                  child: _buildCardContent(call, isMissed),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showQuickMessageSheet(CallRecord call) {
    final textController = TextEditingController();
    final quickMessages = [
      "Can't talk right now. What's up?",
      "I'll call you right back.",
      "I'm on my way.",
      "Please text me instead.",
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) {
        return Container(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 16,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          decoration: const BoxDecoration(
            color: Color(0xFF1B1B22),
            borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
            border: Border(top: BorderSide(color: Colors.white24, width: 1)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 38,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0284C7).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.message_rounded, color: Color(0xFF38BDF8), size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Quick Message to ${call.name.isNotEmpty ? call.name : call.number}',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          call.number,
                          style: const TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text('QUICK REPLIES', style: TextStyle(color: Colors.white38, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: quickMessages.map((msg) {
                  return ActionChip(
                    backgroundColor: const Color(0xFF262630),
                    side: const BorderSide(color: Colors.white12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    label: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 12)),
                    onPressed: () async {
                      Navigator.pop(ctx);
                      final uri = Uri(scheme: 'sms', path: call.number, queryParameters: {'body': msg});
                      if (await canLaunchUrl(uri)) {
                        await launchUrl(uri);
                      }
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: textController,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Type custom message...',
                        hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                        filled: true,
                        fillColor: const Color(0xFF262630),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: const BorderSide(color: Colors.white12),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: const BorderSide(color: Colors.white12),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: const BorderSide(color: Color(0xFF38BDF8)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    style: IconButton.styleFrom(
                      backgroundColor: const Color(0xFF0284C7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                    onPressed: () async {
                      final customText = textController.text.trim();
                      if (customText.isNotEmpty) {
                        Navigator.pop(ctx);
                        final uri = Uri(scheme: 'sms', path: call.number, queryParameters: {'body': customText});
                        if (await canLaunchUrl(uri)) {
                          await launchUrl(uri);
                        }
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFilterPill(String key, String label) {
    final currentStyle = STACK_STYLES[_currentStyleIndex];
    final bool isStyle1 = currentStyle.id == 'ios-depth';
    final isSelected = _selectedFilter == key;

    Color activeColor = const Color(0xFF414145);
    Color activeTextColor = Colors.white;
    Color unselectedTextColor = Colors.white60;

    if (isStyle1) {
      switch (_ios18ThemeVariant) {
        case 'gold_luxury':
          activeColor = const Color(0xFFD97706);
          activeTextColor = Colors.white;
          unselectedTextColor = Colors.white70;
          break;
        case 'sky_premium':
          activeColor = const Color(0xFF38BDF8);
          activeTextColor = const Color(0xFF0F172A);
          unselectedTextColor = Colors.white.withOpacity(0.9);
          break;
        case 'green_nature':
          activeColor = const Color(0xFF10B981);
          activeTextColor = Colors.white;
          unselectedTextColor = Colors.white70;
          break;
        case 'sunset_dream':
          activeColor = const Color(0xFFFB923C);
          activeTextColor = const Color(0xFF280B1C);
          unselectedTextColor = Colors.white70;
          break;
        case 'purple_glow':
        default:
          activeColor = const Color(0xFF7C3AED);
          activeTextColor = Colors.white;
          unselectedTextColor = Colors.white70;
          break;
      }
    }

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() {
          _selectedFilter = key;
          _targetScroll = 0.0;
          _scrollPos = 0.0;
          _updateFilteredCalls();
        });
      },
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? activeColor : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: isSelected ? activeTextColor : unselectedTextColor,
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

class IOS18WallpaperBackground extends StatelessWidget {
  final String variant;

  const IOS18WallpaperBackground({super.key, required this.variant});

  @override
  Widget build(BuildContext context) {
    switch (variant) {
      case 'gold_luxury':
        return Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF080706),
                Color(0xFF0D0B09),
                Color(0xFF15100B),
              ],
            ),
          ),
          child: CustomPaint(
            size: Size.infinite,
            painter: _GoldLuxuryWallpaperPainter(),
          ),
        );
      case 'sky_premium':
        return Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0.0, 0.25, 0.55, 0.85, 1.0],
              colors: [
                Color(0xFF1D4ED8),
                Color(0xFF0284C7),
                Color(0xFF38BDF8),
                Color(0xFFBAE6FD),
                Color(0xFFF1F5F9),
              ],
            ),
          ),
          child: CustomPaint(
            size: Size.infinite,
            painter: _SkyPremiumWallpaperPainter(),
          ),
        );
      case 'green_nature':
        return Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF030D06),
                Color(0xFF07190D),
                Color(0xFF0A2614),
              ],
            ),
          ),
          child: CustomPaint(
            size: Size.infinite,
            painter: _GreenNatureWallpaperPainter(),
          ),
        );
      case 'sunset_dream':
        return Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0.0, 0.22, 0.45, 0.68, 0.88, 1.0],
              colors: [
                Color(0xFF280B1C),
                Color(0xFF6B1D2F),
                Color(0xFF9A3412),
                Color(0xFFEA580C),
                Color(0xFFF59E0B),
                Color(0xFFFDE047),
              ],
            ),
          ),
          child: CustomPaint(
            size: Size.infinite,
            painter: _SunsetDreamWallpaperPainter(),
          ),
        );
      case 'purple_glow':
      default:
        return Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF060515),
                Color(0xFF0B0822),
                Color(0xFF130C30),
              ],
            ),
          ),
          child: CustomPaint(
            size: Size.infinite,
            painter: _PurpleGlowWallpaperPainter(),
          ),
        );
    }
  }
}

class _PurpleGlowWallpaperPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // 1. Ambient top-left neon purple aura
    final glowPaint1 = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF7C3AED).withOpacity(0.42),
          const Color(0xFF6D28D9).withOpacity(0.18),
          Colors.transparent,
        ],
        stops: const [0.0, 0.55, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(w * 0.15, h * 0.12), radius: w * 0.65));
    canvas.drawCircle(Offset(w * 0.15, h * 0.12), w * 0.65, glowPaint1);

    // 2. Ambient bottom-right violet aura
    final glowPaint2 = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF8B5CF6).withOpacity(0.32),
          const Color(0xFF4C1D95).withOpacity(0.14),
          Colors.transparent,
        ],
        stops: const [0.0, 0.6, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(w * 0.85, h * 0.78), radius: w * 0.7));
    canvas.drawCircle(Offset(w * 0.85, h * 0.78), w * 0.7, glowPaint2);

    // 3. Flowing silk ribbon across upper third
    final path1 = Path();
    path1.moveTo(-30, h * 0.18);
    path1.cubicTo(w * 0.35, h * 0.28, w * 0.65, h * 0.14, w + 40, h * 0.22);

    final ribbonGlow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6.0
      ..color = const Color(0xFFC084FC).withOpacity(0.55)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawPath(path1, ribbonGlow);

    final ribbonCore = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..color = const Color(0xFFE9D5FF).withOpacity(0.85);
    canvas.drawPath(path1, ribbonCore);

    // 4. Flowing silk ribbon across lower third
    final path2 = Path();
    path2.moveTo(-20, h * 0.85);
    path2.cubicTo(w * 0.45, h * 0.74, w * 0.75, h * 0.88, w + 30, h * 0.80);

    final ribbon2Glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7.0
      ..color = const Color(0xFFA855F7).withOpacity(0.48)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);
    canvas.drawPath(path2, ribbon2Glow);

    final ribbon2Core = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..color = const Color(0xFFDDD6FE).withOpacity(0.8);
    canvas.drawPath(path2, ribbon2Core);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _GoldLuxuryWallpaperPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // 1. Ambient warm golden pool
    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFFF59E0B).withOpacity(0.32),
          const Color(0xFFB45309).withOpacity(0.12),
          Colors.transparent,
        ],
        stops: const [0.0, 0.6, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(w * 0.6, h * 0.82), radius: w * 0.75));
    canvas.drawCircle(Offset(w * 0.6, h * 0.82), w * 0.75, glowPaint);

    // 2. Liquid gold flowing silk ribbon from bottom-left sweeping up
    final path1 = Path();
    path1.moveTo(-40, h * 0.88);
    path1.cubicTo(w * 0.35, h * 0.75, w * 0.65, h * 0.60, w + 40, h * 0.48);

    final goldGlow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8.0
      ..color = const Color(0xFFF59E0B).withOpacity(0.55)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);
    canvas.drawPath(path1, goldGlow);

    final goldCore = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..color = const Color(0xFFFEF08A).withOpacity(0.9);
    canvas.drawPath(path1, goldCore);

    // 3. Secondary subtle liquid gold wave
    final path2 = Path();
    path2.moveTo(-30, h * 0.42);
    path2.cubicTo(w * 0.4, h * 0.48, w * 0.7, h * 0.35, w + 30, h * 0.38);

    final gold2Glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5.0
      ..color = const Color(0xFFD97706).withOpacity(0.4)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    canvas.drawPath(path2, gold2Glow);

    final gold2Core = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = const Color(0xFFFDE68A).withOpacity(0.75);
    canvas.drawPath(path2, gold2Core);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _SkyPremiumWallpaperPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // 1. Ambient soft cyan / sky glow in upper section
    final cyanGlow = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF38BDF8).withOpacity(0.45),
          const Color(0xFF0284C7).withOpacity(0.2),
          Colors.transparent,
        ],
        stops: const [0.0, 0.55, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(w * 0.85, h * 0.22), radius: w * 0.7));
    canvas.drawCircle(Offset(w * 0.85, h * 0.22), w * 0.7, cyanGlow);

    // 2. Soft fluid luminous organic wave across top right
    final fluidPath = Path();
    fluidPath.moveTo(w + 30, -20);
    fluidPath.lineTo(w + 30, h * 0.42);
    fluidPath.cubicTo(w * 0.75, h * 0.38, w * 0.4, h * 0.25, w * 0.15, 0);
    fluidPath.close();

    final fluidPaint = Paint()
      ..color = Colors.white.withOpacity(0.16)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18);
    canvas.drawPath(fluidPath, fluidPaint);

    // 3. Crisp fluid arc highlight
    final arcPath = Path();
    arcPath.moveTo(-20, h * 0.12);
    arcPath.cubicTo(w * 0.4, h * 0.24, w * 0.7, h * 0.16, w + 30, h * 0.28);

    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..color = Colors.white.withOpacity(0.4)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
    canvas.drawPath(arcPath, arcPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _GreenNatureWallpaperPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // 1. Ambient emerald forest glow
    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF10B981).withOpacity(0.35),
          const Color(0xFF047857).withOpacity(0.14),
          Colors.transparent,
        ],
        stops: const [0.0, 0.58, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(w * 0.25, h * 0.32), radius: w * 0.75));
    canvas.drawCircle(Offset(w * 0.25, h * 0.32), w * 0.75, glowPaint);

    // 2. Neon emerald aurora ribbon sweeping across
    final path1 = Path();
    path1.moveTo(-30, h * 0.25);
    path1.cubicTo(w * 0.4, h * 0.35, w * 0.65, h * 0.20, w + 40, h * 0.30);

    final greenGlow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7.0
      ..color = const Color(0xFF34D399).withOpacity(0.55)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawPath(path1, greenGlow);

    final greenCore = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..color = const Color(0xFFA7F3D0).withOpacity(0.85);
    canvas.drawPath(path1, greenCore);

    // 3. Lower bioluminescent jade wave
    final path2 = Path();
    path2.moveTo(-20, h * 0.82);
    path2.cubicTo(w * 0.5, h * 0.72, w * 0.75, h * 0.86, w + 30, h * 0.78);

    final green2Glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6.0
      ..color = const Color(0xFF059669).withOpacity(0.45)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawPath(path2, green2Glow);

    final green2Core = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = const Color(0xFF6EE7B7).withOpacity(0.8);
    canvas.drawPath(path2, green2Core);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _SunsetDreamWallpaperPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // 1. Sun disc glow at the horizon line
    final sunGlow = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFFFDE047).withOpacity(0.42),
          const Color(0xFFF59E0B).withOpacity(0.22),
          Colors.transparent,
        ],
        stops: const [0.0, 0.5, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(w * 0.5, h * 0.70), radius: w * 0.55));
    canvas.drawCircle(Offset(w * 0.5, h * 0.70), w * 0.55, sunGlow);

    // 2. Horizon luminous light band
    final horizonPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.transparent,
          const Color(0xFFFDE047).withOpacity(0.35),
          const Color(0xFFFB923C).withOpacity(0.4),
          const Color(0xFFFDE047).withOpacity(0.35),
          Colors.transparent,
        ],
      ).createShader(Rect.fromLTWH(0, h * 0.69, w, 4));
    canvas.drawRect(Rect.fromLTWH(0, h * 0.69, w, 4), horizonPaint);

    // 3. Gentle horizontal ocean twilight shimmer lines
    final rippleYOffsets = [0.73, 0.77, 0.82, 0.88, 0.94];
    for (int i = 0; i < rippleYOffsets.length; i++) {
      final y = h * rippleYOffsets[i];
      final ripplePath = Path();
      ripplePath.moveTo(0, y);
      ripplePath.cubicTo(w * 0.25, y + 2, w * 0.75, y - 2, w, y);

      final ripplePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = (i % 2 == 0 ? const Color(0xFFFDE047) : const Color(0xFFFB923C)).withOpacity(0.22);
      canvas.drawPath(ripplePath, ripplePaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

