import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/blocked_numbers_service.dart';
import '../services/speed_dial_service.dart';
import '../services/telecom_service.dart';

class DialerSettingsDialog extends StatefulWidget {
  final VoidCallback? onSimulateIncoming;

  const DialerSettingsDialog({super.key, this.onSimulateIncoming});

  @override
  State<DialerSettingsDialog> createState() => _DialerSettingsDialogState();
}

class _DialerSettingsDialogState extends State<DialerSettingsDialog> {
  bool _isDefault = false;
  bool _autoRecord = false;
  bool _hapticEnabled = true;
  String _preferredSim = 'SIM 1';
  double _stackScrollSpeed = 1.5;
  String _bottomStackStyle = 'three_layer';
  String _ios18ThemeVariant = 'purple_glow';

  @override
  void initState() {
    super.initState();
    _checkDefaultDialer();
    _loadStackSettings();
  }

  Future<void> _loadStackSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _stackScrollSpeed = (prefs.getDouble('stack12_scroll_speed') ?? 1.5).clamp(0.5, 3.0).toDouble();
      _bottomStackStyle = prefs.getString('stack12_bottom_style') ?? 'three_layer';
      _ios18ThemeVariant = prefs.getString('ios18_theme_variant') ?? 'purple_glow';
    });
  }

  Future<void> _saveStackSetting(String key, Object value) async {
    final prefs = await SharedPreferences.getInstance();
    if (value is double) await prefs.setDouble(key, value);
    if (value is String) await prefs.setString(key, value);
  }

  void _checkDefaultDialer() async {
    final def = await TelecomService.isDefaultDialer();
    if (mounted) {
      setState(() => _isDefault = def);
    }
  }

  void _showBlockedNumbersSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1C25),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final blocked = BlockedNumbersService.blockedList;
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Blocked / Spam Numbers',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (blocked.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Center(
                    child: Text('No numbers blocked yet', style: TextStyle(color: Colors.white54)),
                  ),
                )
              else
                ...blocked.map(
                  (num) => ListTile(
                    leading: const Icon(Icons.block, color: Color(0xFFEF4444)),
                    title: Text(num, style: const TextStyle(color: Colors.white)),
                    trailing: TextButton(
                      child: const Text('Unblock', style: TextStyle(color: Color(0xFF38BDF8))),
                      onPressed: () {
                        BlockedNumbersService.unblockNumber(num);
                        Navigator.pop(ctx);
                        _showBlockedNumbersSheet();
                      },
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFEF4444).withOpacity(0.2),
                    foregroundColor: const Color(0xFFEF4444),
                    side: const BorderSide(color: Color(0xFFEF4444)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Block a Phone Number'),
                  onPressed: () {
                    final ctrl = TextEditingController();
                    showDialog(
                      context: ctx,
                      builder: (dCtx) => AlertDialog(
                        backgroundColor: const Color(0xFF1E1C25),
                        title: const Text('Block Number', style: TextStyle(color: Colors.white)),
                        content: TextField(
                          controller: ctrl,
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(color: Colors.white),
                          decoration: const InputDecoration(
                            hintText: '+91 99999 00000',
                            hintStyle: TextStyle(color: Colors.white38),
                          ),
                        ),
                        actions: [
                          TextButton(
                            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
                            onPressed: () => Navigator.pop(dCtx),
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFEF4444)),
                            child: const Text('Block', style: TextStyle(color: Colors.white)),
                            onPressed: () {
                              if (ctrl.text.trim().isNotEmpty) {
                                BlockedNumbersService.blockNumber(ctrl.text.trim());
                              }
                              Navigator.pop(dCtx);
                              Navigator.pop(ctx);
                              _showBlockedNumbersSheet();
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showSpeedDialSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1C25),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final entries = SpeedDialService.getAll();
        return Padding(
          padding: const EdgeInsets.all(20),
          child: ListView(
            shrinkWrap: true,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Speed Dial Shortcuts (Keys 1-9)',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              for (int k = 1; k <= 9; k++)
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFF10B981).withOpacity(0.2),
                    child: Text('$k', style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold)),
                  ),
                  title: Text(entries[k]?.name ?? 'Unassigned (Tap to set)', style: TextStyle(color: entries[k] != null ? Colors.white : Colors.white60)),
                  subtitle: Text(entries[k]?.number ?? 'Tap to assign contact name & number', style: const TextStyle(color: Colors.white38, fontSize: 12)),
                  trailing: const Icon(Icons.edit_outlined, color: Colors.white38, size: 18),
                  onTap: () {
                    final nameCtrl = TextEditingController(text: entries[k]?.name ?? '');
                    final numCtrl = TextEditingController(text: entries[k]?.number ?? '');
                    showDialog(
                      context: ctx,
                      builder: (dlgCtx) => AlertDialog(
                        backgroundColor: const Color(0xFF1E1C25),
                        title: Text('Assign Speed Dial #$k', style: const TextStyle(color: Colors.white)),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextField(
                              controller: nameCtrl,
                              style: const TextStyle(color: Colors.white),
                              decoration: const InputDecoration(labelText: 'Contact Name', labelStyle: TextStyle(color: Colors.white60)),
                            ),
                            TextField(
                              controller: numCtrl,
                              style: const TextStyle(color: Colors.white),
                              keyboardType: TextInputType.phone,
                              decoration: const InputDecoration(labelText: 'Phone Number', labelStyle: TextStyle(color: Colors.white60)),
                            ),
                          ],
                        ),
                        actions: [
                          if (entries[k] != null && k > 1)
                            TextButton(
                              onPressed: () {
                                SpeedDialService.removeEntry(k);
                                Navigator.pop(dlgCtx);
                                Navigator.pop(ctx);
                                _showSpeedDialSheet();
                              },
                              child: const Text('Clear', style: TextStyle(color: Color(0xFFEF4444))),
                            ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF10B981)),
                            onPressed: () {
                              if (numCtrl.text.trim().isNotEmpty) {
                                SpeedDialService.setEntry(
                                  k,
                                  nameCtrl.text.trim().isEmpty ? 'Key #$k' : nameCtrl.text.trim(),
                                  numCtrl.text.trim(),
                                );
                              }
                              Navigator.pop(dlgCtx);
                              Navigator.pop(ctx);
                              _showSpeedDialSheet();
                            },
                            child: const Text('Save', style: TextStyle(color: Colors.white)),
                          ),
                        ],
                      ),
                    );
                  },
                ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF181620),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.settings, color: Color(0xFF10B981), size: 24),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Dialer Preferences',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        Text('Carrier, Telecom & UI Settings', style: TextStyle(fontSize: 12, color: Colors.white54)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // Default Dialer Banner
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _isDefault
                      ? const Color(0xFF10B981).withOpacity(0.12)
                      : const Color(0xFF6366F1).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _isDefault
                        ? const Color(0xFF10B981).withOpacity(0.4)
                        : const Color(0xFF6366F1).withOpacity(0.4),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _isDefault ? Icons.check_circle : Icons.phone_android,
                      color: _isDefault ? const Color(0xFF10B981) : const Color(0xFF818CF8),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _isDefault ? 'Default Phone App: Active' : 'Set as Default Phone App',
                            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 13),
                          ),
                          Text(
                            _isDefault
                                ? 'Custom incoming/outgoing UI active'
                                : 'Enables custom incoming call screen for all SIM calls',
                            style: const TextStyle(fontSize: 11, color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                    if (!_isDefault)
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF6366F1),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          minimumSize: Size.zero,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        onPressed: () async {
                          await TelecomService.requestDefaultDialer();
                          _checkDefaultDialer();
                        },
                        child: const Text('Set', style: TextStyle(fontSize: 12, color: Colors.white)),
                      ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Dual SIM preference
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.sim_card, color: Color(0xFF38BDF8)),
                title: const Text('Default Calling SIM', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: Text(_preferredSim, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: DropdownButton<String>(
                  value: _preferredSim,
                  dropdownColor: const Color(0xFF1E1C25),
                  underline: const SizedBox(),
                  style: const TextStyle(color: Color(0xFF38BDF8), fontSize: 12),
                  items: const [
                    DropdownMenuItem(value: 'SIM 1', child: Text('SIM 1')),
                    DropdownMenuItem(value: 'SIM 2', child: Text('SIM 2')),
                    DropdownMenuItem(value: 'Always Ask', child: Text('Always Ask')),
                  ],
                  onChanged: (val) {
                    if (val != null) setState(() => _preferredSim = val);
                  },
                ),
              ),

              // Auto Record Toggle
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.record_voice_over, color: Color(0xFFEF4444)),
                title: const Text('Spam Number Detection', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Flag suspected spam and telemarketing callers', style: TextStyle(color: Colors.white54, fontSize: 11)),
                value: _autoRecord,
                activeColor: const Color(0xFF10B981),
                onChanged: (val) {
                  setState(() => _autoRecord = val);
                },
              ),

              // Haptic Feedback
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.vibration, color: Color(0xFFF59E0B)),
                title: const Text('Dialpad Haptics & Tones', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Kinetic tactile feedback on key presses', style: TextStyle(color: Colors.white54, fontSize: 11)),
                value: _hapticEnabled,
                activeColor: const Color(0xFF10B981),
                onChanged: (val) {
                  setState(() => _hapticEnabled = val);
                },
              ),

              const Divider(color: Colors.white12),

              // iOS 18 (Style 1) Exclusive 5 Premium Themes Selector
              Container(
                margin: const EdgeInsets.symmetric(vertical: 4),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      const Color(0xFF8B5CF6).withOpacity(0.12),
                      const Color(0xFFEC4899).withOpacity(0.06),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFF8B5CF6).withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF8B5CF6), Color(0xFF38BDF8)],
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.wallpaper_rounded, color: Colors.white, size: 16),
                        ),
                        const SizedBox(width: 10),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'iOS 18 (Style 1) Theme',
                                style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'Applies exclusively to iOS 18 (Style 1)',
                                style: TextStyle(color: Colors.white54, fontSize: 10),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFF8B5CF6).withOpacity(0.25),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: const Color(0xFF8B5CF6).withOpacity(0.5)),
                          ),
                          child: const Text('5 Styles', style: TextStyle(color: Color(0xFFD8B4FE), fontSize: 10, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildIOS18ThemeOption(
                      id: 'purple_glow',
                      title: '1. Style 1 Purple Glow',
                      subtitle: 'Deep cosmic midnight with neon violet silk ribbons',
                      gradientColors: const [Color(0xFF8B5CF6), Color(0xFF6D28D9), Color(0xFF0F0728)],
                      accentColor: const Color(0xFF8B5CF6),
                    ),
                    _buildIOS18ThemeOption(
                      id: 'gold_luxury',
                      title: '2. Style 2 Gold Luxury',
                      subtitle: 'Obsidian charcoal with liquid gold ribbons & amber call CTA',
                      gradientColors: const [Color(0xFFF59E0B), Color(0xFFD97706), Color(0xFF1E170F)],
                      accentColor: const Color(0xFFF59E0B),
                    ),
                    _buildIOS18ThemeOption(
                      id: 'sky_premium',
                      title: '3. Style 3 Sky Premium',
                      subtitle: 'iOS fluid sky blue, white frosted glass & slate typography',
                      gradientColors: const [Color(0xFF38BDF8), Color(0xFF1E40AF), Color(0xFFEEF2FF)],
                      accentColor: const Color(0xFF38BDF8),
                    ),
                    _buildIOS18ThemeOption(
                      id: 'green_nature',
                      title: '4. Style 4 Green Nature',
                      subtitle: 'Deep emerald forest with neon lime aurora waves',
                      gradientColors: const [Color(0xFF10B981), Color(0xFF047857), Color(0xFF061A0C)],
                      accentColor: const Color(0xFF10B981),
                    ),
                    _buildIOS18ThemeOption(
                      id: 'sunset_dream',
                      title: '5. Style 5 Sunset Dream',
                      subtitle: 'Plum tropical sunset seascape & warm peach coral cards',
                      gradientColors: const [Color(0xFFFB923C), Color(0xFFEA580C), Color(0xFF4A1028)],
                      accentColor: const Color(0xFFFB923C),
                    ),
                  ],
                ),
              ),

              const Divider(color: Colors.white12),
              const Padding(
                padding: EdgeInsets.only(top: 6, bottom: 4),
                child: Text('Style 12 — Scroll & Stack', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
              ),
              Row(
                children: [
                  const Icon(Icons.swipe_vertical, color: Color(0xFF10B981), size: 20),
                  const SizedBox(width: 10),
                  const Expanded(child: Text('Scroll / swipe speed', style: TextStyle(color: Colors.white, fontSize: 13))),
                  Text('${(_stackScrollSpeed * 100).round()}%', style: const TextStyle(color: Color(0xFF10B981), fontSize: 12, fontWeight: FontWeight.bold)),
                ],
              ),
              Slider(
                value: _stackScrollSpeed,
                min: 0.5,
                max: 3.0,
                divisions: 10,
                activeColor: const Color(0xFF10B981),
                inactiveColor: Colors.white12,
                onChanged: (value) {
                  setState(() => _stackScrollSpeed = value);
                  _saveStackSetting('stack12_scroll_speed', value);
                },
              ),
              const Text('Slow  ←                         →  Fast', style: TextStyle(color: Colors.white38, fontSize: 10)),
              const SizedBox(height: 8),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.layers_outlined, color: Color(0xFF38BDF8)),
                title: const Text('Bottom stack style', style: TextStyle(color: Colors.white, fontSize: 13)),
                subtitle: const Text('Choose how the 3 cards overlap', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: DropdownButton<String>(
                  value: _bottomStackStyle,
                  dropdownColor: const Color(0xFF1E1C25),
                  underline: const SizedBox(),
                  style: const TextStyle(color: Color(0xFF38BDF8), fontSize: 12),
                  items: const [
                    DropdownMenuItem(value: 'three_layer', child: Text('3 Layers')),
                    DropdownMenuItem(value: 'tight', child: Text('Tight')),
                    DropdownMenuItem(value: 'fan', child: Text('Fan')),
                  ],
                  onChanged: (value) {
                    if (value == null) return;
                    setState(() => _bottomStackStyle = value);
                    _saveStackSetting('stack12_bottom_style', value);
                  },
                ),
              ),

              // Speed Dial Management
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.speed, color: Color(0xFFA855F7)),
                title: const Text('Speed Dial Shortcuts', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Configure long-press contacts for keys 1-9', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                onTap: _showSpeedDialSheet,
              ),

              // Blocked Numbers Management
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.shield_outlined, color: Color(0xFFEF4444)),
                title: const Text('Blocked & Spam Numbers', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Manage blacklisted caller IDs and spam filters', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                onTap: _showBlockedNumbersSheet,
              ),

              const Divider(color: Colors.white12),

              // Hidden Developer & Testing Options Expansion Tile
              Theme(
                data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                child: ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  leading: const Icon(Icons.code_rounded, color: Color(0xFF14B8A6)),
                  title: const Text(
                    'Developer & Testing Options',
                    style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                  subtitle: const Text(
                    'Simulate incoming calls & debug diagnostics',
                    style: TextStyle(color: Colors.white38, fontSize: 10),
                  ),
                  children: [
                    if (widget.onSimulateIncoming != null)
                      ListTile(
                        contentPadding: const EdgeInsets.only(left: 12),
                        leading: const Icon(Icons.phone_callback_rounded, color: Color(0xFFA855F7), size: 20),
                        title: const Text('Simulate Inbound Call', style: TextStyle(color: Colors.white, fontSize: 13)),
                        subtitle: const Text('Trigger incoming call overlay screen', style: TextStyle(color: Colors.white54, fontSize: 10)),
                        trailing: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFA855F7).withOpacity(0.2),
                            foregroundColor: const Color(0xFFA855F7),
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                            widget.onSimulateIncoming!();
                          },
                          child: const Text('Simulate', style: TextStyle(fontSize: 11)),
                        ),
                      ),
                    const ListTile(
                      contentPadding: EdgeInsets.only(left: 12),
                      leading: Icon(Icons.speed, color: Color(0xFF10B981), size: 20),
                      title: Text('Flux Engine 120fps Mode', style: TextStyle(color: Colors.white, fontSize: 13)),
                      subtitle: Text('Hardware acceleration active', style: TextStyle(color: Color(0xFF10B981), fontSize: 10)),
                      trailing: Text('Active ✓', style: TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIOS18ThemeOption({
    required String id,
    required String title,
    required String subtitle,
    required List<Color> gradientColors,
    required Color accentColor,
  }) {
    final isSelected = _ios18ThemeVariant == id;
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() => _ios18ThemeVariant = id);
        _saveStackSetting('ios18_theme_variant', id);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? accentColor.withOpacity(0.15) : const Color(0xFF1B1922),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? accentColor : Colors.white12,
            width: isSelected ? 1.5 : 1.0,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: accentColor.withOpacity(0.25),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: gradientColors,
                ),
                borderRadius: BorderRadius.circular(9),
                border: Border.all(
                  color: isSelected ? accentColor : Colors.white24,
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.4),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: isSelected
                  ? const Center(child: Icon(Icons.check, size: 18, color: Colors.white))
                  : null,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.white.withOpacity(0.85),
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: isSelected ? Colors.white70 : Colors.white38,
                      fontSize: 9.5,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
              color: isSelected ? accentColor : Colors.white30,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}

