# StackDialer — Real Native Android Dialer (Production-Ready)

StackDialer is a fully native Android dialer replacement built with Flutter and Android Telecom APIs. It features real SIM carrier calling, native incoming/outgoing call screens, 10 kinetic 3D card-stack animation styles in Recents, T9 contact search, and default dialer integration.

---

## 🛠️ Critical Audits & Fixes Applied

1. **Speaker Button Fixed**:
   - Flutter MethodChannel now passes both `speaker` and `enabled` parameters.
   - Android native handler (`MainActivity.kt` & `InCallServiceImpl.kt`) routes through Android Telecom `setAudioRoute(ROUTE_SPEAKER / ROUTE_EARPIECE)` with fallback to `AudioManager.isSpeakerphoneOn`.
   - Real-time audio route listener (`onCallAudioStateChanged`) keeps the speaker icon and UI synchronized with the phone's actual audio hardware route.

2. **Incoming Call Screen Fixed**:
   - Registered `InCallServiceImpl` with `BIND_INCALL_SERVICE` and `android.telecom.IN_CALL_SERVICE_UI = true`.
   - `MainActivity` configured with `showWhenLocked="true"`, `turnScreenOn="true"`, and high-priority Heads-Up Notification (`CATEGORY_CALL` with full-screen intent).
   - Custom incoming call UI displays Answer and Reject buttons wired directly to Telecom `answer()` and `reject()`.

3. **Active Call Timer Fixed**:
   - Removed artificial 3-second connect timer.
   - Call duration timer starts **only** when Android Telecom reports that the call is `ACTIVE`.

4. **Recent Calls & Real Call Logs**:
   - Outgoing calls are immediately captured in local state and synced with Android's native `CallLog.Calls` provider upon call disconnection.
   - Removed hardcoded sample data when device call logs are accessed. Empty history shows a clean empty state.

5. **Settings & Favorites Persistence**:
   - Speed dial shortcuts (Keys 1-9) are editable via Settings and persisted across app restarts via `shared_preferences`.
   - Blocked numbers and favorite contacts persist across app reboots.

6. **Removed Unsupported & Simulated Claims**:
   - Removed fake simulated call recording.
   - Removed unsubstantiated 48kHz HD voice and encryption claims.
   - Replaced hardcoded carrier names with dynamic `SIM 1` / `SIM 2` and real carrier detection.

---

## 🚀 Step-by-Step: Create a New GitHub Repo & Build APK

### Step 1: Create a New GitHub Repository
1. Go to [github.com/new](https://github.com/new).
2. Enter a repository name (e.g. `DilerCall` or `StackDialer`).
3. Set the repository to **Public** or **Private**.
4. Leave "Add a README file" **unchecked** (we already provide one).
5. Click **Create repository**.

### Step 2: Extract the ZIP and Push Code
1. Download and unzip `stackdialer_flutter_source.zip`.
2. Open your terminal inside the unzipped folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: StackDialer Android dialer"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

### Step 3: GitHub Actions Auto-Builds the APK
1. As soon as you push to `main`, GitHub Actions triggers the included `.github/workflows/build-apk.yml`.
2. Click the **Actions** tab in your GitHub repository.
3. Click on the running workflow **"Build StackDialer Android APK"**.
4. In about 2-3 minutes, the build completes.
5. Under **Artifacts** at the bottom of the summary page, download **`StackDialer-Release-APK`**.
6. Unzip the downloaded artifact to find `app-release.apk`.

---

## 📱 Installing & Configuring on Your Android Phone

1. Transfer `app-release.apk` to your Android phone (via USB, Google Drive, WhatsApp, or browser download).
2. Tap the APK file to install. If prompted, enable **"Allow from this source"** under *Install unknown apps*.
3. Open **StackDialer**.
4. Grant the requested permissions for **Phone**, **Contacts**, and **Call Logs**.
5. **Set as Default Phone App**:
   - Tap the **"Set Default"** banner at the top of StackDialer, OR
   - Go to phone **Settings** → **Apps** → **Default apps** → **Phone app** → select **StackDialer**.
   *(Setting StackDialer as the default phone app allows it to handle real lockscreen incoming calls, notifications, and telecom audio routing.)*


## Style 11 — Notification Stack Deck

Added a new card style based on the supplied reference: centered wide cards, 12px stacked lips, 0.96 scale per layer, dark frosted-glass surface (18px blur), rounded 30px edges, and restrained spring-like stacking. Existing styles 1–10 are retained. Selection continues to use the existing SharedPreferences key so the chosen style remains saved until manually changed.


## Card Style 12 — Notification Flow Motion (updated)
- Uses wide, dark-charcoal notification cards with 30px rounded corners and a restrained border/shadow.
- Cards are 176px tall with a 152px step, creating a consistent 24px overlap like the reference cards.
- The cards follow the scroll coordinate continuously, with subtle scale/tilt at viewport edges for a spring-like feel.
- Bottom-edge cards keep the same overlap spacing; they do not collapse into a compressed pile.
- Avoids BackdropFilter blur in this style to reduce GPU load during scrolling.
- Selection uses the existing SharedPreferences key and remains saved across app restarts.

Note: this source update has not been built or tested on a physical Android device in this environment.


## Latest UI update (Style 12 + dial pad)
- Style 12 recent-call cards are narrower, have less-rounded corners, and use a slightly faster scroll/inertia response.
- Dial pad now follows the supplied reference: white background, thin pale circular keys, black digits, green circular call button, and a brief green glow on a tapped digit.
- Removed SIM 1 / SIM 2 selector pills remain removed. The bottom navigation switches to a light style while Keypad is selected.

## Latest update: Ripple + app theme
- Dialpad number keys now show a green Material ripple on tap, with the existing green press glow and haptic feedback.
- Settings includes a Dark / Light Theme switch.
- Theme preference is saved locally and restored when the app starts.
- The main shell, navigation bar, dialpad, and primary Recents/Contacts/Insights backgrounds respond to the selected theme.

## Latest update: Bouncy bold keypad
- Dial-pad number keys now press down briefly and spring back with an elastic bounce animation.
- Number glyphs use extra-bold weight for stronger readability.
- The Settings Dark / Light Theme switch remains app-wide and the preference is persisted locally.


## Latest dial-pad/theme adjustments
- Dial-pad number keys use a stronger circular outline in both themes.
- Number keys use a short press-down and elastic spring-back animation with haptic feedback.
- Settings includes the persisted app theme switch (Dark/Light); the root MaterialApp listens to the theme preference.
- Note: some bespoke screens still use fixed colors and should be visually tested/refined for complete light-theme consistency.
