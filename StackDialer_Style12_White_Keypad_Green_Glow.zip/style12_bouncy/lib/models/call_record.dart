enum CallType {
  incoming,
  outgoing,
  missed,
  rejected,
}

class CallRecord {
  final String id;
  final String name;
  final String number;
  final CallType type;
  final DateTime timestamp;
  final int durationSeconds;
  final int simSlot;
  final String simCarrier;
  final String? note;
  final String? reminderTime;
  final String category;
  final String location;

  CallRecord({
    required this.id,
    required this.name,
    required this.number,
    required this.type,
    required this.timestamp,
    required this.durationSeconds,
    this.simSlot = 1,
    this.simCarrier = 'SIM 1',
    this.note,
    this.reminderTime,
    this.category = 'Personal',
    this.location = 'Mobile',
  });

  int get duration => durationSeconds;

  String get durationString {
    if (durationSeconds == 0) return 'Missed';
    final mins = durationSeconds ~/ 60;
    final secs = durationSeconds % 60;
    if (mins == 0) return '${secs}s';
    return '${mins}m ${secs}s';
  }

  String get timeFormatted {
    final hour = timestamp.hour.toString().padLeft(2, '0');
    final minute = timestamp.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  String get dateLabel {
    final now = DateTime.now();
    if (timestamp.year == now.year && timestamp.month == now.month && timestamp.day == now.day) {
      return 'Today';
    }
    final yesterday = now.subtract(const Duration(days: 1));
    if (timestamp.year == yesterday.year && timestamp.month == yesterday.month && timestamp.day == yesterday.day) {
      return 'Yesterday';
    }
    return "${timestamp.day}/${timestamp.month}";
  }
}
