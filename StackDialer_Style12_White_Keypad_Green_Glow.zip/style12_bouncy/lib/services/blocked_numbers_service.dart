import 'package:shared_preferences/shared_preferences.dart';

class BlockedNumbersService {
  static const String _prefKey = 'stackdialer_blocked_numbers';
  static final Set<String> _blockedNumbers = {
    '+91 14000 00000',
  };

  static Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList(_prefKey);
      if (list != null && list.isNotEmpty) {
        _blockedNumbers.clear();
        _blockedNumbers.addAll(list);
      }
    } catch (_) {}
  }

  static List<String> get blockedList => _blockedNumbers.toList();

  static bool isBlocked(String number) {
    final clean = number.replaceAll(RegExp(r'[^\d+]'), '');
    return _blockedNumbers.any((b) {
      final bClean = b.replaceAll(RegExp(r'[^\d+]'), '');
      return bClean == clean || (clean.startsWith('140') && clean.length > 6);
    });
  }

  static void blockNumber(String number) {
    if (number.trim().isNotEmpty) {
      _blockedNumbers.add(number.trim());
      _persist();
    }
  }

  static void unblockNumber(String number) {
    _blockedNumbers.remove(number.trim());
    _persist();
  }

  static Future<void> _persist() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_prefKey, _blockedNumbers.toList());
    } catch (_) {}
  }
}
