import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class SpeedDialEntry {
  final int key; // 1 to 9
  final String name;
  final String number;

  const SpeedDialEntry({
    required this.key,
    required this.name,
    required this.number,
  });

  Map<String, dynamic> toJson() => {
        'key': key,
        'name': name,
        'number': number,
      };

  factory SpeedDialEntry.fromJson(Map<String, dynamic> json) => SpeedDialEntry(
        key: json['key'] as int,
        name: json['name'] as String,
        number: json['number'] as String,
      );
}

class SpeedDialService {
  static const String _prefKey = 'stackdialer_speed_dials';
  static final Map<int, SpeedDialEntry> _entries = {
    1: const SpeedDialEntry(key: 1, name: 'Voicemail', number: '*123#'),
  };

  static Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_prefKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw) as Map<String, dynamic>;
        _entries.clear();
        _entries[1] = const SpeedDialEntry(key: 1, name: 'Voicemail', number: '*123#');
        decoded.forEach((k, v) {
          final intKey = int.tryParse(k);
          if (intKey != null && v is Map<String, dynamic>) {
            _entries[intKey] = SpeedDialEntry.fromJson(v);
          }
        });
      }
    } catch (_) {}
  }

  static SpeedDialEntry? getEntry(int key) => _entries[key];

  static Map<int, SpeedDialEntry> getAll() => Map.unmodifiable(_entries);

  static void setEntry(int key, String name, String number) {
    if (key >= 1 && key <= 9) {
      _entries[key] = SpeedDialEntry(key: key, name: name, number: number);
      _persist();
    }
  }

  static void removeEntry(int key) {
    if (key > 1) {
      _entries.remove(key);
      _persist();
    }
  }

  static Future<void> _persist() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final map = _entries.map((k, v) => MapEntry(k.toString(), v.toJson()));
      await prefs.setString(_prefKey, jsonEncode(map));
    } catch (_) {}
  }
}
