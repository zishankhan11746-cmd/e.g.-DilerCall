import 'package:flutter/foundation.dart';

/// Keeps the original fixed dark appearance. Theme switching is intentionally disabled.
class DialerThemeService {
  static final ValueNotifier<bool> isDark = ValueNotifier<bool>(true);

  static Future<void> init() async {
    isDark.value = true;
  }

  static Future<void> setDark(bool value) async {
    // The app uses the original dark theme only.
    isDark.value = true;
  }
}
