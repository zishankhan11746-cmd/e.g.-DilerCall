import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/call_record.dart';
import '../services/blocked_numbers_service.dart';
import '../services/telecom_service.dart';

enum CallUIState {
  ringing, // Incoming Call UI
  dialing, // Outgoing Call UI
  active,  // Connected in-call
  holding, // On Hold
  ended,   // Call Ended Summary
}

class ActiveCallScreen extends StatefulWidget {
  final String phoneNumber;
  final String? contactName;
  final String? callerCategory;
  final int simSlot;
  final bool isIncoming;
  final bool initiallyActive;
  final Function(CallRecord completedCall)? onCallEnded;

  const ActiveCallScreen({
    super.key,
    required this.phoneNumber,
    this.contactName,
    this.callerCategory,
    this.simSlot = 1,
    this.isIncoming = false,
    this.initiallyActive = false,
    this.onCallEnded,
  });

  @override
  State<ActiveCallScreen> createState() => _ActiveCallScreenState();
}

class _ActiveCallScreenState extends State<ActiveCallScreen> with SingleTickerProviderStateMixin {
  // Shared across temporary screen rebuilds/routes so reopening the call UI never resets elapsed time.
  static DateTime? _sharedCallStartedAt;
  static String? _sharedCallNumber;
  late CallUIState _state;
  bool _isMuted = false;
  bool _isSpeaker = false;
  bool _isOnHold = false;
  bool _isRecording = false;
  bool _addCallEffect = false;
  bool _videoCallEffect = false;
  bool _showDtmfPad = false;
  String _dtmfHistory = '';
  String _callNote = '';
  int _durationSeconds = 0;
  Timer? _callTimer;
  late final AnimationController _orbController;

  @override
  void initState() {
    super.initState();
    _orbController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1150),
    )..repeat(reverse: true);
    _state = widget.isIncoming
        ? CallUIState.ringing
        : (widget.initiallyActive ? CallUIState.active : CallUIState.dialing);
    if (widget.initiallyActive) {
      _startTimer();
    }

    // Initial check for real speaker status
    TelecomService.isSpeakerOn().then((on) {
      if (mounted && on != _isSpeaker) {
        setState(() => _isSpeaker = on);
      }
    });

    // Listen to real Android InCallService native call state events
    TelecomService.setupCallListener((number, nativeState) {
      if (!mounted) return;
      if (nativeState == 'ACTIVE' && _state != CallUIState.active) {
        _transitionToActive();
      } else if (nativeState == 'HOLDING') {
        setState(() {
          _isOnHold = true;
          _state = CallUIState.holding;
        });
      } else if (nativeState == 'DISCONNECTED') {
        _endCall();
      }
    });

    // Listen for confirmed Android audio route changes (earpiece / speaker / bluetooth)
    TelecomService.setupAudioRouteListener((isSpeaker, isMuted) {
      if (!mounted) return;
      setState(() {
        _isSpeaker = isSpeaker;
        _isMuted = isMuted;
      });
    });
  }

  void _transitionToActive() {
    if (_state == CallUIState.active) return;
    HapticFeedback.heavyImpact();
    if (_sharedCallNumber != widget.phoneNumber) {
      _sharedCallNumber = widget.phoneNumber;
      _sharedCallStartedAt = DateTime.now();
    } else {
      _sharedCallStartedAt ??= DateTime.now();
    }
    setState(() {
      _state = CallUIState.active;
      _durationSeconds = DateTime.now().difference(_sharedCallStartedAt!).inSeconds;
    });
    _startTimer();
  }

  void _startTimer() {
    // Do not restart the clock on duplicate ACTIVE callbacks.
    if (_sharedCallNumber != widget.phoneNumber) {
      _sharedCallNumber = widget.phoneNumber;
      _sharedCallStartedAt = DateTime.now();
    } else {
      _sharedCallStartedAt ??= DateTime.now();
    }
    _callTimer?.cancel();
    _durationSeconds = DateTime.now().difference(_sharedCallStartedAt!).inSeconds;
    _callTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && (_state == CallUIState.active || _state == CallUIState.holding)) {
        final elapsed = DateTime.now().difference(_sharedCallStartedAt!).inSeconds;
        if (elapsed != _durationSeconds) {
          setState(() => _durationSeconds = elapsed);
        }
      }
    });
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _orbController.dispose();
    super.dispose();
  }

  String _formatDuration(int seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  void _answerCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.answerCall();
    _transitionToActive();
  }

  void _rejectCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.rejectCall();
    _endCall();
  }

  void _hangupCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.disconnectCall();
    _endCall();
  }

  void _endCall() {
    if (_state == CallUIState.ended) return;
    _callTimer?.cancel();
    if (_sharedCallNumber == widget.phoneNumber) {
      _sharedCallStartedAt = null;
      _sharedCallNumber = null;
    }
    TelecomService.cancelIncomingBanner();
    TelecomService.cancelOngoingNotification();
    HapticFeedback.mediumImpact();
    setState(() {
      _state = CallUIState.ended;
    });

    final record = CallRecord(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: widget.contactName ?? widget.phoneNumber,
      number: widget.phoneNumber,
      type: widget.isIncoming
          ? (_durationSeconds > 0 ? CallType.incoming : CallType.missed)
          : CallType.outgoing,
      timestamp: DateTime.now(),
      durationSeconds: _durationSeconds,
      simSlot: widget.simSlot,
      simCarrier: 'SIM ${widget.simSlot}',
      category: widget.callerCategory ?? 'Personal',
      location: 'Cellular Call',
      note: _callNote.isNotEmpty ? _callNote : null,
    );

    widget.onCallEnded?.call(record);
  }

  void _toggleMute() async {
    HapticFeedback.selectionClick();
    final newMute = !_isMuted;
    await TelecomService.setMuted(newMute);
    setState(() {
      _isMuted = newMute;
    });
  }

  void _toggleSpeaker() async {
    HapticFeedback.selectionClick();
    final newSpeaker = !_isSpeaker;
    await TelecomService.setSpeaker(newSpeaker);
    setState(() {
      _isSpeaker = newSpeaker;
    });
  }

  void _toggleHold() async {
    HapticFeedback.selectionClick();
    final newHold = !_isOnHold;
    await TelecomService.holdCall(newHold);
    setState(() {
      _isOnHold = newHold;
      _state = newHold ? CallUIState.holding : CallUIState.active;
    });
  }

  void _toggleRecord() {
    HapticFeedback.mediumImpact();
    setState(() {
      _isRecording = !_isRecording;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              _isRecording ? Icons.fiber_manual_record : Icons.stop_circle_outlined,
              color: _isRecording ? Colors.redAccent : Colors.white70,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(_isRecording ? '🔴 Call recording in progress' : '⏹️ Call recording saved'),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1E1E22),
      ),
    );
  }

  void _onPressDtmfDigit(String digit) {
    HapticFeedback.lightImpact();
    TelecomService.playDtmf(digit);
    setState(() {
      _dtmfHistory += digit;
    });
    Future.delayed(const Duration(milliseconds: 200), () {
      TelecomService.stopDtmf();
    });
  }

  void _showQuickSmsSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141416),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final messages = [
          "Can't talk now. What's up?",
          "I'll call you right back.",
          "I'm in a meeting right now.",
          "Driving right now, will call later.",
        ];
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Quick Decline with SMS',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ...messages.map(
                (msg) => ListTile(
                  title: Text(msg, style: const TextStyle(color: Colors.white70)),
                  trailing: const Icon(Icons.send_rounded, color: Color(0xFF10B981), size: 18),
                  onTap: () async {
                    Navigator.pop(ctx);
                    _rejectCall();
                    final uri = Uri(
                      scheme: 'sms',
                      path: widget.phoneNumber,
                      queryParameters: {'body': msg},
                    );
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri);
                    }
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showInCallNoteDialog() {
    final controller = TextEditingController(text: _callNote);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF18181C),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Summarise / In-Call Note', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        content: TextField(
          controller: controller,
          maxLines: 4,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Add call notes, summary or follow-up details...',
            hintStyle: const TextStyle(color: Colors.white38),
            filled: true,
            fillColor: const Color(0xFF222226),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFDC2626),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () {
              setState(() {
                _callNote = controller.text.trim();
              });
              Navigator.pop(ctx);
            },
            child: const Text('Save Note', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _onAddCall() {
    HapticFeedback.lightImpact();
    setState(() => _addCallEffect = true);
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _addCallEffect = false);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Add Call: Conference and 2nd line calling active'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF1E1E22),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _onVideoCall() {
    HapticFeedback.lightImpact();
    setState(() => _videoCallEffect = true);
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _videoCallEffect = false);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Carrier ViLTE Video calling is available for 5G/VoLTE lines'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF1E1E22),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final displayName = widget.contactName?.isNotEmpty == true
        ? widget.contactName!
        : widget.phoneNumber;

    return Scaffold(
      backgroundColor: const Color(0xFF070B13),
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBlurredCallBackdrop(),
          SafeArea(
            child: _state == CallUIState.ended
                ? _buildCallEndedSummary(displayName)
                : LayoutBuilder(
                    builder: (context, constraints) => SingleChildScrollView(
                      physics: const ClampingScrollPhysics(),
                      child: ConstrainedBox(
                        constraints: BoxConstraints(minHeight: constraints.maxHeight),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(18, 18, 18, 22),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _buildCallerIdentity(displayName),
                              const SizedBox(height: 26),
                              if (_state == CallUIState.ringing)
                                _buildIncomingCallControls()
                              else if (_showDtmfPad)
                                _buildInCallDialpad()
                              else
                                _buildReferenceThreeByThreeGrid(),
                              const SizedBox(height: 12),
                              if (_state == CallUIState.ringing)
                                const SizedBox(height: 4)
                              else
                                _buildCallSecurityHint(),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCallerIdentity(String displayName) {
    final isConnected = _state == CallUIState.active || _state == CallUIState.holding;
    final status = _state == CallUIState.ringing
        ? 'INCOMING CALL'
        : _state == CallUIState.dialing
            ? 'CALLING'
            : _state == CallUIState.holding
                ? 'CALL ON HOLD'
                : 'CONNECTED';
    final statusColor = _state == CallUIState.ringing
        ? const Color(0xFF65E6B5)
        : _state == CallUIState.holding
            ? const Color(0xFFFFC36A)
            : const Color(0xFF72D9FF);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.055),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: Colors.white.withOpacity(0.10)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 6, height: 6, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle, boxShadow: [BoxShadow(color: statusColor.withOpacity(0.7), blurRadius: 8)])),
              const SizedBox(width: 8),
              Text(status, style: TextStyle(color: statusColor, fontSize: 10.5, letterSpacing: 1.8, fontWeight: FontWeight.w800)),
              const SizedBox(width: 9),
              const Icon(Icons.sim_card_rounded, color: Colors.white54, size: 13),
              const SizedBox(width: 4),
              Text('SIM ${widget.simSlot}', style: const TextStyle(color: Colors.white60, fontSize: 10.5, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Container(
          width: 112,
          height: 112,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF394D72), Color(0xFF202D48), Color(0xFF171D2C)]),
            border: Border.all(color: const Color(0xFF9ABEFF).withOpacity(0.52), width: 1.4),
            boxShadow: [
              BoxShadow(color: const Color(0xFF659CFF).withOpacity(0.20), blurRadius: 34, spreadRadius: 5),
              const BoxShadow(color: Colors.black38, blurRadius: 18, offset: Offset(0, 9)),
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(width: 92, height: 92, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(0.10), width: 1))),
              Icon(widget.contactName?.isNotEmpty == true ? Icons.person_rounded : Icons.phone_in_talk_rounded, color: const Color(0xFFEAF2FF), size: 48),
              if (isConnected)
                Positioned(bottom: 3, right: 5, child: Container(width: 18, height: 18, decoration: BoxDecoration(color: const Color(0xFF4DDBA5), shape: BoxShape.circle, border: Border.all(color: const Color(0xFF182238), width: 3)))),
            ],
          ),
        ),
        const SizedBox(height: 15),
        Text(displayName, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 27, height: 1.12, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: -0.5)),
        const SizedBox(height: 6),
        Text(widget.phoneNumber, style: const TextStyle(fontSize: 14.5, color: Color(0xFFB8C2D2), letterSpacing: 0.4, fontWeight: FontWeight.w500)),
        const SizedBox(height: 12),
        if (isConnected)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 8),
            decoration: BoxDecoration(color: const Color(0xFF65DDB2).withOpacity(0.10), borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFF65DDB2).withOpacity(0.20))),
            child: Text(_formatDuration(_durationSeconds), style: const TextStyle(color: Color(0xFF8AF0C9), fontSize: 19, fontWeight: FontWeight.w700, letterSpacing: 2.0, fontFeatures: [ui.FontFeature.tabularFigures()])),
          )
        else
          Text(_state == CallUIState.ringing ? 'Your phone is ringing' : 'Waiting for answer…', style: const TextStyle(color: Color(0xFF8D9AAF), fontSize: 13, fontWeight: FontWeight.w500)),
      ],
    );
  }

  Widget _buildCallSecurityHint() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: const [
        Icon(Icons.lock_rounded, color: Colors.white30, size: 12),
        SizedBox(width: 6),
        Text('Private cellular call', style: TextStyle(color: Colors.white38, fontSize: 10.5, letterSpacing: 0.4)),
      ],
    );
  }

  Widget _buildBlurredCallBackdrop() {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF526477), Color(0xFF273747), Color(0xFF101B29)],
              stops: [0.0, 0.50, 1.0],
            ),
          ),
        ),
        Positioned(
          top: 190,
          left: -105,
          child: ImageFiltered(
            imageFilter: ui.ImageFilter.blur(sigmaX: 36, sigmaY: 36),
            child: Container(
              width: 330,
              height: 360,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF315D9A),
              ),
            ),
          ),
        ),
        Positioned(
          top: 365,
          right: -125,
          child: ImageFiltered(
            imageFilter: ui.ImageFilter.blur(sigmaX: 36, sigmaY: 36),
            child: Container(
              width: 300,
              height: 340,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF533B86),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -145,
          left: 30,
          child: ImageFiltered(
            imageFilter: ui.ImageFilter.blur(sigmaX: 36, sigmaY: 36),
            child: Container(
              width: 340,
              height: 310,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF176B75),
              ),
            ),
          ),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0x120B1724), Color(0x6807111D)],
            ),
          ),
        ),
      ],
    );
  }

  // =========================================================================
  // Reference layout: exact 3 rows x 3 columns.
  // =========================================================================
  Widget _buildReferenceThreeByThreeGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildCircleAction(icon: Icons.radio_button_checked_rounded, label: 'Record', isActive: _isRecording, activeColor: const Color(0xFFFF5964), onTap: _toggleRecord),
              _buildCircleAction(icon: _isOnHold ? Icons.play_arrow_rounded : Icons.pause_rounded, label: 'Hold', isActive: _isOnHold, activeColor: const Color(0xFFFFBD59), onTap: _toggleHold),
              _buildCircleAction(icon: Icons.add_rounded, label: 'Add call', isActive: _addCallEffect, activeColor: const Color(0xFF45D7FF), onTap: _onAddCall),
            ],
          ),
          const SizedBox(height: 17),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildCircleAction(icon: _isMuted ? Icons.mic_off_rounded : Icons.mic_none_rounded, label: 'Mute', isActive: _isMuted, activeColor: const Color(0xFF55D6FF), onTap: _toggleMute),
              _buildCircleAction(icon: Icons.videocam_rounded, label: 'Video call', isActive: _videoCallEffect, activeColor: const Color(0xFF669FFF), onTap: _onVideoCall),
              _buildCircleAction(icon: Icons.auto_awesome_rounded, label: 'AI Assistant', isActive: _callNote.isNotEmpty, activeColor: const Color(0xFFB56BFF), onTap: _showInCallNoteDialog),
            ],
          ),
          const SizedBox(height: 17),
          // Frosted Glass style #2: all three rows float independently over
          // the blurred backdrop, matching the selected reference layout.
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildCircleAction(icon: Icons.volume_up_rounded, label: 'Speaker', isActive: _isSpeaker, activeColor: const Color(0xFF48D8FF), onTap: _toggleSpeaker),
              _buildCircleAction(icon: Icons.call_end_rounded, label: 'End call', isEnd: true, onTap: _hangupCall),
              _buildCircleAction(icon: Icons.dialpad_rounded, label: 'Keypad', isActive: _showDtmfPad, activeColor: const Color(0xFF72E6B5), onTap: () => setState(() => _showDtmfPad = !_showDtmfPad)),
            ],
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // Frosted glass controls with soft inner highlight and iridescent rim.
  // =========================================================================
  Color _glowColorForAction(String label, Color activeColor, bool isEnd) {
    if (isEnd) return const Color(0xFFFF3B36);
    switch (label.toLowerCase()) {
      case 'record':
        return const Color(0xFFFF4D58);
      case 'hold':
        return const Color(0xFFFFB84D);
      case 'add call':
        return const Color(0xFF42D9FF);
      case 'mute':
        return const Color(0xFF55D6FF);
      case 'video call':
        return const Color(0xFF5C9DFF);
      case 'ai call assistant':
        return const Color(0xFFB56BFF);
      case 'speaker':
        return const Color(0xFF48D8FF);
      case 'dial pad':
        return const Color(0xFF72E6B5);
      default:
        return activeColor;
    }
  }

  Widget _buildCircleAction({
    required IconData icon,
    required String label,
    bool isActive = false,
    Color activeColor = Colors.white,
    bool isEnd = false,
    bool glow = false,
    required VoidCallback onTap,
  }) {
    const diameter = 72.0;
    final effectColor = _glowColorForAction(label, activeColor, isEnd);
    // End Call remains visibly illuminated; other controls light up only while ON.
    final effectsOn = isActive || isEnd;
    return SizedBox(
      width: (MediaQuery.sizeOf(context).width - 48) / 3,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              onTap();
            },
            child: SizedBox(
              width: isEnd ? 80 : diameter + 8,
              height: isEnd ? 80 : diameter + 8,
              child: Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.center,
                children: [
                  // Broad, soft pool of light under the active button.
                  Positioned(
                    bottom: 0,
                    child: AnimatedOpacity(
                      opacity: effectsOn ? 1 : 0,
                      duration: const Duration(milliseconds: 380),
                      curve: Curves.easeOutCubic,
                      child: ImageFiltered(
                        imageFilter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 5),
                        child: Container(
                          width: isEnd ? 58 : 52,
                          height: 15,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: effectColor.withOpacity(0.78),
                            boxShadow: [
                              BoxShadow(color: effectColor.withOpacity(0.88), blurRadius: 22, spreadRadius: 4),
                              BoxShadow(color: effectColor.withOpacity(0.48), blurRadius: 34, spreadRadius: 7),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Small floating orb above the control, softly breathing in place.
                  Positioned(
                    top: 0,
                    child: IgnorePointer(
                      child: AnimatedOpacity(
                        opacity: effectsOn ? 1 : 0,
                        duration: const Duration(milliseconds: 380),
                        curve: Curves.easeOutCubic,
                        child: AnimatedBuilder(
                          animation: _orbController,
                          builder: (context, child) {
                            final lift = -2.5 + (_orbController.value * 5.0);
                            final breathe = 0.78 + (_orbController.value * 0.22);
                            return Transform.translate(
                              offset: Offset(0, lift),
                              child: Opacity(opacity: breathe, child: child),
                            );
                          },
                          child: Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [Colors.white, effectColor, effectColor.withOpacity(0.15)],
                                stops: const [0.0, 0.38, 1.0],
                              ),
                              boxShadow: [
                                BoxShadow(color: effectColor.withOpacity(0.95), blurRadius: 12, spreadRadius: 2),
                                BoxShadow(color: effectColor.withOpacity(0.55), blurRadius: 22, spreadRadius: 4),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Existing frosted-glass button is retained; only its active lighting is refined.
                  Positioned(
                    bottom: 0,
                    child: Container(
                      width: isEnd ? 74 : diameter,
                      height: isEnd ? 74 : diameter,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isEnd
                            ? const LinearGradient(
                                colors: [Color(0xFFFF5148), Color(0xFFE3262C)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              )
                            : const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [Color(0x99DCEBFA), Color(0x557F96AC), Color(0xAA34485B)],
                              ),
                        border: Border.all(
                          color: Colors.white.withOpacity(isEnd ? 0.24 : 0.52),
                          width: 1.25,
                        ),
                        boxShadow: [
                          BoxShadow(color: Colors.black.withOpacity(0.30), blurRadius: 16, offset: const Offset(0, 7)),
                          if (effectsOn)
                            BoxShadow(color: effectColor.withOpacity(isEnd ? 0.62 : 0.52), blurRadius: 19, spreadRadius: 2),
                          if (effectsOn)
                            BoxShadow(color: effectColor.withOpacity(0.28), blurRadius: 30, spreadRadius: 5),
                        ],
                      ),
                      child: ClipOval(
                        child: BackdropFilter(
                          filter: ui.ImageFilter.blur(sigmaX: 24, sigmaY: 24),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (!isEnd)
                                const DecoratedBox(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [Color(0x88FFFFFF), Color(0x26FFFFFF), Color(0x44304050)],
                                    ),
                                  ),
                                ),
                              Center(
                                child: Icon(
                                  icon,
                                  color: Colors.white,
                                  size: isEnd ? 38 : 33,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            label,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13.5, color: Colors.white, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // IN-CALL DIALPAD (Record, Hold, Add call, Mute, Video call, Summarise)
  // Exact 2x3 layout from Video (00:00 & 00:04)
  // =========================================================================
  Widget _buildSixButtonGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        children: [
          // Row 1: Record, Hold, Add call
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildCircleAction(
                icon: _isRecording ? Icons.fiber_manual_record : Icons.radio_button_checked,
                label: 'Record',
                isActive: _isRecording,
                activeColor: const Color(0xFFEF4444),
                onTap: _toggleRecord,
              ),
              _buildCircleAction(
                icon: _isOnHold ? Icons.play_arrow_rounded : Icons.pause_rounded,
                label: 'Hold',
                isActive: _isOnHold,
                activeColor: const Color(0xFFF59E0B),
                onTap: _toggleHold,
              ),
              _buildCircleAction(
                icon: Icons.add_rounded,
                label: 'Add call',
                onTap: _onAddCall,
              ),
            ],
          ),
          const SizedBox(height: 28),
          // Row 2: Mute, Video call, Summarise
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildCircleAction(
                icon: _isMuted ? Icons.mic_off_rounded : Icons.mic_none_rounded,
                label: 'Mute',
                isActive: _isMuted,
                activeColor: const Color(0xFFEF4444),
                onTap: _toggleMute,
              ),
              _buildCircleAction(
                icon: Icons.videocam_outlined,
                label: 'Video call',
                onTap: _onVideoCall,
              ),
              _buildCircleAction(
                icon: Icons.article_outlined,
                label: 'Summarise',
                isActive: _callNote.isNotEmpty,
                activeColor: const Color(0xFF38BDF8),
                onTap: _showInCallNoteDialog,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // BOTTOM 3 PRIMARY ACTIONS: Speaker, Red End Call, Dial pad (Exact Video Match)
  // =========================================================================
  Widget _buildBottomPrimaryActions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 36),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Speaker Button + Label (Left)
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: _toggleSpeaker,
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _isSpeaker ? Colors.white : const Color(0xFF222226),
                    border: Border.all(color: Colors.white.withOpacity(0.08), width: 1.2),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.volume_up_rounded,
                      color: _isSpeaker ? Colors.black : Colors.white,
                      size: 26,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Speaker',
                style: TextStyle(fontSize: 12, color: Color(0xFFD1D5DB), fontWeight: FontWeight.w500),
              ),
            ],
          ),

          // Red End Call Button + Label (Center - Larger Red Circle)
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: _hangupCall,
                borderRadius: BorderRadius.circular(36),
                child: Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFDC2626), // Solid Red
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFDC2626).withOpacity(0.4),
                        blurRadius: 18,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.call_end_rounded,
                      color: Colors.white,
                      size: 34,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'End',
                style: TextStyle(fontSize: 12, color: Color(0xFFD1D5DB), fontWeight: FontWeight.w500),
              ),
            ],
          ),

          // Dial pad Button + Label (Right - Toggles Keypad)
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _showDtmfPad = !_showDtmfPad);
                },
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _showDtmfPad ? Colors.white : const Color(0xFF222226),
                    border: Border.all(color: Colors.white.withOpacity(0.08), width: 1.2),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.dialpad_rounded,
                      color: _showDtmfPad ? Colors.black : Colors.white,
                      size: 26,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Dial pad',
                style: TextStyle(fontSize: 12, color: Color(0xFFD1D5DB), fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // IN-CALL DIALPAD (Exact Frame 00:01-00:03 from Video)
  // Full circular number keys sending DTMF tones
  // =========================================================================
  Widget _buildInCallDialpad() {
    final dialKeys = [
      {'digit': '1', 'letters': ''},
      {'digit': '2', 'letters': 'ABC'},
      {'digit': '3', 'letters': 'DEF'},
      {'digit': '4', 'letters': 'GHI'},
      {'digit': '5', 'letters': 'JKL'},
      {'digit': '6', 'letters': 'MNO'},
      {'digit': '7', 'letters': 'PQRS'},
      {'digit': '8', 'letters': 'TUV'},
      {'digit': '9', 'letters': 'WXYZ'},
      {'digit': '*', 'letters': ''},
      {'digit': '0', 'letters': '+'},
      {'digit': '#', 'letters': ''},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_dtmfHistory.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                _dtmfHistory,
                style: const TextStyle(fontSize: 20, color: Colors.white, fontFamily: 'monospace', letterSpacing: 2),
              ),
            ),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 12,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 16,
              crossAxisSpacing: 24,
              childAspectRatio: 1.0,
            ),
            itemBuilder: (ctx, idx) {
              final item = dialKeys[idx];
              final digit = item['digit']!;
              final letters = item['letters']!;

              return InkWell(
                onTap: () => _onPressDtmfDigit(digit),
                borderRadius: BorderRadius.circular(36),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF222226),
                    border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          digit,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        if (letters.isNotEmpty)
                          Text(
                            letters,
                            style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF9CA3AF),
                              letterSpacing: 0.8,
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // INCOMING CALL CONTROLS (Decline & Answer with SMS reply)
  // =========================================================================
  Widget _buildIncomingCallControls() {
    return Column(
      children: [
        TextButton.icon(
          onPressed: _showQuickSmsSheet,
          icon: const Icon(Icons.message_outlined, color: Colors.white70, size: 16),
          label: const Text(
            'Reply with message',
            style: TextStyle(color: Colors.white70, fontSize: 13),
          ),
        ),
        const SizedBox(height: 32),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Decline Button (Red)
              Column(
                children: [
                  InkWell(
                    onTap: _rejectCall,
                    borderRadius: BorderRadius.circular(36),
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFFDC2626),
                      ),
                      child: const Center(
                        child: Icon(Icons.call_end_rounded, color: Colors.white, size: 34),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Decline', style: TextStyle(color: Colors.white70, fontSize: 13)),
                ],
              ),

              // Answer Button (Green)
              Column(
                children: [
                  InkWell(
                    onTap: _answerCall,
                    borderRadius: BorderRadius.circular(36),
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF16A34A),
                      ),
                      child: const Center(
                        child: Icon(Icons.call_rounded, color: Colors.white, size: 34),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Answer', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  // =========================================================================
  // CALL ENDED SUMMARY
  // =========================================================================
  Widget _buildCallEndedSummary(String displayName) {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(24),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: const Color(0xFF18181C),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle_outline, color: Color(0xFF10B981), size: 48),
            const SizedBox(height: 12),
            const Text(
              'Call Ended',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white),
            ),
            const SizedBox(height: 6),
            Text(
              displayName,
              style: const TextStyle(fontSize: 16, color: Colors.white70),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                'Duration: ${_formatDuration(_durationSeconds)}',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF10B981)),
              ),
            ),
            if (_callNote.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                'Note: "$_callNote"',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Color(0xFF38BDF8), fontStyle: FontStyle.italic),
              ),
            ],
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildSummaryAction(
                  icon: Icons.chat_bubble_outline,
                  label: 'WhatsApp',
                  color: const Color(0xFF25D366),
                  onTap: () async {
                    final clean = widget.phoneNumber.replaceAll(RegExp(r'[^\d]'), '');
                    final uri = Uri.parse('https://wa.me/$clean');
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _buildSummaryAction(
                  icon: Icons.sms_outlined,
                  label: 'SMS',
                  color: const Color(0xFF38BDF8),
                  onTap: () async {
                    final uri = Uri(scheme: 'sms', path: widget.phoneNumber);
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _buildSummaryAction(
                  icon: Icons.block,
                  label: 'Block',
                  color: const Color(0xFFEF4444),
                  onTap: () {
                    BlockedNumbersService.blockNumber(widget.phoneNumber);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Blocked ${widget.phoneNumber}')),
                    );
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFDC2626),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () => Navigator.pop(context),
                child: const Text('Back to Dialer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryAction({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.15),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}
