import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/contact.dart';
import '../services/speed_dial_service.dart';
import '../widgets/settings_dialog.dart';

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> {
  String _digits = '';
  int _selectedSim = 1;

  final List<Map<String, String>> _speedDialFavorites = [
    {'label': 'Mom ❤️', 'number': '+91 98201 45892', 'color': '0xFFEC4899'},
    {'label': 'Sanib A.', 'number': '+91 97654 21980', 'color': '0xFF3B82F6'},
    {'label': 'Mo Faisal', 'number': '+91 98711 00982', 'color': '0xFF10B981'},
    {'label': 'Shivi 🦋', 'number': '+91 98450 11223', 'color': '0xFF8B5CF6'},
    {'label': '112 SOS', 'number': '112', 'color': '0xFFEF4444'},
  ];

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    HapticFeedback.lightImpact();
    setState(() {
      _digits += digit;
    });
  }

  void _onBackspace() {
    HapticFeedback.lightImpact();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    HapticFeedback.mediumImpact();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();
    // Restore the original light dialer appearance; other app screens stay unchanged.
    const isDarkTheme = false;
    const pageBg = Color(0xFFFFFFFF);
    const keyText = Color(0xFF161616);

    return Scaffold(
      backgroundColor: pageBg,
      body: Container(
        decoration: BoxDecoration(color: pageBg),
        child: SafeArea(
          bottom: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              final bool isCompact = screenHeight < 640;
              final double keyHeight = isCompact ? 60.0 : 72.0;
              final double keyWidth = keyHeight;
              final double rowSpacing = isCompact ? 8.0 : 12.0;
              final double callBtnHeight = isCompact ? 62.0 : 76.0;

              return Column(
                children: [
                  // Top-right settings only; SIM selector pills removed per request.
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: IconButton(
                        icon: Icon(Icons.settings_outlined, color: isDarkTheme ? Colors.white54 : Colors.black38, size: 20),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        onPressed: _openSettings,
                      ),
                    ),
                  ),

                  // 2. Flexible Display Area (Scales and scrolls gracefully so it never overflows)
                  Expanded(
                    child: Center(
                      child: SingleChildScrollView(
                        physics: const ClampingScrollPhysics(),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Clean dial-pad number placeholder, matching the supplied reference.
                            if (_digits.isEmpty) ...[
                              const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 16),
                                child: Text(
                                  'Enter number',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Color(0xFFD5D5D9),
                                    fontSize: 34,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ),
                            ] else ...[
                              // Typed Phone Number Display with auto-sizing
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 20),
                                child: FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Text(
                                    _digits,
                                    style: TextStyle(
                                      fontSize: isCompact ? 28 : 34,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 2,
                                      color: keyText,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 4),
                              // Matched Contact preview if any
                              if (matches.isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 24),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFE8F8F1),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: const Color(0xFF10B981).withOpacity(0.3)),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Icon(Icons.person, size: 14, color: Color(0xFF10B981)),
                                        const SizedBox(width: 6),
                                        Text(
                                          '${matches.first.name} • ${matches.first.number}',
                                          style: const TextStyle(
                                            color: Color(0xFF087F5B),
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),

                  // 3. Squircle Dialpad 4x3 Grid (Compact & Perfectly Spaced)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildSquircleRow(['1', '2', '3'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['4', '5', '6'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['7', '8', '9'], keyWidth, keyHeight),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['*', '0', '#'], keyWidth, keyHeight),
                      ],
                    ),
                  ),

                  SizedBox(height: rowSpacing + 4),

                  // 4. Guaranteed-Visible Call Action Row (Never sinks or hides!)
                  Padding(
                    padding: const EdgeInsets.only(left: 32, right: 32, bottom: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Left placeholder / spacer
                        const SizedBox(width: 48),

                        // Glowing Emerald Squircle Call CTA
                        InkWell(
                          onTap: () {
                            if (_digits.isNotEmpty) {
                              HapticFeedback.heavyImpact();
                              widget.onCallNumber(_digits);
                            }
                          },
                          borderRadius: BorderRadius.circular(50),
                          child: Container(
                            width: callBtnHeight,
                            height: callBtnHeight,
                            decoration: BoxDecoration(
                              color: const Color(0xFF19C45B),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF19C45B).withOpacity(0.18),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: const Center(
                              child: Icon(Icons.call, color: Colors.white, size: 26),
                            ),
                          ),
                        ),

                        // Squircle Backspace button
                        _digits.isNotEmpty
                            ? GestureDetector(
                                onTap: _onBackspace,
                                onLongPress: _onClearAll,
                                child: Container(
                                  width: 48,
                                  height: callBtnHeight,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFF5F5F7),
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(color: const Color(0xFFE8E8ED)),
                                  ),
                                  child: const Center(
                                    child: Icon(Icons.backspace_outlined, color: Colors.black87, size: 20),
                                  ),
                                ),
                              )
                            : const SizedBox(width: 48),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSimPill(int slot, String label) {
    final isSelected = _selectedSim == slot;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _selectedSim = slot);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981).withOpacity(0.2) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? const Color(0xFF10B981) : Colors.white12,
            width: isSelected ? 1.2 : 0.8,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? const Color(0xFF10B981) : Colors.white70,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildSquircleRow(List<String> keys, double width, double height) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: keys.map((k) => _buildSquircleButton(k, width, height)).toList(),
    );
  }

  Widget _buildSquircleButton(String key, double width, double height) {
    // Original light keypad buttons.
    const isDarkTheme = false;
    const keyBg = Colors.white;
    final sub = _t9Map[key] ?? '';
    return Material(
      color: Colors.transparent,
      shape: const CircleBorder(),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
      splashColor: const Color(0xFF19C45B).withOpacity(0.28),
      highlightColor: const Color(0xFF19C45B).withOpacity(0.12),
      splashFactory: InkRipple.splashFactory,
      onTap: () => _onDigitPress(key),
      onLongPress: () {
        if (key == '0') {
          _onDigitPress('+');
        } else if (key == '1') {
          HapticFeedback.heavyImpact();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Calling Voicemail (*123#)...')),
          );
          widget.onCallNumber('*123#');
        } else {
          final intKey = int.tryParse(key);
          if (intKey != null && intKey >= 2 && intKey <= 9) {
            final entry = SpeedDialService.getEntry(intKey);
            if (entry != null) {
              HapticFeedback.heavyImpact();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('⚡ Speed Dial #$intKey: Calling ${entry.name} (${entry.number})'),
                  duration: const Duration(seconds: 2),
                ),
              );
              widget.onCallNumber(entry.number);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Speed Dial key $intKey is not assigned yet. Set it in Settings!'),
                ),
              );
            }
          }
        }
      },
      borderRadius: BorderRadius.circular(50),
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: keyBg,
          shape: BoxShape.circle,
          border: Border.all(
            color: const Color(0xFFD0D2DA),
            width: 1.6,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              key,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w900,
                color: isDarkTheme ? Colors.white : const Color(0xFF171717),
                height: 1.1,
              ),
            ),
            if (sub.isNotEmpty)
              Text(
                sub,
                style: TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w600,
                  color: isDarkTheme ? Colors.white54 : const Color(0xFF8B8B93),
                  letterSpacing: 1.2,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
