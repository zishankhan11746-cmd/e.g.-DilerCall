import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'models/call_record.dart';
import 'models/contact.dart';
import 'screens/active_call_screen.dart';
import 'screens/stacked_recents_screen.dart';
import 'screens/t9_dialpad_screen.dart';
import 'screens/contacts_screen.dart';
import 'screens/insights_screen.dart';
import 'services/blocked_numbers_service.dart';
import 'services/speed_dial_service.dart';
import 'services/telecom_service.dart';
import 'services/theme_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0D0C11),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Initialize persistent services
  await SpeedDialService.init();
  await BlockedNumbersService.init();
  await DialerThemeService.init();

  runApp(const StackDialerApp());
}

class StackDialerApp extends StatelessWidget {
  const StackDialerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: DialerThemeService.isDark,
      builder: (context, isDark, _) {
        final base = ThemeData(brightness: isDark ? Brightness.dark : Brightness.light);
        return MaterialApp(
          title: 'StackDialer',
          debugShowCheckedModeBanner: false,
          theme: base.copyWith(
            scaffoldBackgroundColor: isDark ? const Color(0xFF141219) : const Color(0xFFF7F7FA),
            textTheme: GoogleFonts.plusJakartaSansTextTheme(base.textTheme),
            colorScheme: (isDark ? const ColorScheme.dark() : const ColorScheme.light()).copyWith(
              primary: const Color(0xFF10B981),
              surface: isDark ? const Color(0xFF1E1C25) : Colors.white,
            ),
          ),
          home: const MainDialerHost(),
        );
      },
    );
  }
}

class MainDialerHost extends StatefulWidget {
  const MainDialerHost({super.key});

  @override
  State<MainDialerHost> createState() => _MainDialerHostState();
}

class _MainDialerHostState extends State<MainDialerHost> with WidgetsBindingObserver {
  int _currentIndex = 0;
  List<CallRecord> _callLogs = [];
  List<ContactModel> _contacts = [];
  bool _isLoading = true;
  bool _hasActiveCallScreen = false;
  bool _isDefaultDialer = false;
  String? _incomingBannerNumber;
  String? _incomingBannerName;
  String? _activeCallBannerNumber;
  String? _activeCallBannerName;
  bool _activeCallBannerIsIncoming = false;
  final List<CallRecord> _recentDialedCalls = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initDeviceData();
    _checkDefaultDialer();
    _setupTelecomInCallListener();
    _checkPendingCall();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Whenever user returns from making a phone call or switching back,
      // reload live device call logs and update default dialer status!
      _checkDefaultDialer();
      _checkPendingCall();
      _refreshCallLogs();
    }
  }

  Future<void> _checkPendingCall() async {
    try {
      final pending = await TelecomService.getPendingIncomingCall();
      if (pending != null && mounted) {
        final number = pending['number'] ?? '';
        final state = pending['state'] ?? '';
        if (number.isNotEmpty && (state == 'RINGING' || state == 'ACTIVE')) {
          final matched = _findContact(number);
          setState(() {
            _incomingBannerNumber = number;
            _incomingBannerName = matched?.name ?? number;
          });
          _openIncomingCallScreen(number, matched?.name);
        }
      }
    } catch (_) {}
  }

  Future<void> _checkDefaultDialer() async {
    try {
      final isDef = await TelecomService.isDefaultDialer();
      if (mounted) {
        setState(() => _isDefaultDialer = isDef);
      }
    } catch (_) {}
  }

  void _setupTelecomInCallListener() {
    TelecomService.setupCallListener((number, state) {
      if (!mounted) return;
      final matched = _findContact(number);
      if (state == 'RINGING') {
        setState(() {
          _incomingBannerNumber = number;
          _incomingBannerName = matched?.name ?? number;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
        _openIncomingCallScreen(number, matched?.name);
      } else if (state == 'ACTIVE') {
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = number;
          _activeCallBannerName = matched?.name ?? number;
        });
        if (!_hasActiveCallScreen) {
          _openIncomingCallScreen(number, matched?.name);
        }
      } else if (state == 'DISCONNECTED' || state == 'IDLE') {
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
        // Call ended, refresh live device call log after slight buffer for Android CallLog provider to sync!
        Future.delayed(const Duration(milliseconds: 700), () {
          if (mounted) _refreshCallLogs();
        });
      }
    });
  }

  Future<void> _initDeviceData() async {
    setState(() => _isLoading = true);
    await TelecomService.requestPermissions();
    final logs = await TelecomService.fetchDeviceCallLogs();
    final contacts = await TelecomService.fetchDeviceContacts();
    if (mounted) {
      setState(() {
        _callLogs = _mergeCalls(logs, _recentDialedCalls);
        _contacts = contacts;
        _isLoading = false;
      });
    }
  }

  Future<void> _refreshCallLogs() async {
    try {
      final logs = await TelecomService.fetchDeviceCallLogs();
      if (mounted) {
        setState(() {
          _callLogs = _mergeCalls(logs, _recentDialedCalls);
        });
      }
    } catch (_) {}
  }

  List<CallRecord> _mergeCalls(List<CallRecord> deviceLogs, List<CallRecord> localCalls) {
    final Map<String, CallRecord> map = {};
    // Add local calls first
    for (final c in localCalls) {
      map['${c.number}_${c.timestamp.millisecondsSinceEpoch ~/ 30000}'] = c;
    }
    // Add or override with real device logs
    for (final c in deviceLogs) {
      map['${c.number}_${c.timestamp.millisecondsSinceEpoch ~/ 30000}'] = c;
    }
    final merged = map.values.toList();
    merged.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    return merged;
  }

  ContactModel? _findContact(String number) {
    final clean = number.replaceAll(RegExp(r'[^\d]'), '');
    if (clean.isEmpty) return null;
    return _contacts.cast<ContactModel?>().firstWhere(
          (c) => c != null && c.number.replaceAll(RegExp(r'[^\d]'), '').endsWith(clean),
          orElse: () => null,
        );
  }

  void _openIncomingCallScreen(String number, [String? name]) {
    if (_hasActiveCallScreen) return;
    _hasActiveCallScreen = true;
    final matched = _findContact(number);

    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 300),
        pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
          phoneNumber: number,
          contactName: name ?? matched?.name,
          callerCategory: 'Incoming Call',
          isIncoming: true,
          simSlot: 1,
          onCallEnded: (record) {
            _hasActiveCallScreen = false;
            setState(() {
              _recentDialedCalls.insert(0, record);
              _callLogs = _mergeCalls(_callLogs, _recentDialedCalls);
            });
            Future.delayed(const Duration(milliseconds: 700), () {
              if (mounted) _refreshCallLogs();
            });
          },
        ),
      ),
    ).then((_) {
      _hasActiveCallScreen = false;
    });
  }

  void _onCallNumber(String number, {int simSlot = 1}) async {
    HapticFeedback.heavyImpact();
    final clean = number.replaceAll(RegExp(r'[^\d+*#]'), '');
    if (clean.isEmpty) return;

    final matched = _findContact(clean);

    // 1. Immediately create a real CallRecord and insert it at the TOP of recent calls
    final newOutgoingRecord = CallRecord(
      id: 'call_${DateTime.now().millisecondsSinceEpoch}',
      name: matched?.name ?? clean,
      number: clean,
      type: CallType.outgoing,
      timestamp: DateTime.now(),
      durationSeconds: 0,
      simSlot: simSlot,
      simCarrier: 'SIM $simSlot',
      category: matched?.company ?? 'Personal',
      location: 'Mobile Outgoing',
    );

    setState(() {
      _recentDialedCalls.insert(0, newOutgoingRecord);
      _callLogs.insert(0, newOutgoingRecord);
    });

    // 2. Launch real native SIM call via Android Carrier
    await TelecomService.makeRealCall(clean);

    // 3. Immediately present the executive Outgoing ActiveCallScreen
    if (!_hasActiveCallScreen) {
      _hasActiveCallScreen = true;
      if (mounted) {
        Navigator.of(context).push(
          PageRouteBuilder(
            opaque: true,
            transitionDuration: const Duration(milliseconds: 300),
            pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
              phoneNumber: clean,
              contactName: matched?.name,
              callerCategory: matched?.company ?? 'Mobile',
              isIncoming: false,
              simSlot: simSlot,
              onCallEnded: (record) {
                _hasActiveCallScreen = false;
                setState(() {
                  _recentDialedCalls.insert(0, record);
                  _callLogs = _mergeCalls(_callLogs, _recentDialedCalls);
                });
                Future.delayed(const Duration(milliseconds: 700), () {
                  if (mounted) _refreshCallLogs();
                });
              },
            ),
          ),
        ).then((_) {
          _hasActiveCallScreen = false;
        });
      }
    }
  }

  void _onSimulateIncomingCall() {
    HapticFeedback.mediumImpact();
    final demoNumbers = [
      {'num': '+91 98201 45892', 'name': 'Mom ❤️'},
      {'num': '+91 97654 21980', 'name': 'Sanib Ansari'},
      {'num': '+91 14092 10000', 'name': 'Suspected Spam'},
    ];
    final selected = (demoNumbers..shuffle()).first;

    // Trigger native notification banner
    TelecomService.showIncomingBanner(selected['num']!, selected['name']);

    setState(() {
      _incomingBannerNumber = selected['num'];
      _incomingBannerName = selected['name'];
    });

    _openIncomingCallScreen(selected['num']!, selected['name']);
  }

  @override
  Widget build(BuildContext context) {
    final isDarkTheme = DialerThemeService.isDark.value;
    return Scaffold(
      backgroundColor: isDarkTheme ? const Color(0xFF141219) : const Color(0xFFF7F7FA),
      body: Stack(
        children: [
          _isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Color(0xFF10B981),
                  ),
                )
              : Column(
                  children: [
                    // Default dialer alert banner if not set
                    if (!_isDefaultDialer)
                      SafeArea(
                        bottom: false,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          color: isDarkTheme ? const Color(0xFF10B981).withOpacity(0.12) : const Color(0xFFE7F8F1),
                          child: Row(
                            children: [
                              const Icon(Icons.shield_outlined, color: Color(0xFF10B981), size: 16),
                              const SizedBox(width: 8),
                              const Expanded(
                                child: Text(
                                  'Set StackDialer as Default Phone App for full lock-screen UI',
                                  style: TextStyle(color: isDarkTheme ? Colors.white70 : const Color(0xFF55545D), fontSize: 11),
                                ),
                              ),
                              InkWell(
                                onTap: () async {
                                  await TelecomService.requestDefaultDialer();
                                  Future.delayed(const Duration(seconds: 1), _checkDefaultDialer);
                                },
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'Set Default',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    Expanded(
                      child: IndexedStack(
                        index: _currentIndex,
                        children: [
                          StackedRecentsScreen(
                            calls: _callLogs,
                            onRefresh: _refreshCallLogs,
                            onCallNumber: _onCallNumber,
                            onSimulateIncoming: _onSimulateIncomingCall,
                          ),
                          T9DialpadScreen(
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                            onSimulateIncoming: _onSimulateIncomingCall,
                          ),
                          ContactsScreen(
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                          ),
                          InsightsScreen(
                            calls: _callLogs,
                            onCallNumber: _onCallNumber,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

          // 1. Floating Incoming Call Heads-Up Banner at top of the app
          if (_incomingBannerNumber != null)
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 14,
              right: 14,
              child: Material(
                elevation: 24,
                borderRadius: BorderRadius.circular(20),
                color: const Color(0xFF1F1D2B),
                child: InkWell(
                  onTap: () => _openIncomingCallScreen(_incomingBannerNumber!, _incomingBannerName),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF10B981), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF10B981).withOpacity(0.35),
                          blurRadius: 20,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.call_received, color: Color(0xFF10B981), size: 24),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                _incomingBannerName ?? _incomingBannerNumber!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              Text(
                                'Incoming Call... • ${_incomingBannerNumber!}',
                                style: const TextStyle(
                                  color: Color(0xFF10B981),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Reject Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.rejectCall();
                            await TelecomService.cancelIncomingBanner();
                            setState(() {
                              _incomingBannerNumber = null;
                              _incomingBannerName = null;
                            });
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFFEF4444),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call_end, color: Colors.white, size: 18),
                          ),
                        ),
                        // Answer Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.answerCall();
                            await TelecomService.cancelIncomingBanner();
                            final num = _incomingBannerNumber!;
                            final name = _incomingBannerName;
                            setState(() {
                              _incomingBannerNumber = null;
                              _incomingBannerName = null;
                            });
                            _openIncomingCallScreen(num, name);
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFF10B981),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call, color: Colors.white, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          // 2. Floating Active / Outgoing Call Minimized Banner
          if (_activeCallBannerNumber != null && _incomingBannerNumber == null)
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 14,
              right: 14,
              child: Material(
                elevation: 20,
                borderRadius: BorderRadius.circular(20),
                color: const Color(0xFF171E28),
                child: InkWell(
                  onTap: () => _openIncomingCallScreen(_activeCallBannerNumber!, _activeCallBannerName),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF38BDF8).withOpacity(0.6), width: 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF38BDF8).withOpacity(0.2),
                          blurRadius: 16,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.phone_in_talk, color: Color(0xFF10B981), size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                _activeCallBannerName ?? _activeCallBannerNumber!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              Row(
                                children: [
                                  Container(
                                    width: 6,
                                    height: 6,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFF10B981),
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 5),
                                  const Text(
                                    'Call in Progress • Tap to return',
                                    style: TextStyle(
                                      color: Color(0xFF38BDF8),
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        // End Call Red Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.disconnectCall();
                            await TelecomService.cancelIncomingBanner();
                            setState(() {
                              _activeCallBannerNumber = null;
                              _activeCallBannerName = null;
                            });
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(7),
                            decoration: const BoxDecoration(
                              color: Color(0xFFEF4444),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call_end, color: Colors.white, size: 16),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          decoration: BoxDecoration(
            color: isDarkTheme ? (_currentIndex == 1 ? Colors.white : const Color(0xFF121017).withOpacity(0.96)) : const Color(0xFFF7F7FA),
            border: Border(
              top: BorderSide(color: isDarkTheme && _currentIndex != 1 ? Colors.white10 : const Color(0xFFE8E8ED), width: 0.5),
            ),
          ),
          child: BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: (i) {
              HapticFeedback.selectionClick();
              setState(() => _currentIndex = i);
            },
            backgroundColor: Colors.transparent,
            elevation: 0,
            type: BottomNavigationBarType.fixed,
            selectedItemColor: const Color(0xFF10B981),
            unselectedItemColor: isDarkTheme && _currentIndex != 1 ? Colors.white38 : const Color(0xFF8B8B93),
            selectedFontSize: 11,
            unselectedFontSize: 11,
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.layers_outlined),
                activeIcon: Icon(Icons.layers),
                label: 'Recents',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.dialpad_outlined),
                activeIcon: Icon(Icons.dialpad),
                label: 'Keypad',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.contacts_outlined),
                activeIcon: Icon(Icons.contacts),
                label: 'Contacts',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.analytics_outlined),
                activeIcon: Icon(Icons.analytics),
                label: 'Insights',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
