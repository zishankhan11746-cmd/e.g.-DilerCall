import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'call_data_service.dart';

class ContactPhotoService {
  static const String preferenceKey = 'stackdialer_shared_contact_photos_v1';
  static final ValueNotifier<Map<String, String>> photosNotifier = ValueNotifier({});

  static Future<Map<String, String>> loadAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(preferenceKey);
    if (raw == null || raw.isEmpty) { photosNotifier.value = {}; return {}; }
    try {
      final photos = Map<String, dynamic>.from(jsonDecode(raw) as Map)
          .map((key, value) => MapEntry(key, value.toString()));
      photosNotifier.value = photos;
      return photos;
    } catch (_) {
      photosNotifier.value = {};
      return {};
    }
  }

  static Future<String?> loadForNumber(String number) async {
    final photos = await loadAll();
    return photos[CallDataService.normalizeNumber(number)];
  }

  static Future<void> saveForNumber(String number, String base64Image) async {
    final photos = await loadAll();
    photos[CallDataService.normalizeNumber(number)] = base64Image;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(preferenceKey, jsonEncode(photos));
    photosNotifier.value = photos;
  }
}
