import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/contact.dart';
import '../services/speed_dial_service.dart';
import '../widgets/settings_dialog.dart';

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> {
  String _digits = '';
  int _selectedSim = 1;

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    HapticFeedback.lightImpact();
    setState(() {
      _digits += digit;
    });
  }

  void _onBackspace() {
    HapticFeedback.lightImpact();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    HapticFeedback.mediumImpact();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    return Scaffold(
      backgroundColor: const Color(0xFF131316),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF16161A),
              Color(0xFF111114),
            ],
          ),
        ),
        child: SafeArea(
          bottom: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              // Realme UI 7.0 circular button sizing
              final double keyDiameter = screenHeight < 600 ? 58.0 : (screenHeight < 700 ? 66.0 : 74.0);
              final double rowSpacing = screenHeight < 600 ? 8.0 : (screenHeight < 700 ? 12.0 : 14.0);
              final double callBtnHeight = screenHeight < 600 ? 62.0 : (screenHeight < 700 ? 70.0 : 76.0);

              return Column(
                children: [
                  const SizedBox(height: 6),

                  // Top Status / Action Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // SIM Selector Switch
                        Row(
                          children: [
                            _buildSimPill(1, 'SIM 1'),
                            const SizedBox(width: 8),
                            _buildSimPill(2, 'SIM 2'),
                          ],
                        ),
                        // Settings Button
                        IconButton(
                          icon: const Icon(Icons.tune_rounded, color: Colors.white70, size: 20),
                          tooltip: 'Dialer Settings',
                          onPressed: _openSettings,
                        ),
                      ],
                    ),
                  ),

                  // Number display with Realme fluid typography
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: _digits.isEmpty
                            ? const FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  'Dial number',
                                  style: TextStyle(
                                    fontSize: 38,
                                    fontWeight: FontWeight.w400,
                                    letterSpacing: 0.5,
                                    color: Color(0xFF555460),
                                  ),
                                ),
                              )
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: AnimatedDefaultTextStyle(
                                      duration: const Duration(milliseconds: 150),
                                      style: const TextStyle(
                                        fontSize: 40,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 2.0,
                                        color: Colors.white,
                                        fontFamily: 'monospace',
                                      ),
                                      child: Text(_digits),
                                    ),
                                  ),
                                  if (matches.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.06),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(color: Colors.white12),
                                      ),
                                      child: Text(
                                        '${matches.first.name} • ${matches.first.number}',
                                        style: const TextStyle(color: Color(0xFF34D399), fontSize: 13, fontWeight: FontWeight.w500),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                      ),
                    ),
                  ),

                  // Realme UI 7.0 4x3 Circular Keypad
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildKeyRow(['1', '2', '3'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['4', '5', '6'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['7', '8', '9'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['*', '0', '#'], keyDiameter),
                      ],
                    ),
                  ),

                  SizedBox(height: rowSpacing + 6),

                  // Bottom Action Row: Call CTA and Backspace
                  Padding(
                    padding: const EdgeInsets.only(left: 32, right: 32, bottom: 12),
                    child: SizedBox(
                      height: callBtnHeight,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Centered Call Button with Realme UI 7.0 elastic press
                          RealmeActionButton(
                            size: callBtnHeight,
                            color: const Color(0xFF00C853),
                            shadowColor: const Color(0xFF00E676).withOpacity(0.4),
                            onTap: () {
                              if (_digits.isNotEmpty) {
                                HapticFeedback.heavyImpact();
                                widget.onCallNumber(_digits);
                              }
                            },
                            child: const Icon(Icons.call_rounded, color: Colors.white, size: 32),
                          ),

                          // Backspace Button on Right
                          if (_digits.isNotEmpty)
                            Align(
                              alignment: Alignment.centerRight,
                              child: RealmeActionButton(
                                size: 54,
                                color: const Color(0xFF26262B),
                                borderColor: const Color(0xFF38383F),
                                onTap: _onBackspace,
                                onLongPress: _onClearAll,
                                child: const Icon(Icons.backspace_outlined, color: Colors.white70, size: 22),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSimPill(int slot, String label) {
    final isSelected = _selectedSim == slot;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _selectedSim = slot);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981).withOpacity(0.2) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? const Color(0xFF10B981) : Colors.white12,
            width: isSelected ? 1.4 : 0.8,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected ? const Color(0xFF10B981) : Colors.white38,
                boxShadow: isSelected
                    ? [const BoxShadow(color: Color(0xFF10B981), blurRadius: 6, spreadRadius: 1)]
                    : null,
              ),
            ),
            const SizedBox(width: 5),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? const Color(0xFF10B981) : Colors.white70,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildKeyRow(List<String> keys, double diameter) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: keys.map((k) => RealmeDialKey(
        digit: k,
        subLetters: _t9Map[k] ?? '',
        size: diameter,
        onTap: () => _onDigitPress(k),
        onLongPress: () {
          if (k == '0') {
            _onDigitPress('+');
          } else if (k == '1') {
            HapticFeedback.heavyImpact();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Calling Voicemail (*123#)...')),
            );
            widget.onCallNumber('*123#');
          } else {
            final intKey = int.tryParse(k);
            if (intKey != null && intKey >= 2 && intKey <= 9) {
              final entry = SpeedDialService.getEntry(intKey);
              if (entry != null) {
                HapticFeedback.heavyImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('⚡ Speed Dial #$intKey: Calling ${entry.name} (${entry.number})'),
                    duration: const Duration(seconds: 2),
                  ),
                );
                widget.onCallNumber(entry.number);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Speed Dial key $intKey is not assigned yet. Set it in Settings!'),
                  ),
                );
              }
            }
          }
        },
      )).toList(),
    );
  }
}

/// Realme UI 7.0 Circular Number Key with Fluid Elastic Tap Compression (scale 0.88)
/// and Radial Flash Glow Animation cloned from the reference calculator video.
class RealmeDialKey extends StatefulWidget {
  final String digit;
  final String subLetters;
  final double size;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const RealmeDialKey({
    super.key,
    required this.digit,
    required this.subLetters,
    required this.size,
    required this.onTap,
    this.onLongPress,
  });

  @override
  State<RealmeDialKey> createState() => _RealmeDialKeyState();
}

class _RealmeDialKeyState extends State<RealmeDialKey> with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _flashAnimation;
  bool _isDown = false;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 140),
      reverseDuration: const Duration(milliseconds: 220),
    );

    // Elastic squash down to 0.88 scale on tap (Realme UI 7.0 Calculator animation)
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.88).animate(
      CurvedAnimation(
        parent: _animController,
        curve: Curves.easeOutCubic,
        reverseCurve: Curves.easeOutBack,
      ),
    );

    // Radial highlight flash
    _flashAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animController,
        curve: Curves.easeOutQuad,
        reverseCurve: Curves.easeInQuad,
      ),
    );
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails details) {
    _isDown = true;
    _animController.forward();
    HapticFeedback.selectionClick();
  }

  void _handleTapUp(TapUpDetails details) {
    if (_isDown) {
      _isDown = false;
      _animController.reverse();
      widget.onTap();
    }
  }

  void _handleTapCancel() {
    if (_isDown) {
      _isDown = false;
      _animController.reverse();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _handleTapDown,
      onTapUp: _handleTapUp,
      onTapCancel: _handleTapCancel,
      onLongPress: widget.onLongPress,
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _animController,
        builder: (context, child) {
          final scale = _scaleAnimation.value;
          final flash = _flashAnimation.value;

          return Transform.scale(
            scale: scale,
            alignment: Alignment.center,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                // Realme UI 7.0 matte charcoal gradient with illuminated flash on press
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 0.85,
                  colors: [
                    Color.lerp(const Color(0xFF2E2E33), const Color(0xFF5A5A63), flash)!,
                    Color.lerp(const Color(0xFF222226), const Color(0xFF38383E), flash)!,
                  ],
                ),
                border: Border.all(
                  color: Color.lerp(const Color(0xFF38383F), const Color(0xFF888894), flash)!,
                  width: 0.9 + (flash * 0.6),
                ),
                boxShadow: flash > 0.05
                    ? [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.18 * flash),
                          blurRadius: 18 * flash,
                          spreadRadius: 2 * flash,
                        ),
                        BoxShadow(
                          color: const Color(0xFF5A5A63).withOpacity(0.4 * flash),
                          blurRadius: 8 * flash,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.35),
                          offset: const Offset(0, 4),
                          blurRadius: 8,
                        ),
                      ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    widget.digit,
                    style: TextStyle(
                      fontSize: widget.size >= 72 ? 32 : (widget.size >= 64 ? 28 : 24),
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                      height: 1.05,
                    ),
                  ),
                  if (widget.subLetters.isNotEmpty) ...[
                    const SizedBox(height: 1),
                    Text(
                      widget.subLetters,
                      style: TextStyle(
                        fontSize: widget.size >= 72 ? 11 : 9.5,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF8E8E98),
                        letterSpacing: 1.6,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Realme UI 7.0 Circular Action Button (Call / Backspace) with matching 0.88 squash
class RealmeActionButton extends StatefulWidget {
  final double size;
  final Color color;
  final Color? borderColor;
  final Color? shadowColor;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final Widget child;

  const RealmeActionButton({
    super.key,
    required this.size,
    required this.color,
    this.borderColor,
    this.shadowColor,
    required this.onTap,
    this.onLongPress,
    required this.child,
  });

  @override
  State<RealmeActionButton> createState() => _RealmeActionButtonState();
}

class _RealmeActionButtonState extends State<RealmeActionButton> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _isDown = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 140),
      reverseDuration: const Duration(milliseconds: 220),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.88).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOutCubic,
        reverseCurve: Curves.easeOutBack,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        _isDown = true;
        _controller.forward();
      },
      onTapUp: (_) {
        if (_isDown) {
          _isDown = false;
          _controller.reverse();
          widget.onTap();
        }
      },
      onTapCancel: () {
        if (_isDown) {
          _isDown = false;
          _controller.reverse();
        }
      },
      onLongPress: widget.onLongPress,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            alignment: Alignment.center,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.color,
                border: widget.borderColor != null ? Border.all(color: widget.borderColor!, width: 1.2) : null,
                boxShadow: [
                  BoxShadow(
                    color: widget.shadowColor ?? Colors.black.withOpacity(0.3),
                    blurRadius: 18,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Center(child: widget.child),
            ),
          );
        },
      ),
    );
  }
}
