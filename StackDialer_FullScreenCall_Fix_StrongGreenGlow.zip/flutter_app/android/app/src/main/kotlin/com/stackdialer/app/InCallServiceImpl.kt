package com.stackdialer.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile

class InCallServiceImpl : InCallService() {

    companion object {
        var instance: InCallServiceImpl? = null
        var currentCall: Call? = null
        var onCallStateChangedListener: ((String, String, Int) -> Unit)? = null

        fun answerCurrentCall() {
            currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }

        fun rejectCurrentCall() {
            currentCall?.reject(false, null)
        }

        fun disconnectCurrentCall() {
            stopDurationTicker()
            currentCall?.disconnect()
        }

        private var durationTimerHandler: Handler? = null
        private var durationTimerRunnable: Runnable? = null

        fun startDurationTicker(context: Context, number: String) {
            stopDurationTicker()
            durationTimerHandler = Handler(Looper.getMainLooper())
            durationTimerRunnable = object : Runnable {
                override fun run() {
                    val call = currentCall
                    if (call != null && (call.state == Call.STATE_ACTIVE || call.state == Call.STATE_DIALING || call.state == Call.STATE_CONNECTING || call.state == Call.STATE_HOLDING)) {
                        val isSpeaker = instance?.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
                        val isMuted = instance?.callAudioState?.isMuted == true
                        val notif = MainActivity.buildOngoingCallNotification(context, number, null, false, isMuted, isSpeaker)
                        if (notif != null && instance != null) {
                            try {
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                                    instance?.startForeground(MainActivity.ONGOING_NOTIFICATION_ID, notif, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
                                } else {
                                    instance?.startForeground(MainActivity.ONGOING_NOTIFICATION_ID, notif)
                                }
                            } catch (_: Throwable) {
                                MainActivity.showOngoingCallNotification(context, number, null, false, isMuted, isSpeaker)
                            }
                        } else {
                            MainActivity.showOngoingCallNotification(context, number, null, false, isMuted, isSpeaker)
                        }
                        durationTimerHandler?.postDelayed(this, 1000)
                    } else {
                        stopDurationTicker()
                    }
                }
            }
            durationTimerRunnable?.let { durationTimerHandler?.postDelayed(it, 1000) }
        }

        fun stopDurationTicker() {
            durationTimerRunnable?.let { durationTimerHandler?.removeCallbacks(it) }
            durationTimerHandler = null
            durationTimerRunnable = null
        }

        fun holdCurrentCall(hold: Boolean) {
            if (hold) {
                currentCall?.hold()
            } else {
                currentCall?.unhold()
            }
        }

        fun setSpeaker(context: Context?, enabled: Boolean) {
            // 1. Android Telecom InCallService Audio Route
            try {
                instance?.setAudioRoute(if (enabled) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // 2. Hardware AudioManager Fallback
            try {
                val ctx = context ?: instance
                if (ctx != null) {
                    val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    audioManager?.let { am ->
                        am.mode = AudioManager.MODE_IN_COMMUNICATION
                        am.isSpeakerphoneOn = enabled
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun setMuted(context: Context?, muted: Boolean) {
            try {
                instance?.setMuted(muted)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                val ctx = context ?: instance
                if (ctx != null) {
                    val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    audioManager?.let { am ->
                        am.isMicrophoneMute = muted
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun playDtmf(digit: Char) {
            currentCall?.playDtmfTone(digit)
        }

        fun stopDtmf() {
            currentCall?.stopDtmfTone()
        }
    }

    private fun promoteCallNotificationToForeground(number: String) {
        val audio = callAudioState
        val notification = MainActivity.buildOngoingCallNotification(
            this,
            number,
            null,
            false,
            audio?.isMuted == true,
            audio?.route == CallAudioState.ROUTE_SPEAKER
        ) ?: return
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    MainActivity.ONGOING_NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
                )
            } else {
                startForeground(MainActivity.ONGOING_NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            // Telecom still owns the call if the OS disallows foreground promotion.
            MainActivity.showOngoingCallNotification(this, number, null, false, audio?.isMuted == true, audio?.route == CallAudioState.ROUTE_SPEAKER)
        }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        instance = this
        currentCall = call
        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        val state = call.state
        val isOutgoing = call.details?.callDirection == Call.Details.DIRECTION_OUTGOING ||
                         state == Call.STATE_DIALING ||
                         state == Call.STATE_CONNECTING

        // Foreground presentation is driven by the high-priority Telecom call notification
        // and its full-screen PendingIntent. Avoid launching an Activity directly from the
        // background, which can race Samsung's Telecom UI and create duplicate screens.

        if (state == Call.STATE_RINGING && !isOutgoing) {
            MainActivity.showIncomingCallBanner(this, number, null)
        } else if (state == Call.STATE_DIALING || state == Call.STATE_CONNECTING || state == Call.STATE_ACTIVE || (state == Call.STATE_RINGING && isOutgoing)) {
            MainActivity.cancelIncomingCallBanner(this)
            MainActivity.restoreCallConnectedAt(this)
            if (state == Call.STATE_ACTIVE && MainActivity.callStartTimeMillis == 0L) {
                val connectedAt = call.details?.connectTimeMillis ?: 0L
                MainActivity.setCallConnectedAt(this, connectedAt.takeIf { it > 0L } ?: System.currentTimeMillis())
            }
            promoteCallNotificationToForeground(number)
            startDurationTicker(this, number)
        }

        notifyState(number, state)

        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                super.onStateChanged(call, state)
                val num = call.details?.handle?.schemeSpecificPart ?: "Unknown"
                val callIsOutgoing = call.details?.callDirection == Call.Details.DIRECTION_OUTGOING ||
                                     state == Call.STATE_DIALING ||
                                     state == Call.STATE_CONNECTING

                if (state == Call.STATE_RINGING && !callIsOutgoing) {
                    MainActivity.showIncomingCallBanner(this@InCallServiceImpl, num, null)
                } else if (state == Call.STATE_ACTIVE || state == Call.STATE_HOLDING || state == Call.STATE_DIALING || state == Call.STATE_CONNECTING || (state == Call.STATE_RINGING && callIsOutgoing)) {
                    MainActivity.cancelIncomingCallBanner(this@InCallServiceImpl)
                    MainActivity.restoreCallConnectedAt(this@InCallServiceImpl)
                    if (state == Call.STATE_ACTIVE && MainActivity.callStartTimeMillis == 0L) {
                        val connectedAt = call.details?.connectTimeMillis ?: 0L
                        MainActivity.setCallConnectedAt(this@InCallServiceImpl, connectedAt.takeIf { it > 0L } ?: System.currentTimeMillis())
                    }
                    promoteCallNotificationToForeground(num)
                    startDurationTicker(this@InCallServiceImpl, num)
                } else if (state == Call.STATE_DISCONNECTED) {
                    stopDurationTicker()
                    try {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            stopForeground(STOP_FOREGROUND_REMOVE)
                        } else {
                            @Suppress("DEPRECATION")
                            stopForeground(true)
                        }
                    } catch (_: Exception) {}
                    MainActivity.cancelIncomingCallBanner(this@InCallServiceImpl)
                    MainActivity.cancelOngoingCallNotification(this@InCallServiceImpl)
                    MainActivity.clearCallConnectedAt(this@InCallServiceImpl)
                }
                notifyState(num, state)
            }
        })
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        if (audioState != null) {
            val isSpeaker = audioState.route == CallAudioState.ROUTE_SPEAKER
            val isMuted = audioState.isMuted
            val num = currentCall?.details?.handle?.schemeSpecificPart ?: "Unknown"
            if (currentCall != null && currentCall?.state != Call.STATE_DISCONNECTED) {
                MainActivity.showOngoingCallNotification(this, num, null, false, isMuted, isSpeaker)
            }
            Handler(Looper.getMainLooper()).post {
                MainActivity.notifyAudioState(isSpeaker, isMuted)
            }
        }
    }

    private fun notifyState(number: String, state: Int) {
        Handler(Looper.getMainLooper()).post {
            onCallStateChangedListener?.invoke(number, getStateString(state), state)
        }
    }

    private fun getStateString(state: Int): String {
        return when (state) {
            Call.STATE_RINGING -> "RINGING"
            Call.STATE_DIALING -> "DIALING"
            Call.STATE_ACTIVE -> "ACTIVE"
            Call.STATE_HOLDING -> "HOLDING"
            Call.STATE_DISCONNECTED -> "DISCONNECTED"
            else -> "UNKNOWN"
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        stopDurationTicker()
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (_: Exception) {}
        if (currentCall == call) {
            currentCall = null
        }
        MainActivity.cancelIncomingCallBanner(this)
        MainActivity.cancelOngoingCallNotification(this)
        MainActivity.clearCallConnectedAt(this)
        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        notifyState(number, Call.STATE_DISCONNECTED)
    }
}
