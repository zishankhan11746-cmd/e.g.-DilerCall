package com.stackdialer.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.graphics.Color
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.stackdialer.app/telecom"
    private val REQUEST_ID_SET_DEFAULT_DIALER = 1001
    private var dialToneGenerator: ToneGenerator? = null

    companion object {
        const val CHANNEL_ID = "stackdialer_incoming_calls_silent"
        const val NOTIFICATION_ID = 2001
        var methodChannel: MethodChannel? = null
        var pendingCallNumber: String? = null
        var pendingCallState: String? = null

        fun notifyCallState(number: String, state: String) {
            pendingCallNumber = number
            pendingCallState = state
            if (state == "DISCONNECTED" || state == "IDLE") {
                // Clear pending call state once disconnected
                pendingCallNumber = null
                pendingCallState = null
            }
            methodChannel?.invokeMethod("onCallStateChanged", mapOf(
                "number" to number,
                "state" to state
            ))
        }

        fun notifyAudioState(isSpeaker: Boolean, isMuted: Boolean) {
            methodChannel?.invokeMethod("onAudioStateChanged", mapOf(
                "isSpeaker" to isSpeaker,
                "isMuted" to isMuted
            ))
        }

        fun showIncomingCallBanner(context: Context, number: String, name: String?) {
            try {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        "StackDialer Incoming Calls (Silent Alert)",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "Silent incoming-call controls; ringtone is handled by Android Telecom"
                        enableLights(true)
                        enableVibration(false)
                        setSound(null, null)
                        lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                    }
                    notificationManager.createNotificationChannel(channel)
                }

                // Full screen intent to bring StackDialer to front (works even on locked screen)
                val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
                    action = Intent.ACTION_MAIN
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("incoming_number", number)
                    putExtra("incoming_name", name ?: number)
                }

                val fullScreenPendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    fullScreenIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // Answer Action PendingIntent
                val answerIntent = Intent(context, CallActionReceiver::class.java).apply {
                    action = CallActionReceiver.ACTION_ANSWER
                    putExtra("number", number)
                }
                val answerPendingIntent = PendingIntent.getBroadcast(
                    context,
                    1,
                    answerIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // Reject Action PendingIntent
                val rejectIntent = Intent(context, CallActionReceiver::class.java).apply {
                    action = CallActionReceiver.ACTION_REJECT
                    putExtra("number", number)
                }
                val rejectPendingIntent = PendingIntent.getBroadcast(
                    context,
                    2,
                    rejectIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val displayName = if (!name.isNullOrBlank()) name else number
                val contentText = if (!name.isNullOrBlank()) "Incoming call • $number" else "Incoming Cellular Call..."
                val appIcon = context.applicationInfo.icon.takeIf { it != 0 } ?: android.R.drawable.sym_call_incoming

                val person = androidx.core.app.Person.Builder()
                    .setName(displayName)
                    .setImportant(true)
                    .build()

                val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(appIcon)
                    .setContentTitle(displayName)
                    .setContentText(contentText)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setAutoCancel(false)
                    .setOngoing(true)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setFullScreenIntent(fullScreenPendingIntent, true)
                    .setContentIntent(fullScreenPendingIntent)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        builder.setStyle(
                            NotificationCompat.CallStyle.forIncomingCall(
                                person,
                                rejectPendingIntent,
                                answerPendingIntent
                            )
                        )
                    } catch (_: Throwable) {
                        builder.addAction(android.R.drawable.sym_action_call, "ANSWER", answerPendingIntent)
                        builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "DECLINE", rejectPendingIntent)
                    }
                } else {
                    builder.addAction(android.R.drawable.sym_action_call, "ANSWER", answerPendingIntent)
                    builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "DECLINE", rejectPendingIntent)
                }

                notificationManager.notify(NOTIFICATION_ID, builder.build())
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        fun cancelIncomingCallBanner(context: Context) {
            try {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(NOTIFICATION_ID)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        const val ONGOING_CHANNEL_ID = "stackdialer_ongoing_calls_v9"
        const val ONGOING_NOTIFICATION_ID = 2002
        const val ACTION_OPEN_ACTIVE_CALL = "com.stackdialer.app.ACTION_OPEN_ACTIVE_CALL"
        var callStartTimeMillis: Long = 0L
        private const val CALL_PREFS = "stackdialer_call_session"
        private const val CALL_START_KEY = "connected_at"

        fun setCallConnectedAt(context: Context, timestamp: Long) {
            if (timestamp <= 0L) return
            callStartTimeMillis = timestamp
            context.getSharedPreferences(CALL_PREFS, Context.MODE_PRIVATE)
                .edit().putLong(CALL_START_KEY, timestamp).apply()
        }

        fun restoreCallConnectedAt(context: Context): Long {
            if (callStartTimeMillis > 0L) return callStartTimeMillis
            callStartTimeMillis = context.getSharedPreferences(CALL_PREFS, Context.MODE_PRIVATE)
                .getLong(CALL_START_KEY, 0L)
            return callStartTimeMillis
        }

        fun clearCallConnectedAt(context: Context) {
            callStartTimeMillis = 0L
            context.getSharedPreferences(CALL_PREFS, Context.MODE_PRIVATE)
                .edit().remove(CALL_START_KEY).apply()
        }

        fun buildOngoingCallNotification(
            context: Context,
            number: String,
            name: String?,
            isIncoming: Boolean,
            isMuted: Boolean,
            isSpeaker: Boolean
        ): android.app.Notification? {
            try {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

                // High importance enables call heads-up behavior; Telecom/CallStyle controls
                // the device-native ongoing-call presentation.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        ONGOING_CHANNEL_ID,
                        "StackDialer Active Call",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "StackDialer ongoing cellular call notification"
                        enableLights(false)
                        enableVibration(false)
                        setSound(null, null)
                        lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                        setShowBadge(true)
                    }
                    notificationManager.createNotificationChannel(channel)
                }

                // Restore the original Telecom connection timestamp; never start a new
                // timer merely because a notification is being rebuilt.
                restoreCallConnectedAt(context)
                val connected = callStartTimeMillis > 0L
                val effectiveCallStart = callStartTimeMillis.takeIf { it > 0L }
                    ?: System.currentTimeMillis()

                // Use a dedicated, explicit action so a tap on the ongoing-call
                // notification/status capsule restores the call route, not the dial pad.
                // CLEAR_TOP also recreates the single MainActivity when its task was
                // swiped away from Recents; SINGLE_TOP delivers taps to onNewIntent.
                val bringToFrontIntent = Intent(context, MainActivity::class.java).apply {
                    action = ACTION_OPEN_ACTIVE_CALL
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("active_number", number)
                    putExtra("active_name", name ?: number)
                    putExtra("active_call_entry", true)
                }
                val bringToFrontPendingIntent = PendingIntent.getActivity(
                    context,
                    12002,
                    bringToFrontIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // Disconnect Action PendingIntent
                val hangupIntent = Intent(context, CallActionReceiver::class.java).apply {
                    action = CallActionReceiver.ACTION_DISCONNECT
                    putExtra("number", number)
                }
                val hangupPendingIntent = PendingIntent.getBroadcast(
                    context,
                    11,
                    hangupIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val displayName = if (!name.isNullOrBlank()) name else number
                val elapsedSec = if (callStartTimeMillis > 0L) {
                    ((System.currentTimeMillis() - callStartTimeMillis) / 1000).coerceAtLeast(0)
                } else {
                    0L
                }
                val mins = (elapsedSec / 60).toString().padStart(2, '0')
                val secs = (elapsedSec % 60).toString().padStart(2, '0')
                val durationFormatted = "$mins:$secs"
                val appIcon = context.applicationInfo.icon.takeIf { it != 0 } ?: R.drawable.ic_call_white

                val builder = NotificationCompat.Builder(context, ONGOING_CHANNEL_ID)
                    .setSmallIcon(appIcon)
                    .setContentTitle(displayName)
                    .setContentText(if (connected) "Ongoing Call • $durationFormatted" else "Calling…")
                    .setSubText(if (connected) durationFormatted else "Connecting")
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setAutoCancel(false)
                    .setOngoing(true) // CANNOT be cleared or swiped away until call terminates!
                    .setOnlyAlertOnce(true) // Never re-alert or chime on timer ticks
                    .setContentIntent(bringToFrontPendingIntent)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // 100% visible on lock screen
                    .setColor(Color.parseColor("#6B4B38"))
                    .setColorized(false)
                    .setUsesChronometer(connected)
                    .setWhen(effectiveCallStart)
                    .setShowWhen(connected)
                    .setChronometerCountDown(false)

                val person = androidx.core.app.Person.Builder()
                    .setName(displayName)
                    .setImportant(true)
                    .build()

                // Android 12+ uses the platform CallStyle so One UI can render its native
                // compact ongoing-call notification without our own duplicate action row.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        val callStyle = NotificationCompat.CallStyle.forOngoingCall(
                            person,
                            hangupPendingIntent
                        )
                        builder.setStyle(callStyle)
                    } catch (_: Throwable) {}
                } else {
                    // For Android < 12, use custom RemoteViews layout
                    try {
                        val remoteViews = RemoteViews(context.packageName, R.layout.notification_ongoing_call).apply {
                            setTextViewText(R.id.tv_call_title, "Call")
                            setTextViewText(R.id.tv_caller_name, displayName)
                            if (callStartTimeMillis > 0L) {
                                val elapsedRealtimeBase = android.os.SystemClock.elapsedRealtime() -
                                    (System.currentTimeMillis() - callStartTimeMillis).coerceAtLeast(0L)
                                setChronometer(R.id.chronometer_call, elapsedRealtimeBase, null, true)
                                setViewVisibility(R.id.chronometer_call, android.view.View.VISIBLE)
                            } else {
                                setViewVisibility(R.id.chronometer_call, android.view.View.GONE)
                            }
                            setOnClickPendingIntent(R.id.layout_ongoing_call_root, bringToFrontPendingIntent)
                            setOnClickPendingIntent(R.id.btn_end_call, hangupPendingIntent)
                        }
                        builder.setCustomContentView(remoteViews)
                        builder.setCustomBigContentView(remoteViews)
                        builder.setStyle(NotificationCompat.DecoratedCustomViewStyle())
                    } catch (_: Throwable) {}
                }

                // The native CallStyle (Android 12+) or single end button (older Android)
                // is the only action surface; no duplicate text action row is added.

                return builder.build()
            } catch (e: Throwable) {
                e.printStackTrace()
                return null
            }
        }

        fun showOngoingCallNotification(
            context: Context,
            number: String,
            name: String?,
            isIncoming: Boolean,
            isMuted: Boolean,
            isSpeaker: Boolean
        ) {
            try {
                val notification = buildOngoingCallNotification(context, number, name, isIncoming, isMuted, isSpeaker)
                if (notification != null) {
                    val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    notificationManager.notify(ONGOING_NOTIFICATION_ID, notification)
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        fun cancelOngoingCallNotification(context: Context) {
            try {
                clearCallConnectedAt(context)
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(ONGOING_NOTIFICATION_ID)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2005)
                }
            } catch (_: Throwable) {}
        }
        handleCallIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleCallIntent(intent)
    }

    private fun handleCallIntent(intent: Intent?) {
        if (intent == null) return

        // A notification/status-capsule tap must carry enough information to restore
        // the call screen even when Android has removed the app task from Recents.
        val fromActiveCallNotification = intent.action == ACTION_OPEN_ACTIVE_CALL ||
            intent.getBooleanExtra("active_call_entry", false)
        val call = InCallServiceImpl.currentCall
        val intentNumber = intent.getStringExtra("active_number")
            ?: intent.getStringExtra("incoming_number")
        val number = call?.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }
            ?: intentNumber?.takeIf { it.isNotBlank() }
            ?: return
        val state = when (call?.state) {
            android.telecom.Call.STATE_RINGING -> "RINGING"
            android.telecom.Call.STATE_ACTIVE -> "ACTIVE"
            android.telecom.Call.STATE_HOLDING -> "HOLDING"
            android.telecom.Call.STATE_DIALING, android.telecom.Call.STATE_CONNECTING -> "DIALING"
            android.telecom.Call.STATE_DISCONNECTED -> "DISCONNECTED"
            else -> if (fromActiveCallNotification) "ACTIVE" else "RINGING"
        }
        if (state == "DISCONNECTED") return
        notifyCallState(number, state)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getCallStartTimeMillis" -> {
                    result.success(restoreCallConnectedAt(this))
                }
                "getPendingCall" -> {
                    val liveCall = InCallServiceImpl.currentCall
                    val liveNumber = liveCall?.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }
                    val liveState = when (liveCall?.state) {
                        android.telecom.Call.STATE_RINGING -> "RINGING"
                        android.telecom.Call.STATE_ACTIVE -> "ACTIVE"
            android.telecom.Call.STATE_HOLDING -> "HOLDING"
                        android.telecom.Call.STATE_DIALING, android.telecom.Call.STATE_CONNECTING -> "DIALING"
                        else -> null
                    }
                    val number = liveNumber ?: pendingCallNumber
                    val state = liveState ?: pendingCallState
                    if (number != null && state != null) {
                        result.success(mapOf("number" to number, "state" to state))
                    } else {
                        result.success(null)
                    }
                }
                "getCallLogs" -> {
                    try {
                        val logs = fetchNativeCallLogs()
                        result.success(logs)
                    } catch (e: Exception) {
                        result.error("CALL_LOG_ERROR", e.message, null)
                    }
                }
                "getSimInfo" -> {
                    try {
                        val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                        val carrier = tm.networkOperatorName.ifBlank { tm.simOperatorName }.ifBlank { "Carrier SIM" }
                        result.success(mapOf("carrierName" to carrier))
                    } catch (e: Exception) {
                        result.success(mapOf("carrierName" to "Carrier SIM"))
                    }
                }
                "requestDefaultDialer" -> {
                    requestSetDefaultDialer()
                    result.success(true)
                }
                "isDefaultDialer" -> {
                    val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                    val isDefault = telecomManager.defaultDialerPackage == packageName
                    result.success(isDefault)
                }
                "answerCall" -> {
                    InCallServiceImpl.answerCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "rejectCall" -> {
                    InCallServiceImpl.rejectCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "disconnectCall" -> {
                    InCallServiceImpl.disconnectCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "holdCall" -> {
                    val hold = call.argument<Boolean>("hold") ?: false
                    InCallServiceImpl.holdCurrentCall(hold)
                    result.success(true)
                }
                "setSpeaker" -> {
                    // Accepts both 'enabled' and 'speaker' keys to avoid channel mismatch!
                    val enabled = call.argument<Boolean>("enabled")
                        ?: call.argument<Boolean>("speaker")
                        ?: false
                    InCallServiceImpl.setSpeaker(this, enabled)
                    result.success(true)
                }
                "isSpeakerOn" -> {
                    val inCallRoute = InCallServiceImpl.instance?.callAudioState?.route
                    val isSpeaker = if (inCallRoute != null) {
                        inCallRoute == CallAudioState.ROUTE_SPEAKER
                    } else {
                        val am = getSystemService(AUDIO_SERVICE) as AudioManager
                        am.isSpeakerphoneOn
                    }
                    result.success(isSpeaker)
                }
                "setMuted" -> {
                    val muted = call.argument<Boolean>("muted") ?: false
                    InCallServiceImpl.setMuted(this, muted)
                    result.success(true)
                }
                "dialpadHaptic" -> {
                    val kind = call.argument<String>("kind") ?: "light"
                    try {
                        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                            manager.defaultVibrator
                        } else {
                            @Suppress("DEPRECATION")
                            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        }
                        if (vibrator.hasVibrator()) {
                            val isHeavy = kind.contains("thud", ignoreCase = true) || kind == "medium" || kind == "heavy"
                            val isDelete = kind.contains("delete", ignoreCase = true)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                val effect = if (isHeavy) {
                                    VibrationEffect.EFFECT_HEAVY_CLICK
                                } else if (isDelete) {
                                    VibrationEffect.EFFECT_TICK
                                } else {
                                    VibrationEffect.EFFECT_CLICK
                                }
                                vibrator.vibrate(VibrationEffect.createPredefined(effect))
                            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                val duration = if (isHeavy) 45L else 18L
                                val amp = if (isHeavy) 250 else 195
                                vibrator.vibrate(VibrationEffect.createOneShot(duration, amp))
                            } else {
                                @Suppress("DEPRECATION")
                                vibrator.vibrate(if (isHeavy) 45L else 18L)
                            }
                        }
                    } catch (_: Exception) { }
                    result.success(true)
                }
                "playDialpadTone" -> {
                    val digit = call.argument<String>("digit")?.firstOrNull()
                    val tone = when (digit) {
                        '0' -> ToneGenerator.TONE_DTMF_0
                        '1' -> ToneGenerator.TONE_DTMF_1
                        '2' -> ToneGenerator.TONE_DTMF_2
                        '3' -> ToneGenerator.TONE_DTMF_3
                        '4' -> ToneGenerator.TONE_DTMF_4
                        '5' -> ToneGenerator.TONE_DTMF_5
                        '6' -> ToneGenerator.TONE_DTMF_6
                        '7' -> ToneGenerator.TONE_DTMF_7
                        '8' -> ToneGenerator.TONE_DTMF_8
                        '9' -> ToneGenerator.TONE_DTMF_9
                        '*' -> ToneGenerator.TONE_DTMF_S
                        '#' -> ToneGenerator.TONE_DTMF_P
                        else -> -1
                    }
                    try {
                        if (tone >= 0) {
                            if (dialToneGenerator == null) dialToneGenerator = ToneGenerator(AudioManager.STREAM_DTMF, 78)
                            dialToneGenerator?.stopTone()
                            dialToneGenerator?.startTone(tone, 105)
                        }
                    } catch (_: Exception) { }
                    result.success(true)
                }
                "stopDialpadTone" -> {
                    try { dialToneGenerator?.stopTone() } catch (_: Exception) { }
                    result.success(true)
                }
                "playDtmf" -> {
                    val digit = call.argument<String>("digit")?.firstOrNull() ?: '1'
                    InCallServiceImpl.playDtmf(digit)
                    result.success(true)
                }
                "stopDtmf" -> {
                    InCallServiceImpl.stopDtmf()
                    result.success(true)
                }
                "showIncomingBanner" -> {
                    val number = call.argument<String>("number") ?: "Unknown"
                    val name = call.argument<String>("name")
                    showIncomingCallBanner(this, number, name)
                    result.success(true)
                }
                "cancelIncomingBanner" -> {
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "showOngoingNotification" -> {
                    val number = call.argument<String>("number") ?: "Unknown"
                    val name = call.argument<String>("name")
                    val isIncoming = call.argument<Boolean>("isIncoming") ?: false
                    val isMuted = call.argument<Boolean>("isMuted") ?: false
                    val isSpeaker = call.argument<Boolean>("isSpeaker") ?: false
                    showOngoingCallNotification(this, number, name, isIncoming, isMuted, isSpeaker)
                    result.success(true)
                }
                "makeCall" -> {
                    val number = call.argument<String>("number") ?: ""
                    val clean = number.replace(Regex("[^0-9+*#]"), "")
                    if (clean.isNotBlank()) {
                        try {
                            val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                            val uri = android.net.Uri.fromParts("tel", clean, null)
                            val isDefault = telecomManager.defaultDialerPackage == packageName
                            if (isDefault) {
                                val extras = Bundle().apply {
                                    putBoolean(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, false)
                                }
                                telecomManager.placeCall(uri, extras)
                            } else {
                                val callIntent = Intent(Intent.ACTION_CALL, uri).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                startActivity(callIntent)
                            }

                            // Keep MainActivity on top so Samsung/system dialer does NOT hijack screen focus
                            Handler(Looper.getMainLooper()).postDelayed({
                                try {
                                    val bringToFront = Intent(this@MainActivity, MainActivity::class.java).apply {
                                        action = Intent.ACTION_MAIN
                                        addCategory(Intent.CATEGORY_LAUNCHER)
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
                                        putExtra("active_number", clean)
                                    }
                                    startActivity(bringToFront)
                                } catch (_: Exception) {}
                            }, 350)
                            Handler(Looper.getMainLooper()).postDelayed({
                                try {
                                    val bringToFront = Intent(this@MainActivity, MainActivity::class.java).apply {
                                        action = Intent.ACTION_MAIN
                                        addCategory(Intent.CATEGORY_LAUNCHER)
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
                                        putExtra("active_number", clean)
                                    }
                                    startActivity(bringToFront)
                                } catch (_: Exception) {}
                            }, 850)

                            result.success(true)
                        } catch (e: Exception) {
                            e.printStackTrace()
                            try {
                                val uri = android.net.Uri.fromParts("tel", clean, null)
                                val callIntent = Intent(Intent.ACTION_CALL, uri).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                startActivity(callIntent)
                                result.success(true)
                            } catch (ex: Exception) {
                                result.error("CALL_ERROR", ex.message, null)
                            }
                        }
                    } else {
                        result.error("INVALID_NUMBER", "Number is empty", null)
                    }
                }
                "cancelOngoingNotification" -> {
                    cancelOngoingCallNotification(this)
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        // Listen for call state updates from InCallService
        InCallServiceImpl.onCallStateChangedListener = { number, stateStr, _ ->
            val call = InCallServiceImpl.currentCall
            val isOutgoing = call?.details?.callDirection == android.telecom.Call.Details.DIRECTION_OUTGOING
            if (stateStr == "RINGING" && !isOutgoing) {
                showIncomingCallBanner(this, number, null)
            } else if (stateStr == "ACTIVE" || stateStr == "DIALING" || (stateStr == "RINGING" && isOutgoing)) {
                cancelIncomingCallBanner(this)
                showOngoingCallNotification(this, number, null, false, false, false)
            } else if (stateStr == "DISCONNECTED" || stateStr == "IDLE") {
                cancelIncomingCallBanner(this)
                cancelOngoingCallNotification(this)
            }
            notifyCallState(number, stateStr)
        }
    }

    override fun onDestroy() {
        try { dialToneGenerator?.stopTone(); dialToneGenerator?.release(); dialToneGenerator = null } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun fetchNativeCallLogs(): List<Map<String, Any>> {
        val list = mutableListOf<Map<String, Any>>()
        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
            CallLog.Calls.GEOCODED_LOCATION
        )

        val cursor = contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            projection,
            null,
            null,
            "${CallLog.Calls.DATE} DESC LIMIT 100"
        )

        cursor?.use {
            val idIdx = it.getColumnIndex(CallLog.Calls._ID)
            val numIdx = it.getColumnIndex(CallLog.Calls.NUMBER)
            val nameIdx = it.getColumnIndex(CallLog.Calls.CACHED_NAME)
            val typeIdx = it.getColumnIndex(CallLog.Calls.TYPE)
            val dateIdx = it.getColumnIndex(CallLog.Calls.DATE)
            val durIdx = it.getColumnIndex(CallLog.Calls.DURATION)
            val locIdx = it.getColumnIndex(CallLog.Calls.GEOCODED_LOCATION)

            while (it.moveToNext()) {
                val id = if (idIdx >= 0) it.getString(idIdx) ?: "" else ""
                val number = if (numIdx >= 0) it.getString(numIdx) ?: "Unknown" else "Unknown"
                val name = if (nameIdx >= 0) it.getString(nameIdx) ?: "" else ""
                val type = if (typeIdx >= 0) it.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                val date = if (dateIdx >= 0) it.getLong(dateIdx) else System.currentTimeMillis()
                val duration = if (durIdx >= 0) it.getLong(durIdx) else 0L
                val loc = if (locIdx >= 0) it.getString(locIdx) ?: "" else ""

                val typeStr = when (type) {
                    CallLog.Calls.INCOMING_TYPE -> "incoming"
                    CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                    CallLog.Calls.MISSED_TYPE -> "missed"
                    CallLog.Calls.REJECTED_TYPE -> "rejected"
                    CallLog.Calls.VOICEMAIL_TYPE -> "missed"
                    CallLog.Calls.BLOCKED_TYPE -> "blocked"
                    else -> "incoming"
                }

                list.add(mapOf(
                    "id" to id,
                    "number" to number,
                    "name" to name,
                    "type" to typeStr,
                    "timestamp" to date,
                    "duration" to duration,
                    "location" to loc
                ))
            }
        }
        return list
    }

    private fun requestSetDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) && !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
                startActivityForResult(intent, REQUEST_ID_SET_DEFAULT_DIALER)
            }
        } else {
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            }
            startActivityForResult(intent, REQUEST_ID_SET_DEFAULT_DIALER)
        }
    }
}
