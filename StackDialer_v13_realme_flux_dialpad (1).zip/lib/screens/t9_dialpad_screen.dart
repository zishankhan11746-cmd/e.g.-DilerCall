import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/contact.dart';
import '../services/speed_dial_service.dart';
import '../widgets/settings_dialog.dart';

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> {
  String _digits = '';
  int _selectedSim = 1;

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    HapticFeedback.lightImpact();
    setState(() {
      _digits += digit;
    });
  }

  void _onBackspace() {
    HapticFeedback.lightImpact();
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    HapticFeedback.mediumImpact();
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    return Scaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      body: Container(
        color: const Color(0xFF0C0C0E),
        child: SafeArea(
          bottom: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              // Realme UI 7.0 circular button sizing
              final double keyDiameter = screenHeight < 600 ? 60.0 : (screenHeight < 700 ? 68.0 : 76.0);
              final double rowSpacing = screenHeight < 600 ? 8.0 : (screenHeight < 700 ? 12.0 : 15.0);
              final double callBtnHeight = screenHeight < 600 ? 62.0 : (screenHeight < 700 ? 70.0 : 76.0);

              return Column(
                children: [
                  const SizedBox(height: 6),

                  // Top Status / Action Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // SIM Selector Switch
                        Row(
                          children: [
                            _buildSimPill(1, 'SIM 1'),
                            const SizedBox(width: 8),
                            _buildSimPill(2, 'SIM 2'),
                          ],
                        ),
                        // Settings Button
                        IconButton(
                          icon: const Icon(Icons.tune_rounded, color: Colors.white70, size: 20),
                          tooltip: 'Dialer Settings',
                          onPressed: _openSettings,
                        ),
                      ],
                    ),
                  ),

                  // Number display matching Realme UI 7.0 high-contrast typography
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: _digits.isEmpty
                            ? const FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  'Dial number',
                                  style: TextStyle(
                                    fontSize: 38,
                                    fontWeight: FontWeight.w300,
                                    letterSpacing: 0.5,
                                    color: Color(0xFF454550),
                                  ),
                                ),
                              )
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: AnimatedDefaultTextStyle(
                                      duration: const Duration(milliseconds: 150),
                                      style: const TextStyle(
                                        fontSize: 42,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 2.2,
                                        color: Colors.white,
                                      ),
                                      child: Text(_digits),
                                    ),
                                  ),
                                  if (matches.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.08),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(color: Colors.white12),
                                      ),
                                      child: Text(
                                        '${matches.first.name} • ${matches.first.number}',
                                        style: const TextStyle(color: Color(0xFF00E676), fontSize: 13, fontWeight: FontWeight.w500),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                      ),
                    ),
                  ),

                  // Realme UI 7.0 4x3 Circular Keypad
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildKeyRow(['1', '2', '3'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['4', '5', '6'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['7', '8', '9'], keyDiameter),
                        SizedBox(height: rowSpacing),
                        _buildKeyRow(['*', '0', '#'], keyDiameter),
                      ],
                    ),
                  ),

                  SizedBox(height: rowSpacing + 8),

                  // Bottom Action Row: Call CTA and Backspace
                  Padding(
                    padding: const EdgeInsets.only(left: 32, right: 32, bottom: 14),
                    child: SizedBox(
                      height: callBtnHeight,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Centered Call Button with Realme UI 7.0 elastic press & glow
                          RealmeActionButton(
                            size: callBtnHeight,
                            color: const Color(0xFF00C853),
                            shadowColor: const Color(0xFF00E676).withOpacity(0.45),
                            onTap: () {
                              if (_digits.isNotEmpty) {
                                HapticFeedback.heavyImpact();
                                widget.onCallNumber(_digits);
                              }
                            },
                            child: const Icon(Icons.call_rounded, color: Colors.white, size: 34),
                          ),

                          // Backspace Button on Right
                          if (_digits.isNotEmpty)
                            Align(
                              alignment: Alignment.centerRight,
                              child: RealmeActionButton(
                                size: 56,
                                color: const Color(0xFF242429),
                                borderColor: const Color(0xFF383840),
                                onTap: _onBackspace,
                                onLongPress: _onClearAll,
                                child: const Icon(Icons.backspace_outlined, color: Colors.white70, size: 22),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSimPill(int slot, String label) {
    final isSelected = _selectedSim == slot;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _selectedSim = slot);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF00E676).withOpacity(0.18) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? const Color(0xFF00E676) : Colors.white12,
            width: isSelected ? 1.4 : 0.8,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected ? const Color(0xFF00E676) : Colors.white38,
                boxShadow: isSelected
                    ? [const BoxShadow(color: Color(0xFF00E676), blurRadius: 6, spreadRadius: 1)]
                    : null,
              ),
            ),
            const SizedBox(width: 5),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? const Color(0xFF00E676) : Colors.white70,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildKeyRow(List<String> keys, double diameter) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: keys.map((k) => RealmeDialKey(
        digit: k,
        subLetters: _t9Map[k] ?? '',
        size: diameter,
        onTap: () => _onDigitPress(k),
        onLongPress: () {
          if (k == '0') {
            _onDigitPress('+');
          } else if (k == '1') {
            HapticFeedback.heavyImpact();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Calling Voicemail (*123#)...')),
            );
            widget.onCallNumber('*123#');
          } else {
            final intKey = int.tryParse(k);
            if (intKey != null && intKey >= 2 && intKey <= 9) {
              final entry = SpeedDialService.getEntry(intKey);
              if (entry != null) {
                HapticFeedback.heavyImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('⚡ Speed Dial #$intKey: Calling ${entry.name} (${entry.number})'),
                    duration: const Duration(seconds: 2),
                  ),
                );
                widget.onCallNumber(entry.number);
              }
            }
          }
        },
      )).toList(),
    );
  }
}

/// Realme UI 7.0 Exact Circular Number Key
/// Features:
/// 1. Translucent 3D Smoky Glass sphere design with specular bevel rim.
/// 2. Guaranteed full-cycle spring pulse: Scale squish to 0.86 with elastic recoil.
/// 3. Brilliant Radiant Silver-White Radial Glow Orb & Neon Ring Halo on tap (Exact clone of reference video key 7).
class RealmeDialKey extends StatefulWidget {
  final String digit;
  final String subLetters;
  final double size;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const RealmeDialKey({
    super.key,
    required this.digit,
    required this.subLetters,
    required this.size,
    required this.onTap,
    this.onLongPress,
  });

  @override
  State<RealmeDialKey> createState() => _RealmeDialKeyState();
}

class _RealmeDialKeyState extends State<RealmeDialKey> with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;
  Timer? _longPressTimer;
  bool _longPressTriggered = false;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 260),
    );

    // Realme UI 7.0 Elastic Squash & Spring Recoil (1.0 -> 0.86 -> 1.0)
    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 0.86).chain(CurveTween(curve: Curves.easeOutQuad)),
        weight: 35.0,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.86, end: 1.0).chain(CurveTween(curve: Curves.easeOutBack)),
        weight: 65.0,
      ),
    ]).animate(_animController);

    // Radiant Silver-White Radial Glow Flash (0.0 -> 1.0 -> 0.0)
    _glowAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.0, end: 1.0).chain(CurveTween(curve: Curves.easeOutQuad)),
        weight: 30.0,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 0.0).chain(CurveTween(curve: Curves.easeInQuad)),
        weight: 70.0,
      ),
    ]).animate(_animController);
  }

  @override
  void dispose() {
    _longPressTimer?.cancel();
    _animController.dispose();
    super.dispose();
  }

  void _triggerTap() {
    HapticFeedback.selectionClick();
    _animController.forward(from: 0.0);
    widget.onTap();
  }

  void _onPointerDown(PointerDownEvent event) {
    _longPressTriggered = false;
    _animController.forward(from: 0.0);
    HapticFeedback.lightImpact();

    if (widget.onLongPress != null) {
      _longPressTimer?.cancel();
      _longPressTimer = Timer(const Duration(milliseconds: 650), () {
        _longPressTriggered = true;
        widget.onLongPress!();
      });
    }
  }

  void _onPointerUp(PointerUpEvent event) {
    _longPressTimer?.cancel();
    if (!_longPressTriggered) {
      widget.onTap();
    }
  }

  void _onPointerCancel(PointerCancelEvent event) {
    _longPressTimer?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: _onPointerDown,
      onPointerUp: _onPointerUp,
      onPointerCancel: _onPointerCancel,
      child: AnimatedBuilder(
        animation: _animController,
        builder: (context, child) {
          final scale = _scaleAnimation.value;
          final glow = _glowAnimation.value;

          return Transform.scale(
            scale: scale,
            alignment: Alignment.center,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                // Realme UI 7.0 Spherical Glass Lens with Luminous Silver-White Glow Flash
                gradient: RadialGradient(
                  center: const Alignment(0, -0.2),
                  radius: 0.9,
                  colors: [
                    Color.lerp(const Color(0xFF38383F), Colors.white, glow * 0.85)!,
                    Color.lerp(const Color(0xFF2A2A2F), const Color(0xFF757582), glow)!,
                    Color.lerp(const Color(0xFF1D1D21), const Color(0xFF3C3C44), glow)!,
                  ],
                  stops: const [0.0, 0.6, 1.0],
                ),
                // Specular Neon Rim Halo (Becomes pure bright white on tap)
                border: Border.all(
                  color: Color.lerp(
                    Colors.white.withOpacity(0.18),
                    Colors.white.withOpacity(0.95),
                    glow,
                  )!,
                  width: 1.2 + (glow * 1.4),
                ),
                // Radiant Outer Bloom Halo (Exact clone of reference video key 7)
                boxShadow: glow > 0.02
                    ? [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.65 * glow),
                          blurRadius: 26 * glow,
                          spreadRadius: 3.5 * glow,
                        ),
                        BoxShadow(
                          color: const Color(0xFFE2E2EA).withOpacity(0.45 * glow),
                          blurRadius: 10 * glow,
                          spreadRadius: 1.5 * glow,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          offset: const Offset(0, 4),
                          blurRadius: 8,
                        ),
                      ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    widget.digit,
                    style: TextStyle(
                      fontSize: widget.size >= 72 ? 33 : (widget.size >= 64 ? 29 : 25),
                      fontWeight: FontWeight.w400,
                      color: Colors.white,
                      height: 1.05,
                      shadows: glow > 0.1
                          ? [
                              Shadow(
                                color: Colors.white.withOpacity(0.9 * glow),
                                blurRadius: 12 * glow,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  if (widget.subLetters.isNotEmpty) ...[
                    const SizedBox(height: 1.5),
                    Text(
                      widget.subLetters,
                      style: TextStyle(
                        fontSize: widget.size >= 72 ? 10.5 : 9.0,
                        fontWeight: FontWeight.w600,
                        color: Color.lerp(const Color(0xFF8E8E98), Colors.white, glow * 0.7),
                        letterSpacing: 1.8,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Realme UI 7.0 Circular Action Button (Call / Backspace) with matching 0.86 squash & pulse
class RealmeActionButton extends StatefulWidget {
  final double size;
  final Color color;
  final Color? borderColor;
  final Color? shadowColor;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final Widget child;

  const RealmeActionButton({
    super.key,
    required this.size,
    required this.color,
    this.borderColor,
    this.shadowColor,
    required this.onTap,
    this.onLongPress,
    required this.child,
  });

  @override
  State<RealmeActionButton> createState() => _RealmeActionButtonState();
}

class _RealmeActionButtonState extends State<RealmeActionButton> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 240),
    );
    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 0.86).chain(CurveTween(curve: Curves.easeOutQuad)),
        weight: 35.0,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.86, end: 1.0).chain(CurveTween(curve: Curves.easeOutBack)),
        weight: 65.0,
      ),
    ]).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTap() {
    _controller.forward(from: 0.0);
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _handleTap,
      onLongPress: widget.onLongPress,
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            alignment: Alignment.center,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.color,
                border: widget.borderColor != null ? Border.all(color: widget.borderColor!, width: 1.4) : null,
                boxShadow: [
                  BoxShadow(
                    color: widget.shadowColor ?? Colors.black.withOpacity(0.35),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Center(child: widget.child),
            ),
          );
        },
      ),
    );
  }
}
