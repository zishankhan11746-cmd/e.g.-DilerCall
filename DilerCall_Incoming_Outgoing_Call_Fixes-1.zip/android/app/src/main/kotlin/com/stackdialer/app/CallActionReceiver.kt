package com.stackdialer.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CallActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_ANSWER = "com.stackdialer.app.ACTION_ANSWER"
        const val ACTION_REJECT = "com.stackdialer.app.ACTION_REJECT"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val number = intent.getStringExtra("number") ?: "Unknown"

        if (action == ACTION_ANSWER) {
            InCallServiceImpl.answerCurrentCall()
            // Keep the call UI alive until Telecom confirms ACTIVE; the InCallService callback
            // will dismiss/update the incoming notification when the state actually changes.

            // Bring MainActivity to the front
            val appIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra("answered_number", number)
            }
            if (appIntent != null) {
                context.startActivity(appIntent)
            }
        } else if (action == ACTION_REJECT) {
            InCallServiceImpl.rejectCurrentCall()
            // Telecom's DISCONNECTED callback owns final notification cleanup/state update.
        }
    }
}
