package com.stackdialer.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile

class InCallServiceImpl : InCallService() {

    companion object {
        var instance: InCallServiceImpl? = null
        var currentCall: Call? = null
        var onCallStateChangedListener: ((String, String, Int) -> Unit)? = null

        fun answerCurrentCall() {
            currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }

        fun rejectCurrentCall() {
            currentCall?.reject(false, null)
        }

        fun disconnectCurrentCall() {
            currentCall?.disconnect()
        }

        fun holdCurrentCall(hold: Boolean) {
            if (hold) {
                currentCall?.hold()
            } else {
                currentCall?.unhold()
            }
        }

        fun setSpeaker(context: Context?, enabled: Boolean) {
            // 1. Android Telecom InCallService Audio Route
            try {
                instance?.setAudioRoute(if (enabled) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // 2. Hardware AudioManager Fallback
            try {
                val ctx = context ?: instance
                if (ctx != null) {
                    val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    audioManager?.let { am ->
                        am.mode = AudioManager.MODE_IN_COMMUNICATION
                        am.isSpeakerphoneOn = enabled
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun setMuted(context: Context?, muted: Boolean) {
            try {
                instance?.setMuted(muted)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                val ctx = context ?: instance
                if (ctx != null) {
                    val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    audioManager?.let { am ->
                        am.isMicrophoneMute = muted
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun playDtmf(digit: Char) {
            currentCall?.playDtmfTone(digit)
        }

        fun stopDtmf() {
            currentCall?.stopDtmfTone()
        }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        instance = this
        currentCall = call
        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        val state = call.state

        if (state == Call.STATE_RINGING) {
            MainActivity.showIncomingCallBanner(this, number, null)
        }

        notifyState(number, state)

        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                super.onStateChanged(call, state)
                val num = call.details?.handle?.schemeSpecificPart ?: "Unknown"
                currentCall = if (state == Call.STATE_DISCONNECTED) null else call
                if (state == Call.STATE_RINGING) {
                    MainActivity.showIncomingCallBanner(this@InCallServiceImpl, num, null)
                } else if (state == Call.STATE_ACTIVE || state == Call.STATE_DISCONNECTED) {
                    MainActivity.cancelIncomingCallBanner(this@InCallServiceImpl)
                }
                notifyState(num, state)
            }
        })
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        if (audioState != null) {
            val isSpeaker = audioState.route == CallAudioState.ROUTE_SPEAKER
            val isMuted = audioState.isMuted
            Handler(Looper.getMainLooper()).post {
                MainActivity.notifyAudioState(isSpeaker, isMuted)
            }
        }
    }

    private fun notifyState(number: String, state: Int) {
        Handler(Looper.getMainLooper()).post {
            onCallStateChangedListener?.invoke(number, getStateString(state), state)
        }
    }

    private fun getStateString(state: Int): String {
        return when (state) {
            Call.STATE_RINGING -> "RINGING"
            Call.STATE_DIALING -> "DIALING"
            Call.STATE_ACTIVE -> "ACTIVE"
            Call.STATE_HOLDING -> "HOLDING"
            Call.STATE_DISCONNECTED -> "DISCONNECTED"
            else -> "UNKNOWN"
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        if (currentCall == call) {
            currentCall = null
        }
        MainActivity.cancelIncomingCallBanner(this)
        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        notifyState(number, Call.STATE_DISCONNECTED)
    }
}
