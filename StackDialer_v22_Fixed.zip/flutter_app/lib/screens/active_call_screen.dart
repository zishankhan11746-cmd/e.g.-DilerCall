import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/call_record.dart';
import '../services/blocked_numbers_service.dart';
import '../services/telecom_service.dart';

enum CallUIState {
  ringing, // Incoming Call UI
  dialing, // Outgoing Call UI
  active,  // Connected in-call
  holding, // On Hold
  ended,   // Call Ended Summary
}

class ActiveCallScreen extends StatefulWidget {
  final String phoneNumber;
  final String? contactName;
  final String? callerCategory;
  final int simSlot;
  final bool isIncoming;
  final Function(CallRecord completedCall)? onCallEnded;

  const ActiveCallScreen({
    super.key,
    required this.phoneNumber,
    this.contactName,
    this.callerCategory,
    this.simSlot = 1,
    this.isIncoming = false,
    this.onCallEnded,
  });

  @override
  State<ActiveCallScreen> createState() => _ActiveCallScreenState();
}

class _ActiveCallScreenState extends State<ActiveCallScreen> {
  late CallUIState _state;
  bool _isMuted = false;
  bool _isSpeaker = false;
  bool _isOnHold = false;
  bool _isRecording = false;
  int _recordingSeconds = 0;
  Timer? _recordingTimer;
  bool _showDtmfPad = false;
  String _dtmfHistory = '';
  String _callNote = '';
  int _durationSeconds = 0;
  Timer? _callTimer;

  @override
  void initState() {
    super.initState();

    // Persistent CallSession check - Prevents timer from resetting when minimizing or re-opening
    if (CallSession.callStartTime != null) {
      _state = CallUIState.active;
      _durationSeconds = CallSession.elapsedSeconds;
      _startTimer();
    } else {
      _state = widget.isIncoming ? CallUIState.ringing : CallUIState.dialing;
      if (!widget.isIncoming) {
        CallSession.startCall(widget.phoneNumber, name: widget.contactName, incoming: false);
        _startTimer();
      }
    }

    // Initial check for real speaker status
    TelecomService.isSpeakerOn().then((on) {
      if (mounted && on != _isSpeaker) {
        setState(() => _isSpeaker = on);
      }
    });

    // Listen to real Android InCallService native call state events
    TelecomService.setupCallListener((number, nativeState) {
      if (!mounted) return;
      if (nativeState == 'ACTIVE' && _state != CallUIState.active) {
        _transitionToActive();
      } else if (nativeState == 'HOLDING') {
        setState(() {
          _isOnHold = true;
          _state = CallUIState.holding;
        });
      } else if (nativeState == 'DISCONNECTED') {
        _endCall();
      }
    });

    // Listen for confirmed Android audio route changes (earpiece / speaker / bluetooth)
    TelecomService.setupAudioRouteListener((isSpeaker, isMuted) {
      if (!mounted) return;
      setState(() {
        _isSpeaker = isSpeaker;
        _isMuted = isMuted;
      });
    });
  }

  void _transitionToActive() {
    HapticFeedback.heavyImpact();
    CallSession.startCall(widget.phoneNumber, name: widget.contactName, incoming: widget.isIncoming);
    setState(() {
      _state = CallUIState.active;
      _durationSeconds = CallSession.elapsedSeconds;
    });
    _startTimer();
  }

  void _startTimer() {
    _callTimer?.cancel();
    _callTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && _state == CallUIState.active) {
        setState(() {
          _durationSeconds = CallSession.elapsedSeconds;
        });
      }
    });
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _recordingTimer?.cancel();
    super.dispose();
  }

  String _formatDuration(int seconds) {
    final mins = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  void _answerCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.answerCall();
    _transitionToActive();
  }

  void _rejectCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.rejectCall();
    _endCall();
  }

  void _hangupCall() async {
    HapticFeedback.heavyImpact();
    await TelecomService.disconnectCall();
    _endCall();
  }

  void _endCall() {
    _callTimer?.cancel();
    _recordingTimer?.cancel();
    final finalDuration = CallSession.elapsedSeconds > 0 ? CallSession.elapsedSeconds : _durationSeconds;
    CallSession.endCall();
    TelecomService.cancelIncomingBanner();
    TelecomService.cancelOngoingNotification();
    HapticFeedback.mediumImpact();
    setState(() {
      _state = CallUIState.ended;
      _durationSeconds = finalDuration;
    });

    final record = CallRecord(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: widget.contactName ?? widget.phoneNumber,
      number: widget.phoneNumber,
      type: widget.isIncoming
          ? (_durationSeconds > 0 ? CallType.incoming : CallType.missed)
          : CallType.outgoing,
      timestamp: DateTime.now(),
      durationSeconds: _durationSeconds,
      simSlot: widget.simSlot,
      simCarrier: 'SIM ${widget.simSlot}',
      category: widget.callerCategory ?? 'Personal',
      location: 'Cellular Call',
      note: _callNote.isNotEmpty ? _callNote : null,
    );

    widget.onCallEnded?.call(record);
  }

  void _toggleMute() async {
    HapticFeedback.selectionClick();
    final newMute = !_isMuted;
    await TelecomService.setMuted(newMute);
    setState(() {
      _isMuted = newMute;
    });
  }

  void _toggleSpeaker() async {
    HapticFeedback.selectionClick();
    final newSpeaker = !_isSpeaker;
    await TelecomService.setSpeaker(newSpeaker);
    setState(() {
      _isSpeaker = newSpeaker;
    });
  }

  void _toggleHold() async {
    HapticFeedback.selectionClick();
    final newHold = !_isOnHold;
    await TelecomService.holdCall(newHold);
    setState(() {
      _isOnHold = newHold;
      _state = newHold ? CallUIState.holding : CallUIState.active;
    });
  }

  void _toggleRecord() {
    HapticFeedback.mediumImpact();
    final newRecording = !_isRecording;
    _recordingTimer?.cancel();
    if (newRecording) {
      _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (mounted && _isRecording) {
          setState(() => _recordingSeconds++);
        }
      });
    } else {
      _recordingSeconds = 0;
    }
    setState(() {
      _isRecording = newRecording;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              _isRecording ? Icons.fiber_manual_record : Icons.stop_circle_outlined,
              color: _isRecording ? Colors.redAccent : Colors.white70,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(_isRecording ? '🔴 Call recording in progress' : '⏹️ Call recording saved'),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1E1E22),
      ),
    );
  }

  void _onPressDtmfDigit(String digit) {
    HapticFeedback.lightImpact();
    TelecomService.playDtmf(digit);
    setState(() {
      _dtmfHistory += digit;
    });
    Future.delayed(const Duration(milliseconds: 200), () {
      TelecomService.stopDtmf();
    });
  }

  void _showQuickSmsSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141416),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final messages = [
          "Can't talk now. What's up?",
          "I'll call you right back.",
          "I'm in a meeting right now.",
          "Driving right now, will call later.",
        ];
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Quick Decline with SMS',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ...messages.map(
                (msg) => ListTile(
                  title: Text(msg, style: const TextStyle(color: Colors.white70)),
                  trailing: const Icon(Icons.send_rounded, color: Color(0xFF10B981), size: 18),
                  onTap: () async {
                    Navigator.pop(ctx);
                    _rejectCall();
                    final uri = Uri(
                      scheme: 'sms',
                      path: widget.phoneNumber,
                      queryParameters: {'body': msg},
                    );
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri);
                    }
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showInCallNoteDialog() {
    final controller = TextEditingController(text: _callNote);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF18181C),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Summarise / In-Call Note', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        content: TextField(
          controller: controller,
          maxLines: 4,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Add call notes, summary or follow-up details...',
            hintStyle: const TextStyle(color: Colors.white38),
            filled: true,
            fillColor: const Color(0xFF222226),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFDC2626),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () {
              setState(() {
                _callNote = controller.text.trim();
              });
              Navigator.pop(ctx);
            },
            child: const Text('Save Note', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _onAddCall() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Add Call: Conference and 2nd line calling active'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF1E1E22),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _onVideoCall() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Carrier ViLTE Video calling is available for 5G/VoLTE lines'),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF1E1E22),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final displayName = widget.contactName?.isNotEmpty == true
        ? widget.contactName!
        : widget.phoneNumber;

    return Scaffold(
      backgroundColor: const Color(0xFF0F0E10),
      body: Stack(
        children: [
          // 1. Warm ambient dark blurred gradient background (Photo matched)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF221A16), // Warm smoky deep brown/charcoal
                  Color(0xFF14100E),
                  Color(0xFF0F0E10),
                  Color(0xFF1C140F),
                ],
              ),
            ),
          ),
          // Ambient Warm Golden/Amber Glowing Orb from bottom
          Positioned(
            bottom: -50,
            left: -50,
            right: -50,
            height: 380,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFB45309).withOpacity(0.12),
              ),
            ),
          ),
          // Ambient Purple Orb from upper right
          Positioned(
            top: 60,
            right: -40,
            width: 280,
            height: 280,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF6D28D9).withOpacity(0.10),
              ),
            ),
          ),
          // Deep Blur Backdrop Filter
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 36, sigmaY: 36),
              child: Container(color: Colors.black.withOpacity(0.25)),
            ),
          ),

          // 2. Main In-Call Content
          SafeArea(
            child: _state == CallUIState.ended
                ? _buildCallEndedSummary(displayName)
                : Column(
                    children: [
                      const SizedBox(height: 24),

                      // Top Header matching photo (Left aligned, Category Avatar Badge, Vo5G timer)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        displayName,
                                        style: const TextStyle(
                                          fontSize: 30,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white,
                                          letterSpacing: -0.5,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        widget.phoneNumber,
                                        style: const TextStyle(
                                          fontSize: 16,
                                          color: Colors.white70,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // Category / Business Avatar Badge (as seen in photo)
                                Container(
                                  width: 52,
                                  height: 52,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: const Color(0xFF8B5CF6).withOpacity(0.22),
                                    border: Border.all(
                                      color: const Color(0xFFA78BFA).withOpacity(0.55),
                                      width: 1.5,
                                    ),
                                  ),
                                  child: const Center(
                                    child: Icon(
                                      Icons.business_rounded,
                                      color: Color(0xFFC4B5FD),
                                      size: 26,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            // Vo5G Cellular Icon + Live Timer
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const [
                                    Text(
                                      'Vo',
                                      style: TextStyle(
                                        fontSize: 8,
                                        color: Colors.white70,
                                        fontWeight: FontWeight.bold,
                                        height: 0.9,
                                      ),
                                    ),
                                    Text(
                                      '5G',
                                      style: TextStyle(
                                        fontSize: 8,
                                        color: Colors.white70,
                                        fontWeight: FontWeight.bold,
                                        height: 0.9,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  _state == CallUIState.ringing
                                      ? 'Incoming call...'
                                      : (_state == CallUIState.dialing
                                          ? 'Calling...'
                                          : (_state == CallUIState.holding
                                              ? 'On Hold'
                                              : _formatDuration(_durationSeconds))),
                                  style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'monospace',
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      const Spacer(),

                      // Middle Section: 6 Action Buttons OR In-Call Dialpad
                      if (_state == CallUIState.ringing)
                        _buildIncomingCallControls()
                      else if (_showDtmfPad)
                        _buildInCallDialpad()
                      else
                        _buildSixButtonGrid(),

                      const Spacer(),

                      // Bottom Action Strip: Speaker, Red End Call, Dial pad (Photo Matched)
                      if (_state != CallUIState.ringing)
                        _buildBottomPrimaryActions(),

                      const SizedBox(height: 28),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // 6 ACTION BUTTONS GRID (Frosted Glass & Photo Matched)
  // Row 1: Record, Hold, Add call
  // Row 2: Mute, Video call, AI Call Assistant (Iridescent Glow Border)
  // =========================================================================
  Widget _buildSixButtonGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        children: [
          // Row 1: Record, Hold, Add call
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildCircleAction(
                icon: Icons.voicemail_rounded,
                label: 'Record',
                isActive: _isRecording,
                subText: _isRecording ? _formatDuration(_recordingSeconds) : 'Record',
                activeColor: Colors.white,
                onTap: _toggleRecord,
              ),
              _buildCircleAction(
                icon: _isOnHold ? Icons.play_arrow_rounded : Icons.pause_rounded,
                label: 'Hold',
                isActive: _isOnHold,
                onTap: _toggleHold,
              ),
              _buildCircleAction(
                icon: Icons.add_rounded,
                label: 'Add call',
                onTap: _onAddCall,
              ),
            ],
          ),
          const SizedBox(height: 28),
          // Row 2: Mute, Video call, AI Call Assistant (Iridescent Glow Border)
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildCircleAction(
                icon: _isMuted ? Icons.mic_off_rounded : Icons.mic_none_rounded,
                label: 'Mute',
                isActive: _isMuted,
                onTap: _toggleMute,
              ),
              _buildCircleAction(
                icon: Icons.videocam_rounded,
                label: 'Video call',
                onTap: _onVideoCall,
              ),
              _buildCircleAction(
                icon: Icons.auto_awesome_rounded,
                label: 'AI Call Assistant',
                isSpecialAi: true,
                onTap: _showInCallNoteDialog,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCircleAction({
    required IconData icon,
    required String label,
    bool isActive = false,
    Color activeColor = Colors.white,
    bool isSpecialAi = false,
    String? subText,
    required VoidCallback onTap,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        InkWell(
          onTap: () {
            HapticFeedback.selectionClick();
            onTap();
          },
          borderRadius: BorderRadius.circular(36),
          child: Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                if (isSpecialAi)
                  BoxShadow(
                    color: const Color(0xFFA855F7).withOpacity(0.35),
                    blurRadius: 18,
                    spreadRadius: 2,
                  )
                else
                  BoxShadow(
                    color: Colors.white.withOpacity(0.08),
                    blurRadius: 14,
                    spreadRadius: 1,
                  ),
              ],
            ),
            child: ClipOval(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isActive
                        ? Colors.white
                        : const Color(0x33FFFFFF), // Frosted glass translucent fill
                    border: isSpecialAi
                        ? null
                        : Border.all(
                            color: isActive
                                ? Colors.white
                                : Colors.white.withOpacity(0.32),
                            width: 1.4,
                          ),
                    gradient: isSpecialAi
                        ? const SweepGradient(
                            colors: [
                              Color(0xFF67E8F9),
                              Color(0xFFA855F7),
                              Color(0xFFEC4899),
                              Color(0xFFFBBF24),
                              Color(0xFF34D399),
                              Color(0xFF67E8F9),
                            ],
                          )
                        : null,
                  ),
                  child: isSpecialAi
                      ? Container(
                          margin: const EdgeInsets.all(2.5),
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xFF1E1724),
                          ),
                          child: Center(
                            child: Stack(
                              alignment: Alignment.center,
                              children: const [
                                Icon(
                                  Icons.phone_rounded,
                                  color: Colors.white,
                                  size: 24,
                                ),
                                Positioned(
                                  top: 0,
                                  right: 0,
                                  child: Icon(
                                    Icons.auto_awesome,
                                    color: Color(0xFFDDD6FE),
                                    size: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : Center(
                          child: Icon(
                            icon,
                            color: isActive ? Colors.black : Colors.white,
                            size: 27,
                          ),
                        ),
                ),
              ),
            ),
          ),
        ),

        const SizedBox(height: 8),
        Text(
          subText ?? label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: isActive ? Colors.white : const Color(0xFFE5E7EB),
          ),
        ),
      ],
    );
  }

  // =========================================================================
  // BOTTOM 3 PRIMARY ACTIONS: Speaker, Red End Call, Dial pad (Photo Matched)
  // =========================================================================
  Widget _buildBottomPrimaryActions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 36),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Speaker Button + Label (Left)
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: _toggleSpeaker,
                borderRadius: BorderRadius.circular(36),
                child: Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.08),
                        blurRadius: 14,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                      child: Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _isSpeaker ? Colors.white : const Color(0x33FFFFFF),
                          border: Border.all(
                            color: _isSpeaker ? Colors.white : Colors.white.withOpacity(0.32),
                            width: 1.4,
                          ),
                        ),
                        child: Center(
                          child: Icon(
                            Icons.volume_up_rounded,
                            color: _isSpeaker ? Colors.black : Colors.white,
                            size: 28,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Speaker',
                style: TextStyle(fontSize: 12, color: Color(0xFFE5E7EB), fontWeight: FontWeight.w500),
              ),
            ],
          ),

          // Red End Call Button + Label (Center - Solid Red Circle)
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: _hangupCall,
                borderRadius: BorderRadius.circular(38),
                child: Container(
                  width: 74,
                  height: 74,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFEF4444), // Solid Red
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFEF4444).withOpacity(0.45),
                        blurRadius: 22,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.call_end_rounded,
                      color: Colors.white,
                      size: 36,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'End',
                style: TextStyle(fontSize: 12, color: Color(0xFFE5E7EB), fontWeight: FontWeight.w500),
              ),
            ],
          ),

          // Dial pad Button + Label (Right - Toggles Keypad)
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _showDtmfPad = !_showDtmfPad);
                },
                borderRadius: BorderRadius.circular(36),
                child: Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.08),
                        blurRadius: 14,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                      child: Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _showDtmfPad ? Colors.white : const Color(0x33FFFFFF),
                          border: Border.all(
                            color: _showDtmfPad ? Colors.white : Colors.white.withOpacity(0.32),
                            width: 1.4,
                          ),
                        ),
                        child: Center(
                          child: Icon(
                            Icons.dialpad_rounded,
                            color: _showDtmfPad ? Colors.black : Colors.white,
                            size: 28,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Dial pad',
                style: TextStyle(fontSize: 12, color: Color(0xFFE5E7EB), fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // IN-CALL DIALPAD (Frosted Glass Circular Keys)
  // =========================================================================
  Widget _buildInCallDialpad() {
    final dialKeys = [
      {'digit': '1', 'letters': ''},
      {'digit': '2', 'letters': 'ABC'},
      {'digit': '3', 'letters': 'DEF'},
      {'digit': '4', 'letters': 'GHI'},
      {'digit': '5', 'letters': 'JKL'},
      {'digit': '6', 'letters': 'MNO'},
      {'digit': '7', 'letters': 'PQRS'},
      {'digit': '8', 'letters': 'TUV'},
      {'digit': '9', 'letters': 'WXYZ'},
      {'digit': '*', 'letters': ''},
      {'digit': '0', 'letters': '+'},
      {'digit': '#', 'letters': ''},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_dtmfHistory.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                _dtmfHistory,
                style: const TextStyle(fontSize: 20, color: Colors.white, fontFamily: 'monospace', letterSpacing: 2),
              ),
            ),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 12,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 16,
              crossAxisSpacing: 24,
              childAspectRatio: 1.0,
            ),
            itemBuilder: (ctx, idx) {
              final item = dialKeys[idx];
              final digit = item['digit']!;
              final letters = item['letters']!;

              return InkWell(
                onTap: () => _onPressDtmfDigit(digit),
                borderRadius: BorderRadius.circular(36),
                child: ClipOval(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0x33FFFFFF),
                        border: Border.all(color: Colors.white.withOpacity(0.30), width: 1.2),
                      ),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              digit,
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            if (letters.isNotEmpty)
                              Text(
                                letters,
                                style: const TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFFE5E7EB),
                                  letterSpacing: 0.8,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // INCOMING CALL CONTROLS (Decline & Answer with SMS reply)
  // =========================================================================
  Widget _buildIncomingCallControls() {
    return Column(
      children: [
        TextButton.icon(
          onPressed: _showQuickSmsSheet,
          icon: const Icon(Icons.message_outlined, color: Colors.white70, size: 16),
          label: const Text(
            'Reply with message',
            style: TextStyle(color: Colors.white70, fontSize: 13),
          ),
        ),
        const SizedBox(height: 32),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Decline Button (Red)
              Column(
                children: [
                  InkWell(
                    onTap: _rejectCall,
                    borderRadius: BorderRadius.circular(36),
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFFDC2626),
                      ),
                      child: const Center(
                        child: Icon(Icons.call_end_rounded, color: Colors.white, size: 34),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Decline', style: TextStyle(color: Colors.white70, fontSize: 13)),
                ],
              ),

              // Answer Button (Green)
              Column(
                children: [
                  InkWell(
                    onTap: _answerCall,
                    borderRadius: BorderRadius.circular(36),
                    child: Container(
                      width: 72,
                      height: 72,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF16A34A),
                      ),
                      child: const Center(
                        child: Icon(Icons.call_rounded, color: Colors.white, size: 34),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Answer', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  // =========================================================================
  // CALL ENDED SUMMARY
  // =========================================================================
  Widget _buildCallEndedSummary(String displayName) {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(24),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: const Color(0xFF18181C),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle_outline, color: Color(0xFF10B981), size: 48),
            const SizedBox(height: 12),
            const Text(
              'Call Ended',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white),
            ),
            const SizedBox(height: 6),
            Text(
              displayName,
              style: const TextStyle(fontSize: 16, color: Colors.white70),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                'Duration: ${_formatDuration(_durationSeconds)}',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF10B981)),
              ),
            ),
            if (_callNote.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                'Note: "$_callNote"',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Color(0xFF38BDF8), fontStyle: FontStyle.italic),
              ),
            ],
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildSummaryAction(
                  icon: Icons.chat_bubble_outline,
                  label: 'WhatsApp',
                  color: const Color(0xFF25D366),
                  onTap: () async {
                    final clean = widget.phoneNumber.replaceAll(RegExp(r'[^\d]'), '');
                    final uri = Uri.parse('https://wa.me/$clean');
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _buildSummaryAction(
                  icon: Icons.sms_outlined,
                  label: 'SMS',
                  color: const Color(0xFF38BDF8),
                  onTap: () async {
                    final uri = Uri(scheme: 'sms', path: widget.phoneNumber);
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                _buildSummaryAction(
                  icon: Icons.block,
                  label: 'Block',
                  color: const Color(0xFFEF4444),
                  onTap: () {
                    BlockedNumbersService.blockNumber(widget.phoneNumber);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Blocked ${widget.phoneNumber}')),
                    );
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFDC2626),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () => Navigator.pop(context),
                child: const Text('Back to Dialer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryAction({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.15),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}
