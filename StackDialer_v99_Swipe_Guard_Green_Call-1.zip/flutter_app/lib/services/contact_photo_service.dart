import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'call_data_service.dart';

/// Shared, cached contact photos used by Contacts, Recents and the call UI.
/// Decoding is deliberately kept out of widget build methods to avoid scroll jank.
class ContactPhotoService {
  static const String preferenceKey = 'stackdialer_shared_contact_photos_v1';
  static final ValueNotifier<Map<String, String>> photosNotifier =
      ValueNotifier<Map<String, String>>(<String, String>{});

  static Map<String, String> _photos = <String, String>{};
  static final Map<String, Uint8List> _decodedBytes = <String, Uint8List>{};
  static final Map<String, ImageProvider> _imageProviders = <String, ImageProvider>{};
  static Future<Map<String, String>>? _loadFuture;

  static Future<Map<String, String>> loadAll({bool forceRefresh = false}) async {
    if (forceRefresh) _loadFuture = null;
    final pending = _loadFuture;
    if (pending != null) return pending;
    _loadFuture = _readPhotos();
    return _loadFuture!;
  }

  static Future<Map<String, String>> _readPhotos() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(preferenceKey);
    Map<String, String> next = <String, String>{};
    if (raw != null && raw.isNotEmpty) {
      try {
        next = Map<String, dynamic>.from(jsonDecode(raw) as Map)
            .map((key, value) => MapEntry(key, value.toString()));
      } catch (_) {
        next = <String, String>{};
      }
    }
    _photos = next;
    if (!mapEquals(photosNotifier.value, next)) {
      photosNotifier.value = Map<String, String>.unmodifiable(next);
    }
    return Map<String, String>.from(_photos);
  }

  static Future<String?> loadForNumber(String number) async {
    final photos = await loadAll();
    return photos[CallDataService.normalizeNumber(number)];
  }

  static ImageProvider? providerForBase64(String? encoded) {
    if (encoded == null || encoded.isEmpty) return null;
    final existing = _imageProviders[encoded];
    if (existing != null) return existing;
    try {
      final bytes = base64Decode(encoded);
      _decodedBytes[encoded] = bytes;
      final provider = MemoryImage(bytes);
      _imageProviders[encoded] = provider;
      return provider;
    } catch (_) {
      return null;
    }
  }

  static Uint8List? bytesForBase64(String? encoded) {
    if (encoded == null || encoded.isEmpty) return null;
    final cached = _decodedBytes[encoded];
    if (cached != null) return cached;
    try {
      final bytes = base64Decode(encoded);
      _decodedBytes[encoded] = bytes;
      _imageProviders.putIfAbsent(encoded, () => MemoryImage(bytes));
      return bytes;
    } catch (_) {
      return null;
    }
  }

  static Future<void> saveForNumber(String number, String base64Image) async {
    final photos = await loadAll();
    final key = CallDataService.normalizeNumber(number);
    photos[key] = base64Image;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(preferenceKey, jsonEncode(photos));
    _photos = photos;
    _decodedBytes.remove(base64Image);
    _imageProviders.remove(base64Image);
    // Decode once and retain a stable provider for every screen.
    bytesForBase64(base64Image);
    _loadFuture = Future.value(Map<String, String>.from(_photos));
    photosNotifier.value = Map<String, String>.unmodifiable(_photos);
  }

  static Future<void> removeForNumber(String number) async {
    final photos = await loadAll();
    final key = CallDataService.normalizeNumber(number);
    final removed = photos.remove(key);
    if (removed == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(preferenceKey, jsonEncode(photos));
    _photos = photos;
    _loadFuture = Future.value(Map<String, String>.from(_photos));
    _decodedBytes.remove(removed);
    _imageProviders.remove(removed);
    photosNotifier.value = Map<String, String>.unmodifiable(_photos);
  }
}
