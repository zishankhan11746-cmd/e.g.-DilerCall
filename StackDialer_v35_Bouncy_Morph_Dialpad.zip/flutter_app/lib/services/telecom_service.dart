import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/call_record.dart';
import '../models/contact.dart';

class TelecomService {
  static const MethodChannel _channel = MethodChannel('com.stackdialer.app/telecom');

  static void Function(String number, String state)? _callListener;
  static final Set<void Function(String number, String state)> _additionalCallListeners = {};
  static void Function(bool isSpeaker, bool isMuted)? _audioRouteListener;
  static bool _channelInitialized = false;

  static void setupCallListener(void Function(String number, String state) listener) {
    // MainDialerHost owns the persistent app-level listener.
    _callListener = listener;
    _ensureChannelListening();
  }

  static void Function() addCallListener(void Function(String number, String state) listener) {
    // Screen-level listeners must not replace the host listener. Return a disposer
    // so every ActiveCallScreen removes its callback when its route is destroyed.
    _additionalCallListeners.add(listener);
    _ensureChannelListening();
    return () => _additionalCallListeners.remove(listener);
  }

  static void setupAudioRouteListener(void Function(bool isSpeaker, bool isMuted) listener) {
    _audioRouteListener = listener;
    _ensureChannelListening();
  }

  static void _ensureChannelListening() {
    if (_channelInitialized) return;
    _channelInitialized = true;

    _channel.setMethodCallHandler((call) async {
      if (call.method == 'onCallStateChanged') {
        final args = call.arguments as Map?;
        final number = (args?['number'] as String?) ?? 'Unknown';
        final state = (args?['state'] as String?) ?? 'IDLE';
        _callListener?.call(number, state);
        for (final listener in List.of(_additionalCallListeners)) {
          listener(number, state);
        }
      } else if (call.method == 'onAudioStateChanged') {
        final args = call.arguments as Map?;
        final isSpeaker = (args?['isSpeaker'] as bool?) ?? false;
        final isMuted = (args?['isMuted'] as bool?) ?? false;
        _audioRouteListener?.call(isSpeaker, isMuted);
      }
    });
  }


  static Future<bool> openSystemRingtoneSettings() async {
    try { return await _channel.invokeMethod<bool>('openSystemRingtoneSettings') ?? false; }
    catch (_) { return false; }
  }

  static Future<int> getCallStartTimeMillis() async {
    try {
      final value = await _channel.invokeMethod<num>('getCallStartTimeMillis');
      return value?.toInt() ?? 0;
    } catch (_) {
      return 0;
    }
  }

  static Future<Map<String, String>?> getPendingIncomingCall() async {
    try {
      final res = await _channel.invokeMethod('getPendingCall');
      if (res is Map) {
        return {
          'number': (res['number'] as String?) ?? '',
          'state': (res['state'] as String?) ?? '',
        };
      }
    } catch (_) {}
    return null;
  }

  static Future<bool> requestPermissions() async {
    try {
      final statuses = await [
        Permission.phone,
        Permission.contacts,
        Permission.notification,
      ].request();
      return statuses.values.every((s) => s.isGranted);
    } catch (_) {
      return false;
    }
  }

  static Future<bool> isDefaultDialer() async {
    try {
      final bool? isDefault = await _channel.invokeMethod('isDefaultDialer');
      return isDefault ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestDefaultDialer() async {
    try {
      await _channel.invokeMethod('requestDefaultDialer');
    } catch (_) {}
  }

  static Future<String> getSimCarrierName() async {
    try {
      final res = await _channel.invokeMethod('getSimInfo');
      if (res is Map && res['carrierName'] != null) {
        return res['carrierName'].toString();
      }
    } catch (_) {}
    return 'Carrier SIM';
  }

  static Future<bool> makeRealCall(String phoneNumber, {int simSlot = 1}) async {
    final clean = phoneNumber.replaceAll(RegExp(r'[^\d+*#]'), '');
    if (clean.isEmpty) return false;

    // SIM selection must be performed by Android Telecom using the actual
    // PhoneAccountHandle for the requested subscription. Do not fall back to
    // ACTION_CALL / a generic caller because that can silently use the other SIM.
    try {
      final bool? result = await _channel.invokeMethod<bool>('makeCall', {
        'number': clean,
        'simSlot': simSlot,
      });
      return result ?? false;
    } on PlatformException {
      rethrow;
    } catch (_) {
      return false;
    }
  }

  static Future<void> answerCall() async {
    try {
      await _channel.invokeMethod('answerCall');
    } catch (_) {}
  }

  static Future<void> rejectCall() async {
    try {
      await _channel.invokeMethod('rejectCall');
    } catch (_) {}
  }

  static Future<void> disconnectCall() async {
    try {
      await _channel.invokeMethod('disconnectCall');
    } catch (_) {}
  }

  static Future<void> setMuted(bool isMuted) async {
    try {
      await _channel.invokeMethod('setMuted', {'muted': isMuted});
    } catch (_) {}
  }

  static Future<void> setSpeaker(bool isSpeaker) async {
    try {
      // Send both parameter keys to avoid MethodChannel mismatch with Android native handlers
      await _channel.invokeMethod('setSpeaker', {
        'speaker': isSpeaker,
        'enabled': isSpeaker,
      });
    } catch (_) {}
  }

  static Future<bool> isSpeakerOn() async {
    try {
      final bool? res = await _channel.invokeMethod('isSpeakerOn');
      return res ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> holdCall(bool isHold) async {
    try {
      await _channel.invokeMethod('holdCall', {'hold': isHold});
    } catch (_) {}
  }

  static void playDtmf(String digit) {
    try {
      _channel.invokeMethod('playDtmf', {'digit': digit});
    } catch (_) {}
  }

  static void stopDtmf() {
    try {
      _channel.invokeMethod('stopDtmf');
    } catch (_) {}
  }

  static Future<void> showIncomingBanner(String number, [String? name]) async {
    try {
      await _channel.invokeMethod('showIncomingBanner', {
        'number': number,
        'name': name,
      });
    } catch (_) {}
  }

  static Future<void> cancelIncomingBanner() async {
    try {
      await _channel.invokeMethod('cancelIncomingBanner');
    } catch (_) {}
  }

  static Future<void> showOngoingNotification(
    String number, {
    String? name,
    bool isIncoming = false,
    bool isMuted = false,
    bool isSpeaker = false,
  }) async {
    try {
      await _channel.invokeMethod('showOngoingNotification', {
        'number': number,
        'name': name,
        'isIncoming': isIncoming,
        'isMuted': isMuted,
        'isSpeaker': isSpeaker,
      });
    } catch (_) {}
  }

  static Future<void> cancelOngoingNotification() async {
    try {
      await _channel.invokeMethod('cancelOngoingNotification');
    } catch (_) {}
  }

  static Future<List<CallRecord>> fetchDeviceCallLogs() async {
    try {
      final dynamic rawLogs = await _channel.invokeMethod('getCallLogs');
      if (rawLogs is List) {
        final List<CallRecord> records = [];
        // Resolve blank/number-only call-log names against the device contacts so
        // saved callers are displayed by name in Recents.
        final Map<String, String> savedContactNames = {};
        try {
          final hasContactsPermission = await FlutterContacts.requestPermission(readonly: true);
          if (hasContactsPermission) {
            final deviceContacts = await FlutterContacts.getContacts(
              withProperties: true,
              withPhoto: false,
            );
            String digitsOnly(String value) => value.replaceAll(RegExp(r'\D'), '');
            for (final contact in deviceContacts) {
              final displayName = contact.displayName.trim();
              if (displayName.isEmpty) continue;
              for (final phone in contact.phones) {
                final digits = digitsOnly(phone.number);
                if (digits.length >= 7) {
                  savedContactNames.putIfAbsent(digits, () => displayName);
                  // A suffix key also handles country-code/local-format differences.
                  savedContactNames.putIfAbsent(digits.substring(digits.length > 10 ? digits.length - 10 : 0), () => displayName);
                }
              }
            }
          }
        } catch (_) {
          // Call logs remain usable even if contacts permission is unavailable.
        }
        for (final raw in rawLogs) {
          if (raw is Map) {
            final id = raw['id']?.toString() ?? 'log_${DateTime.now().microsecondsSinceEpoch}';
            final number = raw['number']?.toString() ?? 'Unknown';
            final rawName = raw['name']?.toString() ?? '';
            final digits = number.replaceAll(RegExp(r'\D'), '');
            final matchedContactName = savedContactNames[digits] ??
                (digits.length >= 7 ? savedContactNames[digits.substring(digits.length > 10 ? digits.length - 10 : 0)] : null);
            final resolvedName = rawName.trim().isNotEmpty && rawName.trim() != number
                ? rawName.trim()
                : (matchedContactName ?? '');
            final typeStr = raw['type']?.toString() ?? 'incoming';
            final timestampMs = raw['timestamp'] is num ? (raw['timestamp'] as num).toInt() : DateTime.now().millisecondsSinceEpoch;
            final durationSec = raw['duration'] is num ? (raw['duration'] as num).toInt() : 0;
            final loc = raw['location']?.toString() ?? 'Mobile';

            CallType type = CallType.incoming;
            if (typeStr == 'outgoing') {
              type = CallType.outgoing;
            } else if (typeStr == 'missed') {
              type = CallType.missed;
            } else if (typeStr == 'rejected') {
              type = CallType.rejected;
            }

            records.add(
              CallRecord(
                id: id,
                name: resolvedName.isNotEmpty ? resolvedName : number,
                number: number,
                type: type,
                timestamp: DateTime.fromMillisecondsSinceEpoch(timestampMs),
                durationSeconds: durationSec,
                simSlot: 1,
                simCarrier: 'Carrier SIM',
                category: resolvedName.isNotEmpty ? 'Contact' : 'Recent',
                location: loc.isNotEmpty ? loc : 'Mobile',
              ),
            );
          }
        }
        return records;
      }
    } catch (e) {
      // Permission denied or native query unavailable
    }
    return [];
  }

  static Future<List<ContactModel>> fetchDeviceContacts() async {
    try {
      final bool hasPermission = await FlutterContacts.requestPermission(readonly: true);
      if (hasPermission) {
        final List<Contact> contacts = await FlutterContacts.getContacts(
          withProperties: true,
          withPhoto: false,
        );
        if (contacts.isNotEmpty) {
          return contacts.where((c) => c.phones.isNotEmpty).map((c) {
            final phone = c.phones.first.number;
            return ContactModel(
              id: c.id,
              name: c.displayName,
              number: phone,
              company: 'Device Contact',
              isFavorite: false,
            );
          }).toList();
        }
      }
    } catch (_) {}
    return [];
  }
}
