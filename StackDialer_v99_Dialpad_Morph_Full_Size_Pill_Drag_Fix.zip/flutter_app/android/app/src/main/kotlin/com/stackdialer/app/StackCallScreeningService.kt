package com.stackdialer.app

import android.telecom.Call
import android.telecom.CallScreeningService
import android.os.Build

/** Rejects explicitly blocked numbers and, when enabled, silences anonymous callers.
 * Android only binds this service after the user grants the Call Screening role. */
class StackCallScreeningService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        if (details.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(details, CallResponse.Builder().setDisallowCall(false).build())
            return
        }
        val handle = details.handle
        val number = handle?.schemeSpecificPart.orEmpty()
        if (number.isNotBlank() && isBlocked(number)) {
            val blockedResponse = CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(true)
                .build()
            respondToCall(details, blockedResponse)
            return
        }
        // No trustworthy spam-number feed is bundled with the app. When the
        // opt-in protection is enabled, only anonymous/restricted callers are
        // silenced; ordinary unknown mobile numbers are never auto-rejected.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && isAnonymousProtectionEnabled() &&
            (handle == null || details.handlePresentation != android.telecom.TelecomManager.PRESENTATION_ALLOWED)) {
            respondToCall(details, CallResponse.Builder()
                .setDisallowCall(false)
                .setSilenceCall(true)
                .build())
            return
        }
        respondToCall(details, CallResponse.Builder().setDisallowCall(false).build())
    }

    private fun isAnonymousProtectionEnabled(): Boolean =
        getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE)
            .getBoolean("flutter.stackdialer_spam_detection_enabled", false)

    private fun isBlocked(number: String): Boolean {
        val prefs = getSharedPreferences("stackdialer_blocked_native", MODE_PRIVATE)
        val blocked = prefs.getStringSet("numbers", emptySet()).orEmpty()
        val candidate = normalize(number)
        return candidate.isNotEmpty() && blocked.any { normalize(it) == candidate }
    }

    private fun normalize(value: String): String = value.filter { it.isDigit() }
        .removePrefix("91").let { if (it.length == 10) it else value.filter { c -> c.isDigit() } }
}
