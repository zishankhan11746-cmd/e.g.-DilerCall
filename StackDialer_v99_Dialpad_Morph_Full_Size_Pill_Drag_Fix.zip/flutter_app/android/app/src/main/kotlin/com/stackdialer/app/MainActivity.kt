package com.stackdialer.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.ContentValues
import android.net.Uri
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.telephony.SubscriptionManager
import android.graphics.Color
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.stackdialer.app/telecom"
    private val REQUEST_ID_SET_DEFAULT_DIALER = 1001
    private var dialToneGenerator: ToneGenerator? = null
    private var pendingBackupJson: String? = null
    private var pendingBackupResult: MethodChannel.Result? = null
    private var pendingImportResult: MethodChannel.Result? = null
    private var pendingDefaultDialerResult: MethodChannel.Result? = null
    private var pendingCallLogPermissionResult: MethodChannel.Result? = null
    private val REQUEST_CALL_LOG_PERMISSIONS = 2006
    private val REQUEST_EXPORT_BACKUP = 4101
    private val REQUEST_IMPORT_BACKUP = 4102
    private val REQUEST_CONTACT_RINGTONE = 4103
    private var pendingContactRingtoneId: String? = null
    private var pendingContactRingtoneResult: MethodChannel.Result? = null

    companion object {
        const val CHANNEL_ID = "stackdialer_incoming_calls_silent"
        const val NOTIFICATION_ID = 2001
        var methodChannel: MethodChannel? = null
        var pendingCallNumber: String? = null
        var pendingCallState: String? = null
        @Volatile var isAppInForeground: Boolean = false

        fun notifyCallState(number: String, state: String) {
            pendingCallNumber = number
            pendingCallState = state
            if (state == "DISCONNECTED" || state == "IDLE") {
                // Clear pending call state once disconnected
                pendingCallNumber = null
                pendingCallState = null
            }
            methodChannel?.invokeMethod("onCallStateChanged", mapOf(
                "number" to number,
                "state" to state
            ))
        }

        fun notifyAudioState(isSpeaker: Boolean, isMuted: Boolean) {
            methodChannel?.invokeMethod("onAudioStateChanged", mapOf(
                "isSpeaker" to isSpeaker,
                "isMuted" to isMuted
            ))
        }

        fun showIncomingCallBanner(context: Context, number: String, name: String?) {
            // Never manufacture a caller banner for an empty/unknown handle.
            if (number.isBlank() || number.equals("unknown", ignoreCase = true)) return
            try {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                // When StackDialer is already visible, its Telecom listener opens the
                // in-app incoming screen. A second full-screen notification here was
                // creating a duplicate/fake-looking popup over the real call UI.
                if (isAppInForeground) {
                    notificationManager.cancel(NOTIFICATION_ID)
                    return
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        "StackDialer Incoming Calls (Silent Alert)",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "Silent incoming-call controls; ringtone is handled by Android Telecom"
                        enableLights(true)
                        enableVibration(false)
                        setSound(null, null)
                        lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                    }
                    notificationManager.createNotificationChannel(channel)
                }

                // Full screen intent to bring StackDialer to front (works even on locked screen)
                val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
                    action = Intent.ACTION_MAIN
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("incoming_number", number)
                    putExtra("incoming_name", name ?: number)
                }

                val fullScreenPendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    fullScreenIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // Answer Action PendingIntent
                val answerIntent = Intent(context, CallActionReceiver::class.java).apply {
                    action = CallActionReceiver.ACTION_ANSWER
                    putExtra("number", number)
                }
                val answerPendingIntent = PendingIntent.getBroadcast(
                    context,
                    1,
                    answerIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // Reject Action PendingIntent
                val rejectIntent = Intent(context, CallActionReceiver::class.java).apply {
                    action = CallActionReceiver.ACTION_REJECT
                    putExtra("number", number)
                }
                val rejectPendingIntent = PendingIntent.getBroadcast(
                    context,
                    2,
                    rejectIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val displayName = if (!name.isNullOrBlank()) name else number
                val contentText = if (!name.isNullOrBlank()) "Incoming call • $number" else "Incoming Cellular Call..."
                val appIcon = context.applicationInfo.icon.takeIf { it != 0 } ?: android.R.drawable.sym_call_incoming

                val person = androidx.core.app.Person.Builder()
                    .setName(displayName)
                    .setImportant(true)
                    .build()

                val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(appIcon)
                    .setContentTitle(displayName)
                    .setContentText(contentText)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setAutoCancel(false)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setFullScreenIntent(fullScreenPendingIntent, true)
                    .setContentIntent(fullScreenPendingIntent)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        builder.setStyle(
                            NotificationCompat.CallStyle.forIncomingCall(
                                person,
                                rejectPendingIntent,
                                answerPendingIntent
                            )
                        )
                    } catch (_: Throwable) {
                        builder.addAction(android.R.drawable.sym_action_call, "ANSWER", answerPendingIntent)
                        builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "DECLINE", rejectPendingIntent)
                    }
                } else {
                    builder.addAction(android.R.drawable.sym_action_call, "ANSWER", answerPendingIntent)
                    builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "DECLINE", rejectPendingIntent)
                }

                notificationManager.notify(NOTIFICATION_ID, builder.build())
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        fun cancelIncomingCallBanner(context: Context) {
            try {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(NOTIFICATION_ID)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        const val ONGOING_CHANNEL_ID = "stackdialer_ongoing_calls_v9"
        const val ONGOING_NOTIFICATION_ID = 2002
        const val ACTION_OPEN_ACTIVE_CALL = "com.stackdialer.app.ACTION_OPEN_ACTIVE_CALL"
        var callStartTimeMillis: Long = 0L
        private const val CALL_PREFS = "stackdialer_call_session"
        private const val CALL_START_KEY = "connected_at"

        fun setCallConnectedAt(context: Context, timestamp: Long) {
            if (timestamp <= 0L) return
            callStartTimeMillis = timestamp
            context.getSharedPreferences(CALL_PREFS, Context.MODE_PRIVATE)
                .edit().putLong(CALL_START_KEY, timestamp).apply()
        }

        fun restoreCallConnectedAt(context: Context): Long {
            if (callStartTimeMillis > 0L) return callStartTimeMillis
            callStartTimeMillis = context.getSharedPreferences(CALL_PREFS, Context.MODE_PRIVATE)
                .getLong(CALL_START_KEY, 0L)
            return callStartTimeMillis
        }

        fun clearCallConnectedAt(context: Context) {
            callStartTimeMillis = 0L
            context.getSharedPreferences(CALL_PREFS, Context.MODE_PRIVATE)
                .edit().remove(CALL_START_KEY).apply()
        }

        fun buildOngoingCallNotification(
            context: Context,
            number: String,
            name: String?,
            isIncoming: Boolean,
            isMuted: Boolean,
            isSpeaker: Boolean
        ): android.app.Notification? {
            try {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

                // High importance enables call heads-up behavior; Telecom/CallStyle controls
                // the device-native ongoing-call presentation.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        ONGOING_CHANNEL_ID,
                        "StackDialer Active Call",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "StackDialer ongoing cellular call notification"
                        enableLights(false)
                        enableVibration(false)
                        setSound(null, null)
                        lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                        setShowBadge(true)
                    }
                    notificationManager.createNotificationChannel(channel)
                }

                // Restore the original Telecom connection timestamp; never start a new
                // timer merely because a notification is being rebuilt.
                restoreCallConnectedAt(context)
                val connected = callStartTimeMillis > 0L
                val effectiveCallStart = callStartTimeMillis.takeIf { it > 0L }
                    ?: System.currentTimeMillis()

                // Use a dedicated, explicit action so a tap on the ongoing-call
                // notification/status capsule restores the call route, not the dial pad.
                // CLEAR_TOP also recreates the single MainActivity when its task was
                // swiped away from Recents; SINGLE_TOP delivers taps to onNewIntent.
                val bringToFrontIntent = Intent(context, MainActivity::class.java).apply {
                    action = ACTION_OPEN_ACTIVE_CALL
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("active_number", number)
                    putExtra("active_name", name ?: number)
                    putExtra("active_call_entry", true)
                }
                val bringToFrontPendingIntent = PendingIntent.getActivity(
                    context,
                    12002,
                    bringToFrontIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // Disconnect Action PendingIntent
                val hangupIntent = Intent(context, CallActionReceiver::class.java).apply {
                    action = CallActionReceiver.ACTION_DISCONNECT
                    putExtra("number", number)
                }
                val hangupPendingIntent = PendingIntent.getBroadcast(
                    context,
                    11,
                    hangupIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val displayName = if (!name.isNullOrBlank()) name else number
                val elapsedSec = if (callStartTimeMillis > 0L) {
                    ((System.currentTimeMillis() - callStartTimeMillis) / 1000).coerceAtLeast(0)
                } else {
                    0L
                }
                val mins = (elapsedSec / 60).toString().padStart(2, '0')
                val secs = (elapsedSec % 60).toString().padStart(2, '0')
                val durationFormatted = "$mins:$secs"
                val appIcon = context.applicationInfo.icon.takeIf { it != 0 } ?: R.drawable.ic_call_white

                val builder = NotificationCompat.Builder(context, ONGOING_CHANNEL_ID)
                    .setSmallIcon(appIcon)
                    .setContentTitle(displayName)
                    .setContentText(if (connected) "Ongoing Call • $durationFormatted" else "Calling…")
                    .setSubText(if (connected) durationFormatted else "Connecting")
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setAutoCancel(false)
                    .setOngoing(true) // CANNOT be cleared or swiped away until call terminates!
                    .setOnlyAlertOnce(true) // Never re-alert or chime on timer ticks
                    .setContentIntent(bringToFrontPendingIntent)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // 100% visible on lock screen
                    .setColor(Color.parseColor("#6B4B38"))
                    .setColorized(false)
                    .setUsesChronometer(connected)
                    .setWhen(effectiveCallStart)
                    .setShowWhen(connected)
                    .setChronometerCountDown(false)

                val person = androidx.core.app.Person.Builder()
                    .setName(displayName)
                    .setImportant(true)
                    .build()

                // Android 12+ uses the platform CallStyle so One UI can render its native
                // compact ongoing-call notification without our own duplicate action row.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        val callStyle = NotificationCompat.CallStyle.forOngoingCall(
                            person,
                            hangupPendingIntent
                        )
                        builder.setStyle(callStyle)
                    } catch (_: Throwable) {}
                } else {
                    // For Android < 12, use custom RemoteViews layout
                    try {
                        val remoteViews = RemoteViews(context.packageName, R.layout.notification_ongoing_call).apply {
                            setTextViewText(R.id.tv_call_title, "Call")
                            setTextViewText(R.id.tv_caller_name, displayName)
                            if (callStartTimeMillis > 0L) {
                                val elapsedRealtimeBase = android.os.SystemClock.elapsedRealtime() -
                                    (System.currentTimeMillis() - callStartTimeMillis).coerceAtLeast(0L)
                                setChronometer(R.id.chronometer_call, elapsedRealtimeBase, null, true)
                                setViewVisibility(R.id.chronometer_call, android.view.View.VISIBLE)
                            } else {
                                setViewVisibility(R.id.chronometer_call, android.view.View.GONE)
                            }
                            setOnClickPendingIntent(R.id.layout_ongoing_call_root, bringToFrontPendingIntent)
                            setOnClickPendingIntent(R.id.btn_end_call, hangupPendingIntent)
                        }
                        builder.setCustomContentView(remoteViews)
                        builder.setCustomBigContentView(remoteViews)
                        builder.setStyle(NotificationCompat.DecoratedCustomViewStyle())
                    } catch (_: Throwable) {}
                }

                // The native CallStyle (Android 12+) or single end button (older Android)
                // is the only action surface; no duplicate text action row is added.

                return builder.build()
            } catch (e: Throwable) {
                e.printStackTrace()
                return null
            }
        }

        fun showOngoingCallNotification(
            context: Context,
            number: String,
            name: String?,
            isIncoming: Boolean,
            isMuted: Boolean,
            isSpeaker: Boolean
        ) {
            try {
                val notification = buildOngoingCallNotification(context, number, name, isIncoming, isMuted, isSpeaker)
                if (notification != null) {
                    val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    notificationManager.notify(ONGOING_NOTIFICATION_ID, notification)
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        fun cancelOngoingCallNotification(context: Context) {
            try {
                clearCallConnectedAt(context)
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(ONGOING_NOTIFICATION_ID)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2005)
                }
            } catch (_: Throwable) {}
        }
        handleCallIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        isAppInForeground = true
    }

    override fun onPause() {
        isAppInForeground = false
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleCallIntent(intent)
        if (intent.action == "com.stackdialer.app.OPEN_CALLBACK_REMINDER" || intent.hasExtra("reminder_number")) {
            methodChannel?.invokeMethod("onReminderNotificationTap", null)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CALL_LOG_PERMISSIONS) {
            val readGranted = checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val writeGranted = checkSelfPermission(android.Manifest.permission.WRITE_CALL_LOG) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val callback = pendingCallLogPermissionResult
            pendingCallLogPermissionResult = null
            callback?.success(readGranted && writeGranted)
        }
    }

    @Deprecated("Deprecated in Android API; retained for the document picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_EXPORT_BACKUP) {
            val callback = pendingBackupResult
            val json = pendingBackupJson
            pendingBackupResult = null
            pendingBackupJson = null
            if (resultCode == RESULT_OK && data?.data != null && json != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json) }
                    callback?.success(true)
                } catch (e: Exception) { callback?.error("BACKUP_WRITE", e.message, null) }
            } else callback?.success(false)
        } else if (requestCode == REQUEST_IMPORT_BACKUP) {
            val callback = pendingImportResult
            pendingImportResult = null
            if (resultCode == RESULT_OK && data?.data != null) {
                try {
                    val json = contentResolver.openInputStream(data.data!!)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    callback?.success(json)
                } catch (e: Exception) { callback?.error("BACKUP_READ", e.message, null) }
            } else callback?.success(null)
        } else if (requestCode == REQUEST_ID_SET_DEFAULT_DIALER) {
            val callback = pendingDefaultDialerResult
            pendingDefaultDialerResult = null
            val isDefault = (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage == packageName
            callback?.success(isDefault)
        } else if (requestCode == REQUEST_CONTACT_RINGTONE) {
            val contactId = pendingContactRingtoneId
            val callback = pendingContactRingtoneResult
            pendingContactRingtoneId = null
            pendingContactRingtoneResult = null
            if (contactId == null) {
                callback?.success(false)
            } else {
                try {
                    val picked = if (resultCode == RESULT_OK) data?.getParcelableExtra<Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI) else null
                    val contactUri = android.content.ContentUris.withAppendedId(android.provider.ContactsContract.Contacts.CONTENT_URI, contactId.toLong())
                    val values = ContentValues().apply { put(android.provider.ContactsContract.Contacts.CUSTOM_RINGTONE, picked?.toString()) }
                    val updated = contentResolver.update(contactUri, values, null, null) > 0
                    callback?.success(updated)
                } catch (e: Exception) {
                    callback?.error("CONTACT_RINGTONE", e.message, null)
                }
            }
        }
    }

    private fun handleCallIntent(intent: Intent?) {
        if (intent == null) return

        // A notification/status-capsule tap must carry enough information to restore
        // the call screen even when Android has removed the app task from Recents.
        val call = InCallServiceImpl.currentCall
        // Intent extras are only routing hints, never proof that a call exists.
        // Treating an old incoming_number extra as RINGING when Telecom had no
        // live Call created a fake incoming-call screen after stale notifications.
        if (call == null) return
        val number = call.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }
            ?: return
        val state = when (call.state) {
            android.telecom.Call.STATE_RINGING -> "RINGING"
            android.telecom.Call.STATE_ACTIVE -> "ACTIVE"
            android.telecom.Call.STATE_HOLDING -> "HOLDING"
            android.telecom.Call.STATE_DIALING, android.telecom.Call.STATE_CONNECTING -> "DIALING"
            android.telecom.Call.STATE_DISCONNECTED -> "DISCONNECTED"
            else -> return
        }
        if (state == "DISCONNECTED") return
        notifyCallState(number, state)
    }

    private fun blockedPrefs() = getSharedPreferences("stackdialer_blocked_native", Context.MODE_PRIVATE)

    private fun normalizePhone(value: String): String {
        val digits = value.filter { it.isDigit() }
        return if (digits.length == 12 && digits.startsWith("91")) digits.drop(2) else digits
    }

    private fun archiveAndDeleteCallLog(id: String): Boolean {
        if (id.isBlank() || id.any { !it.isDigit() }) return false
        val rowUri = android.content.ContentUris.withAppendedId(CallLog.Calls.CONTENT_URI, id.toLong())
        val projection = arrayOf(
            CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE,
            CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.NEW,
            CallLog.Calls.COUNTRY_ISO, CallLog.Calls.GEOCODED_LOCATION,
            CallLog.Calls.NUMBER_PRESENTATION, CallLog.Calls.POST_DIAL_DIGITS,
            CallLog.Calls.VIA_NUMBER, CallLog.Calls.FEATURES,
            CallLog.Calls.PHONE_ACCOUNT_COMPONENT_NAME, CallLog.Calls.PHONE_ACCOUNT_ID
        )

        // Archive when the provider permits reading the row. Some OEMs grant
        // write access to the default dialer before read access is refreshed;
        // do not let an optional undo snapshot block the actual delete.
        val row = JSONObject()
        try {
            contentResolver.query(rowUri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    for (i in projection.indices) {
                        val column = projection[i]
                        val index = cursor.getColumnIndex(column)
                        if (index < 0 || cursor.isNull(index)) continue
                        when (cursor.getType(index)) {
                            android.database.Cursor.FIELD_TYPE_INTEGER -> row.put(column, cursor.getLong(index))
                            android.database.Cursor.FIELD_TYPE_FLOAT -> row.put(column, cursor.getDouble(index))
                            else -> row.put(column, cursor.getString(index))
                        }
                    }
                }
            }
        } catch (_: SecurityException) {
            // Continue to the provider delete; it may allow write-only access.
        } catch (_: Exception) { }

        val prefs = getSharedPreferences("stackdialer_deleted_call_logs", Context.MODE_PRIVATE)
        val all = try { JSONObject(prefs.getString("rows", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val archived = row.length() > 0
        if (archived) {
            row.put("deletedAt", System.currentTimeMillis())
            all.put(id, row)
            if (!prefs.edit().putString("rows", all.toString()).commit()) return false
        }

        // Some OEM CallLog providers return 0 for a row-URI delete even when
        // collection selection deletion is supported. Try both, then verify.
        var deletedCount = 0
        try { deletedCount = contentResolver.delete(rowUri, null, null) } catch (_: Exception) { }
        if (deletedCount <= 0) {
            try {
                deletedCount = contentResolver.delete(
                    CallLog.Calls.CONTENT_URI,
                    "${CallLog.Calls._ID} = ?",
                    arrayOf(id)
                )
            } catch (_: Exception) { }
        }

        val stillExists = try {
            contentResolver.query(rowUri, arrayOf(CallLog.Calls._ID), null, null, null)?.use { it.moveToFirst() } ?: false
        } catch (_: Exception) { true }
        val success = deletedCount > 0 || !stillExists
        if (!success && archived) {
            all.remove(id)
            prefs.edit().putString("rows", all.toString()).commit()
        }
        return success
    }

    private fun restoreDeletedCallLog(id: String): String? {
        val prefs = getSharedPreferences("stackdialer_deleted_call_logs", Context.MODE_PRIVATE)
        val all = try { JSONObject(prefs.getString("rows", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val row = all.optJSONObject(id) ?: return null
        val values = ContentValues()
        val keys = arrayOf(
            CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE,
            CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.NEW,
            CallLog.Calls.COUNTRY_ISO, CallLog.Calls.GEOCODED_LOCATION,
            CallLog.Calls.NUMBER_PRESENTATION, CallLog.Calls.POST_DIAL_DIGITS,
            CallLog.Calls.VIA_NUMBER, CallLog.Calls.FEATURES,
            CallLog.Calls.PHONE_ACCOUNT_COMPONENT_NAME, CallLog.Calls.PHONE_ACCOUNT_ID
        )
        for (key in keys) {
            if (!row.has(key) || row.isNull(key)) continue
            when (key) {
                CallLog.Calls.TYPE, CallLog.Calls.NEW, CallLog.Calls.FEATURES -> values.put(key, row.optInt(key))
                CallLog.Calls.DATE, CallLog.Calls.DURATION -> values.put(key, row.optLong(key))
                else -> values.put(key, row.optString(key))
            }
        }
        val inserted = contentResolver.insert(CallLog.Calls.CONTENT_URI, values) ?: return null
        all.remove(id)
        prefs.edit().putString("rows", all.toString()).apply()
        return inserted.lastPathSegment
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "pickContactRingtone" -> {
                    val contactId = call.argument<String>("contactId")
                    if (contactId.isNullOrBlank() || contactId.toLongOrNull() == null) {
                        result.error("CONTACT_ID", "A valid Android contact ID is required", null)
                    } else if (checkSelfPermission(android.Manifest.permission.WRITE_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        result.error("CONTACT_PERMISSION", "Allow Contacts permission to assign a ringtone", null)
                    } else {
                        pendingContactRingtoneId = contactId
                        pendingContactRingtoneResult = result
                        val picker = Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_RINGTONE)
                            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose ringtone for contact")
                            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        }
                        try { startActivityForResult(picker, REQUEST_CONTACT_RINGTONE) }
                        catch (e: Exception) { pendingContactRingtoneId = null; pendingContactRingtoneResult = null; result.error("RINGTONE_PICKER", e.message, null) }
                    }
                }
                "resetContactRingtone" -> {
                    val contactId = call.argument<String>("contactId")
                    try {
                        if (contactId.isNullOrBlank() || contactId.toLongOrNull() == null) result.success(false)
                        else {
                            val uri = android.content.ContentUris.withAppendedId(android.provider.ContactsContract.Contacts.CONTENT_URI, contactId.toLong())
                            val values = ContentValues().apply { putNull(android.provider.ContactsContract.Contacts.CUSTOM_RINGTONE) }
                            result.success(contentResolver.update(uri, values, null, null) > 0)
                        }
                    } catch (e: Exception) { result.error("CONTACT_RINGTONE", e.message, null) }
                }
                "openSystemRingtoneSettings" -> {
                    try {
                        val intent = Intent(Settings.ACTION_SOUND_SETTINGS)
                        startActivity(intent)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("RINGTONE_SETTINGS", e.message, null)
                    }
                }
                "getCallStartTimeMillis" -> {
                    result.success(restoreCallConnectedAt(this))
                }
                "consumePendingReminder" -> {
                    val number = intent?.getStringExtra("reminder_number")
                    val id = intent?.getStringExtra("reminder_id")
                    if (!number.isNullOrBlank()) {
                        intent?.removeExtra("reminder_number")
                        intent?.removeExtra("reminder_id")
                        result.success(mapOf("number" to number, "id" to (id ?: "")))
                    } else {
                        result.success(null)
                    }
                }
                "scheduleCallbackReminder" -> {
                    val id = call.argument<String>("id") ?: ""
                    val name = call.argument<String>("name") ?: "Contact"
                    val number = call.argument<String>("number") ?: ""
                    val atMillis = call.argument<Number>("atMillis")?.toLong() ?: 0L
                    val label = call.argument<String>("label") ?: "Callback reminder"
                    if (id.isBlank() || atMillis <= System.currentTimeMillis()) {
                        result.error("INVALID_REMINDER", "Reminder time must be in the future", null)
                    } else {
                        CallbackReminderReceiver.schedule(this, id, name, number, atMillis, label)
                        result.success(true)
                    }
                }
                "cancelCallbackReminder" -> {
                    val id = call.argument<String>("id") ?: ""
                    if (id.isNotBlank()) CallbackReminderReceiver.cancel(this, id)
                    result.success(true)
                }
                "exportBackup" -> {
                    val json = call.argument<String>("json")
                    if (json.isNullOrBlank()) {
                        result.error("EMPTY_BACKUP", "Backup data is empty", null)
                    } else {
                        pendingBackupJson = json
                        pendingBackupResult = result
                        val picker = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "application/json"
                            putExtra(Intent.EXTRA_TITLE, "StackDialer_Backup_${System.currentTimeMillis()}.json")
                        }
                        try { startActivityForResult(picker, REQUEST_EXPORT_BACKUP) }
                        catch (e: Exception) { pendingBackupResult = null; pendingBackupJson = null; result.error("BACKUP_PICKER", e.message, null) }
                    }
                }
                "importBackup" -> {
                    pendingImportResult = result
                    val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                    }
                    try { startActivityForResult(picker, REQUEST_IMPORT_BACKUP) }
                    catch (e: Exception) { pendingImportResult = null; result.error("IMPORT_PICKER", e.message, null) }
                }
                "getPendingCall" -> {
                    val liveCall = InCallServiceImpl.currentCall
                    val liveNumber = liveCall?.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }
                    val liveState = when (liveCall?.state) {
                        android.telecom.Call.STATE_RINGING -> "RINGING"
                        android.telecom.Call.STATE_ACTIVE -> "ACTIVE"
            android.telecom.Call.STATE_HOLDING -> "HOLDING"
                        android.telecom.Call.STATE_DIALING, android.telecom.Call.STATE_CONNECTING -> "DIALING"
                        else -> null
                    }
                    val number = liveNumber ?: pendingCallNumber
                    val state = liveState ?: pendingCallState
                    if (number != null && state != null) {
                        result.success(mapOf("number" to number, "state" to state))
                    } else {
                        result.success(null)
                    }
                }
                "getCallLogs" -> {
                    try {
                        val logs = fetchNativeCallLogs()
                        result.success(logs)
                    } catch (e: Exception) {
                        result.error("CALL_LOG_ERROR", e.message, null)
                    }
                }
                "requestCallLogPermissions" -> {
                    val readGranted = checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    val writeGranted = checkSelfPermission(android.Manifest.permission.WRITE_CALL_LOG) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (readGranted && writeGranted) {
                        result.success(true)
                    } else {
                        pendingCallLogPermissionResult = result
                        requestPermissions(
                            arrayOf(android.Manifest.permission.READ_CALL_LOG, android.Manifest.permission.WRITE_CALL_LOG),
                            REQUEST_CALL_LOG_PERMISSIONS
                        )
                    }
                }
                "deleteCallLog" -> {
                    try {
                        val id = call.argument<String>("id") ?: ""
                        if (id.isBlank() || id.any { !it.isDigit() }) {
                            result.success(false)
                        } else {
                            result.success(archiveAndDeleteCallLog(id))
                        }
                    } catch (e: SecurityException) {
                        result.error("CALL_LOG_PERMISSION", "Allow call-log access and set StackDialer as default dialer to delete device history", null)
                    } catch (e: Exception) {
                        result.error("CALL_LOG_DELETE_ERROR", e.message, null)
                    }
                }
                "getDeletedCallLogs" -> {
                    try {
                        val prefs = getSharedPreferences("stackdialer_deleted_call_logs", Context.MODE_PRIVATE)
                        val all = JSONObject(prefs.getString("rows", "{}") ?: "{}")
                        val rows = JSONArray()
                        val keys = all.keys()
                        while (keys.hasNext()) {
                            val id = keys.next(); val row = all.optJSONObject(id) ?: continue
                            rows.put(JSONObject().apply {
                                put("id", id); put("number", row.optString(CallLog.Calls.NUMBER))
                                put("name", row.optString(CallLog.Calls.CACHED_NAME))
                                put("deletedAt", row.optLong("deletedAt"))
                            })
                        }
                        result.success(rows.toString())
                    } catch (e: Exception) { result.error("TRASH_READ", e.message, null) }
                }
                "restoreDeletedCallLog" -> {
                    try {
                        val id = call.argument<String>("id") ?: ""
                        result.success(restoreDeletedCallLog(id))
                    } catch (e: SecurityException) {
                        result.error("CALL_LOG_PERMISSION", "Call-log write permission and default dialer access are required to restore", null)
                    } catch (e: Exception) { result.error("CALL_LOG_RESTORE", e.message, null) }
                }
                "syncBlockedNumbers" -> {
                    val numbers = call.argument<List<String>>("numbers") ?: emptyList()
                    val normalized = numbers.map { normalizePhone(it) }.filter { it.isNotBlank() }.toSet()
                    blockedPrefs().edit().putStringSet("numbers", normalized).apply()
                    result.success(normalized.size)
                }
                "requestCallScreeningRole" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val roleManager = getSystemService(RoleManager::class.java)
                        if (roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && !roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                            startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 4103)
                        }
                        result.success(roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING))
                    } else result.success(false)
                }
                "isCallScreeningRoleHeld" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        result.success(getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING))
                    } else result.success(false)
                }
                "canScheduleExactAlarms" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val alarm = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                        result.success(alarm.canScheduleExactAlarms())
                    } else result.success(true)
                }
                "requestExactAlarmPermission" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val alarm = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                        if (!alarm.canScheduleExactAlarms()) {
                            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                        }
                        result.success(alarm.canScheduleExactAlarms())
                    } else result.success(true)
                }
                "getSimInfo" -> {
                    try {
                        val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                        val carrier = tm.networkOperatorName.ifBlank { tm.simOperatorName }.ifBlank { "Carrier SIM" }
                        result.success(mapOf("carrierName" to carrier))
                    } catch (e: Exception) {
                        result.success(mapOf("carrierName" to "Carrier SIM"))
                    }
                }
                "requestDefaultDialer" -> {
                    val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                    if (telecomManager.defaultDialerPackage == packageName) {
                        result.success(true)
                    } else {
                        pendingDefaultDialerResult = result
                        requestSetDefaultDialer(result)
                    }
                }
                "isDefaultDialer" -> {
                    val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                    val isDefault = telecomManager.defaultDialerPackage == packageName
                    result.success(isDefault)
                }
                "answerCall" -> {
                    val accepted = InCallServiceImpl.answerCurrentCall()
                    if (accepted) cancelIncomingCallBanner(this)
                    result.success(accepted)
                }
                "rejectCall" -> {
                    InCallServiceImpl.rejectCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "disconnectCall" -> {
                    InCallServiceImpl.disconnectCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "holdCall" -> {
                    val hold = call.argument<Boolean>("hold") ?: false
                    InCallServiceImpl.holdCurrentCall(hold)
                    result.success(true)
                }
                "setSpeaker" -> {
                    // Accepts both 'enabled' and 'speaker' keys to avoid channel mismatch!
                    val enabled = call.argument<Boolean>("enabled")
                        ?: call.argument<Boolean>("speaker")
                        ?: false
                    InCallServiceImpl.setSpeaker(this, enabled)
                    result.success(true)
                }
                "isSpeakerOn" -> {
                    val inCallRoute = InCallServiceImpl.instance?.callAudioState?.route
                    val isSpeaker = if (inCallRoute != null) {
                        inCallRoute == CallAudioState.ROUTE_SPEAKER
                    } else {
                        val am = getSystemService(AUDIO_SERVICE) as AudioManager
                        am.isSpeakerphoneOn
                    }
                    result.success(isSpeaker)
                }
                "setMuted" -> {
                    val muted = call.argument<Boolean>("muted") ?: false
                    InCallServiceImpl.setMuted(this, muted)
                    result.success(true)
                }
                "dialpadHaptic" -> {
                    val kind = call.argument<String>("kind") ?: "light"
                    try {
                        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                            manager.defaultVibrator
                        } else {
                            @Suppress("DEPRECATION")
                            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        }
                        if (vibrator.hasVibrator()) {
                            val isHeavy = kind.contains("thud", ignoreCase = true) || kind == "medium" || kind == "heavy"
                            val isDelete = kind.contains("delete", ignoreCase = true)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                val effect = if (isHeavy) {
                                    VibrationEffect.EFFECT_HEAVY_CLICK
                                } else if (isDelete) {
                                    VibrationEffect.EFFECT_TICK
                                } else {
                                    VibrationEffect.EFFECT_CLICK
                                }
                                vibrator.vibrate(VibrationEffect.createPredefined(effect))
                            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                val duration = if (isHeavy) 45L else 18L
                                val amp = if (isHeavy) 250 else 195
                                vibrator.vibrate(VibrationEffect.createOneShot(duration, amp))
                            } else {
                                @Suppress("DEPRECATION")
                                vibrator.vibrate(if (isHeavy) 45L else 18L)
                            }
                        }
                    } catch (_: Exception) { }
                    result.success(true)
                }
                "playDialpadTone" -> {
                    val digit = call.argument<String>("digit")?.firstOrNull()
                    val tone = when (digit) {
                        '0' -> ToneGenerator.TONE_DTMF_0
                        '1' -> ToneGenerator.TONE_DTMF_1
                        '2' -> ToneGenerator.TONE_DTMF_2
                        '3' -> ToneGenerator.TONE_DTMF_3
                        '4' -> ToneGenerator.TONE_DTMF_4
                        '5' -> ToneGenerator.TONE_DTMF_5
                        '6' -> ToneGenerator.TONE_DTMF_6
                        '7' -> ToneGenerator.TONE_DTMF_7
                        '8' -> ToneGenerator.TONE_DTMF_8
                        '9' -> ToneGenerator.TONE_DTMF_9
                        '*' -> ToneGenerator.TONE_DTMF_S
                        '#' -> ToneGenerator.TONE_DTMF_P
                        else -> -1
                    }
                    try {
                        if (tone >= 0) {
                            if (dialToneGenerator == null) dialToneGenerator = ToneGenerator(AudioManager.STREAM_DTMF, 78)
                            dialToneGenerator?.stopTone()
                            dialToneGenerator?.startTone(tone, 105)
                        }
                    } catch (_: Exception) { }
                    result.success(true)
                }
                "stopDialpadTone" -> {
                    try { dialToneGenerator?.stopTone() } catch (_: Exception) { }
                    result.success(true)
                }
                "playDtmf" -> {
                    val digit = call.argument<String>("digit")?.firstOrNull() ?: '1'
                    InCallServiceImpl.playDtmf(digit)
                    result.success(true)
                }
                "stopDtmf" -> {
                    InCallServiceImpl.stopDtmf()
                    result.success(true)
                }
                "showIncomingBanner" -> {
                    val number = call.argument<String>("number") ?: "Unknown"
                    val name = call.argument<String>("name")
                    showIncomingCallBanner(this, number, name)
                    result.success(true)
                }
                "cancelIncomingBanner" -> {
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "showOngoingNotification" -> {
                    val number = call.argument<String>("number") ?: "Unknown"
                    val name = call.argument<String>("name")
                    val isIncoming = call.argument<Boolean>("isIncoming") ?: false
                    val isMuted = call.argument<Boolean>("isMuted") ?: false
                    val isSpeaker = call.argument<Boolean>("isSpeaker") ?: false
                    showOngoingCallNotification(this, number, name, isIncoming, isMuted, isSpeaker)
                    result.success(true)
                }
                "makeCall" -> {
                    val number = call.argument<String>("number") ?: ""
                    val requestedSlot = (call.argument<Int>("simSlot") ?: 1).coerceIn(1, 2)
                    val clean = number.replace(Regex("[^0-9+*#]"), "")
                    if (clean.isBlank()) {
                        result.error("INVALID_NUMBER", "Number is empty", null)
                        return@setMethodCallHandler
                    }
                    try {
                        val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                        val uri = android.net.Uri.fromParts("tel", clean, null)
                        val accounts = telecomManager.callCapablePhoneAccounts
                        val subscriptions = try {
                            val manager = getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
                            manager.activeSubscriptionInfoList.orEmpty().sortedBy { it.simSlotIndex }
                        } catch (_: Exception) { emptyList() }

                        // Resolve the SIM slot to the subscription's PhoneAccountHandle.
                        // On Android telephony accounts the handle id normally contains
                        // the subscription id; slot-order is the compatibility fallback.
                        val targetSub = subscriptions.firstOrNull { it.simSlotIndex == requestedSlot - 1 }
                        val targetAccount = if (targetSub != null) {
                            accounts.firstOrNull { handle ->
                                handle.id == targetSub.subscriptionId.toString() ||
                                    handle.id.endsWith("${targetSub.subscriptionId}")
                            } ?: accounts.getOrNull(requestedSlot - 1)
                        } else {
                            accounts.getOrNull(requestedSlot - 1)
                        }

                        if (targetAccount == null) {
                            result.error("SIM_UNAVAILABLE", "SIM $requestedSlot is not available for calls", null)
                            return@setMethodCallHandler
                        }
                        if (telecomManager.defaultDialerPackage != packageName) {
                            result.error("NOT_DEFAULT_DIALER", "Set StackDialer as the default phone app to place calls through the selected SIM", null)
                            return@setMethodCallHandler
                        }

                        val extras = Bundle().apply {
                            putBoolean(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, false)
                            putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, targetAccount)
                        }
                        telecomManager.placeCall(uri, extras)
                        // No generic ACTION_CALL fallback: it could ignore the chosen SIM.
                        result.success(true)
                    } catch (e: SecurityException) {
                        result.error("CALL_PERMISSION", e.message ?: "Phone permission is required", null)
                    } catch (e: Exception) {
                        result.error("CALL_ERROR", e.message, null)
                    }
                }
                "cancelOngoingNotification" -> {
                    cancelOngoingCallNotification(this)
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        // Listen for call state updates from InCallService
        // InCallServiceImpl owns Android notification creation/cancellation. The Activity
        // listener only forwards state to Flutter; publishing notifications from both
        // places caused duplicate incoming-call updates and repeated heads-up presentation.
        InCallServiceImpl.onCallStateChangedListener = { number, stateStr, _ ->
            notifyCallState(number, stateStr)
        }
    }

    override fun onDestroy() {
        try { dialToneGenerator?.stopTone(); dialToneGenerator?.release(); dialToneGenerator = null } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun fetchNativeCallLogs(): List<Map<String, Any>> {
        val list = mutableListOf<Map<String, Any>>()
        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
            CallLog.Calls.GEOCODED_LOCATION,
            CallLog.Calls.PHONE_ACCOUNT_ID,
            CallLog.Calls.PHONE_ACCOUNT_COMPONENT_NAME
        )

        val cursor = contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            projection,
            null,
            null,
            "${CallLog.Calls.DATE} DESC LIMIT 100"
        )

        cursor?.use {
            val idIdx = it.getColumnIndex(CallLog.Calls._ID)
            val numIdx = it.getColumnIndex(CallLog.Calls.NUMBER)
            val nameIdx = it.getColumnIndex(CallLog.Calls.CACHED_NAME)
            val typeIdx = it.getColumnIndex(CallLog.Calls.TYPE)
            val dateIdx = it.getColumnIndex(CallLog.Calls.DATE)
            val durIdx = it.getColumnIndex(CallLog.Calls.DURATION)
            val locIdx = it.getColumnIndex(CallLog.Calls.GEOCODED_LOCATION)
            val accountIdIdx = it.getColumnIndex(CallLog.Calls.PHONE_ACCOUNT_ID)
            val accountComponentIdx = it.getColumnIndex(CallLog.Calls.PHONE_ACCOUNT_COMPONENT_NAME)
            val subscriptions = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1 &&
                    checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    (getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager)
                        .activeSubscriptionInfoList.orEmpty().sortedBy { info -> info.simSlotIndex }
                } else emptyList()
            } catch (_: Exception) { emptyList() }

            while (it.moveToNext()) {
                val id = if (idIdx >= 0) it.getString(idIdx) ?: "" else ""
                val number = if (numIdx >= 0) it.getString(numIdx) ?: "Unknown" else "Unknown"
                val name = if (nameIdx >= 0) it.getString(nameIdx) ?: "" else ""
                val type = if (typeIdx >= 0) it.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                val date = if (dateIdx >= 0) it.getLong(dateIdx) else System.currentTimeMillis()
                val duration = if (durIdx >= 0) it.getLong(durIdx) else 0L
                val loc = if (locIdx >= 0) it.getString(locIdx) ?: "" else ""
                val accountId = if (accountIdIdx >= 0) it.getString(accountIdIdx).orEmpty() else ""
                val accountComponent = if (accountComponentIdx >= 0) it.getString(accountComponentIdx).orEmpty() else ""
                val accountSubId = accountId.toIntOrNull()
                val matchedSubscription = subscriptions.firstOrNull { info ->
                    (accountSubId != null && info.subscriptionId == accountSubId) ||
                    accountId == info.iccId || accountId == info.number
                }
                val simSlot = matchedSubscription?.simSlotIndex?.plus(1) ?: 0
                val simCarrier = matchedSubscription?.carrierName?.toString().orEmpty()

                val typeStr = when (type) {
                    CallLog.Calls.INCOMING_TYPE -> "incoming"
                    CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                    CallLog.Calls.MISSED_TYPE -> "missed"
                    CallLog.Calls.REJECTED_TYPE -> "rejected"
                    CallLog.Calls.VOICEMAIL_TYPE -> "missed"
                    CallLog.Calls.BLOCKED_TYPE -> "blocked"
                    else -> "incoming"
                }

                list.add(mapOf(
                    "id" to id,
                    "number" to number,
                    "name" to name,
                    "type" to typeStr,
                    "timestamp" to date,
                    "duration" to duration,
                    "location" to loc,
                    "simSlot" to simSlot,
                    "simCarrier" to simCarrier,
                    "phoneAccountId" to accountId,
                    "phoneAccountComponent" to accountComponent
                ))
            }
        }
        return list
    }

    private fun requestSetDefaultDialer(result: MethodChannel.Result? = null) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
                if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) && !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER), REQUEST_ID_SET_DEFAULT_DIALER)
                } else {
                    pendingDefaultDialerResult = null
                    result?.success(roleManager.isRoleHeld(RoleManager.ROLE_DIALER))
                }
            } else {
                val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                    putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                }
                startActivityForResult(intent, REQUEST_ID_SET_DEFAULT_DIALER)
            }
        } catch (e: Exception) {
            pendingDefaultDialerResult = null
            result?.error("DEFAULT_DIALER_REQUEST", e.message, null)
        }
    }
}
