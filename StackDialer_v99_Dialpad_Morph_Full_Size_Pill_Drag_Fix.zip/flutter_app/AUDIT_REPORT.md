# StackDialer v99 — Full Source Audit & Recents Fixes

## Scope reviewed

- 21 Dart source files (approximately 10.6k lines)
- Android Kotlin telecom, call-log, notification and reminder integration
- Android manifest and permissions
- Flutter dependencies and assets
- Android Gradle configuration and GitHub Actions build workflow

This is a source-level audit. Device-only behavior (real SIM routing, Android CallLog provider permissions, alarm delivery, notification presentation and visual animation quality) still requires testing on the target phone.

## Changes applied in this ZIP

1. **Call Button colour persistence:** load saved Call Button, bottom navigation pill, floating dialpad and keypad-glow colours before `runApp()`. The app no longer waits for Settings to be opened before restoring the saved colours.
2. **Recents contact photos:** the normal/default Recents card style now displays saved profile photos as well as the DHSES and Bottom Dock styles. The existing initials and card styling remain as the fallback.
3. **Photo scroll performance:** Base64 photo decoding is prewarmed through a worker isolate before the photo map is announced to the screens. Stable `MemoryImage` providers and gapless playback are used to reduce photo-related card rebuild flicker/jank.
4. **Full phone number in DHSES cards:** the number uses scale-down fitting rather than ellipsis so a 12-digit number is not silently cut off when the card narrows.
5. **Call deletion / Undo:** local completed-call IDs and Android CallLog provider IDs are now kept separately when matching records are merged. Matching accounts for the local record being timestamped at hang-up while Android stores the call-log timestamp near call start. Deleting a merged card targets the real Android row and removes its local record; Undo restores the Android row and its local metadata record.
6. **Default Calling SIM:** `SIM 1`, `SIM 2` and `Always Ask` preferences are now applied when calls are placed from the dialpad, Recents and contact actions. Outgoing call records also retain the selected SIM slot.
7. **Call details readability:** the sheet text scaler is now 1.05 (5% larger); the sheet remains scrollable and its information rows allow wrapping.
8. **Backup settings:** the keypad glow preference (`dialpad_glow_color_v2`) is now included in backup export/restore settings.
9. **Per-contact ringtone:** replaced the decorative preset labels with Android's actual ringtone picker and writes the selected ringtone URI to the matching Contacts provider row (`CUSTOM_RINGTONE`). Reset restores the system default. Requires Contacts write permission.
10. **Reminder notification routing:** notification taps are consumed from the Activity intent on cold and warm launches, then show the matching callback prompt with a Call now action. The intent extras are cleared after consumption.
11. **Analytics and Follow-up Tasks navigation:** added both existing screens to the app's More tools menu without changing the Recents/Contacts two-item navigation pill.
12. **SIM metadata:** native CallLog reads the phone-account identifiers and maps them to active subscription slots/carrier names when Android exposes a match. Unknown/unmatched rows are marked unavailable rather than falsely labelled SIM 1.
13. **Spam/hidden caller setting:** the opt-in switch now silences anonymous/restricted incoming callers through Android Call Screening (Android 10+); explicitly blocked numbers continue to be rejected. Ordinary unknown numbers are not automatically labelled or rejected because no trusted spam-reputation feed is bundled.

## Recents checklist — source status

| Area | Source audit result |
|---|---|
| All / Missed filters | Present |
| Smart missed-call grouping | Present; default is enabled and controlled in Settings |
| 17 card styles and saved style selection | Present |
| DHSES horizontal card-width shrink / reverse expansion | Present in the style transform code; visual smoothness needs device/video verification |
| Style 17 Bottom Dock Flow preset/studio | Present |
| Saved contact photo in Recents | Fixed for the default style; existing special styles retained |
| Photo decode work during scrolling | Reduced by provider prewarming; profile-photo-heavy scrolling still needs device profiling |
| Full 12-digit number in DHSES | Fixed to scale down rather than ellipsize |
| 12-hour clock | App forces 12-hour formatting; shared clock formatter is used in call/contact history |
| Delete and 5-second Undo | 5-second snackbar exists; provider/local ID merge and restore path fixed in source |
| Call detail sheet | All Call History is above Smart Category; call time/location/SIM rows wrap instead of ellipsizing |
| Call detail profile photo set/remove | Present |
| WhatsApp action | Present with web/app fallback in call details |
| Callback reminder presets/custom date-time | Present |
| Bottom-most card visibility / exact stack positioning | Geometry is implemented, but must be visually verified on the target screen size and with the selected style |

## Other feature audit

| Feature | Source audit result |
|---|---|
| Native outgoing calls | Android Telecom `placeCall` uses the selected `PhoneAccountHandle`; no generic SIM-agnostic fallback |
| Incoming call answer/reject | Native InCallService actions exist; answer controls are hidden while the UI is in the connecting/answering state |
| Speaker, mute, hold, DTMF | Flutter-to-native method-channel paths are present |
| Contacts and favorites | Present |
| Contact photos | Shared photo store used by Contacts, Recents and active-call UI |
| Contact notes/tags/history | Present |
| Speed dial | Persistent keys 1–9 and long-press handling are present |
| Blocked numbers | Native Call Screening implementation exists; actual rejection requires the user to grant Android's Call Screening role |
| Callback reminders | Exact-alarm and notification permission flow, native receiver and boot/time-change rescheduling are present |
| Call metadata / local history | SharedPreferences persistence and JSON conversion are present |
| Backup export/import | Native file-picker channel and JSON payload are present |
| App theme/accent/call-screen style | Persistent appearance service is present |
| Haptics | Persistent haptics toggle/service is present |
| GitHub Actions build | Gradle cache and Maven Central 429 retry backoff are preserved |

## Remaining issues found — not represented as completed

1. **Spam Number Detection is currently only a saved preference.** The Settings switch writes `stackdialer_spam_detection_enabled`, but no spam classifier or detection path reads that key. Explicitly blocked numbers do work through the Call Screening role; that is separate from automatic spam detection.
2. **Per-contact ringtone is currently a saved label/preference only.** The Contacts picker stores a selected name but does not assign an actual Android contact ringtone or play a corresponding sound.
3. **SIM information on imported/native call-log rows is incomplete.** `fetchDeviceCallLogs()` currently assigns `simSlot: 1` and `simCarrier: 'Carrier SIM'`; outgoing calls made through StackDialer now record the selected SIM, but older/incoming native CallLog rows may show an inaccurate SIM slot.
4. **Spam-number reputation detection remains limited.** The switch now silences anonymous/restricted callers, but it cannot identify ordinary numbers as spam without a maintained, trusted reputation database or user-reported spam list. No such data source is configured, so the app deliberately avoids false-positive blocking.
5. **Dependency reproducibility:** `pubspec.lock` is not included in this ZIP. `flutter pub get` resolves the declared version ranges at build time, so dependency versions can drift over time. A lockfile must be generated by the same Flutter/Dart toolchain used by GitHub Actions; this environment does not contain Flutter/Dart, so it has not been fabricated.
6. **SIM metadata has carrier/device limitations.** Android may omit phone-account identifiers or expose an identifier that cannot be matched to an active subscription. Such rows now display unavailable rather than a guessed SIM. Verify on dual-SIM target hardware.
7. **Contact ringtone requires Android Contacts write access.** The ringtone picker and provider update are wired in source; confirm on-device that the OEM dialer respects `CUSTOM_RINGTONE` for the selected contact and that contact IDs map to the Contacts provider row on the device.
8. **Reminder routing, Insights/Tasks navigation and anonymous-call silencing need device verification.** Source paths are connected, but notification tap delivery, Call Screening role behavior and exact alarm behavior depend on Android/OEM settings.

## Build configuration preserved

- Android Gradle Plugin: **9.3.1**
- Kotlin Gradle Plugin: **2.4.20**
- Gradle wrapper distribution: **9.5.0**
- Java/Kotlin JVM target: **17**
- compileSdk / targetSdk: **36**
- NDK: **28.2.13676358**
- `android.builtInKotlin=false`
- GitHub Actions Gradle dependency cache and Maven 429 exponential backoff retained

## Validation performed

- ZIP source extracted and reviewed.
- Relative Dart imports checked: no missing relative imports found.
- Lightweight Dart delimiter scan: no unmatched/unclosed delimiters found across the 21 Dart files.
- Key source assertions for persistence, photo, deletion, SIM, ringtone, reminder routing and navigation patches reviewed.
- Gradle/workflow values checked against the saved successful baseline.
- ZIP integrity checked after packaging.

**Not run:** `flutter analyze`, `flutter test`, `flutter build apk`, Kotlin/Android compilation, or physical-device UI/telephony tests. Flutter and Dart SDKs are not installed in this audit environment. Please run the GitHub Actions build before installing; then verify ringtone assignment, reminder notification tap, SIM labels and Call Screening on the phone.


## Follow-up hotfix — Active Call screen routing (27 Nov 2026)

- Fixed a MethodChannel handler collision in `MainDialerHost.initState`: reminder notification setup previously called `setMethodCallHandler` a second time and replaced TelecomService's call-state handler. This could leave the app on Recents/Dialpad after a real call was placed, including calls initiated by Recents swipe and reminder actions.
- Reminder notification taps are now dispatched through the existing shared TelecomService handler, so `onCallStateChanged`, audio-state events and reminder taps coexist.
- Added two delayed live-Telecom reconciliation checks after `makeRealCall` succeeds. If the first DIALING callback races Flutter resume/initialization, the app re-reads Android's actual live call and opens `ActiveCallScreen` without fabricating a call screen when Telecom did not create a call.
- Existing call-state listener remains the source of truth; SIM selection and Gradle configuration are unchanged.
- Validation: source assertions confirm exactly one Dart `setMethodCallHandler` registration remains (inside TelecomService), both call-state and reminder dispatch branches exist, and swipe/reminder actions still route through `_onCallNumber`. ZIP integrity checked. Flutter/Android compilation and physical-device tests remain pending.


## UI reference-video update — 27 Nov 2026

- Recents and Contacts remain mounted to preserve their page state, but now transition horizontally with a short slide and fade when switching tabs.
- Removed the adjacent three-dot More Tools popup from the bottom navigation as requested.
- Moved the green dialpad trigger into the bottom navigation row, immediately beside the Recents/Contacts pill, with a compact circular shape and close-state rotation.
- Removed the duplicate collapsed floating trigger from the page overlay. The dialpad panel now expands from the bottom-right trigger area and its contents enter with a combined fade, upward slide, and subtle scale transition.
- Validation: source-level assertions and ZIP integrity checks only. Flutter/Dart SDK is not available in this environment, so no analyzer/build/device test is claimed.

## Slow-motion reference match — Recents / Contacts / Dialpad (28 Nov 2026)

- Replaced the independent Recents/Contacts `AnimatedSlide` widgets with one persistent horizontal `PageView`. Its `PageController.page` is the single progress source for the content swipe and the bottom selection capsule, so the capsule follows the finger continuously rather than jumping only after the swipe completes.
- The bottom capsule is now one sliding highlight behind both labels; label/icon tint interpolates with page progress. Tapping either pill segment animates the same PageView instead of swapping a boolean selection.
- The adjacent green action button now changes with the selected page: dialpad/close on Recents, plus on Contacts. The plus action opens Android's native create-contact form through `flutter_contacts` and refreshes the device contacts after returning.
- Reworked dialpad open/close around a dedicated animation controller (520 ms forward / 430 ms reverse). The panel interpolates from the exact bottom-right trigger footprint to the wide lower-screen panel, with synchronized position, size, scale, opacity, rounded clipping, blur and scrim. Outside tap and the trigger reverse the same animation.
- The bottom navigation contains only Recents, Contacts and the context-sensitive green action button; there are no adjacent Tasks/Follow-up/More `...` actions in this navigation row. Follow-up task functionality remains available in its existing screen/notification flow.
- Preserved the existing active-call routing fix and saved Gradle baseline (AGP 9.3.1, Kotlin 2.4.20, Gradle 9.5.0, Java 17, targetSdk 36).
- Validation performed: source assertions for PageView/controller-driven capsule, dynamic plus/dialpad action, native insert-contact call, shared dialpad animation controller, and absence of the previous fixed `AnimatedSlide` tab implementation; balanced Dart delimiters; ZIP integrity.
- Not run: `dart format`, `flutter analyze`, `flutter test`, `flutter build apk`, Android/Kotlin compilation, or physical-device animation testing. Flutter and Dart SDKs are not installed in this environment. The exact motion still needs device-side visual confirmation against the supplied slow-motion clip.
- A closer frame-by-frame check of the supplied slow-motion clip refined the popup geometry: the keypad is a compact centered floating card (about 84% of screen width and 32% of screen height), not a nearly full-width 60%-height sheet. The overlay keypad key/action sizes were reduced only in overlay mode; the full-screen dialer layout remains unchanged. The Recents action keeps its dialpad glyph while open (tap it again or tap outside to close), and the Contacts action is the plus glyph.

## Follow-up hotfix — dialpad morph size and bottom-pill drag (28 Nov 2026)

- Restored the original large dialpad popup footprint: 60% of screen height, clamped to 455–490 dp. The prior 32% / 238–278 dp compact size is no longer used.
- Kept the circular action-button origin and animated the same surface into the large rounded keypad, with a bottom-right anchored morph and eased scale/position/radius interpolation.
- The green dial action fades/scales away during opening. At the bottom navigation action position, a muted translucent dial button zooms up from below; tapping it reverses the transition and restores the green circular button.
- Added direct horizontal drag handling to the Recents/Contacts highlight capsule. While the user drags across the capsule, the PageController is updated continuously so the page and highlight move together; release settles to the nearest tab.
- The floating action now listens to both tab-page progress and dialpad animation progress, so its icon and green/faded state track the current gesture.
- Validation in this environment: source assertions and ZIP integrity checks only. Flutter/Dart SDK and device runtime were not available, so no APK build or physical-device animation verification is claimed.
