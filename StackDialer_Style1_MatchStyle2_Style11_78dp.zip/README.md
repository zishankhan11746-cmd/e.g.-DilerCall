StackDialer update

Requested changes in this source archive:
- Style 1 (iOS 18): top stack positioning now uses the same geometry as Style 2, while bottom-stack logic remains unchanged.
- Style 11 (Snake Stack): card height changed to 78dp; spacing step changed to 92dp.
- Other styles were not intentionally modified.

Validation: source archive contents were checked. Android build and on-device animation have not been tested in this environment.
