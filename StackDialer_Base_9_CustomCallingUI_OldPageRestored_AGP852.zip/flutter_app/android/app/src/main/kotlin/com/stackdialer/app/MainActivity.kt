package com.stackdialer.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.stackdialer.app/telecom"
    private val REQUEST_ID_SET_DEFAULT_DIALER = 1001
    private var dialToneGenerator: ToneGenerator? = null

    companion object {
        const val CHANNEL_ID = "stackdialer_incoming_calls_silent"
        const val NOTIFICATION_ID = 2001
        var methodChannel: MethodChannel? = null
        var pendingCallNumber: String? = null
        var pendingCallState: String? = null

        fun notifyCallState(number: String, state: String) {
            pendingCallNumber = number
            pendingCallState = state
            if (state == "DISCONNECTED" || state == "IDLE") {
                // Clear pending call state once disconnected
                pendingCallNumber = null
                pendingCallState = null
            }
            methodChannel?.invokeMethod("onCallStateChanged", mapOf(
                "number" to number,
                "state" to state
            ))
        }

        fun notifyAudioState(isSpeaker: Boolean, isMuted: Boolean) {
            methodChannel?.invokeMethod("onAudioStateChanged", mapOf(
                "isSpeaker" to isSpeaker,
                "isMuted" to isMuted
            ))
        }

        fun showIncomingCallBanner(context: Context, number: String, name: String?) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Keep the call notification silent: Android Telecom/system phone audio
            // already plays the incoming ringtone. A second ringtone on this channel
            // causes the caller's ringtone to sound doubled on the receiving phone.
            // A new channel ID is used so Android does not reuse old channel sound settings.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "StackDialer Incoming Calls (Silent Alert)",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Silent incoming-call controls; ringtone is handled by Android Telecom"
                    enableLights(true)
                    enableVibration(false)
                    setSound(null, null)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                }
                notificationManager.createNotificationChannel(channel)
            }

            // Full screen intent to bring StackDialer to front (works even on locked screen)
            val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
                action = Intent.ACTION_MAIN
                addCategory(Intent.CATEGORY_LAUNCHER)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("incoming_number", number)
                putExtra("incoming_name", name ?: number)
            }

            val fullScreenPendingIntent = PendingIntent.getActivity(
                context,
                0,
                fullScreenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Answer Action PendingIntent
            val answerIntent = Intent(context, CallActionReceiver::class.java).apply {
                action = CallActionReceiver.ACTION_ANSWER
                putExtra("number", number)
            }
            val answerPendingIntent = PendingIntent.getBroadcast(
                context,
                1,
                answerIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Reject Action PendingIntent
            val rejectIntent = Intent(context, CallActionReceiver::class.java).apply {
                action = CallActionReceiver.ACTION_REJECT
                putExtra("number", number)
            }
            val rejectPendingIntent = PendingIntent.getBroadcast(
                context,
                2,
                rejectIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val displayName = if (!name.isNullOrBlank()) name else number
            val contentText = if (!name.isNullOrBlank()) "Incoming call • $number" else "Incoming Cellular Call..."
            val appIcon = context.applicationInfo.icon.takeIf { it != 0 } ?: android.R.drawable.sym_call_incoming

            val person = androidx.core.app.Person.Builder()
                .setName(displayName)
                .setImportant(true)
                .build()

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(appIcon)
                .setContentTitle(displayName)
                .setContentText(contentText)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setAutoCancel(false) // Sticky: cannot be dismissed by tapping outside
                .setOngoing(true)    // Persistent: cannot be swiped away until call terminates
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setFullScreenIntent(fullScreenPendingIntent, true)
                .setContentIntent(fullScreenPendingIntent)

            // Use CallStyle on supported Android versions for native incoming call UI
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                builder.setStyle(
                    NotificationCompat.CallStyle.forIncomingCall(
                        person,
                        rejectPendingIntent,
                        answerPendingIntent
                    )
                )
            } else {
                builder.addAction(android.R.drawable.sym_action_call, "ANSWER", answerPendingIntent)
                builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "DECLINE", rejectPendingIntent)
            }

            notificationManager.notify(NOTIFICATION_ID, builder.build())
        }

        fun cancelIncomingCallBanner(context: Context) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(NOTIFICATION_ID)
        }

        const val ONGOING_CHANNEL_ID = "stackdialer_ongoing_calls"
        const val ONGOING_NOTIFICATION_ID = 2002

        fun showOngoingCallNotification(
            context: Context,
            number: String,
            name: String?,
            isIncoming: Boolean,
            isMuted: Boolean,
            isSpeaker: Boolean
        ) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    ONGOING_CHANNEL_ID,
                    "StackDialer Active Ongoing Call",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Persistent ongoing call notification banner and controls"
                    enableLights(false)
                    enableVibration(false)
                    setSound(null, null)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                }
                notificationManager.createNotificationChannel(channel)
            }

            val bringToFrontIntent = Intent(context, MainActivity::class.java).apply {
                action = Intent.ACTION_MAIN
                addCategory(Intent.CATEGORY_LAUNCHER)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("active_number", number)
                putExtra("active_name", name ?: number)
            }
            val bringToFrontPendingIntent = PendingIntent.getActivity(
                context,
                10,
                bringToFrontIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Disconnect Action PendingIntent
            val hangupIntent = Intent(context, CallActionReceiver::class.java).apply {
                action = CallActionReceiver.ACTION_DISCONNECT
                putExtra("number", number)
            }
            val hangupPendingIntent = PendingIntent.getBroadcast(
                context,
                11,
                hangupIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Mute Action PendingIntent
            val muteIntent = Intent(context, CallActionReceiver::class.java).apply {
                action = CallActionReceiver.ACTION_MUTE
                putExtra("number", number)
                putExtra("muted", isMuted)
            }
            val mutePendingIntent = PendingIntent.getBroadcast(
                context,
                12,
                muteIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Speaker Action PendingIntent
            val speakerIntent = Intent(context, CallActionReceiver::class.java).apply {
                action = CallActionReceiver.ACTION_SPEAKER
                putExtra("number", number)
                putExtra("speaker", isSpeaker)
            }
            val speakerPendingIntent = PendingIntent.getBroadcast(
                context,
                13,
                speakerIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val displayName = if (!name.isNullOrBlank()) name else number
            val statusText = if (isIncoming) "Incoming Call • Active" else "Ongoing Call • Cellular Audio"
            val appIcon = context.applicationInfo.icon.takeIf { it != 0 } ?: android.R.drawable.sym_action_call

            val person = androidx.core.app.Person.Builder()
                .setName(displayName)
                .setImportant(true)
                .build()

            val builder = NotificationCompat.Builder(context, ONGOING_CHANNEL_ID)
                .setSmallIcon(appIcon)
                .setContentTitle(displayName)
                .setContentText(statusText)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setAutoCancel(false)
                .setOngoing(true) // CANNOT be cleared or swiped away until call terminates!
                .setContentIntent(bringToFrontPendingIntent)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                builder.setStyle(
                    NotificationCompat.CallStyle.forOngoingCall(
                        person,
                        hangupPendingIntent
                    )
                )
            } else {
                builder.addAction(
                    if (isMuted) android.R.drawable.ic_lock_silent_mode else android.R.drawable.ic_btn_speak_now,
                    if (isMuted) "UNMUTE" else "MUTE",
                    mutePendingIntent
                )
                builder.addAction(
                    android.R.drawable.ic_lock_silent_mode_off,
                    if (isSpeaker) "SPEAKER OFF" else "SPEAKER ON",
                    speakerPendingIntent
                )
                builder.addAction(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    "END CALL",
                    hangupPendingIntent
                )
            }

            notificationManager.notify(ONGOING_NOTIFICATION_ID, builder.build())
        }

        fun cancelOngoingCallNotification(context: Context) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(ONGOING_NOTIFICATION_ID)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleCallIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleCallIntent(intent)
    }

    private fun handleCallIntent(intent: Intent?) {
        // Intent extras only bring the app to foreground. Never treat them as proof
        // of a live call; real state is supplied by InCallServiceImpl.
        val call = InCallServiceImpl.currentCall ?: return
        val number = call.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() } ?: return
        val state = when (call.state) {
            android.telecom.Call.STATE_RINGING -> "RINGING"
            android.telecom.Call.STATE_ACTIVE, android.telecom.Call.STATE_HOLDING -> "ACTIVE"
            android.telecom.Call.STATE_DISCONNECTED -> "DISCONNECTED"
            else -> return
        }
        notifyCallState(number, state)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getPendingCall" -> {
                    if (pendingCallNumber != null && pendingCallState != null) {
                        result.success(mapOf(
                            "number" to pendingCallNumber,
                            "state" to pendingCallState
                        ))
                    } else {
                        result.success(null)
                    }
                }
                "getCallLogs" -> {
                    try {
                        val logs = fetchNativeCallLogs()
                        result.success(logs)
                    } catch (e: Exception) {
                        result.error("CALL_LOG_ERROR", e.message, null)
                    }
                }
                "getSimInfo" -> {
                    try {
                        val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                        val carrier = tm.networkOperatorName.ifBlank { tm.simOperatorName }.ifBlank { "Carrier SIM" }
                        result.success(mapOf("carrierName" to carrier))
                    } catch (e: Exception) {
                        result.success(mapOf("carrierName" to "Carrier SIM"))
                    }
                }
                "requestDefaultDialer" -> {
                    requestSetDefaultDialer()
                    result.success(true)
                }
                "placeCall" -> {
                    try {
                        val number = call.argument<String>("number")?.trim().orEmpty()
                        if (number.isBlank()) {
                            result.success(false)
                        } else {
                            val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                            if (telecomManager.defaultDialerPackage != packageName) {
                                result.error("NOT_DEFAULT_DIALER", "Set StackDialer as the default Phone app first.", null)
                            } else {
                                val uri = android.net.Uri.fromParts("tel", number, null)
                                telecomManager.placeCall(uri, Bundle())
                                result.success(true)
                            }
                        }
                    } catch (e: SecurityException) {
                        result.error("CALL_PERMISSION", e.message, null)
                    } catch (e: Exception) {
                        result.error("PLACE_CALL_FAILED", e.message, null)
                    }
                }
                "isDefaultDialer" -> {
                    val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                    val isDefault = telecomManager.defaultDialerPackage == packageName
                    result.success(isDefault)
                }
                "answerCall" -> {
                    InCallServiceImpl.answerCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "rejectCall" -> {
                    InCallServiceImpl.rejectCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "disconnectCall" -> {
                    InCallServiceImpl.disconnectCurrentCall()
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "holdCall" -> {
                    val hold = call.argument<Boolean>("hold") ?: false
                    InCallServiceImpl.holdCurrentCall(hold)
                    result.success(true)
                }
                "setSpeaker" -> {
                    // Accepts both 'enabled' and 'speaker' keys to avoid channel mismatch!
                    val enabled = call.argument<Boolean>("enabled")
                        ?: call.argument<Boolean>("speaker")
                        ?: false
                    InCallServiceImpl.setSpeaker(this, enabled)
                    result.success(true)
                }
                "isSpeakerOn" -> {
                    val inCallRoute = InCallServiceImpl.instance?.callAudioState?.route
                    val isSpeaker = if (inCallRoute != null) {
                        inCallRoute == CallAudioState.ROUTE_SPEAKER
                    } else {
                        val am = getSystemService(AUDIO_SERVICE) as AudioManager
                        am.isSpeakerphoneOn
                    }
                    result.success(isSpeaker)
                }
                "setMuted" -> {
                    val muted = call.argument<Boolean>("muted") ?: false
                    InCallServiceImpl.setMuted(this, muted)
                    result.success(true)
                }
                "dialpadHaptic" -> {
                    val kind = call.argument<String>("kind") ?: "light"
                    try {
                        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                            manager.defaultVibrator
                        } else {
                            @Suppress("DEPRECATION")
                            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        }
                        if (vibrator.hasVibrator()) {
                            val isHeavy = kind.contains("thud", ignoreCase = true) || kind == "medium" || kind == "heavy"
                            val isDelete = kind.contains("delete", ignoreCase = true)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                val effect = if (isHeavy) {
                                    VibrationEffect.EFFECT_HEAVY_CLICK
                                } else if (isDelete) {
                                    VibrationEffect.EFFECT_TICK
                                } else {
                                    VibrationEffect.EFFECT_CLICK
                                }
                                vibrator.vibrate(VibrationEffect.createPredefined(effect))
                            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                val duration = if (isHeavy) 45L else 18L
                                val amp = if (isHeavy) 250 else 195
                                vibrator.vibrate(VibrationEffect.createOneShot(duration, amp))
                            } else {
                                @Suppress("DEPRECATION")
                                vibrator.vibrate(if (isHeavy) 45L else 18L)
                            }
                        }
                    } catch (_: Exception) { }
                    result.success(true)
                }
                "playDialpadTone" -> {
                    val digit = call.argument<String>("digit")?.firstOrNull()
                    val tone = when (digit) {
                        '0' -> ToneGenerator.TONE_DTMF_0
                        '1' -> ToneGenerator.TONE_DTMF_1
                        '2' -> ToneGenerator.TONE_DTMF_2
                        '3' -> ToneGenerator.TONE_DTMF_3
                        '4' -> ToneGenerator.TONE_DTMF_4
                        '5' -> ToneGenerator.TONE_DTMF_5
                        '6' -> ToneGenerator.TONE_DTMF_6
                        '7' -> ToneGenerator.TONE_DTMF_7
                        '8' -> ToneGenerator.TONE_DTMF_8
                        '9' -> ToneGenerator.TONE_DTMF_9
                        '*' -> ToneGenerator.TONE_DTMF_S
                        '#' -> ToneGenerator.TONE_DTMF_P
                        else -> -1
                    }
                    try {
                        if (tone >= 0) {
                            if (dialToneGenerator == null) dialToneGenerator = ToneGenerator(AudioManager.STREAM_DTMF, 78)
                            dialToneGenerator?.stopTone()
                            dialToneGenerator?.startTone(tone, 105)
                        }
                    } catch (_: Exception) { }
                    result.success(true)
                }
                "stopDialpadTone" -> {
                    try { dialToneGenerator?.stopTone() } catch (_: Exception) { }
                    result.success(true)
                }
                "playDtmf" -> {
                    val digit = call.argument<String>("digit")?.firstOrNull() ?: '1'
                    InCallServiceImpl.playDtmf(digit)
                    result.success(true)
                }
                "stopDtmf" -> {
                    InCallServiceImpl.stopDtmf()
                    result.success(true)
                }
                "showIncomingBanner" -> {
                    val number = call.argument<String>("number") ?: "Unknown"
                    val name = call.argument<String>("name")
                    showIncomingCallBanner(this, number, name)
                    result.success(true)
                }
                "cancelIncomingBanner" -> {
                    cancelIncomingCallBanner(this)
                    result.success(true)
                }
                "showOngoingNotification" -> {
                    val number = call.argument<String>("number") ?: "Unknown"
                    val name = call.argument<String>("name")
                    val isIncoming = call.argument<Boolean>("isIncoming") ?: false
                    val isMuted = call.argument<Boolean>("isMuted") ?: false
                    val isSpeaker = call.argument<Boolean>("isSpeaker") ?: false
                    showOngoingCallNotification(this, number, name, isIncoming, isMuted, isSpeaker)
                    result.success(true)
                }
                "cancelOngoingNotification" -> {
                    cancelOngoingCallNotification(this)
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }

        // Listen for call state updates from InCallService
        InCallServiceImpl.onCallStateChangedListener = { number, stateStr, _ ->
            if (stateStr == "RINGING") {
                showIncomingCallBanner(this, number, null)
            } else if (stateStr == "ACTIVE" || stateStr == "DIALING") {
                cancelIncomingCallBanner(this)
                showOngoingCallNotification(this, number, null, stateStr == "ACTIVE", false, false)
            } else if (stateStr == "DISCONNECTED" || stateStr == "IDLE") {
                cancelIncomingCallBanner(this)
                cancelOngoingCallNotification(this)
            }
            notifyCallState(number, stateStr)
        }
    }

    override fun onDestroy() {
        try { dialToneGenerator?.stopTone(); dialToneGenerator?.release(); dialToneGenerator = null } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun fetchNativeCallLogs(): List<Map<String, Any>> {
        val list = mutableListOf<Map<String, Any>>()
        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
            CallLog.Calls.GEOCODED_LOCATION
        )

        val cursor = contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            projection,
            null,
            null,
            "${CallLog.Calls.DATE} DESC LIMIT 100"
        )

        cursor?.use {
            val idIdx = it.getColumnIndex(CallLog.Calls._ID)
            val numIdx = it.getColumnIndex(CallLog.Calls.NUMBER)
            val nameIdx = it.getColumnIndex(CallLog.Calls.CACHED_NAME)
            val typeIdx = it.getColumnIndex(CallLog.Calls.TYPE)
            val dateIdx = it.getColumnIndex(CallLog.Calls.DATE)
            val durIdx = it.getColumnIndex(CallLog.Calls.DURATION)
            val locIdx = it.getColumnIndex(CallLog.Calls.GEOCODED_LOCATION)

            while (it.moveToNext()) {
                val id = if (idIdx >= 0) it.getString(idIdx) ?: "" else ""
                val number = if (numIdx >= 0) it.getString(numIdx) ?: "Unknown" else "Unknown"
                val name = if (nameIdx >= 0) it.getString(nameIdx) ?: "" else ""
                val type = if (typeIdx >= 0) it.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                val date = if (dateIdx >= 0) it.getLong(dateIdx) else System.currentTimeMillis()
                val duration = if (durIdx >= 0) it.getLong(durIdx) else 0L
                val loc = if (locIdx >= 0) it.getString(locIdx) ?: "" else ""

                val typeStr = when (type) {
                    CallLog.Calls.INCOMING_TYPE -> "incoming"
                    CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                    CallLog.Calls.MISSED_TYPE -> "missed"
                    CallLog.Calls.REJECTED_TYPE -> "rejected"
                    CallLog.Calls.VOICEMAIL_TYPE -> "missed"
                    CallLog.Calls.BLOCKED_TYPE -> "blocked"
                    else -> "incoming"
                }

                list.add(mapOf(
                    "id" to id,
                    "number" to number,
                    "name" to name,
                    "type" to typeStr,
                    "timestamp" to date,
                    "duration" to duration,
                    "location" to loc
                ))
            }
        }
        return list
    }

    private fun requestSetDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) && !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
                startActivityForResult(intent, REQUEST_ID_SET_DEFAULT_DIALER)
            }
        } else {
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            }
            startActivityForResult(intent, REQUEST_ID_SET_DEFAULT_DIALER)
        }
    }
}
