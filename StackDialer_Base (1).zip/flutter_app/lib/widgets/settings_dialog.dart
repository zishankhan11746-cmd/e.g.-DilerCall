import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/blocked_numbers_service.dart';
import '../services/speed_dial_service.dart';
import '../services/telecom_service.dart';

class DialerSettingsDialog extends StatefulWidget {
  final VoidCallback? onSimulateIncoming;
  final bool showIos18Appearance;
  final String ios18Appearance;
  final ValueChanged<String>? onIos18AppearanceChanged;

  const DialerSettingsDialog({super.key, this.onSimulateIncoming, this.showIos18Appearance = false, this.ios18Appearance = 'sunset', this.onIos18AppearanceChanged});

  @override
  State<DialerSettingsDialog> createState() => _DialerSettingsDialogState();
}

class _DialerSettingsDialogState extends State<DialerSettingsDialog> {
  bool _isDefault = false;
  bool _autoRecord = false;
  bool _hapticEnabled = true;
  String _preferredSim = 'SIM 1';
  late String _ios18AppearanceChoice;

  @override
  void initState() {
    super.initState();
    _ios18AppearanceChoice = _normalizeTheme(widget.ios18Appearance);
    _checkDefaultDialer();
    _loadGeneralSettings();
  }

  static String _normalizeTheme(String? val) {
    if (val == null || val.isEmpty) return 'sunset_dream';
    if (val == 'sunset' || val == 'sunset_dream') return 'sunset_dream';
    if (val == 'purple' || val == 'purple_glow') return 'purple_glow';
    if (val == 'gold' || val == 'gold_luxury') return 'gold_luxury';
    if (val == 'sky' || val == 'sky_premium') return 'sky_premium';
    if (val == 'green' || val == 'green_nature') return 'green_nature';
    return val;
  }

  Future<void> _loadGeneralSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _preferredSim = prefs.getString('stackdialer_preferred_sim') ?? 'SIM 1';
      _autoRecord = prefs.getBool('stackdialer_spam_detection_enabled') ?? false;
      _hapticEnabled = prefs.getBool('stackdialer_haptics_enabled') ?? true;
      final savedAppearance = prefs.getString('ios18_theme_variant') ?? prefs.getString('stackdialer_ios18_appearance');
      if (savedAppearance != null && savedAppearance.isNotEmpty) {
        _ios18AppearanceChoice = _normalizeTheme(savedAppearance);
      }
    });
  }


  void _checkDefaultDialer() async {
    final def = await TelecomService.isDefaultDialer();
    if (mounted) {
      setState(() => _isDefault = def);
    }
  }

  void _showBlockedNumbersSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1C25),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final blocked = BlockedNumbersService.blockedList;
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Blocked / Spam Numbers',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (blocked.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Center(
                    child: Text('No numbers blocked yet', style: TextStyle(color: Colors.white54)),
                  ),
                )
              else
                ...blocked.map(
                  (num) => ListTile(
                    leading: const Icon(Icons.block, color: Color(0xFFEF4444)),
                    title: Text(num, style: const TextStyle(color: Colors.white)),
                    trailing: TextButton(
                      child: const Text('Unblock', style: TextStyle(color: Color(0xFF38BDF8))),
                      onPressed: () {
                        BlockedNumbersService.unblockNumber(num);
                        Navigator.pop(ctx);
                        _showBlockedNumbersSheet();
                      },
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFEF4444).withOpacity(0.2),
                    foregroundColor: const Color(0xFFEF4444),
                    side: const BorderSide(color: Color(0xFFEF4444)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Block a Phone Number'),
                  onPressed: () {
                    final ctrl = TextEditingController();
                    showDialog(
                      context: ctx,
                      builder: (dCtx) => AlertDialog(
                        backgroundColor: const Color(0xFF1E1C25),
                        title: const Text('Block Number', style: TextStyle(color: Colors.white)),
                        content: TextField(
                          controller: ctrl,
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(color: Colors.white),
                          decoration: const InputDecoration(
                            hintText: '+91 99999 00000',
                            hintStyle: TextStyle(color: Colors.white38),
                          ),
                        ),
                        actions: [
                          TextButton(
                            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
                            onPressed: () => Navigator.pop(dCtx),
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFEF4444)),
                            child: const Text('Block', style: TextStyle(color: Colors.white)),
                            onPressed: () {
                              if (ctrl.text.trim().isNotEmpty) {
                                BlockedNumbersService.blockNumber(ctrl.text.trim());
                              }
                              Navigator.pop(dCtx);
                              Navigator.pop(ctx);
                              _showBlockedNumbersSheet();
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showSpeedDialSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1C25),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final entries = SpeedDialService.getAll();
        return Padding(
          padding: const EdgeInsets.all(20),
          child: ListView(
            shrinkWrap: true,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Speed Dial Shortcuts (Keys 1-9)',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              for (int k = 1; k <= 9; k++)
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFF10B981).withOpacity(0.2),
                    child: Text('$k', style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold)),
                  ),
                  title: Text(entries[k]?.name ?? 'Unassigned (Tap to set)', style: TextStyle(color: entries[k] != null ? Colors.white : Colors.white60)),
                  subtitle: Text(entries[k]?.number ?? 'Tap to assign contact name & number', style: const TextStyle(color: Colors.white38, fontSize: 12)),
                  trailing: const Icon(Icons.edit_outlined, color: Colors.white38, size: 18),
                  onTap: () {
                    final nameCtrl = TextEditingController(text: entries[k]?.name ?? '');
                    final numCtrl = TextEditingController(text: entries[k]?.number ?? '');
                    showDialog(
                      context: ctx,
                      builder: (dlgCtx) => AlertDialog(
                        backgroundColor: const Color(0xFF1E1C25),
                        title: Text('Assign Speed Dial #$k', style: const TextStyle(color: Colors.white)),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextField(
                              controller: nameCtrl,
                              style: const TextStyle(color: Colors.white),
                              decoration: const InputDecoration(labelText: 'Contact Name', labelStyle: TextStyle(color: Colors.white60)),
                            ),
                            TextField(
                              controller: numCtrl,
                              style: const TextStyle(color: Colors.white),
                              keyboardType: TextInputType.phone,
                              decoration: const InputDecoration(labelText: 'Phone Number', labelStyle: TextStyle(color: Colors.white60)),
                            ),
                          ],
                        ),
                        actions: [
                          if (entries[k] != null && k > 1)
                            TextButton(
                              onPressed: () {
                                SpeedDialService.removeEntry(k);
                                Navigator.pop(dlgCtx);
                                Navigator.pop(ctx);
                                _showSpeedDialSheet();
                              },
                              child: const Text('Clear', style: TextStyle(color: Color(0xFFEF4444))),
                            ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF10B981)),
                            onPressed: () {
                              if (numCtrl.text.trim().isNotEmpty) {
                                SpeedDialService.setEntry(
                                  k,
                                  nameCtrl.text.trim().isEmpty ? 'Key #$k' : nameCtrl.text.trim(),
                                  numCtrl.text.trim(),
                                );
                              }
                              Navigator.pop(dlgCtx);
                              Navigator.pop(ctx);
                              _showSpeedDialSheet();
                            },
                            child: const Text('Save', style: TextStyle(color: Colors.white)),
                          ),
                        ],
                      ),
                    );
                  },
                ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF181620),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.settings, color: Color(0xFF10B981), size: 24),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Dialer Preferences',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        Text('Carrier, Telecom & UI Settings', style: TextStyle(fontSize: 12, color: Colors.white54)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // Default Dialer Banner
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _isDefault
                      ? const Color(0xFF10B981).withOpacity(0.12)
                      : const Color(0xFF6366F1).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _isDefault
                        ? const Color(0xFF10B981).withOpacity(0.4)
                        : const Color(0xFF6366F1).withOpacity(0.4),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _isDefault ? Icons.check_circle : Icons.phone_android,
                      color: _isDefault ? const Color(0xFF10B981) : const Color(0xFF818CF8),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _isDefault ? 'Default Phone App: Active' : 'Set as Default Phone App',
                            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 13),
                          ),
                          Text(
                            _isDefault
                                ? 'Custom incoming/outgoing UI active'
                                : 'Enables custom incoming call screen for all SIM calls',
                            style: const TextStyle(fontSize: 11, color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                    if (!_isDefault)
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF6366F1),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          minimumSize: Size.zero,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        onPressed: () async {
                          await TelecomService.requestDefaultDialer();
                          _checkDefaultDialer();
                        },
                        child: const Text('Set', style: TextStyle(fontSize: 12, color: Colors.white)),
                      ),
                  ],
                ),
              ),

              const SizedBox(height: 16),
              const Divider(color: Colors.white12),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(7),
                    decoration: BoxDecoration(
                      color: const Color(0xFF9B4DFF).withOpacity(0.18),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.palette_outlined, color: Color(0xFFC084FC), size: 20),
                  ),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'iOS 18 Style 1 — Theme & Design',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        Text(
                          '5 Premium Background & Card Styles (for iOS 18 Style 1)',
                          style: TextStyle(color: Colors.white54, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ...const [
                ('sunset_dream', '5. Sunset Dream (Vibrant Coral Ocean)', Color(0xFFFB923C), Color(0xFF6B1D2F)),
                ('purple_glow', '1. Purple Glow (Deep Amethyst)', Color(0xFF9B4DFF), Color(0xFF24104D)),
                ('gold_luxury', '2. Gold Luxury (Warm Amber Gold)', Color(0xFFFFC247), Color(0xFF38250B)),
                ('sky_premium', '3. Sky Premium (Frost Azure)', Color(0xFF64B5FF), Color(0xFFBDE8FF)),
                ('green_nature', '4. Green Nature (Emerald)', Color(0xFF45D66B), Color(0xFF102D18)),
              ].map((item) => RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                activeColor: item.$3,
                value: item.$1,
                groupValue: _ios18AppearanceChoice,
                title: Text(item.$2, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500)),
                secondary: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [item.$3, item.$4]),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.white38),
                  ),
                ),
                onChanged: (value) {
                  if (value != null) {
                    HapticFeedback.selectionClick();
                    setState(() => _ios18AppearanceChoice = value);
                    SharedPreferences.getInstance().then((p) {
                      p.setString('ios18_theme_variant', value);
                      p.setString('stackdialer_ios18_appearance', value);
                    });
                    widget.onIos18AppearanceChanged?.call(value);
                  }
                },
              )),

              const SizedBox(height: 16),

              // Dual SIM preference
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.sim_card, color: Color(0xFF38BDF8)),
                title: const Text('Default Calling SIM', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: Text(_preferredSim, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: DropdownButton<String>(
                  value: _preferredSim,
                  dropdownColor: const Color(0xFF1E1C25),
                  underline: const SizedBox(),
                  style: const TextStyle(color: Color(0xFF38BDF8), fontSize: 12),
                  items: const [
                    DropdownMenuItem(value: 'SIM 1', child: Text('SIM 1')),
                    DropdownMenuItem(value: 'SIM 2', child: Text('SIM 2')),
                    DropdownMenuItem(value: 'Always Ask', child: Text('Always Ask')),
                  ],
                  onChanged: (val) {
                    if (val != null) {
                      setState(() => _preferredSim = val);
                      SharedPreferences.getInstance().then((p) => p.setString('stackdialer_preferred_sim', val));
                    }
                  },
                ),
              ),

              // Auto Record Toggle
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.record_voice_over, color: Color(0xFFEF4444)),
                title: const Text('Spam Number Detection', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Enable spam-flag preference for supported checks', style: TextStyle(color: Colors.white54, fontSize: 11)),
                value: _autoRecord,
                activeColor: const Color(0xFF10B981),
                onChanged: (val) {
                  setState(() => _autoRecord = val);
                  SharedPreferences.getInstance().then((p) => p.setBool('stackdialer_spam_detection_enabled', val));
                },
              ),

              // Haptic Feedback
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.vibration, color: Color(0xFFF59E0B)),
                title: const Text('Dialpad Haptics & Tones', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Turn dialpad vibration feedback on or off', style: TextStyle(color: Colors.white54, fontSize: 11)),
                value: _hapticEnabled,
                activeColor: const Color(0xFF10B981),
                onChanged: (val) {
                  setState(() => _hapticEnabled = val);
                  SharedPreferences.getInstance().then((p) => p.setBool('stackdialer_haptics_enabled', val));
                },
              ),

              const Divider(color: Colors.white12),

              const Divider(color: Colors.white12),

              // Speed Dial Management
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.speed, color: Color(0xFFA855F7)),
                title: const Text('Speed Dial Shortcuts', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Configure long-press contacts for keys 1-9', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                onTap: _showSpeedDialSheet,
              ),

              // Blocked Numbers Management
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.shield_outlined, color: Color(0xFFEF4444)),
                title: const Text('Blocked & Spam Numbers', style: TextStyle(color: Colors.white, fontSize: 14)),
                subtitle: const Text('Manage blacklisted caller IDs and spam filters', style: TextStyle(color: Colors.white54, fontSize: 11)),
                trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                onTap: _showBlockedNumbersSheet,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
