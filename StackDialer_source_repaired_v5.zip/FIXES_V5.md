# StackDialer V5 source change

- Added persistent storage for the selected recent-call card style using SharedPreferences.
- The selected style index is loaded when the Recent Calls screen initializes.
- Choosing a style, cycling styles, and pressing Reset now save the selected index. Reset intentionally saves style 1.

## Verification status
This is a source-level change only. An Android APK build and device test have not been run here. After installing the new APK, select style 8, fully close/reopen the app, and verify style 8 remains selected.
