# StackDialer repair pass V4

Changes made:
- Recent-call stack now clips to its viewport and only builds a bounded range of cards near the visible region. This reduces rendering work and avoids the unbounded transformed Stack that could cause blank/black frames with long call histories.
- Stack momentum and spring interpolation are time-based rather than assuming a fixed refresh rate, for smoother scrolling across displays.
- Incoming-call notification uses a new channel ID (`stackdialer_incoming_calls_v2`) so Android can create a fresh high-importance channel instead of reusing stale channel settings from previous builds.

Important Android limitations:
- On Android 13+, notification permission must be allowed. On Android 14+, full-screen-intent special access may also need to be enabled in system settings. The app should be selected as the default phone app for its native InCallService to be used.
- This source has not been built or tested on a physical phone in this environment. Verify build and real incoming/outgoing calls before relying on it.
