import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/contact.dart';
import '../widgets/settings_dialog.dart';

class T9DialpadScreen extends StatefulWidget {
  final List<ContactModel> contacts;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const T9DialpadScreen({
    super.key,
    required this.contacts,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<T9DialpadScreen> createState() => _T9DialpadScreenState();
}

class _T9DialpadScreenState extends State<T9DialpadScreen> with SingleTickerProviderStateMixin {
  static const MethodChannel _dialpadFeedback = MethodChannel('com.stackdialer.app/telecom');
  String _digits = '';
  late final AnimationController _actionController;
  late final Animation<double> _actionScale;
  late final Animation<double> _actionGlow;
  bool _hapticsEnabled = true;

  @override
  void initState() {
    super.initState();
    _actionController = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _actionScale = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.96).chain(CurveTween(curve: Curves.easeOutCubic)), weight: 35),
      TweenSequenceItem(tween: Tween(begin: 0.96, end: 1.0).chain(CurveTween(curve: Curves.easeInOutCubic)), weight: 65),
    ]).animate(_actionController);
    _actionGlow = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0).chain(CurveTween(curve: Curves.easeOut)), weight: 22),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0).chain(CurveTween(curve: Curves.easeOut)), weight: 78),
    ]).animate(_actionController);
    _loadHapticsPreference();
  }

  Future<void> _loadHapticsPreference() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _hapticsEnabled = prefs.getBool('stackdialer_haptics_enabled') ?? true);
  }

  final List<Map<String, String>> _speedDialFavorites = [
    {'label': 'Mom ❤️', 'number': '+91 98201 45892', 'color': '0xFFEC4899'},
    {'label': 'Sanib A.', 'number': '+91 97654 21980', 'color': '0xFF3B82F6'},
    {'label': 'Mo Faisal', 'number': '+91 98711 00982', 'color': '0xFF10B981'},
    {'label': 'Shivi 🦋', 'number': '+91 98450 11223', 'color': '0xFF8B5CF6'},
    {'label': '112 SOS', 'number': '112', 'color': '0xFFEF4444'},
  ];

  final Map<String, String> _t9Map = {
    '1': '',
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
    '*': '',
    '0': '+',
    '#': '',
  };

  void _onDigitPress(String digit) {
    if (_hapticsEnabled) {
      _dialpadFeedback.invokeMethod('dialpadHaptic', {'kind': 'light'}).catchError((_) {});
    }
    if (digit.length == 1 && '0123456789*#'.contains(digit)) {
      _dialpadFeedback.invokeMethod('playDialpadTone', {'digit': digit}).catchError((_) {});
    }
    setState(() {
      _digits += digit;
    });
  }

  void _pulseAction() {
    _actionController.forward(from: 0);
  }

  @override
  void dispose() {
    _actionController.dispose();
    super.dispose();
  }

  void _onBackspace() {
    if (_hapticsEnabled) _dialpadFeedback.invokeMethod('dialpadHaptic', {'kind': 'light'}).catchError((_) {});
    if (_digits.isNotEmpty) {
      setState(() {
        _digits = _digits.substring(0, _digits.length - 1);
      });
    }
  }

  void _onClearAll() {
    if (_hapticsEnabled) _dialpadFeedback.invokeMethod('dialpadHaptic', {'kind': 'medium'}).catchError((_) {});
    setState(() {
      _digits = '';
    });
  }

  List<ContactModel> _getMatchedContacts() {
    if (_digits.isEmpty) return [];
    final q = _digits.toLowerCase();
    return widget.contacts.where((c) {
      final cleanNum = c.number.replaceAll(RegExp(r'[^\d]'), '');
      return cleanNum.contains(q) || c.name.toLowerCase().contains(q);
    }).take(2).toList();
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) => DialerSettingsDialog(
        onSimulateIncoming: widget.onSimulateIncoming,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matches = _getMatchedContacts();

    return Scaffold(
      backgroundColor: const Color(0xFF101113),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF17181B), Color(0xFF101113), Color(0xFF0B0C0E)],
          ),
        ),
        child: SafeArea(
          bottom: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final double screenHeight = constraints.maxHeight;
              // Match the supplied Realme calculator video: 68dp circular
              // graphite keys, broad horizontal breathing room and a compact
              // vertical rhythm. Scale down proportionally on narrow phones.
              final double keyHeight = math.min(68.0, constraints.maxWidth * 0.189);
              final double keyWidth = keyHeight;
              final double keyGap = math.min(48.0, constraints.maxWidth * 0.1333);
              final double rowSpacing = screenHeight < 600 ? 8.0 : 12.0;
              final double callBtnHeight = math.min(keyHeight * 1.08, screenHeight < 600 ? 76.0 : 78.0);

              return Column(
                children: [
                  // Keep the dialpad header clear: no SIM labels or extra controls.
                  const SizedBox(height: 8),

                  // Number display / placeholder, positioned above the large keypad.
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: _digits.isEmpty
                            ? const FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  'Dial number',
                                  style: TextStyle(
                                    fontSize: 36,
                                    fontWeight: FontWeight.w300,
                                    letterSpacing: 0.2,
                                    color: Color(0xFF777B83),
                                  ),
                                ),
                              )
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  AnimatedSwitcher(
                                    duration: const Duration(milliseconds: 230),
                                    switchInCurve: Curves.easeOutCubic,
                                    switchOutCurve: Curves.easeInCubic,
                                    layoutBuilder: (currentChild, previousChildren) {
                                      // Clip the transition so outgoing and incoming
                                      // number strings cannot paint over adjacent UI.
                                      return ClipRect(
                                        child: Stack(
                                          alignment: Alignment.center,
                                          clipBehavior: Clip.hardEdge,
                                          children: <Widget>[
                                            ...previousChildren,
                                            if (currentChild != null) currentChild,
                                          ],
                                        ),
                                      );
                                    },
                                    transitionBuilder: (child, animation) {
                                      final bool isLeaving = animation.status == AnimationStatus.reverse;
                                      final slide = Tween<Offset>(
                                        begin: isLeaving ? Offset.zero : const Offset(0, 0.18),
                                        end: isLeaving ? const Offset(0, -0.18) : Offset.zero,
                                      ).animate(CurvedAnimation(
                                        parent: animation,
                                        curve: Curves.easeInOutCubic,
                                      ));
                                      return FadeTransition(
                                        opacity: animation,
                                        child: SlideTransition(position: slide, child: child),
                                      );
                                    },
                                    child: FittedBox(
                                      key: ValueKey<String>(_digits),
                                      fit: BoxFit.scaleDown,
                                      child: Text(
                                        _digits,
                                        style: const TextStyle(
                                          fontSize: 36,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 1.5,
                                          color: Color(0xFFF4F5F7),
                                        ),
                                      ),
                                    ),
                                  ),
                                  if (matches.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF00C853).withOpacity(0.13),
                                        borderRadius: BorderRadius.circular(18),
                                        border: Border.all(color: const Color(0xFF00D45A).withOpacity(0.35)),
                                      ),
                                      child: Text(
                                        '${matches.first.name} • ${matches.first.number}',
                                        style: const TextStyle(color: Color(0xFF00D879), fontSize: 12, fontWeight: FontWeight.w600),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                      ),
                    ),
                  ),

                  // 3. Large 3D calculator-style phone keypad.
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildSquircleRow(['1', '2', '3'], keyWidth, keyHeight, keyGap),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['4', '5', '6'], keyWidth, keyHeight, keyGap),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['7', '8', '9'], keyWidth, keyHeight, keyGap),
                        SizedBox(height: rowSpacing),
                        _buildSquircleRow(['*', '0', '#'], keyWidth, keyHeight, keyGap),
                      ],
                    ),
                  ),

                  SizedBox(height: rowSpacing + 2),

                  // Keep the call action prominent below the keypad.
                  SizedBox(height: rowSpacing + 4),
                  Padding(
                    padding: const EdgeInsets.only(left: 24, right: 24, bottom: 8),
                    child: SizedBox(
                      height: callBtnHeight,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          AnimatedBuilder(
                            animation: _actionController,
                            builder: (context, child) => Transform.scale(
                              scale: _actionScale.value,
                              child: InkWell(
                                onTap: () {
                                  if (_digits.isNotEmpty) {
                                    _pulseAction();
                                    if (_hapticsEnabled) _dialpadFeedback.invokeMethod('dialpadHaptic', {'kind': 'medium'}).catchError((_) {});
                                    widget.onCallNumber(_digits);
                                  }
                                },
                                customBorder: const CircleBorder(),
                                child: Container(
                                  width: callBtnHeight,
                                  height: callBtnHeight,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF00C853),
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(color: const Color(0xFF00D95B).withOpacity(0.34), blurRadius: 26, spreadRadius: 4),
                                      BoxShadow(color: const Color(0xFF00C853).withOpacity(0.18), blurRadius: 42, spreadRadius: 8),
                                      const BoxShadow(color: Color(0x6600A844), blurRadius: 10, offset: Offset(0, 3)),
                                    ],
                                  ),
                                  child: const Center(child: Icon(Icons.call, color: Color(0xFFF5F6F8), size: callBtnHeight * 0.43)),
                                ),
                              ),
                            ),
                          ),
                          Align(
                              alignment: Alignment.centerRight,
                              child: GestureDetector(
                                onTap: () { _pulseAction(); _onBackspace(); },
                                onLongPress: () { _pulseAction(); _onClearAll(); },
                                child: AnimatedBuilder(
                                  animation: _actionController,
                                  builder: (context, child) => Transform.scale(
                                    scale: _actionScale.value,
                                    child: Container(
                                  width: keyHeight,
                                  height: keyHeight,
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [Color(0xFF34363B), Color(0xFF24262A)],
                                    ),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0x66FFFFFF), width: 1.1),
                                    boxShadow: [
                                      if (_actionGlow.value > 0.015)
                                        BoxShadow(
                                          color: const Color(0xFFFFFFFF).withOpacity(0.95 * _actionGlow.value),
                                          blurRadius: 30 * _actionGlow.value,
                                          spreadRadius: 3.5 * _actionGlow.value,
                                        ),
                                      const BoxShadow(color: Color(0x99000000), blurRadius: 8, offset: Offset(0, 4)),
                                    ],
                                  ),
                                  child: Icon(Icons.backspace_outlined, color: const Color(0xFFFFFFFF), size: keyHeight * 0.38),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSquircleRow(List<String> keys, double width, double height, double gap) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (int i = 0; i < keys.length; i++) ...[
          if (i > 0) SizedBox(width: gap),
          _buildSquircleButton(keys[i], width, height),
        ],
      ],
    );
  }

  Widget _buildSquircleButton(String key, double width, double height) {
    final sub = _t9Map[key] ?? '';
    return Material(
      color: const Color(0xFF292B30),
      shape: const CircleBorder(),
      elevation: 0,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _onDigitPress(key),
        // Keep the standard long-press '+' shortcut on the 0 key.
        onLongPress: key == '0' ? () => _onDigitPress('+') : null,
        customBorder: const CircleBorder(),
        splashFactory: NoSplash.splashFactory,
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
        child: SizedBox(
          width: height,
          height: height,
          child: DecoratedBox(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF292B30),
              border: Border.all(
                color: const Color(0xFF484B52),
                width: 1.2,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  key,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFFF5F6F8),
                    height: 1.0,
                  ),
                ),
                if (sub.isNotEmpty) ...[
                  const SizedBox(height: 3),
                  Text(
                    sub,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF9A9DA5),
                      letterSpacing: 1.7,
                      height: 1.0,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

}
