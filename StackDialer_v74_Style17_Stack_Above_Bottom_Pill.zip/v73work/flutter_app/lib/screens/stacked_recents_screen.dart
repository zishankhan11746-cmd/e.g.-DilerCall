import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/scheduler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/app_haptics.dart';
import '../models/call_record.dart';
import '../services/telecom_service.dart';
import '../services/call_data_service.dart';
import '../widgets/call_detail_bottom_sheet.dart';
import '../widgets/settings_dialog.dart';
import 'package:url_launcher/url_launcher.dart';
import 't9_dialpad_screen.dart';

class StackStyleConfig {
  final String id;
  final int number;
  final String name;
  final String hindiName;
  final String badge;
  final Color badgeBg;
  final Color badgeTextColor;
  final String description;
  final List<Color> highlightGradient;

  const StackStyleConfig({
    required this.id,
    required this.number,
    required this.name,
    required this.hindiName,
    required this.badge,
    required this.badgeBg,
    required this.badgeTextColor,
    required this.description,
    required this.highlightGradient,
  });
}

const List<StackStyleConfig> STACK_STYLES = [
  StackStyleConfig(
    id: 'ios-depth',
    number: 1,
    name: 'iOS Depth Stack',
    hindiName: 'क्लासिक iOS शेड',
    badge: 'iOS 18',
    badgeBg: Color(0x330284C7),
    badgeTextColor: Color(0xFF7DD3FC),
    description: 'Apple notification shade with 3D lip rollup and gentle scale compression.',
    highlightGradient: [Color(0xFF38BDF8), Color(0xFF3B82F6)],
  ),
  StackStyleConfig(
    id: 'coverflow-3d',
    number: 2,
    name: '3D Coverflow Deck',
    hindiName: 'कवरफ्लो 3D टिल्ट',
    badge: 'macOS 3D',
    badgeBg: Color(0x333B82F6),
    badgeTextColor: Color(0xFF93C5FD),
    description: 'Perspective 3D tilt with metallic edge reflection and depth perspective.',
    highlightGradient: [Color(0xFF60A5FA), Color(0xFF6366F1)],
  ),
  StackStyleConfig(
    id: 'cascade-waterfall',
    number: 3,
    name: 'Cascade Waterfall',
    hindiName: 'झरना कैस्केड वेव',
    badge: 'Fluid Wave',
    badgeBg: Color(0x3314B8A6),
    badgeTextColor: Color(0xFF5EEAD4),
    description: 'Fluid staggered waterfall with alternating wave offsets (translateX glide).',
    highlightGradient: [Color(0xFF2DD4BF), Color(0xFF10B981)],
  ),
  StackStyleConfig(
    id: 'cyberpunk-neon',
    number: 4,
    name: 'Cyberpunk Neon',
    hindiName: 'साइबरपंक नियॉन',
    badge: 'Cyber Neon',
    badgeBg: Color(0x33D946EF),
    badgeTextColor: Color(0xFFF0ABFC),
    description: 'Sci-fi stack with horizontal tilt, cyan & magenta edge glows.',
    highlightGradient: [Color(0xFF22D3EE), Color(0xFFE879F9)],
  ),
  StackStyleConfig(
    id: 'origami-fold',
    number: 5,
    name: 'Origami 3D Fold',
    hindiName: 'ओरिगेमी फोल्ड',
    badge: 'Papercraft',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFCD34D),
    description: 'Geometric papercraft folding motion as cards stack at top and bottom.',
    highlightGradient: [Color(0xFFFBBF24), Color(0xFFF97316)],
  ),
  StackStyleConfig(
    id: 'tinder-arc',
    number: 6,
    name: 'Tinder Arc Fan',
    hindiName: 'कार्ड्स फैन आर्क',
    badge: 'Cards Fan',
    badgeBg: Color(0x33F43F5E),
    badgeTextColor: Color(0xFFFDA4AF),
    description: 'Radial deck fanning like a hand of playing cards with smooth rotateZ arc curves.',
    highlightGradient: [Color(0xFFFB7185), Color(0xFFEF4444)],
  ),
  StackStyleConfig(
    id: 'accordion-spring',
    number: 7,
    name: 'Accordion Spring',
    hindiName: 'एलास्टिक स्प्रिंग बाउंस',
    badge: 'Elastic Bounce',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Dynamic elastic compression physics with playful spring recoil.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF22C55E)],
  ),
  StackStyleConfig(
    id: 'dynamic-island',
    number: 8,
    name: 'Dynamic Island',
    hindiName: 'डायनामिक कैप्सूल',
    badge: 'Apple Pill',
    badgeBg: Color(0x338B5CF6),
    badgeTextColor: Color(0xFFC4B5FD),
    description: 'Morphing rounded capsule pill stack with status ring beacons.',
    highlightGradient: [Color(0xFFA78BFA), Color(0xFF8B5CF6)],
  ),
  StackStyleConfig(
    id: 'visionos-glass',
    number: 9,
    name: 'VisionOS Frosted',
    hindiName: 'विज़नओएस ग्लास',
    badge: 'Spatial Glass',
    badgeBg: Color(0x336366F1),
    badgeTextColor: Color(0xFFA5B4FC),
    description: 'Spatial translucent frosted glass with iridescent rim highlights.',
    highlightGradient: [Color(0xFF818CF8), Color(0xFF38BDF8)],
  ),
  StackStyleConfig(
    id: 'charcoal-executive',
    number: 10,
    name: 'Charcoal Executive',
    hindiName: 'प्रीमियम चारकोल स्टैक',
    badge: 'Pro Executive',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Deep luxury matte obsidian charcoal with specular highlights and precision bevels.',
    highlightGradient: [Color(0xFF10B981), Color(0xFF059669)],
  ),
  StackStyleConfig(
    id: 'notification-stack-deck',
    number: 11,
    name: 'Notification Stack Deck',
    hindiName: 'iOS नोटिफिकेशन स्टैक',
    badge: 'Frosted Deck',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Wide overlapping notification cards with 0.96 scale lips, 12px stack spacing, frosted-glass surface and spring-like motion.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'android-notification-flow',
    number: 12,
    name: 'Notification Flow',
    hindiName: 'स्मूद नोटिफिकेशन फ्लो',
    badge: 'Android Shade',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Android notification shade style: separated cards near the top, gradually forming a smooth overlapping deck at the bottom.',
    highlightGradient: [Color(0xFF34D399), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'realme-flux-engine',
    number: 13,
    name: 'Realme Flux Engine',
    hindiName: 'रियलमी फ्लक्स इंजन 7.0',
    badge: 'Flux 7.0',
    badgeBg: Color(0x33F59E0B),
    badgeTextColor: Color(0xFFFBBF24),
    description: 'Realme UI 7.0 Flux Engine: 78dp rigid cards with dynamic progressFactor, 6% bottom-center scale compression, and 0.82 vertical stack displacement.',
    highlightGradient: [Color(0xFFF59E0B), Color(0xFFEF4444)],
  ),

  StackStyleConfig(
    id: 'dynamic-shrink-expand-stack',
    number: 14,
    name: 'Dynamic Shrink & Expand',
    hindiName: 'डायनामिक श्रिंक-एक्सपैंड स्टैक',
    badge: 'Bottom Dock',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF86EFAC),
    description: 'Dynamic Horizontal Shrinking & Expanding Stack (DHSES): card height stays fixed while cards progressively narrow from both sides as live scroll progress brings them into the bottom-only stack; reverse scrolling expands them smoothly.',
    highlightGradient: [Color(0xFF22C55E), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'dynamic-shrink-expand-stack-15',
    number: 15,
    name: 'Dynamic Shrink & Expand – Lower Dock',
    hindiName: 'डायनामिक श्रिंक-एक्सपैंड – लोअर डॉक',
    badge: 'Bottom Dock',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF86EFAC),
    description: 'Same DHSES animation and card design as Style 14, with the bottom stack positioned slightly lower.',
    highlightGradient: [Color(0xFF22C55E), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'dynamic-shrink-expand-stack-16',
    number: 16,
    name: 'Dynamic Shrink & Expand – Style 14 Copy',
    hindiName: 'डायनामिक श्रिंक-एक्सपैंड – स्टाइल 14 कॉपी',
    badge: 'Style 14 Clone',
    badgeBg: Color(0x3322C55E),
    badgeTextColor: Color(0xFF86EFAC),
    description: 'An independent exact copy of Style 14 from the v66 project: same card design, sizing, bottom stack levels, spacing and live expand/shrink behavior.',
    highlightGradient: [Color(0xFF22C55E), Color(0xFF0F766E)],
  ),
  StackStyleConfig(
    id: 'bottom-dock-flow-17',
    number: 17,
    name: 'Bottom Dock Flow – Style 15 Copy',
    hindiName: 'बॉटम डॉक फ्लो – स्टाइल 15 कॉपी',
    badge: 'Dock Pro',
    badgeBg: Color(0x3310B981),
    badgeTextColor: Color(0xFF6EE7B7),
    description: 'Exact independent copy of Style 15 from StackDialer v27: same bottom-only dock, horizontal shrink-expand motion, card design, spacing and scroll response.',
    highlightGradient: [Color(0xFF0B8261), Color(0xFF10B981)],
  ),
];

bool _isDhsesStyle(String styleId) =>
    styleId == 'dynamic-shrink-expand-stack' ||
    styleId == 'dynamic-shrink-expand-stack-15' ||
    styleId == 'dynamic-shrink-expand-stack-16';

bool _isStyle14Copy(String styleId) =>
    styleId == 'dynamic-shrink-expand-stack' ||
    styleId == 'dynamic-shrink-expand-stack-16';

class StackedRecentsScreen extends StatefulWidget {
  final List<CallRecord> calls;
  final VoidCallback onRefresh;
  final Function(String number) onCallNumber;
  final VoidCallback? onSimulateIncoming;

  const StackedRecentsScreen({
    super.key,
    required this.calls,
    required this.onRefresh,
    required this.onCallNumber,
    this.onSimulateIncoming,
  });

  @override
  State<StackedRecentsScreen> createState() => _StackedRecentsScreenState();
}

class _StackedRecentsScreenState extends State<StackedRecentsScreen>
    with SingleTickerProviderStateMixin {
  late Ticker _ticker;
  double _scrollPos = 0.0;
  double _targetScroll = 0.0;
  double _velocity = 0.0;
  bool _isDragging = false;
  double _lastDragY = 0.0;
  DateTime _lastDragTime = DateTime.now();
  double _viewportHeight = 600.0;
  Duration _lastTickElapsed = Duration.zero;

  // Normalized progress for the Style 14 dock shimmer. It follows the
  // current scroll offset across one compact-card step (0.0 to 1.0).
  double get dynamicDockProgress =>
      (_scrollPos % _activeCardStep) / _activeCardStep;

  static const String _stylePreferenceKey = 'stackdialer_selected_card_style_index';
  int _currentStyleIndex = 0;
  bool _stylePreferenceLoaded = false;
  double _scrollSpeedMultiplier = 1.5;
  String _ios18Appearance = 'sunset';
  String _bottomStackStyle = 'three_layer';
  bool _isStackCollapsed = false;
  String _searchQuery = '';
  String _selectedFilter = 'all'; // 'all', 'missed', 'incoming', 'outgoing'
  bool _smartSortEnabled = true;
  final Set<String> _expandedGroupIds = {};
  List<CallRecord> _cachedFilteredCalls = [];

  void _updateFilteredCalls() {
    final baseFiltered = widget.calls.where((call) {
      if (_selectedFilter == 'missed') {
        if (call.type != CallType.missed && call.type != CallType.rejected) return false;
      } else if (_selectedFilter == 'incoming') {
        if (call.type != CallType.incoming) return false;
      } else if (_selectedFilter == 'outgoing') {
        if (call.type != CallType.outgoing) return false;
      }

      if (_searchQuery.trim().isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        return call.name.toLowerCase().contains(q) ||
            call.number.contains(q);
      }
      return true;
    }).toList();

    if (!_smartSortEnabled) {
      _cachedFilteredCalls = baseFiltered;
      return;
    }

    // Smart Sort: Group repeated missed calls from the same number into a single collapsible entry
    final List<CallRecord> smartSorted = [];
    final Map<String, List<CallRecord>> missedGroups = {};
    final Set<String> processedMissedNumbers = {};

    for (final call in baseFiltered) {
      if (call.type == CallType.missed || call.type == CallType.rejected) {
        final clean = call.number.replaceAll(RegExp(r'[^\d+]'), '');
        missedGroups.putIfAbsent(clean, () => []).add(call);
      }
    }

    for (final call in baseFiltered) {
      final isMissed = call.type == CallType.missed || call.type == CallType.rejected;
      if (!isMissed) {
        smartSorted.add(call);
      } else {
        final clean = call.number.replaceAll(RegExp(r'[^\d+]'), '');
        if (!processedMissedNumbers.contains(clean)) {
          processedMissedNumbers.add(clean);
          final group = missedGroups[clean] ?? [call];
          if (group.length > 1) {
            smartSorted.add(CallRecord(
              id: 'group_${call.id}',
              name: call.name,
              number: call.number,
              type: call.type,
              timestamp: group.first.timestamp,
              durationSeconds: 0,
              simSlot: call.simSlot,
              simCarrier: call.simCarrier,
              note: call.note,
              reminderTime: call.reminderTime,
              category: call.category,
              location: call.location,
              repeatCount: group.length,
              groupedSubCalls: group,
            ));
          } else {
            smartSorted.add(call);
          }
        }
      }
    }

    _cachedFilteredCalls = smartSorted;
  }

  // Card physics constants
  static const double cardHeight = 90.0;
  static const double cardGap = 8.0;
  static const double cardStep = cardHeight + cardGap; // 98.0 for styles 1-10
  static const double notificationCardHeight = 176.0;
  static const double notificationCardStep = 152.0; // Style 11: overlapping notification deck
  static const double notificationFlowCardHeight = 78.0;
  static const double notificationFlowCardStep = 98.0; // Style 12: slim cards with visible overlap as they gather into the deck
  static const double fluxCardHeight = 78.0; // Style 13: Realme UI 7.0 rigid card height
  static const double fluxCardStep = 92.0; // Style 13: 78dp card with 14dp gap in free viewport
  static const double dynamicStackCardHeight = 62.0; // Style 15 retains its original compact card
  static const double dynamicStackCardStep = 68.0; // Style 15 retains its original 6dp gap
  static const double dhsesCardHeight = 90.0; // Style 14: full-size reference card
  static const double dhsesCardStep = 98.0; // Style 14: 90dp card + 8dp breathing gap
  static const double bottomDockFlow17CardHeight = 68.0; // Exact v27 Style 15 copy
  static const double bottomDockFlow17CardStep = 74.0; // Exact v27 Style 15 spacing
  static const double headerOffset = 10.0;

  double get _activeCardStep {
    if (_currentStyleIndex == 10) return notificationCardStep;
    if (_currentStyleIndex == 11) return notificationFlowCardStep;
    if (_currentStyleIndex == 12) return fluxCardStep;
    if (_currentStyleIndex == 13 || _currentStyleIndex == 15) return dhsesCardStep;
    if (_currentStyleIndex == 14) return dynamicStackCardStep;
    if (_currentStyleIndex == 16) return bottomDockFlow17CardStep;
    return cardStep;
  }
  double get _activeCardHeight {
    if (_currentStyleIndex == 10) return notificationCardHeight;
    if (_currentStyleIndex == 11) return notificationFlowCardHeight;
    if (_currentStyleIndex == 12) return fluxCardHeight;
    if (_currentStyleIndex == 13 || _currentStyleIndex == 15) return dhsesCardHeight;
    if (_currentStyleIndex == 14) return dynamicStackCardHeight;
    if (_currentStyleIndex == 16) return bottomDockFlow17CardHeight;
    return cardHeight;
  }

  @override
  void initState() {
    super.initState();
    _updateFilteredCalls();
    _ticker = createTicker(_onTick);
    _ticker.start();
    _loadSavedStyle();
    _loadStackMotionPreferences();
  }

  @override
  void didUpdateWidget(covariant StackedRecentsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    _updateFilteredCalls();
    if (widget.calls.length != oldWidget.calls.length ||
        (widget.calls.isNotEmpty && oldWidget.calls.isNotEmpty && widget.calls.first.id != oldWidget.calls.first.id)) {
      _scrollPos = 0.0;
      _targetScroll = 0.0;
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    if (!mounted) return;

    final filtered = _cachedFilteredCalls;
    final double maxScroll = math.max(
      0.0,
      headerOffset + filtered.length * _activeCardStep - _viewportHeight +
          ((_currentStyleIndex == 13 || _currentStyleIndex == 14 || _currentStyleIndex == 15) ? 0.0 : (_currentStyleIndex == 16 ? 42.0 : _activeCardHeight)),
    ).toDouble();
    if (_lastTickElapsed == Duration.zero) {
      _lastTickElapsed = elapsed;
      return;
    }
    // Use elapsed frame time so animation speed is consistent on 60/90/120 Hz screens.
    final frameMs = (elapsed - _lastTickElapsed).inMicroseconds / 1000.0;
    _lastTickElapsed = elapsed;
    final dt = frameMs.clamp(0.0, 40.0);
    if (dt <= 0) return;
    final frameFactor = dt / 16.6667;

    bool changed = false;

    // 1. Time-based kinetic momentum decay (independent of refresh rate).
    if (!_isDragging && _velocity.abs() > 0.08) {
      _targetScroll += _velocity * frameFactor;
      // High-precision silky friction for fluid inertial glide across all 14 styles
      const double friction = 0.952;
      _velocity *= math.pow(friction, frameFactor).toDouble();
      if (_targetScroll < 0) {
        _targetScroll = 0;
        _velocity = 0;
      } else if (_targetScroll > maxScroll) {
        _targetScroll = maxScroll;
        _velocity = 0;
      }
      changed = true;
    } else if (!_isDragging) {
      _velocity = 0;
    }

    // 2. High-performance finger tracking & frame-rate-independent settling across all 14 styles
    final diff = _targetScroll - _scrollPos;
    if (_isDragging) {
      // Instant direct finger tracking during drag eliminates any visible touch latency on 60/90/120Hz screens
      if (diff.abs() > 0.001) {
        _scrollPos = _targetScroll;
        changed = true;
      }
    } else if (diff.abs() > 0.05) {
      // Ultra-smooth 24ms critical damping response for silky glide settling
      const double responseMs = 30.0;
      final interpolation = 1.0 - math.exp(-dt / responseMs);
      _scrollPos += diff * interpolation;
      changed = true;
    } else if (_scrollPos != _targetScroll) {
      _scrollPos = _targetScroll;
      changed = true;
    }

    if (changed) {
      setState(() {});
    }
  }

  List<CallRecord> _getFilteredCalls() {
    return _cachedFilteredCalls;
  }

  Future<void> _loadStackMotionPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _ios18Appearance = prefs.getString('stackdialer_ios18_appearance') ?? 'sunset';
      _scrollSpeedMultiplier = (prefs.getDouble('stack12_scroll_speed') ?? 1.5).clamp(0.5, 3.0).toDouble();
      _bottomStackStyle = prefs.getString('stack12_bottom_style') ?? 'three_layer';
    });
  }

  Future<void> _loadSavedStyle() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedIndex = prefs.getInt(_stylePreferenceKey) ?? 0;
      if (!mounted) return;
      setState(() {
        _currentStyleIndex = savedIndex >= 0 && savedIndex < STACK_STYLES.length
            ? savedIndex
            : 0;
        // Prevent a stale animation/scroll offset from placing every Style 12
        // card outside the viewport when restoring the saved style on launch.
        _scrollPos = 0.0;
        _targetScroll = 0.0;
        _velocity = 0.0;
        _isDragging = false;
        _stylePreferenceLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _stylePreferenceLoaded = true);
    }
  }

  Future<void> _saveSelectedStyle(int index) async {
    final safeIndex = index >= 0 && index < STACK_STYLES.length ? index : 0;
    // Update the UI immediately; persist the selection across app restarts.
    if (mounted) {
      setState(() {
        _currentStyleIndex = safeIndex;
        // Each style can use a different card step/height. Reset the previous
        // style's scroll offset so Style 12 never opens with every card off-screen.
        _scrollPos = 0.0;
        _targetScroll = 0.0;
        _velocity = 0.0;
        _isDragging = false;
      });
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_stylePreferenceKey, safeIndex);
    } catch (_) {
      // Keep the in-memory selection even if device storage is temporarily unavailable.
    }
  }

  void _cycleNextStyle() {
    AppHaptics.lightImpact();
    _saveSelectedStyle((_currentStyleIndex + 1) % STACK_STYLES.length);
  }

  void _restoreDefaultStyle() {
    AppHaptics.mediumImpact();
    _saveSelectedStyle(0);
  }

  void _toggleStackCollapsed() {
    AppHaptics.lightImpact();
    setState(() {
      _isStackCollapsed = !_isStackCollapsed;
    });
  }

  // Exact 3D math engine matching web preview
  Map<String, dynamic> _computeCardTransforms({
    required String styleId,
    required int index,
    required double naturalY,
    required double topBoundary,
    required double bottomBoundary,
    required double dockTopY,
    required double step,
    required int totalCards,
  }) {
    double yPos = naturalY;
    double xPos = 0;
    double scale = 1.0;
    double rotateX = 0;
    double rotateY = 0;
    double rotateZ = 0;
    double skewX = 0;
    double opacity = 1.0;
    bool isStacked = false;
    Alignment transformOrigin = Alignment.center;
    int zIndex = 200 - index * 4;

    if (styleId == 'bottom-dock-flow-17') {
      // Style 17: exact motion logic copied from v27 Style 15.
      if (naturalY <= bottomBoundary) {
        yPos = naturalY;
        scale = 1.0;
        opacity = 1.0;
        isStacked = false;
        rotateX = rotateY = rotateZ = skewX = 0.0;
        transformOrigin = Alignment.center;
      } else {
        isStacked = true;
        final double bottomOverflow = naturalY - bottomBoundary;
        final double progress = (bottomOverflow / math.max(step, 1.0)).clamp(0.0, 4.0).toDouble();
        final double dockOffset = 46.0 * (2.0 / (1.0 + math.exp(-progress * 0.80)) - 1.0);
        yPos = (bottomBoundary + dockOffset).toDouble();
        scale = 1.0;
        rotateX = rotateY = rotateZ = skewX = 0.0;
        opacity = progress <= 1.2
            ? 1.0
            : (progress <= 2.4
                ? (1.0 - (progress - 1.2) * 0.14).clamp(0.0, 1.0).toDouble()
                : (0.832 - (progress - 2.4) * 0.88).clamp(0.0, 1.0).toDouble());
        transformOrigin = Alignment.bottomCenter;
      }
    } else if (_isDhsesStyle(styleId)) {
      // Style 14 keeps its own compact bottom-dock motion.
      if (naturalY > bottomBoundary) {
        final double bottomOverflow = naturalY - bottomBoundary;
        // Video 2 reference: cards gather into a compact layered deck.
        // Keep each rear card visible as a small, even lip instead of collapsing
        // every card into one nearly identical position.
        final double stackDepth = (bottomOverflow / math.max(step, 1.0))
            .clamp(0.0, 4.0)
            .toDouble();
        if (_isStyle14Copy(styleId)) {
          // Even, clearly readable 14dp card lips create the layered Video 2 deck.
          yPos = (bottomBoundary + stackDepth * 14.0).toDouble();
        } else {
          final double easedDepth = stackDepth * (0.88 + 0.12 * (1.0 - math.exp(-stackDepth)));
          yPos = (bottomBoundary + easedDepth * 12.0 + 8.0).toDouble();
        }
        scale = 1.0;
        rotateX = 0.0;
        rotateY = 0.0;
        rotateZ = 0.0;
        opacity = (1.0 - stackDepth * 0.035).clamp(0.84, 1.0).toDouble();
        transformOrigin = Alignment.bottomCenter;
        isStacked = bottomOverflow > step * 0.25;
      }
    } else if (styleId == 'ios-depth') {
      // iOS 18 Style 1: copied from the Style 1 (id: ios-depth) implementation
      // in StackDialer_Style13_FastScroll_Fixed.zip. This is its original
      // bottom-stack transform: logarithmic card displacement, gentle scale
      // compression, 3D lip roll and opacity falloff. Keep Style 1 bottom-only
      // as separately requested: cards above the viewport scroll away normally.
      if (naturalY > bottomBoundary) {
        isStacked = true;
        final double bottomOverflow = naturalY - bottomBoundary;
        final double stackFactor = bottomOverflow / step;
        yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        scale = (math.max(1.0 - math.min(stackFactor, 4.0) * 0.025, 0.90)).toDouble();
        rotateX = (math.min(stackFactor * 1.5, 4.5)).toDouble();
        opacity = (math.max(1.0 - stackFactor * 0.08, 0.50)).toDouble();
        transformOrigin = Alignment.center;
      }
    } else if (_isStackCollapsed && (styleId == 'android-notification-flow' || styleId == 'realme-flux-engine')) {
      const double deckBaseY = 16.0;
      final int stackIndex = math.min(index, 6);
      isStacked = true;
      zIndex = 200 - index * 4;
      yPos = deckBaseY + stackIndex * 14.0;
      scale = (math.max(1.0 - stackIndex * 0.024, 0.88)).toDouble();
      rotateX = (math.min(stackIndex * 2.0, 7.0)).toDouble();
      opacity = (index > 6 ? 0.35 : math.max(1.0 - stackIndex * 0.11, 0.40)).toDouble();
      transformOrigin = Alignment.bottomCenter;
    } else {
      if (naturalY >= topBoundary && naturalY <= bottomBoundary) {
        // NATURAL IN-VIEW POSITION: 100% fully visible, crisp and responsive
        yPos = naturalY;
        isStacked = false;
        scale = 1.0;
        opacity = 1.0;
        rotateX = 0;
        rotateY = 0;
        rotateZ = 0;
        skewX = 0;
        transformOrigin = Alignment.center;
      } else if (naturalY < topBoundary) {
        // Style 1 follows the supplied iOS Depth reference: cards tuck into
        // a soft layered stack at the top while the lower deck remains active.
        // TOP STACK BUNCHING for styles that retain an upper stack.
        isStacked = true;
        final double topOverflow = topBoundary - naturalY;
        final double stackFactor = math.min(topOverflow / step, 3.5).toDouble();
        yPos = (topBoundary - math.pow(stackFactor, 0.7) * 12.0).toDouble();
        scale = (math.max(1.0 - stackFactor * 0.02, 0.94)).toDouble();
        rotateX = (-math.min(stackFactor * 1.5, 4.5)).toDouble();
        // Safe top opacity floor - NEVER black or invisible
        opacity = (math.max(1.0 - stackFactor * 0.18, 0.35)).toDouble();

        if (styleId == 'realme-flux-engine') {
          // Realme UI 7.0 "Flux Engine" Top Overlapping Stack Logic:
          // Fixed item height: exactly 78dp
          const double totalItemHeight = fluxCardHeight; // 78.0dp
          // Rigid progressFactor dynamically calculated: (-itemTopPosition / totalItemHeight).clamp(0.0, 1.0)
          final double progressFactor = (topOverflow / totalItemHeight).clamp(0.0, 1.0);

          // Overlapping Y Displacement: Intercept linear displacement vector and offset it dynamically
          // by (progressFactor * totalItemHeight * 0.82) to tightly compress subsequent cards directly underneath active foreground card
          final double linearDisplacement = -topOverflow; // = naturalY - topBoundary
          final double overlappingOffset = progressFactor * totalItemHeight * 0.82;
          yPos = (topBoundary + linearDisplacement + overlappingOffset).toDouble();

          // Smooth background stack tuck as scrolling goes deeper:
          if (topOverflow > totalItemHeight) {
            final double deepOverflow = topOverflow - totalItemHeight;
            final double stackProgress = math.min(deepOverflow / totalItemHeight, 4.0);
            yPos = (topBoundary - (totalItemHeight * 0.18) - stackProgress * 8.0).toDouble();
          }

          // Scale Transform Matrix: Compress top-sliding overlapping cards by exactly 6%
          // (down to 0.94 scale factor) using bottom-center alignment vector:
          scale = (1.0 - progressFactor * 0.06).toDouble();
          transformOrigin = Alignment.bottomCenter;

          // Alpha Translucency Level: Apply smooth opacity degradation layer where cards
          // compressing into background stack drop alpha/opacity by up to 45% (down to 0.55 opacity threshold):
          opacity = (1.0 - progressFactor * 0.45).toDouble();

          // Performance Optimizer: Viewport boundary clause to prune cards scrolled completely away
          if (topOverflow > totalItemHeight * 5.0) {
            opacity = 0.0;
          }
        } else if (styleId == 'notification-stack-deck') {
          yPos = (topBoundary - math.min(stackFactor, 5.0) * 12.0).toDouble();
          scale = math.pow(0.96, math.min(stackFactor, 5.0)).toDouble();
          rotateX = (-math.min(stackFactor * 0.8, 2.5)).toDouble();
          opacity = math.max(1.0 - stackFactor * 0.07, 0.68).toDouble();
        } else if (styleId == 'android-notification-flow') {
          final double deckProgress = math.min(topOverflow / math.max(step, 1.0), 4.0).toDouble();
          yPos = (topBoundary - deckProgress * 8.0).toDouble();
          scale = math.max(1.0 - deckProgress * 0.025, 0.92).toDouble();
          rotateX = -math.min(deckProgress * 1.2, 4.0).toDouble();
          opacity = math.max(1.0 - deckProgress * 0.12, 0.40).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'coverflow-3d') {
          rotateX = (-math.min(stackFactor * 2.2, 5.5)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'origami-fold') {
          rotateX = (-math.min(stackFactor * 2.5, 6.0)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.022, 0.93)).toDouble();
        } else if (styleId == 'tinder-arc') {
          rotateZ = (((index % 5) - 2) * math.min(stackFactor * 1.5, 4.5)).toDouble();
          xPos = (((index % 5) - 2) * math.min(stackFactor * 2.0, 7.5)).toDouble();
        } else if (styleId == 'cascade-waterfall') {
          xPos = ((index % 2 == 0 ? -10.0 : 10.0) * math.min(stackFactor, 1.8)).toDouble();
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = ((index % 2 == 0 ? 3.0 : -3.0) * math.min(stackFactor, 1.6)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.022, 0.93)).toDouble();
        } else if (styleId == 'accordion-spring') {
          yPos = (topBoundary - math.sin(math.min(stackFactor, 3.0) * 1.2) * 12.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'dynamic-island') {
          scale = (math.max(1.0 - stackFactor * 0.03, 0.90)).toDouble();
          yPos = (topBoundary - math.pow(stackFactor, 0.75) * 12.0).toDouble();
        } else if (styleId == 'visionos-glass') {
          opacity = (math.max(1.0 - stackFactor * 0.20, 0.35)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.02, 0.95)).toDouble();
        } else if (styleId == 'charcoal-executive') {
          yPos = (topBoundary - math.pow(stackFactor, 0.75) * 10.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.02, 0.94)).toDouble();
        }
      } else if (naturalY > bottomBoundary) {
        // BOTTOM STACK OVERLAP: cards gather into smooth 3D layered deck
        isStacked = true;
        final double bottomOverflow = naturalY - bottomBoundary;
        final double stackFactor = bottomOverflow / step;
        yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        scale = (math.max(1.0 - math.min(stackFactor, 4.0) * 0.025, 0.90)).toDouble();
        rotateX = (math.min(stackFactor * 1.5, 4.5)).toDouble();
        // Safe bottom opacity: NEVER 0.0!
        opacity = (math.max(1.0 - stackFactor * 0.08, 0.50)).toDouble();

        if (_isDhsesStyle(styleId)) {
          // Fixed bottom dock; continuous progress keeps the animation tied to finger movement.
          final double progress = (bottomOverflow / math.max(step, 1.0)).clamp(0.0, 5.0).toDouble();
          final double dockProgress = 1.0 - math.exp(-progress * 0.92);
          yPos = (bottomBoundary + dockProgress * 18.0).toDouble();
          scale = 1.0; // Never shrink card height.
          rotateX = 0.0;
          rotateY = 0.0;
          rotateZ = 0.0;
          opacity = (1.0 - dockProgress * 0.14).clamp(0.82, 1.0).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'realme-flux-engine') {
          // Realme UI 7.0 "Flux Engine" Bottom Notification Stack:
          // Continuous elastic unstacking & docking animation exactly matching the Realme UI 7.0 update video
          final double progress = (bottomOverflow / step).clamp(0.0, 5.0);

          // 1. Fluid asymptotic docking displacement: cards nest into the bottom deck with 12-14px lip tiers
          // Using continuous exponential deceleration (zero discrete step cuts)
          final double dockOffset = (1.0 - math.exp(-progress * 0.75)) * 26.0;
          yPos = (bottomBoundary + dockOffset).toDouble();

          // 2. Continuous scale compression: scales smoothly from 1.0 (active emerging) down to 0.92 (stacked deep)
          // When swiped up, the card expands smoothly out of the bottom stack!
          scale = (1.0 - (1.0 - math.exp(-progress * 0.70)) * 0.08).clamp(0.88, 1.0).toDouble();

          // 3. Smooth alpha degradation: top 2 stacked cards remain crisp & clear with frosted look
          opacity = (1.0 - progress * 0.10).clamp(0.45, 1.0).toDouble();

          // Bottom-center vector so the card expands outwards and upwards when peeling out of the stack
          transformOrigin = Alignment.bottomCenter;
        } else if (styleId == 'notification-stack-deck') {
          yPos = (bottomBoundary + math.min(stackFactor, 5.0) * 12.0).toDouble();
          scale = math.pow(0.96, math.min(stackFactor, 5.0)).toDouble();
          rotateX = math.min(stackFactor * 0.8, 2.5).toDouble();
          opacity = math.max(1.0 - stackFactor * 0.045, 0.65).toDouble();
        } else if (styleId == 'android-notification-flow') {
          final int layer = math.max(1, stackFactor.ceil());
          final double layerIndex = (layer - 1).toDouble();
          yPos = (bottomBoundary + math.min(layerIndex, 5.0) * 12.0).toDouble();
          scale = (math.max(1.0 - math.min(layerIndex, 5.0) * 0.03, 0.88)).toDouble();
          rotateX = (math.min(layerIndex * 0.6, 2.5)).toDouble();
          opacity = (math.max(1.0 - layerIndex * 0.09, 0.40)).toDouble();
          transformOrigin = Alignment.center;
        } else if (styleId == 'coverflow-3d') {
          rotateX = (math.min(stackFactor * 2.0, 5.0)).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'cascade-waterfall') {
          xPos = ((index % 2 == 0 ? -8.0 : 8.0) * math.min(stackFactor, 1.8)).toDouble();
        } else if (styleId == 'origami-fold') {
          rotateX = (math.min(stackFactor * 2.2, 5.5)).toDouble();
        } else if (styleId == 'tinder-arc') {
          rotateZ = (((index % 5) - 2) * math.min(stackFactor * 1.2, 3.5)).toDouble();
          xPos = (((index % 5) - 2) * math.min(stackFactor * 1.8, 6.0)).toDouble();
        } else if (styleId == 'cyberpunk-neon') {
          rotateY = ((index % 2 == 0 ? -2.5 : 2.5) * math.min(stackFactor, 1.4)).toDouble();
        } else if (styleId == 'accordion-spring') {
          yPos = (bottomBoundary + math.sin(math.min(stackFactor, 3.0) * 1.0) * 16.0).toDouble();
          scale = (math.max(1.0 - stackFactor * 0.025, 0.92)).toDouble();
        } else if (styleId == 'dynamic-island' || styleId == 'ios-depth') {
          // Match iOS 18 Style 1 to Style 8's Dynamic Island bottom stack:
          // same compact scale, layered vertical tuck, and fade behavior.
          scale = (math.max(1.0 - stackFactor * 0.03, 0.90)).toDouble();
        } else if (styleId == 'visionos-glass') {
          opacity = (math.max(1.0 - stackFactor * 0.08, 0.60)).toDouble();
        } else if (styleId == 'charcoal-executive') {
          yPos = (bottomBoundary + (math.log(1.0 + stackFactor * 2.2) * 22.0)).toDouble();
        }
      }
    }

    return {
      'yPos': yPos,
      'xPos': xPos,
      'scale': scale,
      'rotateX': rotateX,
      'rotateY': rotateY,
      'rotateZ': rotateZ,
      'skewX': skewX,
      'opacity': opacity.clamp(0.0, 1.0),
      'isStacked': isStacked,
      'zIndex': zIndex,
      'transformOrigin': transformOrigin,
    };
  }

  void _showStyleSelectorSheet() {
    AppHaptics.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141219),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Sheet Grab handle
              Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.style, color: Color(0xFF10B981), size: 18),
                      ),
                      const SizedBox(width: 10),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Card Stack Animation Styles',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '14 Distinct Card Motion Styles',
                            style: TextStyle(color: Colors.white38, fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  TextButton.icon(
                    onPressed: () {
                      _restoreDefaultStyle();
                      Navigator.pop(ctx);
                    },
                    icon: const Icon(Icons.refresh, size: 14, color: Colors.blueAccent),
                    label: const Text('Reset', style: TextStyle(color: Colors.blueAccent, fontSize: 12)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView.builder(
                  itemCount: STACK_STYLES.length,
                  itemBuilder: (context, idx) {
                    final style = STACK_STYLES[idx];
                    final isSelected = idx == _currentStyleIndex;
                    return InkWell(
                      onTap: () {
                        AppHaptics.selectionClick();
                        _saveSelectedStyle(idx);
                        Navigator.pop(ctx);
                      },
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFF10B981).withOpacity(0.12)
                              : const Color(0xFF1F1D27).withOpacity(0.8),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF10B981).withOpacity(0.6)
                                : Colors.white.withOpacity(0.08),
                            width: isSelected ? 1.5 : 1.0,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: isSelected ? const Color(0xFF10B981) : Colors.white10,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Text(
                                  style.number.toString().padLeft(2, '0'),
                                  style: TextStyle(
                                    color: isSelected ? Colors.white : Colors.white70,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        style.name,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '(${style.hindiName})',
                                        style: const TextStyle(color: Colors.white38, fontSize: 11),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    style.description,
                                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: style.badgeBg,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                style.badge,
                                style: TextStyle(
                                  color: style.badgeTextColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  static const Map<String, Map<String, Color>> _ios18Palettes = {
    // Original iOS 18 Style 1 appearance remains available as a separate option.
    'original': {'bg1': Color(0xFF1B1822), 'bg2': Color(0xFF141219), 'bg3': Color(0xFF0D0C11), 'card1': Color(0xF522202C), 'card2': Color(0xF522202C), 'edge': Color(0x33FFFFFF), 'text': Color(0xFFFFFFFF)},
    'purple': {'bg1': Color(0xFF160B35), 'bg2': Color(0xFF35106B), 'bg3': Color(0xFF100A27), 'card1': Color(0xA83B1B82), 'card2': Color(0xA81B3B91), 'edge': Color(0xFFE7CFFF), 'text': Color(0xFFFFFFFF)},
    'gold': {'bg1': Color(0xFF090A0D), 'bg2': Color(0xFF34230B), 'bg3': Color(0xFF08090C), 'card1': Color(0xB52B2414), 'card2': Color(0xB58A5B16), 'edge': Color(0xFFFFD978), 'text': Color(0xFFFFF4D8)},
    'sky': {'bg1': Color(0xFF0755B8), 'bg2': Color(0xFF8BCBFF), 'bg3': Color(0xFFE8F5FF), 'card1': Color(0xBDF4FBFF), 'card2': Color(0xC9B9DFFF), 'edge': Color(0xFFFFFFFF), 'text': Color(0xFF102C4B)},
    'green': {'bg1': Color(0xFF031B0A), 'bg2': Color(0xFF145326), 'bg3': Color(0xFF020C05), 'card1': Color(0xB51A4824), 'card2': Color(0xB51C6A35), 'edge': Color(0xFFB8F5BD), 'text': Color(0xFFF0FFF1)},
    'sunset': {'bg1': Color(0xFF51218B), 'bg2': Color(0xFFE8798D), 'bg3': Color(0xFFFFA34E), 'card1': Color(0xCFFCE0D7), 'card2': Color(0xDFFFCB9F), 'edge': Color(0xFFFFF4EE), 'text': Color(0xFF32152E)},
  };

  Map<String, Color> get _activeIos18Palette => _ios18Palettes[_ios18Appearance] ?? _ios18Palettes['original']!;

  String? get _activeIos18WallpaperAsset => _ios18Appearance == 'original'
      ? null
      : 'assets/${_ios18Appearance}_wallpaper.jpg';

  String? get _activeIos18CardTextureAsset => _ios18Appearance == 'original'
      ? null
      : 'assets/${_ios18Appearance}_card_texture.png';

  Future<void> _setIos18Appearance(String value) async {
    setState(() => _ios18Appearance = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('stackdialer_ios18_appearance', value);
  }

  BoxDecoration _getCardBoxDecoration(String styleId, bool isMissed) {
    // Style 17: exact card surface copied from v27 Style 15, including the
    // same charcoal gradient, 24dp corners, cool rim and shadow treatment.
    if (styleId == 'bottom-dock-flow-17') {
      return BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF20222C), Color(0xFF161820)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFB7BACB).withOpacity(0.24), width: 1.05),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.50),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.05),
            blurRadius: 8,
            spreadRadius: -1,
          ),
        ],
      );
    }
    if (isMissed && !_isDhsesStyle(styleId)) {
      if (styleId == 'visionos-glass') {
        return BoxDecoration(
          color: Colors.redAccent.withOpacity(0.18),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.redAccent.withOpacity(0.55), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.redAccent.withOpacity(0.2),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        );
      } else if (styleId == 'cyberpunk-neon') {
        return BoxDecoration(
          color: const Color(0xFF281120).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.pinkAccent.withOpacity(0.8), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.pinkAccent.withOpacity(0.35),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        );
      } else if (styleId == 'ios-depth') {
        final palette = _activeIos18Palette;
        return BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [palette['card1']!.withOpacity(0.92), palette['card2']!.withOpacity(0.92)]),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: palette['edge']!.withOpacity(0.82), width: 1.1),
          boxShadow: [
            BoxShadow(color: palette['bg1']!.withOpacity(0.24), blurRadius: 16, offset: const Offset(0, 6)),
          ],
        );
      } else if (styleId == 'realme-flux-engine') {
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFA2C1E26),
              const Color(0xFA1F151B),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: const Color(0xFFF43F5E).withOpacity(0.35),
            width: 0.9,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.40),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: const Color(0xFFF43F5E).withOpacity(0.12),
              blurRadius: 12,
              offset: const Offset(0, 2),
            ),
          ],
        );
      }
      return BoxDecoration(
        color: const Color(0xFF2B161E).withOpacity(0.96),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFEF4444).withOpacity(0.2),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      );
    }

    switch (styleId) {
      case 'dynamic-shrink-expand-stack':
      case 'dynamic-shrink-expand-stack-15':
      case 'dynamic-shrink-expand-stack-16':
        // Style 16 is an exact independent copy of Style 14's card decoration.
        final double dhsesRadius = _isStyle14Copy(styleId) ? 26.0 : 14.0;
        return BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xF0252630), Color(0xF01B1C25)],
          ),
          borderRadius: BorderRadius.circular(dhsesRadius),
          border: Border.all(color: const Color(0xFFB7BACB).withOpacity(0.22), width: 0.9),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.30),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'realme-flux-engine':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFA28272F),
              const Color(0xFA1F1E26),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: Colors.white.withOpacity(0.10),
            width: 0.8,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.04),
              blurRadius: 1,
              offset: const Offset(0, -1),
            ),
          ],
        );
      case 'android-notification-flow':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF25232F).withOpacity(0.96),
              const Color(0xFF1D1B24).withOpacity(0.96),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFF34D399).withOpacity(0.40),
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.12),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.55),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'notification-stack-deck':
        return BoxDecoration(
          color: const Color(0xE61B1B20), // dark 90% frosted-glass base
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(0.16), width: 1.1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.42),
              blurRadius: 22,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: const Color(0xFF34D399).withOpacity(0.07),
              blurRadius: 18,
              spreadRadius: -3,
            ),
          ],
        );
      case 'coverflow-3d':
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF1E283C).withOpacity(0.95),
              const Color(0xFF141C2B).withOpacity(0.95),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF60A5FA).withOpacity(0.45), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF3B82F6).withOpacity(0.2),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'cyberpunk-neon':
        return BoxDecoration(
          color: const Color(0xFF141724).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF22D3EE).withOpacity(0.7), width: 1.3),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF22D3EE).withOpacity(0.25),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'cascade-waterfall':
        return BoxDecoration(
          color: const Color(0xFF132626).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF2DD4BF).withOpacity(0.45), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF14B8A6).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'origami-fold':
        return BoxDecoration(
          color: const Color(0xFF262016).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFBBF24).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF59E0B).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'tinder-arc':
        return BoxDecoration(
          color: const Color(0xFF2A1522).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFB7185).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF43F5E).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'accordion-spring':
        return BoxDecoration(
          color: const Color(0xFF13281E).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF34D399).withOpacity(0.5), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF10B981).withOpacity(0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
      case 'dynamic-island':
        return BoxDecoration(
          color: const Color(0xFF141120).withOpacity(0.96),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: const Color(0xFFA78BFA).withOpacity(0.55), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF8B5CF6).withOpacity(0.25),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'visionos-glass':
        return BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.1),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        );
      case 'charcoal-executive':
        return BoxDecoration(
          color: const Color(0xFF1E1E26).withOpacity(0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF10B981).withOpacity(0.35), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        );
      case 'ios-depth':
        final palette = _activeIos18Palette;
        return BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isMissed
                ? [palette['card1']!.withOpacity(0.92), palette['card2']!.withOpacity(0.92)]
                : [palette['card1']!, palette['card2']!, palette['card1']!.withOpacity(0.88)],
          ),
          image: _activeIos18CardTextureAsset == null
              ? null
              : DecorationImage(
                  image: AssetImage(_activeIos18CardTextureAsset!),
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: palette['edge']!.withOpacity(0.78), width: 1.15),
          boxShadow: [
            BoxShadow(color: palette['bg1']!.withOpacity(0.28), blurRadius: 18, offset: const Offset(0, 7)),
            BoxShadow(color: Colors.white.withOpacity(0.22), blurRadius: 1, offset: const Offset(0, -1)),
          ],
        );
      default:
        return BoxDecoration(
          color: const Color(0xFF22202C).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        );
    }
  }

  String _formatTimeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays == 1) return 'Yesterday';
    return '${dt.day}/${dt.month}';
  }

  List<Color> _sunsetAvatarColors(CallRecord call) {
    final int palette = call.name.hashCode.abs() % 3;
    switch (palette) {
      case 0:
        return const [Color(0xFF4F7BFF), Color(0xFF2555D8)];
      case 1:
        return const [Color(0xFFE65AAE), Color(0xFF8B2BAA)];
      default:
        return const [Color(0xFF35CDB8), Color(0xFF087F9D)];
    }
  }

  Future<void> _openWhatsApp(String number) async {
    RealmeOHaptics.microTick();
    final clean = number.replaceAll(RegExp(r'\D'), '');
    if (clean.isEmpty) return;
    final uri = Uri.https('wa.me', '/$clean');
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('WhatsApp could not be opened. Check that it is installed.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('WhatsApp could not be opened.')),
        );
      }
    }
  }

  Future<void> _setCallbackReminder(CallRecord call, String label, Duration delay) async {
    RealmeOHaptics.microTick();
    final reminderAt = DateTime.now().add(delay);
    final scheduled = await CallDataService.scheduleCallbackReminder(
      callId: call.id, name: call.name, number: call.number, at: reminderAt, label: label,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.alarm_on, color: Color(0xFF10B981), size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                scheduled ? '⏰ Callback Reminder scheduled: "${call.name}" ($label)' : 'Allow notifications and exact alarms, then schedule again.',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1F1F2B),
      ),
    );
  }

  Future<void> _chooseCallbackReminder(CallRecord call) async {
    final date = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 1)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)));
    if (date == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (time == null || !mounted) return;
    final at = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    if (!at.isAfter(DateTime.now())) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose a future reminder time')));
      return;
    }
    final ok = await CallDataService.scheduleCallbackReminder(callId: call.id, name: call.name, number: call.number, at: at, label: 'Callback reminder');
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Callback reminder scheduled' : 'Allow notifications and exact alarms, then schedule again')));
  }

  Future<void> _deleteCall(String id) async {
    final matches = widget.calls.where((c) => c.id == id);
    if (matches.isEmpty) return;
    // Device call-log rows use the Android CallLog _ID; locally-created call rows
    // are removed from the app's durable history instead.
    final isDeviceLog = RegExp(r'^\d+$').hasMatch(id);
    final deletedFromDevice = isDeviceLog ? await CallDataService.deleteDeviceCallLog(id) : true;
    if (!deletedFromDevice) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Android could not delete this call. Check call-log permission and default dialer access.')));
      return;
    }
    await CallDataService.deleteSavedCall(id);
    if (!mounted) return;
    setState(() { widget.calls.removeWhere((c) => c.id == id); _updateFilteredCalls(); });
    widget.onRefresh();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(isDeviceLog ? 'Call moved to Recently Deleted' : 'Call removed from StackDialer history'),
      action: isDeviceLog ? SnackBarAction(label: 'UNDO', onPressed: () async {
        final restoredId = await CallDataService.restoreDeletedDeviceCallLog(id);
        if (restoredId != null) {
          widget.onRefresh();
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Call log entry restored')));
        } else if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Restore failed. Check default dialer and call-log write permission.')));
        }
      }) : null,
    ));
  }

  void _showLeftSwipeActionSheet(CallRecord call) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1C1A24),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF0284C7), Color(0xFF38BDF8)],
                        ),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Center(
                        child: Text(
                          call.name.isNotEmpty ? call.name[0].toUpperCase() : '?',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            call.name,
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            call.number,
                            style: const TextStyle(color: Colors.white60, fontSize: 12, fontFamily: 'monospace'),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white54),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Divider(color: Colors.white12),
                const SizedBox(height: 6),
                ListTile(
                  leading: const Icon(Icons.call, color: Color(0xFF10B981)),
                  title: const Text('Call back now', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Start a real phone call', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () { Navigator.pop(ctx); widget.onCallNumber(call.number); },
                ),
                ListTile(
                  leading: const Icon(Icons.edit_note, color: Color(0xFF38BDF8)),
                  title: const Text('Add note and tags', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Save details against this phone number', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () { Navigator.pop(ctx); showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => CallDetailBottomSheet(call: call, allCalls: widget.calls, onCallNumber: widget.onCallNumber, onDeleteCall: _deleteCall)); },
                ),
                ListTile(
                  leading: const Icon(Icons.alarm_add, color: Color(0xFFFBBF24)),
                  title: const Text('Choose callback reminder time', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Schedule a real Android notification', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () { Navigator.pop(ctx); _chooseCallbackReminder(call); },
                ),
                // Quick SMS Action
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: const Color(0xFF0284C7).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.sms_rounded, color: Color(0xFF38BDF8), size: 20),
                  ),
                  title: const Text('Send Quick SMS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Open default SMS composer', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () async {
                    Navigator.pop(ctx);
                    final uri = Uri.parse('sms:${call.number}');
                    if (await canLaunchUrl(uri)) await launchUrl(uri);
                  },
                ),
                // 1-Tap Direct WhatsApp Chat
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: const Color(0xFF25D366).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 20),
                  ),
                  title: const Text('1-Tap WhatsApp Chat', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Chat instantly without saving number to contacts', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () {
                    Navigator.pop(ctx);
                    _openWhatsApp(call.number);
                  },
                ),
                // Quick Callback Reminder 15m
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: const Color(0xFFF59E0B).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.alarm, color: Color(0xFFFBBF24), size: 20),
                  ),
                  title: const Text('Remind me in 15 mins', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Set 1-tap quick callback alarm', style: TextStyle(color: Colors.white54, fontSize: 11)),
                  onTap: () {
                    Navigator.pop(ctx);
                    _setCallbackReminder(call, 'In 15 mins', const Duration(minutes: 15));
                  },
                ),
                // Delete Call
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: const Color(0xFFEF4444).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.delete_outline, color: Color(0xFFEF4444), size: 20),
                  ),
                  title: const Text('Delete from Recent Calls', style: TextStyle(color: Color(0xFFEF4444), fontWeight: FontWeight.w600)),
                  onTap: () {
                    Navigator.pop(ctx);
                    _deleteCall(call.id);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }


  Widget _buildDynamicStyle14CardContent(CallRecord call, bool isMissed, {required bool video2Sizing}) {
    final String rawName = call.name.trim();
    final bool unsaved = rawName.isEmpty ||
        rawName == call.number.trim() ||
        rawName.toLowerCase() == 'unknown';
    final String title = unsaved ? call.number : rawName;
    final String duration = call.duration > 0
        ? '${call.duration ~/ 60}m ${call.duration % 60}s'
        : '0s';
    final double avatarSize = video2Sizing ? 56.0 : 34.0;
    final double titleSize = video2Sizing ? 18.0 : 12.5;
    final double numberSize = video2Sizing ? 15.0 : 10.5;
    final double callSize = video2Sizing ? 54.0 : 38.0;
    final double actionRadius = video2Sizing ? 16.0 : 11.0;

    final IconData directionIcon = isMissed
        ? Icons.call_missed_rounded
        : (call.type == CallType.outgoing
            ? Icons.call_made_rounded
            : Icons.call_received_rounded);
    final Color directionColor = isMissed
        ? const Color(0xFFF87171)
        : (call.type == CallType.outgoing
            ? const Color(0xFF38BDF8)
            : const Color(0xFF10B981));

    return Row(
      children: [
        Container(
          width: avatarSize,
          height: avatarSize,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isMissed
                  ? const [Color(0xFFB83D66), Color(0xFF633A78)]
                  : const [Color(0xFF245B67), Color(0xFF263B59)],
            ),
            borderRadius: BorderRadius.circular(video2Sizing ? 16 : 10),
            border: Border.all(color: Colors.white.withOpacity(0.14), width: 0.8),
          ),
          child: Center(
            child: Text(
              title.isNotEmpty ? title[0].toUpperCase() : '?',
              maxLines: 1,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: video2Sizing ? 26 : 16,
              ),
            ),
          ),
        ),
        SizedBox(width: video2Sizing ? 14 : 8),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: isMissed ? const Color(0xFFFF9292) : Colors.white,
                        fontSize: titleSize,
                        fontWeight: FontWeight.w700,
                        height: 1.0,
                      ),
                    ),
                  ),
                  SizedBox(width: video2Sizing ? 8 : 5),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: const Color(0xFF777987).withOpacity(0.22),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                      'SIM ${call.simSlot}',
                      style: TextStyle(
                        color: const Color(0xFFB8BAC6),
                        fontSize: video2Sizing ? 11.5 : 8.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Flexible(
                    child: Text(
                      _formatTimeAgo(call.timestamp),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.end,
                      style: TextStyle(
                        color: const Color(0xFF9699A8),
                        fontSize: video2Sizing ? 12.0 : 9,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: video2Sizing ? 7 : 4),
              Row(
                children: [
                  Icon(directionIcon, color: directionColor, size: video2Sizing ? 17 : 13),
                  SizedBox(width: video2Sizing ? 6 : 4),
                  Expanded(
                    child: Text(
                      call.number,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: const Color(0xFFD4D5DC),
                        fontSize: numberSize,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Text(
                    '· $duration',
                    maxLines: 1,
                    style: TextStyle(
                      color: const Color(0xFF8D909E),
                      fontSize: video2Sizing ? 11.5 : 9,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        SizedBox(width: video2Sizing ? 10 : 6),
        InkWell(
          onTap: () => Clipboard.setData(ClipboardData(text: call.number)),
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            width: video2Sizing ? 30 : 24,
            height: video2Sizing ? 50 : 34,
            child: Center(
              child: Icon(Icons.copy_rounded, color: const Color(0xFF9A9CAA), size: video2Sizing ? 21 : 17),
            ),
          ),
        ),
        const SizedBox(width: 5),
        InkWell(
          onTap: () {
            AppHaptics.heavyImpact();
            widget.onCallNumber(call.number);
          },
          borderRadius: BorderRadius.circular(actionRadius),
          child: Container(
            width: callSize,
            height: callSize,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF10B981), Color(0xFF059669)],
              ),
              borderRadius: BorderRadius.circular(actionRadius),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF10B981).withOpacity(0.25),
                  blurRadius: video2Sizing ? 12 : 7,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Center(
              child: Icon(Icons.call_rounded, color: Colors.white, size: video2Sizing ? 25 : 17),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBottomDockFlow17CardContent(CallRecord call, bool isMissed) {
    const String styleId = 'bottom-dock-flow';
    final bool sunsetStyle = styleId == 'ios-depth';
    final bool bottomDockFlowStyle = styleId == 'bottom-dock-flow';
    final Color ios18Text = _activeIos18Palette['text']!;
    IconData typeIcon;
    Color typeColor;
    if (isMissed) {
      typeIcon = Icons.call_missed;
      typeColor = Colors.redAccent;
    } else if (call.type == CallType.outgoing) {
      typeIcon = Icons.call_made;
      typeColor = Colors.lightBlueAccent;
    } else {
      typeIcon = Icons.call_received;
      typeColor = const Color(0xFF10B981);
    }

    final durationText = call.duration > 0
        ? '${(call.duration ~/ 60)}m ${(call.duration % 60)}s'
        : '0s';

    return Row(
      children: [
        // Avatar
        Container(
          width: bottomDockFlowStyle ? 40 : 42,
          height: bottomDockFlowStyle ? 40 : 42,
          decoration: BoxDecoration(
            color: bottomDockFlowStyle ? const Color(0xFF313946) : null,
            gradient: bottomDockFlowStyle
                ? null
                : LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: sunsetStyle
                        ? (isMissed
                            ? [const Color(0xFFE45A7A), const Color(0xFF8D3D9B)]
                            : _sunsetAvatarColors(call))
                        : (isMissed
                            ? [Colors.redAccent.withOpacity(0.35), Colors.purpleAccent.withOpacity(0.2)]
                            : [const Color(0xFF10B981).withOpacity(0.35), Colors.blueAccent.withOpacity(0.2)]),
                  ),
            borderRadius: BorderRadius.circular(bottomDockFlowStyle ? 20 : 13),
            border: Border.all(
              color: bottomDockFlowStyle
                  ? Colors.white.withOpacity(0.12)
                  : (sunsetStyle ? Colors.white.withOpacity(0.48) : (isMissed ? Colors.redAccent.withOpacity(0.3) : Colors.white12)),
            ),
          ),
          child: Center(
            child: Text(
              call.name.isNotEmpty ? call.name[0].toUpperCase() : '?',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        // Name, Number & Info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      call.name,
                      style: TextStyle(
                        color: sunsetStyle
                            ? ios18Text
                            : (bottomDockFlowStyle
                                ? Colors.white
                                : (isMissed ? const Color(0xFFFF8B8B) : Colors.white)),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (call.repeatCount > 1) ...[
                    const SizedBox(width: 5),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEF4444).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.6), width: 0.8),
                      ),
                      child: Text(
                        '(${call.repeatCount})',
                        style: const TextStyle(
                          color: Color(0xFFF87171),
                          fontSize: 9.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                    decoration: BoxDecoration(
                      color: sunsetStyle ? ios18Text.withOpacity(0.12) : Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(
                      'SIM ${call.simSlot}',
                      style: TextStyle(color: sunsetStyle ? ios18Text.withOpacity(0.82) : Colors.white60, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _formatTimeAgo(call.timestamp),
                    style: TextStyle(
                      color: sunsetStyle ? ios18Text.withOpacity(0.68) : Colors.white38,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 4),
                  if (DateTime.now().difference(call.timestamp).inMinutes < 5) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(
                        color: sunsetStyle ? const Color(0xFF10B981).withOpacity(0.16) : const Color(0xFF10B981).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: const Color(0xFF10B981), width: 0.8),
                      ),
                      child: const Text(
                        'LIVE',
                        style: TextStyle(
                          color: Color(0xFF10B981),
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                  if (isMissed) ...[
                    const SizedBox(width: 4),
                    InkWell(
                      onTap: () => _setCallbackReminder(call, '15m', const Duration(minutes: 15)),
                      borderRadius: BorderRadius.circular(5),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF59E0B).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: const Color(0xFFF59E0B), width: 0.8),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.alarm, color: Color(0xFFF59E0B), size: 8),
                            SizedBox(width: 2),
                            Text(
                              'Remind 15m',
                              style: TextStyle(
                                color: Color(0xFFFBBF24),
                                fontSize: 8,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 3),
              Row(
                children: [
                  Icon(typeIcon, color: typeColor, size: 12),
                  const SizedBox(width: 4),
                  Text(
                    call.number,
                    style: TextStyle(color: sunsetStyle ? ios18Text.withOpacity(0.92) : Colors.white60, fontSize: 11, fontFamily: 'monospace'),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    call.repeatCount > 1 ? '• ${call.repeatCount} Missed Calls (Grouped)' : '• $durationText',
                    style: TextStyle(
                      color: call.repeatCount > 1 ? const Color(0xFFF87171) : (sunsetStyle ? ios18Text.withOpacity(0.68) : Colors.white38),
                      fontSize: 10,
                      fontWeight: call.repeatCount > 1 ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        // Action Buttons: WhatsApp, Copy & Direct Call CTA
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 1-Tap Direct WhatsApp Chat
            InkWell(
              onTap: () => _openWhatsApp(call.number),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: const Color(0xFF25D366).withOpacity(0.18),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFF25D366).withOpacity(0.4), width: 0.8),
                ),
                child: const Center(
                  child: Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 15),
                ),
              ),
            ),
            IconButton(
              icon: Icon(Icons.copy, color: sunsetStyle ? ios18Text.withOpacity(0.8) : Colors.white38, size: 16),
              tooltip: 'Copy Number',
              onPressed: () {
                Clipboard.setData(ClipboardData(text: call.number));
                HapticFeedback.lightImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Copied ${call.number} to clipboard'),
                    duration: const Duration(seconds: 1),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
            InkWell(
              onTap: () {
                HapticFeedback.heavyImpact();
                widget.onCallNumber(call.number);
              },
              borderRadius: BorderRadius.circular(bottomDockFlowStyle ? 20 : 14),
              child: Container(
                width: bottomDockFlowStyle ? 38 : 40,
                height: bottomDockFlowStyle ? 38 : 40,
                decoration: BoxDecoration(
                  gradient: bottomDockFlowStyle
                      ? const LinearGradient(
                          colors: [Color(0xFF0B8261), Color(0xFF0A7355)],
                        )
                      : const LinearGradient(
                          colors: [Color(0xFF10B981), Color(0xFF059669)],
                        ),
                  borderRadius: BorderRadius.circular(bottomDockFlowStyle ? 19 : 14),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF10B981).withOpacity(bottomDockFlowStyle ? 0.25 : 0.4),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Center(
                  child: Icon(Icons.call, color: Colors.white, size: 19),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }


  Widget _buildCardContent(CallRecord call, bool isMissed, {String styleId = ''}) {
    if (styleId == 'bottom-dock-flow-17') {
      return _buildBottomDockFlow17CardContent(call, isMissed);
    }
    if (_isDhsesStyle(styleId)) {
      return _buildDynamicStyle14CardContent(call, isMissed, video2Sizing: _isStyle14Copy(styleId));
    }
    final bool sunsetStyle = styleId == 'ios-depth';
    final bool bottomDockFlowStyle = styleId == 'bottom-dock-flow-17';
    final Color ios18Text = _activeIos18Palette['text']!;
    IconData typeIcon;
    Color typeColor;
    if (isMissed) {
      typeIcon = Icons.call_missed;
      typeColor = Colors.redAccent;
    } else if (call.type == CallType.outgoing) {
      typeIcon = Icons.call_made;
      typeColor = Colors.lightBlueAccent;
    } else {
      typeIcon = Icons.call_received;
      typeColor = const Color(0xFF10B981);
    }
    final durationText = call.duration > 0
        ? '${(call.duration ~/ 60)}m ${(call.duration % 60)}s'
        : '0s';
    final rawName = call.name.trim();
    final isUnsavedNumber = rawName.isEmpty ||
        rawName == call.number.trim() ||
        rawName.toLowerCase() == 'unknown';
    final displayTitle = isUnsavedNumber ? call.number : rawName;

    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: sunsetStyle
                  ? (isMissed
                      ? [const Color(0xFFE45A7A), const Color(0xFF8D3D9B)]
                      : _sunsetAvatarColors(call))
                  : (isMissed
                      ? [Colors.redAccent.withOpacity(0.35), Colors.purpleAccent.withOpacity(0.2)]
                      : [const Color(0xFF10B981).withOpacity(0.35), Colors.blueAccent.withOpacity(0.2)]),
            ),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(
              color: sunsetStyle ? Colors.white.withOpacity(0.48) : (isMissed ? Colors.redAccent.withOpacity(0.3) : Colors.white12),
            ),
          ),
          child: Center(
            child: Text(
              displayTitle.isNotEmpty ? displayTitle[0].toUpperCase() : '?',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      displayTitle,
                      style: TextStyle(
                        color: sunsetStyle ? ios18Text : (isMissed ? const Color(0xFFFF8B8B) : Colors.white),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        height: 1.12,
                      ),
                      maxLines: 3,
                      softWrap: true,
                      overflow: TextOverflow.visible,
                    ),
                  ),
                  if (call.repeatCount > 1) ...[
                    const SizedBox(width: 4),
                    Text('(${call.repeatCount})',
                      style: const TextStyle(color: Color(0xFFF87171), fontSize: 9.5, fontWeight: FontWeight.w900)),
                  ],
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  Icon(typeIcon, color: typeColor, size: 15),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      call.repeatCount > 1 ? '${call.repeatCount} Missed Calls (Grouped)' : durationText,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: call.repeatCount > 1 ? const Color(0xFFF87171) : (sunsetStyle ? ios18Text.withOpacity(0.68) : Colors.white38),
                        fontSize: 10,
                        fontWeight: call.repeatCount > 1 ? FontWeight.w600 : FontWeight.normal,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatTimeAgo(call.timestamp),
                    style: TextStyle(
                      color: sunsetStyle ? ios18Text.withOpacity(0.68) : Colors.white54,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              if (isMissed) ...[
                const SizedBox(height: 3),
                InkWell(
                  onTap: () => _setCallbackReminder(call, '15m', const Duration(minutes: 15)),
                  borderRadius: BorderRadius.circular(5),
                  child: const Text('◷ Remind 15m', style: TextStyle(color: Color(0xFFFBBF24), fontSize: 8, fontWeight: FontWeight.bold)),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(width: 5),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            InkWell(
              onTap: () => _openWhatsApp(call.number),
              borderRadius: BorderRadius.circular(8),
              child: Container(
                width: 25,
                height: 25,
                decoration: BoxDecoration(
                  color: const Color(0xFF25D366).withOpacity(0.18),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFF25D366).withOpacity(0.45), width: 0.8),
                ),
                child: const Center(child: Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 12)),
              ),
            ),
            const SizedBox(width: 7),
            InkWell(
              onTap: () {
                AppHaptics.heavyImpact();
                widget.onCallNumber(call.number);
              },
              borderRadius: BorderRadius.circular(12),
              child: Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF10B981), Color(0xFF059669)]),
                  borderRadius: BorderRadius.circular(11),
                  boxShadow: [
                    BoxShadow(color: const Color(0xFF10B981).withOpacity(0.35), blurRadius: 7, offset: const Offset(0, 2)),
                  ],
                ),
                child: const Center(child: Icon(Icons.call, color: Colors.white, size: 15)),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _cachedFilteredCalls;
    final currentStyle = STACK_STYLES[_currentStyleIndex];

    return Scaffold(
      extendBody: true,
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: BoxDecoration(
          image: currentStyle.id == 'ios-depth' && _activeIos18WallpaperAsset != null
              ? DecorationImage(image: AssetImage(_activeIos18WallpaperAsset!), fit: BoxFit.cover, alignment: Alignment.center)
              : null,
          gradient: currentStyle.id == 'ios-depth'
              ? LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_activeIos18Palette['bg1']!, _activeIos18Palette['bg2']!, _activeIos18Palette['bg3']!])
              : (currentStyle.id == 'bottom-dock-flow-17'
                  ? const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF0C0F13), Color(0xFF0A0D11), Color(0xFF07090C)])
                  : const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF1B1822), Color(0xFF141219), Color(0xFF0D0C11)])),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              // 1. Top Executive Control Strip
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                // Keep the top control strip fully transparent so the selected
                // wallpaper remains visible behind it (no Recent Calls header bar).
                decoration: const BoxDecoration(
                  color: Colors.transparent,
                ),
                child: Column(
                  children: [
                    // Row 1: larger Recents heading with a compact centered style/settings pill.
                    SizedBox(
                      height: 38,
                      child: Stack(
                        children: [
                          const Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Recents',
                              style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800, letterSpacing: 0.15),
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Transform.scale(
                              scale: 0.88,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.06),
                                  borderRadius: BorderRadius.circular(22),
                                  border: Border.all(color: Colors.white12),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    InkWell(
                                      onTap: _showStyleSelectorSheet,
                                      borderRadius: BorderRadius.circular(16),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Icon(Icons.auto_awesome, color: Color(0xFF10B981), size: 12),
                                          const SizedBox(width: 4),
                                          Text(
                                            '${currentStyle.number}. ${currentStyle.name.split(' ')[0]}',
                                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                                          ),
                                          const SizedBox(width: 3),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFF10B981).withOpacity(0.2),
                                              borderRadius: BorderRadius.circular(4),
                                            ),
                                            child: Text('${STACK_STYLES.length}', style: const TextStyle(color: Color(0xFF10B981), fontSize: 9, fontWeight: FontWeight.bold)),
                                          ),
                                          const SizedBox(width: 1),
                                          const Icon(Icons.arrow_drop_down, color: Colors.white54, size: 13),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 3),
                                    Container(width: 1, height: 16, color: Colors.white24),
                                    const SizedBox(width: 3),
                                    InkWell(
                                      onTap: () {
                                        AppHaptics.selectionClick();
                                        showDialog(
                                          context: context,
                                          builder: (ctx) => DialerSettingsDialog(
                                            onSimulateIncoming: widget.onSimulateIncoming,
                                            showIos18Appearance: currentStyle.id == 'ios-depth',
                                            ios18Appearance: _ios18Appearance,
                                            onIos18AppearanceChanged: _setIos18Appearance,
                                          ),
                                        ).then((_) => _loadStackMotionPreferences());
                                      },
                                      borderRadius: BorderRadius.circular(18),
                                      child: const Padding(
                                        padding: EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                                        child: Icon(Icons.settings_outlined, size: 15, color: Colors.white70),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 5),

                    // Compact, centered All / Missed / Smart filter pill.
                    // The separate style/settings control above is intentionally unchanged.
                    Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 310),
                        child: SizedBox(
                          width: double.infinity,
                          child: Container(
                            height: 34,
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              color: currentStyle.id == 'ios-depth' ? _activeIos18Palette['card2']!.withOpacity(0.38) : const Color(0xFF242428),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(color: Colors.white.withOpacity(0.055)),
                            ),
                            child: Row(
                              children: [
                                Expanded(child: _buildFilterPill('all', 'All')),
                                Expanded(child: _buildFilterPill('missed', 'Missed')),
                                const SizedBox(width: 4),
                                _buildSmartSortToggle(),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // 2. 3D Kinetic Card Stack Stage Viewport
              Expanded(
                child: filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.phone_missed, color: Colors.white.withOpacity(0.15), size: 54),
                            const SizedBox(height: 12),
                            const Text(
                              'No recent calls found',
                              style: TextStyle(color: Colors.white54, fontSize: 14),
                            ),
                          ],
                        ),
                      )
                    : LayoutBuilder(
                        builder: (context, constraints) {
                          final double containerHeight = constraints.maxHeight;
                          _viewportHeight = containerHeight;
                          final double topStackBoundary = headerOffset;
                          // Bottom-edge dock entrance for Styles 1, 14 and 15. Cards join the deck
                          // only as they pass this lower viewport boundary.
                          final bool isDhsesSelected = _currentStyleIndex == 13 || _currentStyleIndex == 14 || _currentStyleIndex == 15;
                          final bool isStyle14Selected = _currentStyleIndex == 13 || _currentStyleIndex == 15;
                          final bool isBottomDockFlow17Selected = _currentStyleIndex == 16;
                          final double bottomStackBoundary = isBottomDockFlow17Selected
                              ? math.max(topStackBoundary + _activeCardStep, containerHeight - _activeCardHeight - 72.0).toDouble()
                              : (isStyle14Selected
                              // Keep the deck in the lower viewport while leaving room for
                              // the large 90dp card and the visible layered rear-card lips.
                              ? math.max(
                                  topStackBoundary + _activeCardStep,
                                  containerHeight - 3 * _activeCardStep - 42.0,
                                ).toDouble()
                              : isDhsesSelected
                                  ? math.max(topStackBoundary + _activeCardStep, containerHeight - 3 * _activeCardStep - 42.0).toDouble()
                                  : containerHeight - (_currentStyleIndex == 0 ? 226.0 : 238.0)); // Style 1 deck sits just a little lower, as requested.
                          final double maxScroll = math.max(
                            0.0,
                            headerOffset + filtered.length * _activeCardStep - containerHeight +
                                ((_currentStyleIndex == 13 || _currentStyleIndex == 14 || _currentStyleIndex == 15) ? 0.0 : _activeCardHeight),
                          ).toDouble();
                          // Defensive clamp: if the call count, filter, or card style
                          // changes, don't retain an offset beyond the new scroll range.
                          _scrollPos = _scrollPos.clamp(0.0, maxScroll).toDouble();
                          _targetScroll = _targetScroll.clamp(0.0, maxScroll).toDouble();

                          return GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onVerticalDragStart: (details) {
                              _isDragging = true;
                              _velocity = 0;
                            },
                            onVerticalDragUpdate: (details) {
                              // Flutter native primary delta - immune to child layout rebuilds or localPosition coordinate shifts!
                              final deltaY = -details.delta.dy;
                              if (deltaY.isNaN || deltaY.isInfinite) return;
                              // The adjustable motion control is exclusive to Style 12.
                              // Preserve the previous drag feel for every other card style.
                              final double activeSpeed = _currentStyleIndex == 11 ? _scrollSpeedMultiplier : 1.5;
                              _velocity = (deltaY * 1.12 * activeSpeed).clamp(-60.0, 60.0).toDouble();
                              final double dragGain = activeSpeed * 0.92;
                              _targetScroll = (_targetScroll + deltaY * dragGain).clamp(0.0, maxScroll).toDouble();
                              // Let the ticker's frame-based interpolation follow the finger;
                              // avoid assigning _scrollPos directly, which causes visible micro-jumps.
                              setState(() {});
                            },
                            onVerticalDragEnd: (details) {
                              _isDragging = false;
                              final pv = details.primaryVelocity;
                              if (pv != null && pv.abs() > 40) {
                                final double activeSpeed = _currentStyleIndex == 11 ? _scrollSpeedMultiplier : 1.5;
                                final double flingDivisor = 52.0 / activeSpeed;
                                final double maxFling = 22.0 * activeSpeed;
                                _velocity = (-pv / flingDivisor).clamp(-maxFling, maxFling).toDouble();
                              } else {
                                _velocity = _velocity.clamp(-16.0, 16.0).toDouble();
                              }
                            },
                            child: SizedBox(
                              width: constraints.maxWidth,
                              height: containerHeight,
                              child: ClipRect(
                                child: Stack(
                                  fit: StackFit.expand,
                                  clipBehavior: Clip.none,
                                  children: [
                                    const SizedBox.expand(),
                                    for (int i = filtered.length - 1; i >= 0; i--)
                                      _buildCardWidget(
                                        index: i,
                                        call: filtered[i],
                                        currentStyle: currentStyle,
                                        topBoundary: topStackBoundary,
                                        bottomBoundary: bottomStackBoundary,
                                        step: _activeCardStep,
                                        containerWidth: constraints.maxWidth,
                                        totalCards: filtered.length,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCardWidget({
    required int index,
    required CallRecord call,
    required StackStyleConfig currentStyle,
    required double topBoundary,
    required double bottomBoundary,
    required double step,
    required double containerWidth,
    required int totalCards,
  }) {
    final double naturalY = headerOffset + index * step - _scrollPos;
    // Bottom dock sits just above the gesture/navigation area. Two 12dp lips
    // remain visible while every card retains its original 90dp height.
    final bool iosDepthStyle = currentStyle.id == 'ios-depth';
    final bool dynamicShrinkStyle = _isDhsesStyle(currentStyle.id);
    // Style 17 is the independent copy of v27 Style 15 (bottom-dock-flow).
    // Keep this flag local to the card renderer so all Style 17-only sizing,
    // clipping and horizontal shrink logic is gated by the registered ID.
    final bool bottomDockFlow17Style = currentStyle.id == 'bottom-dock-flow-17';
    // Style 1's five-card overlap deck must fit entirely above the bottom pill.
    // Reserve an extra four lips (4 x 17.5dp) so the lowest rear card stops
    // just above the navigation pill instead of sliding behind it.
    final double dynamicDockTopY = _viewportHeight - _activeCardHeight -
        (iosDepthStyle ? 152.0 : 82.0);

    // Keep only a handful of lower-edge layers alive. This prevents dozens
    // of off-screen calls from collapsing onto the same coordinates.
    final bool bottomDockStyle = dynamicShrinkStyle || currentStyle.id == 'ios-depth' || bottomDockFlow17Style;
    if (bottomDockStyle) {
      // Style 1 keeps the foreground card plus four visible rear layers.
      // Styles 14 and 15 retain the same five-step compact dock allowance.
      final double lowerRetention = dynamicShrinkStyle ? 5.2 : 4.5;
      if (naturalY < topBoundary - step * 3.2 || naturalY > bottomBoundary + step * lowerRetention) {
        return const SizedBox.shrink();
      }
    } else if (naturalY < topBoundary - step * 3.2 || naturalY > bottomBoundary + step * 3.2) {
      return const SizedBox.shrink();
    }

    final transforms = _computeCardTransforms(
      styleId: currentStyle.id,
      index: index,
      naturalY: naturalY,
      topBoundary: topBoundary,
      bottomBoundary: bottomBoundary,
      dockTopY: dynamicDockTopY,
      step: step,
      totalCards: totalCards,
    );

    double yPos = transforms['yPos'];
    final double xPos = transforms['xPos'];
    double scale = transforms['scale'];
    final double rotateX = transforms['rotateX'];
    final double rotateY = transforms['rotateY'];
    final double rotateZ = transforms['rotateZ'];
    double opacity = transforms['opacity'];
    final Alignment origin = transforms['transformOrigin'];
    final bool isMissed = call.type == CallType.missed || call.type == CallType.rejected;
    final bool fluxEngineStyle = currentStyle.id == 'realme-flux-engine';
    final bool notificationFlowStyle = currentStyle.id == 'android-notification-flow';
    final bool notificationStackStyle = currentStyle.id == 'notification-stack-deck';

    // Universal visibility guard: cards in visible area MUST be 100% visible
    if (!yPos.isFinite) yPos = naturalY;
    if (!scale.isFinite || scale < 0.6) scale = 1.0;
    if (!opacity.isFinite || (!bottomDockFlow17Style && opacity < 0.20)) opacity = bottomDockFlow17Style ? 0.0 : 0.25;
    if (!dynamicShrinkStyle && !bottomDockFlow17Style && naturalY >= topBoundary && naturalY <= bottomBoundary) {
      yPos = naturalY;
      opacity = 1.0;
      scale = 1.0;
    }

    // DHSES (Style 14): derive each card's dock depth from its LIVE layout
    // position, which itself is driven by _scrollPos. This keeps the animation
    // synchronized with the user's finger and makes reverse scrolling expand
    // the same cards continuously. Cards above the bottom boundary remain full
    // width; cards entering the bottom-only dock progressively narrow evenly
    // from the left and right edges. No vertical scale is applied, so card
    // height and text size remain constant/readable.
    double bottomDockFlow17WidthScale = 1.0;
    if (bottomDockFlow17Style && naturalY > bottomBoundary) {
      final double bottomOverflow = naturalY - bottomBoundary;
      final double progress = (bottomOverflow / math.max(step, 1.0)).clamp(0.0, 3.6).toDouble();
      final double shrinkT = math.max(0.0, progress - 0.15);
      bottomDockFlow17WidthScale = (1.0 - shrinkT * 0.205).clamp(0.48, 1.0).toDouble();
    }
    final double dhsesDockDepth = dynamicShrinkStyle
        ? ((naturalY - bottomBoundary) / math.max(step, 1.0)).clamp(0.0, 4.0).toDouble()
        : 0.0;
    // Style 14's reference deck is deliberately stepped, not a uniform
    // shrink on every card: the two deepest cards form the visible tail.
    // The card immediately above the tail eases from 100% to 90%; the
    // bottom-most card eases from 90% to 78%. All cards above that pair stay
    // at the same full width. Smoothstep keeps the change continuous while
    // the finger moves and reverses without a size pop.
    final double style14DepthA = (dhsesDockDepth - 2.0).clamp(0.0, 1.0).toDouble();
    final double style14EaseA = style14DepthA * style14DepthA * (3.0 - 2.0 * style14DepthA);
    final double style14DepthB = (dhsesDockDepth - 3.0).clamp(0.0, 1.0).toDouble();
    final double style14EaseB = style14DepthB * style14DepthB * (3.0 - 2.0 * style14DepthB);
    final double style14WidthScale = 1.0 - (0.10 * style14EaseA) - (0.12 * style14EaseB);
    final double dynamicWidthScale = bottomDockFlow17Style
        ? bottomDockFlow17WidthScale
        : (dynamicShrinkStyle
            ? (_isStyle14Copy(currentStyle.id)
                ? style14WidthScale.clamp(0.78, 1.0).toDouble()
                : (1.0 - (dhsesDockDepth / 4.0) * 0.16)
                    .clamp(0.84, 1.0)
                    .toDouble())
            : 1.0);

    final double baseHorizontalInset = notificationStackStyle
        ? 20.0
        : (notificationFlowStyle || fluxEngineStyle || bottomDockFlow17Style) ? 12.0 : 14.0;
    final double widthInset = (dynamicShrinkStyle || bottomDockFlow17Style)
        ? math.max(0.0, (containerWidth - baseHorizontalInset * 2) * (1.0 - dynamicWidthScale) / 2.0)
        : 0.0;

    // Width is changed through Positioned.left/right rather than Transform.scale:
    // the card height, text size, icons and tap targets are not compressed.
    final matrix3D = Matrix4.identity()
      ..setEntry(3, 2, 0.0008)
      ..rotateX(rotateX * math.pi / 180.0)
      ..rotateY(rotateY * math.pi / 180.0)
      ..rotateZ(rotateZ * math.pi / 180.0)
      ..scale(scale, scale, 1.0);

    return Positioned(
      top: yPos,
      left: baseHorizontalInset + xPos + widthInset,
      right: baseHorizontalInset - xPos + widthInset,
      child: Transform(
        transform: matrix3D,
        alignment: origin,
        child: Opacity(
          opacity: opacity.clamp(0.0, 1.0),
          child: Dismissible(
            key: ValueKey('swipe_call_${call.id}_$index'),
            direction: DismissDirection.horizontal,
            confirmDismiss: (direction) async {
              if (direction == DismissDirection.startToEnd) {
                // Right Swipe: Instant Call
                RealmeOHaptics.solidThud();
                widget.onCallNumber(call.number);
                return false;
              } else if (direction == DismissDirection.endToStart) {
                // Left Swipe: Quick Message & Options
                RealmeOHaptics.microTick();
                _showLeftSwipeActionSheet(call);
                return false;
              }
              return false;
            },
            background: Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(iosDepthStyle ? 28 : ((dynamicShrinkStyle || bottomDockFlow17Style) ? (bottomDockFlow17Style ? 24 : (_isStyle14Copy(currentStyle.id) ? 26 : 14)) : (notificationStackStyle ? 21 : 16))),
                gradient: const LinearGradient(
                  colors: [Color(0xFF00C853), Color(0xFF00E676)],
                ),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.call_rounded, color: Colors.white, size: 22),
                  SizedBox(width: 8),
                  Text(
                    'Instant Call',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            secondaryBackground: Container(
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(iosDepthStyle ? 28 : ((dynamicShrinkStyle || bottomDockFlow17Style) ? (bottomDockFlow17Style ? 24 : (_isStyle14Copy(currentStyle.id) ? 26 : 14)) : (notificationStackStyle ? 21 : 16))),
                gradient: const LinearGradient(
                  colors: [Color(0xFF0284C7), Color(0xFFEF4444)],
                ),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Quick Message',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(width: 8),
                  Icon(Icons.sms_rounded, color: Colors.white, size: 22),
                ],
              ),
            ),
            child: GestureDetector(
            onTap: () {
              if (_isStackCollapsed) {
                _toggleStackCollapsed();
              } else {
                AppHaptics.lightImpact();
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (ctx) => CallDetailBottomSheet(
                    call: call,
                    allCalls: widget.calls,
                    onCallNumber: widget.onCallNumber,
                    onDeleteCall: _deleteCall,
                    onSaveMetadata: (id, note, category) async {
                      setState(() {
                        final index = widget.calls.indexWhere((c) => c.id == id);
                        if (index >= 0) {
                          final updated = widget.calls[index].copyWith(note: note, category: category);
                          widget.calls[index] = updated;
                          CallDataService.saveCompletedCall(updated);
                        }
                      });
                    },
                  ),
                );
              }
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(iosDepthStyle ? 28 : ((dynamicShrinkStyle || bottomDockFlow17Style) ? (bottomDockFlow17Style ? 24 : (_isStyle14Copy(currentStyle.id) ? 26 : 14)) : (notificationStackStyle ? 21 : 16))),
              child: Container(
                height: bottomDockFlow17Style
                    ? bottomDockFlow17CardHeight
                    : (notificationStackStyle
                    ? notificationCardHeight
                    : (notificationFlowStyle
                        ? notificationFlowCardHeight
                        : (fluxEngineStyle
                            ? fluxCardHeight
                            : (dynamicShrinkStyle
                                ? (_isStyle14Copy(currentStyle.id) ? dhsesCardHeight : dynamicStackCardHeight)
                                : cardHeight)))),
                padding: EdgeInsets.symmetric(
                  horizontal: bottomDockFlow17Style ? 12 : (dynamicShrinkStyle
                      ? (_isStyle14Copy(currentStyle.id) ? 14 : 8)
                      : ((notificationFlowStyle || fluxEngineStyle) ? 12 : 14)),
                  vertical: bottomDockFlow17Style ? 6 : (dynamicShrinkStyle
                      ? (_isStyle14Copy(currentStyle.id) ? 12 : 4)
                      : ((notificationFlowStyle || fluxEngineStyle) ? 7 : 12)),
                ),
                decoration: _getCardBoxDecoration(currentStyle.id, isMissed),
                child: _buildCardContent(call, isMissed, styleId: currentStyle.id),
              ),
            ),
          ),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterPill(String key, String label) {
    final isSelected = _selectedFilter == key;
    return GestureDetector(
      onTap: () {
        AppHaptics.selectionClick();
        setState(() {
          _selectedFilter = key;
          _targetScroll = 0.0;
          _scrollPos = 0.0;
          _updateFilteredCalls();
        });
      },
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF414145) : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white60,
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildSmartSortToggle() {
    return GestureDetector(
      onTap: () {
        AppHaptics.lightImpact();
        setState(() {
          _smartSortEnabled = !_smartSortEnabled;
          _targetScroll = 0.0;
          _scrollPos = 0.0;
          _updateFilteredCalls();
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3.5),
        decoration: BoxDecoration(
          color: _smartSortEnabled ? const Color(0xFF10B981).withOpacity(0.24) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _smartSortEnabled ? const Color(0xFF10B981).withOpacity(0.65) : Colors.white12,
            width: 0.9,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.auto_awesome,
              size: 11,
              color: _smartSortEnabled ? const Color(0xFF10B981) : Colors.white38,
            ),
            const SizedBox(width: 3),
            Text(
              'Smart',
              style: TextStyle(
                color: _smartSortEnabled ? const Color(0xFF10B981) : Colors.white54,
                fontSize: 10,
                fontWeight: _smartSortEnabled ? FontWeight.bold : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
