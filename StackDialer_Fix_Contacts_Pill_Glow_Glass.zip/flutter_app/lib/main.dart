import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'utils/clock_format.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';
import 'models/call_record.dart';
import 'models/contact.dart';
import 'screens/active_call_screen.dart';
import 'screens/stacked_recents_screen.dart';
import 'screens/t9_dialpad_screen.dart';
import 'screens/contacts_screen.dart';
import 'screens/insights_screen.dart';
import 'screens/follow_up_tasks_screen.dart';
import 'services/blocked_numbers_service.dart';
import 'services/speed_dial_service.dart';
import 'services/telecom_service.dart';
import 'services/call_data_service.dart';
import 'services/app_appearance_service.dart';
import 'services/app_haptics.dart';
import 'services/follow_up_task_service.dart';
import 'widgets/settings_dialog.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0D0C11),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Initialize persistent services
  await SpeedDialService.init();
  await BlockedNumbersService.init();
  await AppAppearanceService.instance.init();
  await AppHaptics.init();
  // Restore persisted button/pill colours before the first frame is rendered.
  await loadPersistedColorPreferences();

  runApp(const StackDialerApp());
}

class StackDialerApp extends StatelessWidget {
  const StackDialerApp({super.key});

  ThemeData _theme(Brightness brightness, Color accent) {
    final base = ThemeData(brightness: brightness, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: brightness == Brightness.dark ? (AppAppearanceService.instance.amoled ? Colors.black : const Color(0xFF141219)) : const Color(0xFFF4F5F8),
      colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: brightness),
      textTheme: GoogleFonts.plusJakartaSansTextTheme(base.textTheme),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppAppearanceService.instance,
      builder: (context, _) {
        final appearance = AppAppearanceService.instance;
        return MaterialApp(
          title: 'StackDialer', debugShowCheckedModeBanner: false,
          theme: _theme(Brightness.light, appearance.accent),
          darkTheme: _theme(Brightness.dark, appearance.accent),
          themeMode: appearance.mode,
          builder: (context, child) {
            final media = MediaQuery.of(context);
            return MediaQuery(data: media.copyWith(alwaysUse24HourFormat: false), child: child ?? const SizedBox.shrink());
          },
          home: const MainDialerHost(),
        );
      },
    );
  }
}

class MainDialerHost extends StatefulWidget {
  const MainDialerHost({super.key});

  @override
  State<MainDialerHost> createState() => _MainDialerHostState();
}

class _MainDialerHostState extends State<MainDialerHost> with WidgetsBindingObserver {
  static const MethodChannel _nativeChannel = MethodChannel('com.stackdialer.app/telecom');
  int _currentIndex = 1;
  // 0.0 = Recents, 1.0 = Contacts. This drives the pill highlight directly
  // from the finger position while the user drags across the two tabs.
  double _pillDragProgress = 0.0;
  bool _isPillDragging = false;
  bool _showDialpadOverlay = false;
  List<CallRecord> _callLogs = [];
  List<ContactModel> _contacts = [];
  bool _isLoading = true;
  bool _hasActiveCallScreen = false;
  bool _isDefaultDialer = false;
  String? _incomingBannerNumber;
  String? _incomingBannerName;
  String? _activeCallBannerNumber;
  String? _activeCallBannerName;
  bool _activeCallBannerIsIncoming = false;
  final List<CallRecord> _recentDialedCalls = [];

  bool _isCurrentCallIncoming = false;
  int _pendingCallSimSlot = 1;


  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initDeviceData();
    _checkDefaultDialer();
    _setupTelecomInCallListener();
    // Keep reminder taps on TelecomService's shared MethodChannel handler.
    // Registering another handler here would replace onCallStateChanged and
    // prevent both swipe-to-call and reminder calls from opening ActiveCallScreen.
    TelecomService.setupReminderNotificationListener(_consumePendingReminder);
    _checkPendingCall();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Whenever user returns from making a phone call or switching back,
      // reload live device call logs and update default dialer status!
      _checkDefaultDialer();
      _refreshCallLogs();
      _refreshContacts(); // Refresh after Android's native New Contact form closes.
      _checkPendingCall(); // Recover Telecom events that arrived while Flutter was paused.
      FollowUpTaskService.reschedulePendingReminders();
      _consumePendingReminder();
    }
  }

  Future<void> _checkPendingCall() async {
    try {
      final pending = await TelecomService.getPendingIncomingCall();
      if (pending == null || !mounted) return;
      final number = pending['number'] ?? '';
      final state = pending['state'] ?? '';
      if (number.isEmpty || !['RINGING', 'ACTIVE', 'DIALING', 'HOLDING'].contains(state)) return;

      final isIncoming = state == 'RINGING';
      if (isIncoming && _hasActiveCallScreen && _activeCallBannerNumber == number) return;
      final matched = _findContact(number);
      _isCurrentCallIncoming = isIncoming;
      if (isIncoming) {
        // Keep a compact in-app heads-up for a real ringing call. Opening the
        // full call page immediately was hiding this popup and made it appear
        // inconsistently depending on callback timing.
        setState(() {
          _incomingBannerNumber = number;
          _incomingBannerName = matched?.name ?? number;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
      } else {
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = number;
          _activeCallBannerName = matched?.name ?? number;
        });
        _openCallScreen(
          number,
          name: matched?.name,
          isIncoming: false,
          initiallyActive: state == 'ACTIVE',
          initiallyHolding: state == 'HOLDING',
        );
      }
    } catch (_) {}
  }

  Future<void> _checkDefaultDialer() async {
    try {
      final isDef = await TelecomService.isDefaultDialer();
      if (mounted) {
        setState(() => _isDefaultDialer = isDef);
      }
    } catch (_) {}
  }

  void _setupTelecomInCallListener() {
    TelecomService.setupCallListener((number, state) {
      if (!mounted) return;
      if (number.trim().isEmpty || number.trim().toLowerCase() == 'unknown') return;
      final matched = _findContact(number);
      if (state == 'RINGING') {
        // Remote ringback for our outgoing call is not an incoming call.
        if (_activeCallBannerNumber != null && !_isCurrentCallIncoming) return;
        // A ringing event is shown as a compact heads-up. The user can tap it
        // to open the full call UI; do not push a second route automatically.
        if (_hasActiveCallScreen && _activeCallBannerNumber == number && _isCurrentCallIncoming) return;
        _isCurrentCallIncoming = true;
        setState(() {
          _incomingBannerNumber = number;
          _incomingBannerName = matched?.name ?? number;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
      } else if (state == 'ACTIVE' || state == 'DIALING' || state == 'HOLDING') {
        final wasIncoming = _isCurrentCallIncoming;
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = number;
          _activeCallBannerName = matched?.name ?? number;
        });
        // If the task was removed from Recents, a notification/capsule tap can
        // recreate MainActivity. Re-open the active call route instead of leaving
        // the user on the dial pad. Existing call route is not duplicated.
        if (!_hasActiveCallScreen) {
          _openCallScreen(number, name: matched?.name, isIncoming: wasIncoming, initiallyActive: state == 'ACTIVE', initiallyHolding: state == 'HOLDING');
        }
      } else if (state == 'DISCONNECTED' || state == 'IDLE') {
        _isCurrentCallIncoming = false;
        setState(() {
          _incomingBannerNumber = null;
          _incomingBannerName = null;
          _activeCallBannerNumber = null;
          _activeCallBannerName = null;
        });
        // Call ended, refresh live device call log after slight buffer for Android CallLog provider to sync!
        Future.delayed(const Duration(milliseconds: 700), () {
          if (mounted) _refreshCallLogs();
        });
      }
    });
  }

  Future<void> _initDeviceData() async {
    setState(() => _isLoading = true);
    await TelecomService.requestPermissions();
    await FollowUpTaskService.reschedulePendingReminders();
    final logs = await TelecomService.fetchDeviceCallLogs();
    final savedCalls = await CallDataService.loadSavedCalls();
    final contacts = await TelecomService.fetchDeviceContacts();
    if (mounted) {
      setState(() {
        _recentDialedCalls
          ..clear()
          ..addAll(savedCalls);
        _callLogs = _mergeCalls(logs, _recentDialedCalls);
        _contacts = contacts;
        _isLoading = false;
      });
      await _consumePendingReminder();
    }
  }

  Future<void> _consumePendingReminder() async {
    try {
      final payload = await const MethodChannel('com.stackdialer.app/telecom').invokeMapMethod<String, dynamic>('consumePendingReminder');
      if (!mounted || payload == null) return;
      final number = payload['number']?.toString() ?? '';
      if (number.isEmpty) return;
      final contact = _findContact(number);
      setState(() { _currentIndex = 1; _pillDragProgress = 0.0; _isPillDragging = false; _showDialpadOverlay = false; });
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF211F29),
        title: const Text('Callback reminder', style: TextStyle(color: Colors.white)),
        content: Text('Time to call ${contact?.name ?? number}\n$number', style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          ElevatedButton.icon(onPressed: () { Navigator.pop(ctx); _onCallNumber(number); }, icon: const Icon(Icons.call), label: const Text('Call now')),
        ],
      ));
    } catch (_) {}
  }

  Future<void> _refreshContacts() async {
    try {
      final contacts = await TelecomService.fetchDeviceContacts();
      if (mounted) setState(() => _contacts = contacts);
    } catch (_) {}
  }

  Future<void> _refreshCallLogs() async {
    try {
      final logs = await TelecomService.fetchDeviceCallLogs();
      final savedCalls = await CallDataService.loadSavedCalls();
      if (mounted) {
        setState(() {
          _recentDialedCalls
            ..clear()
            ..addAll(savedCalls);
          _callLogs = _mergeCalls(logs, _recentDialedCalls);
        });
      }
    } catch (_) {}
  }

  List<CallRecord> _mergeCalls(List<CallRecord> deviceLogs, List<CallRecord> localCalls) {
    final Map<String, CallRecord> map = {};
    final Map<String, List<CallRecord>> deviceByNumber = {};
    final Set<String> matchedDeviceIds = {};
    String normalized(CallRecord call) => CallDataService.normalizeNumber(call.number);
    String bucketKey(CallRecord call) =>
        '${normalized(call)}_${call.timestamp.millisecondsSinceEpoch ~/ 30000}';
    String deviceKey(CallRecord call) => '${bucketKey(call)}_${call.deviceLogId ?? call.id}';

    // Android stores the call-log timestamp near call start, while the local
    // completed-call record is timestamped at hang-up. Index the provider rows
    // by normalized number, then compare against the local estimated start.
    for (final device in deviceLogs) {
      map[deviceKey(device)] = device;
      deviceByNumber.putIfAbsent(normalized(device), () => <CallRecord>[]).add(device);
    }

    for (final local in localCalls) {
      final estimatedStartMs = local.timestamp.millisecondsSinceEpoch -
          (local.durationSeconds * 1000);
      final candidates = deviceByNumber[normalized(local)] ?? const <CallRecord>[];
      CallRecord? bestMatch;
      var bestDifference = 90001;
      for (final candidate in candidates) {
        final providerId = candidate.deviceLogId ??
            (RegExp(r'^\d{1,20}$').hasMatch(candidate.id) ? candidate.id : null);
        if (providerId == null || matchedDeviceIds.contains(providerId) || candidate.type != local.type) {
          continue;
        }
        final difference = (candidate.timestamp.millisecondsSinceEpoch - estimatedStartMs).abs();
        if (difference <= 90000 && difference < bestDifference) {
          bestDifference = difference;
          bestMatch = candidate;
        }
      }

      if (bestMatch == null) {
        map['local_${local.id}'] = local;
        continue;
      }

      final providerId = bestMatch.deviceLogId ?? bestMatch.id;
      matchedDeviceIds.add(providerId);
      // Keep the local ID for notes/categories and carry the real Android row
      // ID separately so deleting/undoing a merged record targets both stores.
      map[deviceKey(bestMatch)] = local.copyWith(deviceLogId: providerId);
    }

    final merged = map.values.toList();
    merged.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    return merged;
  }

  void _saveCompletedCallRecord(CallRecord record) {
    CallDataService.saveCompletedCall(record);
    if ((record.note ?? '').trim().isNotEmpty) {
      CallDataService.saveCallMetadata(record.id, note: record.note, category: record.category);
    }
    if (!mounted) return;
    setState(() {
      // Replace the outgoing placeholder with the completed record, not a duplicate.
      _recentDialedCalls.removeWhere((item) => item.number == record.number && item.id.startsWith('call_'));
      _callLogs.removeWhere((item) => item.number == record.number && item.id.startsWith('call_'));
      _recentDialedCalls.insert(0, record);
      _callLogs = _mergeCalls(_callLogs, _recentDialedCalls);
    });
  }

  ContactModel? _findContact(String number) {
    final clean = number.replaceAll(RegExp(r'[^\d]'), '');
    if (clean.isEmpty) return null;
    return _contacts.cast<ContactModel?>().firstWhere(
          (c) => c != null && c.number.replaceAll(RegExp(r'[^\d]'), '').endsWith(clean),
          orElse: () => null,
        );
  }

  void _openCallScreen(String number, {String? name, bool isIncoming = false, bool initiallyActive = false, bool initiallyHolding = false}) {
    if (_hasActiveCallScreen) return;
    _hasActiveCallScreen = true;
    _isCurrentCallIncoming = isIncoming;
    final matched = _findContact(number);
    final displayName = name ?? matched?.name ?? number;

    setState(() {
      _activeCallBannerNumber = number;
      _activeCallBannerName = displayName;
      // The full-screen call page replaces the compact in-app incoming banner.
      // Keeping both visible caused a duplicate call popup over the call UI.
      _incomingBannerNumber = null;
      _incomingBannerName = null;
    });

    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 160),
        reverseTransitionDuration: const Duration(milliseconds: 120),
        // Full-size fade only; do not scale the call screen like a bottom sheet.
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final fade = CurvedAnimation(parent: animation, curve: Curves.easeOut);
          return FadeTransition(opacity: fade, child: child);
        },
        pageBuilder: (context, animation, secondaryAnimation) => ActiveCallScreen(
          phoneNumber: number,
          contactName: displayName,
          callerCategory: isIncoming ? 'Incoming Call' : 'Mobile Call',
          isIncoming: isIncoming,
          initiallyActive: initiallyActive,
          initiallyHolding: initiallyHolding,
          simSlot: isIncoming ? 1 : _pendingCallSimSlot,
          onCallEnded: (record) {
            _hasActiveCallScreen = false;
            _isCurrentCallIncoming = false;
            _pendingCallSimSlot = 1;
            TelecomService.cancelIncomingBanner();
            TelecomService.cancelOngoingNotification();
            setState(() {
              _activeCallBannerNumber = null;
              _activeCallBannerName = null;
              _incomingBannerNumber = null;
              _incomingBannerName = null;
              _saveCompletedCallRecord(record);
            });
            Future.delayed(const Duration(milliseconds: 700), () {
              if (mounted) _refreshCallLogs();
            });
          },
        ),
      ),
    ).then((_) {
      _hasActiveCallScreen = false;
    });
  }

  Future<int?> _resolveCallingSimSlot(int requestedSlot) async {
    final prefs = await SharedPreferences.getInstance();
    final preference = prefs.getString('stackdialer_preferred_sim') ?? 'SIM 1';
    if (preference == 'SIM 2') return 2;
    if (preference == 'SIM 1') return 1;
    if (preference != 'Always Ask') return requestedSlot;
    if (!mounted) return null;
    return showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF24212B),
        title: const Text('Choose calling SIM', style: TextStyle(color: Colors.white)),
        content: const Text('Select which SIM should place this call.', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, null), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(dialogContext, 1), child: const Text('SIM 1')),
          ElevatedButton(onPressed: () => Navigator.pop(dialogContext, 2), child: const Text('SIM 2')),
        ],
      ),
    );
  }

  void _onCallNumber(String number, {int simSlot = 1}) async {
    final clean = number.replaceAll(RegExp(r'[^\d+*#]'), '');
    if (clean.isEmpty) return;
    final selectedSimSlot = await _resolveCallingSimSlot(simSlot);
    if (!mounted || selectedSimSlot == null) return;
    AppHaptics.heavyImpact();
    _pendingCallSimSlot = selectedSimSlot;
    _isCurrentCallIncoming = false;

    // Do not fabricate a recent-call card, an active-call screen, or an ongoing
    // notification just because the dial button was tapped. Android Telecom is
    // the source of truth: _setupTelecomInCallListener opens the call UI only
    // after it reports a real DIALING/ACTIVE call.
    try {
      final launched = await TelecomService.makeRealCall(clean, simSlot: selectedSimSlot);
      if (launched) {
        // Telecom may deliver its first DIALING callback while Flutter is
        // resuming from a notification or a Recents gesture. Reconcile against
        // Android's live call state as a fallback so the call page is not lost
        // if that one event arrives before the Dart listener is ready.
        Future.delayed(const Duration(milliseconds: 350), () {
          if (mounted && !_hasActiveCallScreen) _checkPendingCall();
        });
        Future.delayed(const Duration(milliseconds: 1000), () {
          if (mounted && !_hasActiveCallScreen) _checkPendingCall();
        });
      }
      if (!launched && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('SIM $selectedSimSlot se call start nahi ho saki. SIM availability, Phone permission aur default dialer setting check karein.')),
        );
      }
    } on PlatformException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? 'SIM $selectedSimSlot se call start nahi ho saki.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('SIM $selectedSimSlot se call start nahi ho saki.')),
        );
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([bottomPillColorNotifier, floatingDialpadColorNotifier]),
      builder: (context, _) => Scaffold(
      backgroundColor: Colors.transparent,
      extendBody: true,
      body: Stack(
        children: [
          _isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Color(0xFF10B981),
                  ),
                )
              : Column(
                  children: [
                    // Default dialer alert banner if not set
                    if (!_isDefaultDialer)
                      SafeArea(
                        bottom: false,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          color: const Color(0xFF10B981).withOpacity(0.12),
                          child: Row(
                            children: [
                              const Icon(Icons.shield_outlined, color: Color(0xFF10B981), size: 16),
                              const SizedBox(width: 8),
                              const Expanded(
                                child: Text(
                                  'Set StackDialer as Default Phone App for full lock-screen UI',
                                  style: TextStyle(color: Colors.white70, fontSize: 11),
                                ),
                              ),
                              InkWell(
                                onTap: () async {
                                  await TelecomService.requestDefaultDialer();
                                  Future.delayed(const Duration(seconds: 1), _checkDefaultDialer);
                                },
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'Set Default',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    Expanded(
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          _buildRecentsContactsPages(
                            StackedRecentsScreen(
                              calls: _callLogs,
                              onRefresh: _refreshCallLogs,
                              onCallNumber: _onCallNumber,
                            ),
                            ContactsScreen(
                              contacts: _contacts,
                              calls: _callLogs,
                              onCallNumber: _onCallNumber,
                            ),
                          ),
                          _buildAnimatedTab(3, DialerSearchScreen(
                            calls: _callLogs,
                            contacts: _contacts,
                            onCallNumber: _onCallNumber,
                            isActive: _currentIndex == 3,
                          )),
                          _buildAnimatedTab(4, InsightsScreen(calls: _callLogs, onCallNumber: _onCallNumber, onBackupRestored: _refreshCallLogs)),
                          _buildAnimatedTab(5, FollowUpTasksScreen(onCallNumber: _onCallNumber)),
                          // The keypad is a floating panel over the current page,
                          // not a replacement tab. Keep it mounted so entered digits persist.
                          Positioned.fill(
                            child: Stack(
                                children: [
                                  // A light scrim keeps the Recents page visible, like the
                                  // reference video. The keypad is a compact floating card,
                                  // not a full-height replacement screen.
                                  IgnorePointer(
                                    ignoring: !_showDialpadOverlay,
                                    child: AnimatedOpacity(
                                      opacity: _showDialpadOverlay ? 1 : 0,
                                      duration: const Duration(milliseconds: 220),
                                      child: GestureDetector(
                                      behavior: HitTestBehavior.opaque,
                                      onTap: () => setState(() => _showDialpadOverlay = false),
                                      child: BackdropFilter(
                                        // HyperOS-style soft-focus scrim keeps the page
                                        // recognizable while visually separating the keypad.
                                        filter: ImageFilter.blur(
                                          sigmaX: _showDialpadOverlay ? 5.0 : 0.0,
                                          sigmaY: _showDialpadOverlay ? 5.0 : 0.0,
                                        ),
                                        child: AnimatedContainer(
                                          duration: const Duration(milliseconds: 320),
                                          curve: Curves.easeOutCubic,
                                          color: Colors.black.withOpacity(
                                            _showDialpadOverlay ? 0.28 : 0.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  ),
                                  // One continuous surface: the green floating button expands
                                  // into the dialpad card and collapses back into the same button.
                                  AnimatedPositioned(
                                    duration: const Duration(milliseconds: 440),
                                    curve: Curves.easeInOutCubic,
                                    left: _showDialpadOverlay
                                        ? 16
                                        : MediaQuery.of(context).size.width - 60,
                                    right: 12,
                                    bottom: _showDialpadOverlay
                                        ? MediaQuery.of(context).padding.bottom + 60
                                        : MediaQuery.of(context).padding.bottom + 12,
                                    height: _showDialpadOverlay
                                        ? (MediaQuery.of(context).size.height * 0.60).clamp(455.0, 490.0).toDouble()
                                        : 46,
                                    child: TweenAnimationBuilder<double>(
                                      tween: Tween<double>(
                                        begin: _showDialpadOverlay ? 0.82 : 1.0,
                                        end: 1.0,
                                      ),
                                      duration: const Duration(milliseconds: 440),
                                      curve: Curves.easeInOutCubic,
                                      builder: (context, scale, child) => Transform.scale(
                                        scale: scale,
                                        alignment: Alignment.bottomRight,
                                        child: child,
                                      ),
                                      child: AnimatedContainer(
                                        duration: const Duration(milliseconds: 440),
                                        curve: Curves.easeInOutCubic,
                                        decoration: BoxDecoration(
                                          color: _showDialpadOverlay ? const Color(0x33252932) : floatingDialpadColorNotifier.value,
                                          borderRadius: BorderRadius.circular(_showDialpadOverlay ? 26 : 10),
                                          border: Border.all(
                                            color: Colors.white.withOpacity(_showDialpadOverlay ? 0.10 : 0.0),
                                            width: 1,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: (_showDialpadOverlay ? Colors.black : floatingDialpadColorNotifier.value)
                                                  .withOpacity(_showDialpadOverlay ? 0.34 : 0.32),
                                              blurRadius: _showDialpadOverlay ? 28 : 18,
                                              spreadRadius: _showDialpadOverlay ? 1 : 1,
                                              offset: const Offset(0, 8),
                                            ),
                                          ],
                                        ),
                                        clipBehavior: Clip.antiAlias,
                                        child: _showDialpadOverlay
                                            ? Stack(
                                                children: [
                                                  Positioned.fill(
                                                    child: BackdropFilter(
                                                      filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
                                                      child: Container(color: Colors.black.withOpacity(0.16)),
                                                    ),
                                                  ),
                                                  Positioned.fill(
                                                    child: AnimatedSwitcher(
                                                      duration: const Duration(milliseconds: 240),
                                                      reverseDuration: const Duration(milliseconds: 180),
                                                      switchInCurve: Curves.easeInOutCubic,
                                                      switchOutCurve: Curves.easeInCubic,
                                                      transitionBuilder: (child, animation) => FadeTransition(
                                                        opacity: animation,
                                                        child: ScaleTransition(
                                                          scale: Tween<double>(begin: 0.94, end: 1.0).animate(
                                                            CurvedAnimation(parent: animation, curve: Curves.easeOutBack),
                                                          ),
                                                          child: child,
                                                        ),
                                                      ),
                                                      child: T9DialpadScreen(
                                                        key: const ValueKey('hyperos_morph_dialpad'),
                                                        contacts: _contacts,
                                                        onCallNumber: _onCallNumber,
                                                        overlay: true,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              )
                                            : ClipRRect(
                                                borderRadius: BorderRadius.circular(10),
                                                child: Stack(
                                                  fit: StackFit.expand,
                                                  children: [
                                                    BackdropFilter(
                                                      filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: floatingDialpadColorNotifier.value.withOpacity(0.66),
                                                          border: Border.all(color: Colors.white.withOpacity(0.38), width: 1),
                                                          borderRadius: BorderRadius.circular(10),
                                                        ),
                                                      ),
                                                    ),
                                                    Material(
                                                      color: Colors.transparent,
                                                      child: InkWell(
                                                        onTap: () {
                                                          AppHaptics.selectionClick();
                                                          setState(() => _showDialpadOverlay = true);
                                                        },
                                                        borderRadius: BorderRadius.circular(10),
                                                        child: const Center(
                                                          child: Icon(Icons.dialpad_rounded, color: Colors.black, size: 25),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

          // 1. Floating Incoming Call Heads-Up Banner at top of the app
          if (_incomingBannerNumber != null)
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 14,
              right: 14,
              child: Material(
                elevation: 24,
                borderRadius: BorderRadius.circular(20),
                color: const Color(0xFF1F1D2B),
                child: InkWell(
                  onTap: () => _openCallScreen(_incomingBannerNumber!, name: _incomingBannerName, isIncoming: true),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF10B981), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF10B981).withOpacity(0.35),
                          blurRadius: 20,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.call_received, color: Color(0xFF10B981), size: 24),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                _incomingBannerName ?? _incomingBannerNumber!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              Text(
                                'Incoming Call... • ${_incomingBannerNumber!}',
                                style: const TextStyle(
                                  color: Color(0xFF10B981),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Reject Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.rejectCall();
                            await TelecomService.cancelIncomingBanner();
                            setState(() {
                              _incomingBannerNumber = null;
                              _incomingBannerName = null;
                            });
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFFEF4444),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call_end, color: Colors.white, size: 18),
                          ),
                        ),
                        // Answer Button
                        IconButton(
                          onPressed: () async {
                            await TelecomService.answerCall();
                            await TelecomService.cancelIncomingBanner();
                            final num = _incomingBannerNumber!;
                            final name = _incomingBannerName;
                            setState(() {
                              _incomingBannerNumber = null;
                              _incomingBannerName = null;
                            });
                            _openCallScreen(num, name: name, isIncoming: true);
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFF10B981),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.call, color: Colors.white, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(12, 2, 12, 5),
        child: SizedBox(
          height: 52,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Two-tab pill: the selected surface tracks horizontal finger
              // movement continuously instead of waiting for a tab tap/release.
              ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                  child: SizedBox(
                    width: 176,
                    height: 46,
                    child: LayoutBuilder(
                    builder: (context, constraints) {
                      final innerWidth = constraints.maxWidth - 6;
                      final itemWidth = innerWidth / 2;
                      // Stack is already inset by the parent Container's 3dp padding.
                      // Do not add that inset again: it clipped the right edge
                      // of the selected Contacts highlight.
                      final left = _pillDragProgress.clamp(0.0, 1.0).toDouble() * itemWidth;
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onHorizontalDragStart: (_) {
                          setState(() {
                            _isPillDragging = true;
                            _pillDragProgress = _currentIndex == 2 ? 1.0 : 0.0;
                          });
                        },
                        onHorizontalDragUpdate: (details) {
                          setState(() {
                            _pillDragProgress = (_pillDragProgress + details.delta.dx / itemWidth).clamp(0.0, 1.0).toDouble();
                            // Switch the visible page as soon as the moving highlight
                            // crosses the midpoint, so content follows the finger.
                            final page = _pillDragProgress >= 0.5 ? 2 : 1;
                            if (_currentIndex != page) {
                              _currentIndex = page;
                              _showDialpadOverlay = false;
                            }
                          });
                        },
                        onHorizontalDragEnd: (details) {
                          // Release always settles to the nearest tab, not fling velocity.
                          final target = _pillDragProgress >= 0.5 ? 2 : 1;
                          AppHaptics.selectionClick();
                          setState(() {
                            _currentIndex = target;
                            _showDialpadOverlay = false;
                            _pillDragProgress = target == 2 ? 1.0 : 0.0;
                            _isPillDragging = false;
                          });
                        },
                        child: Container(
                          width: 176,
                          height: 46,
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            color: const Color(0x887D86B8),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(color: Colors.white.withOpacity(0.32), width: 1),
                            boxShadow: const [
                              BoxShadow(color: Color(0x44000000), blurRadius: 14, offset: Offset(0, 4)),
                            ],
                          ),
                          child: Stack(
                            children: [
                              AnimatedPositioned(
                                duration: _isPillDragging ? Duration.zero : const Duration(milliseconds: 240),
                                curve: Curves.easeOutCubic,
                                left: left,
                                top: 0,
                                bottom: 0,
                                width: itemWidth,
                                child: DecoratedBox(
                                  decoration: BoxDecoration(
                                    color: bottomPillColorNotifier.value,
                                    borderRadius: BorderRadius.circular(30),
                                    boxShadow: _isPillDragging ? const [
                                      BoxShadow(color: Color(0x33000000), blurRadius: 7, offset: Offset(0, 2)),
                                    ] : const [],
                                  ),
                                ),
                              ),
                              Row(
                                children: [
                                  _buildPillNavItem(1, Icons.call_rounded, 'Recents'),
                                  _buildPillNavItem(2, Icons.contacts_rounded, 'Contacts'),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  ),
                ),
              ),
              const SizedBox(width: 5),
              Material(
                color: const Color(0x33252932),
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () {
                    AppHaptics.selectionClick();
                    if (_currentIndex == 2) {
                      _openAndroidNewContact();
                    } else {
                      setState(() => _showDialpadOverlay = !_showDialpadOverlay);
                    }
                  },
                  child: SizedBox(
                    width: 46,
                    height: 46,
                    child: Icon(
                      _currentIndex == 2 ? Icons.add_rounded : Icons.dialpad_rounded,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ));
  }

  Future<void> _openAndroidNewContact() async {
    try {
      await _nativeChannel.invokeMethod<bool>('openNewContact');
    } on PlatformException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open Android Contacts: ${e.message ?? 'Unknown error'}')),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open Android Contacts')),
      );
    }
  }

  Widget _buildRecentsContactsPages(Widget recents, Widget contacts) {
    // During a pill drag the two full screens are positioned from the same
    // normalized progress as the highlight, so the viewport follows the finger
    // continuously. On release/tap AnimatedPositioned eases to the nearest page.
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final progress = _pillDragProgress.clamp(0.0, 1.0).toDouble();
        final duration = _isPillDragging ? Duration.zero : const Duration(milliseconds: 280);
        if (_currentIndex != 1 && _currentIndex != 2) {
          return Stack(children: [
            _buildAnimatedTab(1, recents),
            _buildAnimatedTab(2, contacts),
          ]);
        }
        return Stack(clipBehavior: Clip.hardEdge, children: [
          AnimatedPositioned(
            duration: duration,
            curve: Curves.easeOutCubic,
            left: -progress * width,
            top: 0,
            bottom: 0,
            width: width,
            child: IgnorePointer(
              ignoring: _currentIndex != 1,
              child: TickerMode(enabled: _currentIndex == 1, child: recents),
            ),
          ),
          AnimatedPositioned(
            duration: duration,
            curve: Curves.easeOutCubic,
            left: (1.0 - progress) * width,
            top: 0,
            bottom: 0,
            width: width,
            child: IgnorePointer(
              ignoring: _currentIndex != 2,
              child: TickerMode(enabled: _currentIndex == 2, child: contacts),
            ),
          ),
        ]);
      },
    );
  }

  Widget _buildAnimatedTab(int index, Widget child) {
    final active = _currentIndex == index;
    if (index == 0) return const Positioned.fill(child: SizedBox.shrink());
    return Positioned.fill(
      child: Offstage(
        offstage: !active,
        child: TickerMode(enabled: active, child: child),
      ),
    );
  }

  Widget _buildPillNavItem(int index, IconData icon, String label) {
    final selected = _isPillDragging
        ? (_pillDragProgress >= 0.5 ? index == 2 : index == 1)
        : (_currentIndex == index && !_showDialpadOverlay);
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          AppHaptics.selectionClick();
          setState(() {
            _currentIndex = index;
            _showDialpadOverlay = false;
            _pillDragProgress = index == 2 ? 1.0 : 0.0;
            _isPillDragging = false;
          });
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(30),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 20, color: Colors.white),
              const SizedBox(height: 1),
              Text(label, style: TextStyle(
                color: Colors.white,
                fontSize: 10.5,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                letterSpacing: 0.1,
              )),
            ],
          ),
        ),
      ),
    );
  }
}


class DialerSearchScreen extends StatefulWidget {
  final List<CallRecord> calls;
  final List<ContactModel> contacts;
  final void Function(String number, {int simSlot}) onCallNumber;
  final bool isActive;

  const DialerSearchScreen({
    super.key,
    required this.calls,
    required this.contacts,
    required this.onCallNumber,
    this.isActive = false,
  });

  @override
  State<DialerSearchScreen> createState() => _DialerSearchScreenState();
}

class _DialerSearchScreenState extends State<DialerSearchScreen> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  @override
  void didUpdateWidget(covariant DialerSearchScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && widget.isActive) {
          _searchFocusNode.requestFocus();
        }
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  bool _matches(String name, String number) {
    final query = _controller.text.trim().toLowerCase();
    return query.isEmpty || name.toLowerCase().contains(query) || number.toLowerCase().contains(query);
  }

  @override
  Widget build(BuildContext context) {
    final contacts = widget.contacts.where((c) => _matches(c.name, c.number)).take(30).toList();
    final calls = widget.calls.where((c) => _matches(c.name, c.number)).take(30).toList();
    return Scaffold(
      backgroundColor: const Color(0xFF141219),
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 18, 20, 12),
              child: Text('Search', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w700)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                height: 52,
                decoration: BoxDecoration(
                  color: const Color(0xFF242428),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: Colors.white12),
                ),
                child: TextField(
                  controller: _controller,
                  focusNode: _searchFocusNode,
                  autofocus: false,
                  onChanged: (_) => setState(() {}),
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  decoration: InputDecoration(
                    hintText: 'Search contacts and calls',
                    hintStyle: const TextStyle(color: Colors.white54),
                    prefixIcon: const Icon(Icons.search_rounded, color: Colors.white70),
                    suffixIcon: _controller.text.isEmpty ? null : IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white70),
                      onPressed: () { _controller.clear(); setState(() {}); },
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 15),
                  ),
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 16, 14, 20),
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(6, 2, 6, 8),
                    child: Text('CONTACTS', style: TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  ),
                  if (contacts.isEmpty)
                    const Padding(padding: EdgeInsets.all(10), child: Text('No matching contacts', style: TextStyle(color: Colors.white38, fontSize: 13)))
                  else
                    ...contacts.map((contact) => _searchResultTile(
                      icon: Icons.person_outline_rounded,
                      title: contact.name,
                      subtitle: contact.number,
                      onTap: () => widget.onCallNumber(contact.number),
                    )),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(6, 18, 6, 8),
                    child: Text('RECENT CALLS', style: TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  ),
                  if (calls.isEmpty)
                    const Padding(padding: EdgeInsets.all(10), child: Text('No matching recent calls', style: TextStyle(color: Colors.white38, fontSize: 13)))
                  else
                    ...calls.map((call) => _searchResultTile(
                      icon: call.type == CallType.missed || call.type == CallType.rejected ? Icons.call_missed_rounded : Icons.call_rounded,
                      title: call.name.isEmpty ? call.number : call.name,
                      subtitle: '${call.number}  ·  ${call.dateLabel} ${call.timeFormatted}',
                      onTap: () => widget.onCallNumber(call.number, simSlot: call.simSlot),
                    )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _searchResultTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      decoration: BoxDecoration(color: const Color(0xFF202024), borderRadius: BorderRadius.circular(17), border: Border.all(color: Colors.white.withOpacity(0.055))),
      child: ListTile(
        onTap: onTap,
        leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF10B981).withOpacity(0.15), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: const Color(0xFF10B981), size: 21)),
        title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        trailing: const Icon(Icons.call_rounded, color: Color(0xFF10B981), size: 20),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      ),
    );
  }
}
